package com.iekei.client;

import com.iekei.IekeiClient;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_304.class_11900;
import org.lwjgl.glfw.GLFW;

public class IekeiClientClient implements ClientModInitializer {
	private static final class_304 OPEN_GUI = new class_304(
			"key.iekeiclient.open_gui",
			GLFW.GLFW_KEY_RIGHT_SHIFT,
			class_11900.method_74698(class_2960.method_60655(IekeiClient.MOD_ID, "main"))
	);

	@Override
	public void onInitializeClient() {
		KeyBindingHelper.registerKeyBinding(OPEN_GUI);
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (OPEN_GUI.method_1436()) {
				if (client.field_1755 instanceof IekeiClientScreen) {
					client.method_1507(null);
				} else {
					client.method_1507(new IekeiClientScreen());
				}
			}
		});
	}
}
