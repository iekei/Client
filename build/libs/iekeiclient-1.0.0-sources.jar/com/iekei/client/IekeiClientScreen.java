package com.iekei.client;

import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class IekeiClientScreen extends class_437 {
	private static final int PANEL_WIDTH = 650;
	private static final int PANEL_HEIGHT = 450;
	private static final int SIDEBAR_WIDTH = 70;
	private static final String[] PAGES = {"Home", "Modules", "Mirror", "Music", "Edit", "Settings"};
	private static final String[] ICONS = {"H", "M", "◇", "♫", "E", "⚙"};
	private static final int BACKGROUND = 0xFFF3F4F6;
	private static final int WHITE = 0xFFFFFFFF;
	private static final int TEXT = 0xFF333333;
	private static final int MUTED = 0xFF777777;
	private static final int BLUE = 0xFF3BB6FF;
	private int activePage;
	private int panelLeft;
	private int panelTop;
	private int panelWidth;
	private int panelHeight;

	public IekeiClientScreen() {
		super(class_2561.method_43470("IekeiClient"));
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
		graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0x88000000);
		panelWidth = Math.min(PANEL_WIDTH, this.field_22789 - 24);
		panelHeight = Math.min(PANEL_HEIGHT, this.field_22790 - 24);
		panelLeft = (this.field_22789 - panelWidth) / 2;
		panelTop = (this.field_22790 - panelHeight) / 2;

		graphics.method_25294(panelLeft, panelTop, panelLeft + panelWidth, panelTop + panelHeight, BACKGROUND);
		graphics.method_25294(panelLeft, panelTop, panelLeft + SIDEBAR_WIDTH, panelTop + panelHeight, WHITE);
		renderSidebar(graphics, mouseX, mouseY);

		if (activePage == 0) {
			renderHome(graphics);
		} else {
			renderPlaceholder(graphics);
		}
		super.method_25394(graphics, mouseX, mouseY, delta);
	}

	private void renderSidebar(class_332 graphics, int mouseX, int mouseY) {
		drawCentered(graphics, "≡", panelLeft + SIDEBAR_WIDTH / 2, panelTop + 29, MUTED);
		for (int i = 0; i < PAGES.length; i++) {
			int top = panelTop + 70 + i * 58;
			boolean selected = i == activePage;
			boolean hovered = contains(mouseX, mouseY, panelLeft + 13, top, 44, 44);
			if (selected || hovered) {
				graphics.method_25294(panelLeft + 13, top, panelLeft + 57, top + 44, selected ? BLUE : 0xFFF0F0F0);
			}
			drawCentered(graphics, ICONS[i], panelLeft + SIDEBAR_WIDTH / 2, top + 14, selected ? WHITE : MUTED);
			if (hovered) {
				drawText(graphics, PAGES[i], panelLeft + SIDEBAR_WIDTH + 8, top + 17, TEXT);
			}
		}
	}

	private void renderHome(class_332 graphics) {
		int contentLeft = panelLeft + SIDEBAR_WIDTH + 30;
		int contentRight = panelLeft + panelWidth - 30;
		int contentWidth = contentRight - contentLeft;
		drawText(graphics, "Home", contentLeft, panelTop + 26, TEXT);

		int y = panelTop + 66;
		drawCard(graphics, contentLeft, y, contentWidth, 100);
		drawText(graphics, "Welcome to Iekei Client", contentLeft + 20, y + 20, TEXT);
		graphics.method_25294(contentLeft + 20, y + 50, contentLeft + 68, y + 98, 0xFFD8EFFF);
		drawCentered(graphics, "I", contentLeft + 44, y + 66, BLUE);
		drawText(graphics, playerName(), contentLeft + 82, y + 67, 0xFF555555);

		y += 115;
		drawCard(graphics, contentLeft, y, contentWidth, 114);
		renderUnavailableModule(graphics, contentLeft, y + 12, contentWidth, "KillAura");
		renderUnavailableModule(graphics, contentLeft, y + 48, contentWidth, "AutoArmor");
		renderUnavailableModule(graphics, contentLeft, y + 84, contentWidth, "Sprint");

		y += 129;
		drawCard(graphics, contentLeft, y, contentWidth, 76);
		graphics.method_25294(contentLeft, y, contentRight, y + 76, 0xFF72D7EA);
		drawText(graphics, "Join Our Discord", contentLeft + 20, y + 20, WHITE);
		drawText(graphics, "Community link is not configured.", contentLeft + 20, y + 43, WHITE);
	}

	private void renderUnavailableModule(class_332 graphics, int left, int top, int width, String name) {
		drawText(graphics, name, left + 20, top + 9, 0xFF444444);
		int badgeWidth = 112;
		graphics.method_25294(left + width - badgeWidth - 16, top + 3, left + width - 16, top + 28, 0xFFF0F0F0);
		drawCentered(graphics, "Unavailable", left + width - badgeWidth / 2 - 16, top + 10, MUTED);
		if (!name.equals("Sprint")) {
			graphics.method_25294(left + 18, top + 35, left + width - 18, top + 36, 0xFFF0F0F0);
		}
	}

	private void renderPlaceholder(class_332 graphics) {
		int contentLeft = panelLeft + SIDEBAR_WIDTH + 30;
		drawText(graphics, PAGES[activePage], contentLeft, panelTop + 26, TEXT);
		drawCard(graphics, contentLeft, panelTop + 66, panelLeft + panelWidth - 30 - contentLeft, 84);
		drawText(graphics, "This page is not available yet.", contentLeft + 20, panelTop + 96, MUTED);
	}

	private void drawCard(class_332 graphics, int left, int top, int width, int height) {
		graphics.method_25294(left, top, left + width, top + height, WHITE);
	}

	private void drawText(class_332 graphics, String text, int x, int y, int color) {
		graphics.method_51433(this.field_22793, text, x, y, color, false);
	}

	private void drawCentered(class_332 graphics, String text, int centerX, int y, int color) {
		drawText(graphics, text, centerX - this.field_22793.method_1727(text) / 2, y, color);
	}

	private String playerName() {
		class_310 minecraft = class_310.method_1551();
		return minecraft.method_1548() == null ? "PlayerName" : minecraft.method_1548().method_1676();
	}

	private boolean contains(double mouseX, double mouseY, int left, int top, int width, int height) {
		return mouseX >= left && mouseX < left + width && mouseY >= top && mouseY < top + height;
	}

	@Override
	public boolean method_25402(class_11909 event, boolean doubleClick) {
		if (event.method_74245() == 0) {
			for (int i = 0; i < PAGES.length; i++) {
				int top = panelTop + 70 + i * 58;
				if (contains(event.comp_4798(), event.comp_4799(), panelLeft + 13, top, 44, 44)) {
					activePage = i;
					return true;
				}
			}
		}
		return super.method_25402(event, doubleClick);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
