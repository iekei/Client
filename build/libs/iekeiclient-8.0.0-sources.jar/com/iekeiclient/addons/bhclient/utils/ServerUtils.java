package com.iekeiclient.addons.bhclient.utils;

import com.iekeiclient.addons.bhclient.IekeiBaseHuntingAddon;
import com.iekeiclient.engine.IekeiClient;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_642;
import com.iekeiclient.engine.IekeiClient;

/** Small helpers shared by every module for describing "where am I right now". */
public final class ServerUtils {
    private ServerUtils() {
    }

    public static class_310 mc() {
        return IekeiClient.mc;
    }

    /** Singleplayer worlds report no server entry, so fall back to a readable label. */
    public static String serverAddress() {
        class_310 mc = mc();
        if (mc == null) return "unknown";

        class_642 info = mc.method_1558();
        if (info != null && info.field_3761 != null && !info.field_3761.isBlank()) return info.field_3761;

        if (mc.method_1542()) return "singleplayer";
        return "unknown";
    }

    public static String dimension() {
        class_310 mc = mc();
        if (mc == null || mc.field_1687 == null) return "unknown";

        class_1937 world = mc.field_1687;
        if (world.method_27983() == class_1937.field_25179) return "overworld";
        if (world.method_27983() == class_1937.field_25180) return "nether";
        if (world.method_27983() == class_1937.field_25181) return "end";
        return world.method_27983().method_29177().method_12832();
    }

    public static String playerName() {
        class_310 mc = mc();
        if (mc == null || mc.field_1724 == null) return "unknown";
        return mc.field_1724.method_7334().name();
    }

    public static String coordinates() {
        class_310 mc = mc();
        if (mc == null || mc.field_1724 == null) return "unknown";

        return "%d, %d, %d".formatted(
            (int) Math.floor(mc.field_1724.method_23317()),
            (int) Math.floor(mc.field_1724.method_23318()),
            (int) Math.floor(mc.field_1724.method_23321())
        );
    }

    public static String position() {
        class_310 mc = mc();
        if (mc == null || mc.field_1724 == null) return "unknown";

        return "%s [%s] %s".formatted(playerName(), serverAddress(), coordinates());
    }

    public static int spawnDistance(int x, int z) {
        class_310 mc = mc();
        if (mc == null || mc.field_1687 == null) return 0;

        // 1.21.11 replaced the spawn position getter with a spawn point record.
        double dx = x - mc.field_1687.method_74854().method_74897().method_10263();
        double dz = z - mc.field_1687.method_74854().method_74897().method_10260();
        return (int) Math.sqrt(dx * dx + dz * dz);
    }

    public static void log(String message) {
        IekeiBaseHuntingAddon.LOG.info(message);
    }
}
