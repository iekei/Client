package com.iekeiclient.addons.bhclient.modules;

import com.iekeiclient.addons.bhclient.IekeiBaseHuntingAddon;
import com.iekeiclient.addons.bhclient.utils.BaritoneHelper;
import com.iekeiclient.addons.bhclient.utils.ServerUtils;
import com.iekeiclient.addons.bhclient.utils.WebhookManager;
import com.iekeiclient.addons.bhclient.utils.WebhookSettings;
import com.iekeiclient.engine.events.game.GameLeftEvent;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.settings.StringListSetting;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2663;
import java.util.List;

/**
 * Disconnects automatically when something dangerous happens, and reports it to the webhook first.
 *
 * <p>The webhook is sent <i>before</i> the disconnect because the connection is gone afterwards, and
 * knowing where you were when you logged is the whole point on an anarchy server.
 */
public class AutoLog extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgTriggers = settings.createGroup("Triggers");
    private final SettingGroup sgWebhook = settings.createGroup("Webhook");

    // General

    private final Setting<Boolean> chatFeedback = sgGeneral.add(new BoolSetting.Builder()
        .name("chat-feedback")
        .description("Print the reason in chat before disconnecting.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> cancelBaritone = sgGeneral.add(new BoolSetting.Builder()
        .name("stop-baritone")
        .description("Cancel Baritone pathing before disconnecting so it does not keep moving.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> delayTicks = sgGeneral.add(new IntSetting.Builder()
        .name("delay-ticks")
        .description("Wait this many ticks after a trigger before disconnecting, giving the webhook time to send.")
        .defaultValue(20)
        .min(0)
        .sliderRange(0, 200)
        .build()
    );

    // Triggers

    private final Setting<Boolean> onHealth = sgTriggers.add(new BoolSetting.Builder()
        .name("low-health")
        .description("Disconnect when health drops below the threshold.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> healthThreshold = sgTriggers.add(new IntSetting.Builder()
        .name("health-threshold")
        .description("Health level that triggers a disconnect.")
        .defaultValue(8)
        .min(1)
        .max(20)
        .sliderRange(1, 20)
        .visible(onHealth::get)
        .build()
    );

    private final Setting<Boolean> onPlayerNear = sgTriggers.add(new BoolSetting.Builder()
        .name("player-nearby")
        .description("Disconnect when another player comes within the radius.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> playerRadius = sgTriggers.add(new IntSetting.Builder()
        .name("player-radius")
        .description("Distance at which another player triggers a disconnect.")
        .defaultValue(128)
        .min(8)
        .sliderRange(8, 2048)
        .visible(onPlayerNear::get)
        .build()
    );

    private final Setting<List<String>> playerNames = sgTriggers.add(new StringListSetting.Builder()
        .name("player-names")
        .description("Disconnect when any of these names appears in the tab list. Leave empty to ignore.")
        .build()
    );

    private final Setting<Boolean> onTotemPop = sgTriggers.add(new BoolSetting.Builder()
        .name("totem-pop")
        .description("Disconnect when you pop a totem.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> onElytraBreak = sgTriggers.add(new BoolSetting.Builder()
        .name("elytra-break")
        .description("Disconnect when your elytra runs out of durability mid flight.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> onOutOfFireworks = sgTriggers.add(new BoolSetting.Builder()
        .name("out-of-fireworks")
        .description("Disconnect when you run out of fireworks while flying.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> onlyWhileFlying = sgTriggers.add(new BoolSetting.Builder()
        .name("only-while-flying")
        .description("Only apply the fireworks and elytra triggers while actually gliding.")
        .defaultValue(true)
        .build()
    );

    // Webhook

    private final WebhookSettings webhook = new WebhookSettings(sgWebhook);

    private final Setting<Boolean> notifyOnLog = sgWebhook.add(new BoolSetting.Builder()
        .name("notify-on-disconnect")
        .description("Send a webhook describing why the client logged out.")
        .defaultValue(true)
        .visible(webhook.enabled::get)
        .build()
    );

    private final Setting<Boolean> notifyDanger = sgWebhook.add(new BoolSetting.Builder()
        .name("notify-on-danger")
        .description("Send a webhook as soon as a dangerous condition is noticed, even if the disconnect is delayed.")
        .defaultValue(true)
        .visible(webhook.enabled::get)
        .build()
    );

    private boolean triggered;
    private int countdown;
    private String triggerReason;

    public AutoLog() {
        super(IekeiBaseHuntingAddon.CATEGORY, "auto-log", "Automatically disconnects when you are in danger and reports it.");
    }

    @Override
    public void onActivate() {
        triggered = false;
        countdown = 0;
        triggerReason = null;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (triggered) {
            if (countdown-- <= 0) disconnect();
            return;
        }

        String reason = evaluateTriggers();
        if (reason != null) trigger(reason);
    }

    private String evaluateTriggers() {
        if (onHealth.get() && mc.field_1724.method_6032() <= healthThreshold.get()) {
            return "Health dropped to %s".formatted(mc.field_1724.method_6032());
        }

        if (onPlayerNear.get()) {
            class_1657 nearby = nearestPlayer(playerRadius.get());
            if (nearby != null) {
                return "%s is %d blocks away".formatted(
                    nearby.method_5477().getString(),
                    (int) mc.field_1724.method_5739(nearby));
            }
        }

        List<String> names = playerNames.get();
        if (!names.isEmpty()) {
            for (class_1657 player : mc.field_1687.method_18456()) {
                if (player == mc.field_1724) continue;

                String name = player.method_5477().getString();
                for (String watched : names) {
                    if (!watched.isBlank() && name.equalsIgnoreCase(watched.trim())) {
                        return "%s is online".formatted(name);
                    }
                }
            }
        }

        boolean flying = mc.field_1724.method_6128();

        if (onlyWhileFlying.get() && !flying) return null;

        if (onElytraBreak.get() && flying) {
            var chest = mc.field_1724.method_6118(net.minecraft.class_1304.field_6174);
            if (chest.method_7909() != net.minecraft.class_1802.field_8833 || chest.method_7936() - chest.method_7919() <= 1) {
                return "Elytra is about to break";
            }
        }

        if (onOutOfFireworks.get() && flying && countFireworks() == 0) {
            return "Out of fireworks";
        }

        return null;
    }

    private void trigger(String reason) {
        triggered = true;
        triggerReason = reason;
        countdown = delayTicks.get();

        if (chatFeedback.get()) warning("Auto log: %s.", reason);

        if (cancelBaritone.get()) BaritoneHelper.stop();

        if (notifyDanger.get() && webhook.isEnabled() && !WebhookSettings.globallyMuted()) {
            webhook.send(new WebhookManager.Embed()
                .title("Danger detected")
                .description(reason)
                .color(0xFF5555)
                .field("Position", ServerUtils.coordinates())
                .field("Server", ServerUtils.serverAddress())
                .field("Dimension", ServerUtils.dimension())
                .field("Health", String.valueOf(mc.field_1724.method_6032()))
                .field("Logging out in", delayTicks.get() / 20.0 + "s")
                .footer("Base Hunting Client"));
        }
    }

    private void disconnect() {
        triggered = false;

        if (notifyOnLog.get() && webhook.isEnabled() && !WebhookSettings.globallyMuted()) {
            webhook.send(new WebhookManager.Embed()
                .title("Auto logged out")
                .description(triggerReason == null ? "Unknown reason" : triggerReason)
                .color(0xFF5555)
                .field("Position", ServerUtils.coordinates())
                .field("Server", ServerUtils.serverAddress())
                .footer("Base Hunting Client"));
        }

        if (chatFeedback.get()) info("Disconnecting.");
        mc.field_1724.field_3944.method_48296().method_10747(class_2561.method_43470("Auto Log: " + (triggerReason == null ? "danger" : triggerReason)));
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        if (!onTotemPop.get() || triggered) return;
        if (!(event.packet instanceof class_2663 packet)) return;
        if (mc.field_1724 == null) return;

        // Status 35 is the totem-of-undying animation; the packet names the entity that popped.
        if (packet.method_11470() != 35) return;
        if (packet.method_11469(mc.field_1687) != mc.field_1724) return;

        trigger("Popped a totem");
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        triggered = false;
        triggerReason = null;
    }

    private class_1657 nearestPlayer(int radius) {
        double radiusSq = (double) radius * radius;

        for (class_1657 player : mc.field_1687.method_18456()) {
            if (player == mc.field_1724) continue;
            if (mc.field_1724.method_5858(player) <= radiusSq) return player;
        }

        return null;
    }

    private int countFireworks() {
        int total = 0;

        for (int slot = 0; slot < mc.field_1724.method_31548().method_5439(); slot++) {
            if (mc.field_1724.method_31548().method_5438(slot).method_7909() == net.minecraft.class_1802.field_8639) {
                total += mc.field_1724.method_31548().method_5438(slot).method_7947();
            }
        }

        return total;
    }

    public boolean isTriggered() {
        return triggered;
    }
}
