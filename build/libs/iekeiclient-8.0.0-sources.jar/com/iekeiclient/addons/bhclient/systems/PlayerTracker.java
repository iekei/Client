package com.iekeiclient.addons.bhclient.systems;

import com.iekeiclient.addons.bhclient.utils.ServerUtils;
import com.iekeiclient.engine.systems.System;
import com.iekeiclient.engine.systems.Systems;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

/**
 * Keeps a per-server log of players the client has seen, where they were first and last spotted and when.
 *
 * <p>Anarchy servers rotate alt accounts constantly, so entries are matched on UUID and the username is
 * only ever used as a display label.
 */
public class PlayerTracker extends System<PlayerTracker> {
    private static final int MAX_ENTRIES_PER_SERVER = 5000;

    private final List<Entry> entries = new ArrayList<>();

    public PlayerTracker() {
        super("base-hunting-players");
    }

    public static PlayerTracker get() {
        return Systems.get(PlayerTracker.class);
    }

    public List<Entry> getAll() {
        return entries;
    }

    public List<Entry> forCurrentServer() {
        String server = ServerUtils.serverAddress();
        List<Entry> result = new ArrayList<>();

        for (Entry entry : entries) {
            if (entry.server.equals(server)) result.add(entry);
        }

        result.sort(Comparator.comparingLong((Entry e) -> -e.lastSeen));
        return result;
    }

    public Entry get(UUID uuid) {
        String server = ServerUtils.serverAddress();

        for (Entry entry : entries) {
            if (entry.uuid.equals(uuid) && entry.server.equals(server)) return entry;
        }

        return null;
    }

    public Entry track(UUID uuid, String name, int x, int y, int z) {
        Entry entry = get(uuid);
        if (entry == null) {
            entry = new Entry(uuid, name, ServerUtils.serverAddress());
            entry.dimension = ServerUtils.dimension();
            entry.firstX = x;
            entry.firstY = y;
            entry.firstZ = z;
            entries.add(entry);
            trim(entry.server);
        }

        entry.name = name;
        entry.lastX = x;
        entry.lastY = y;
        entry.lastZ = z;
        entry.lastSeen = java.lang.System.currentTimeMillis();
        entry.dimension = ServerUtils.dimension();
        entry.sightings++;

        return entry;
    }

    /** Marks the player as having logged out; the next sighting starts a new session. */
    public void markLoggedOut(UUID uuid, int x, int y, int z) {
        Entry entry = get(uuid);
        if (entry == null) return;

        entry.logoutX = x;
        entry.logoutY = y;
        entry.logoutZ = z;
        entry.logoutTime = java.lang.System.currentTimeMillis();
        entry.logoutDimension = ServerUtils.dimension();
        entry.sessionsSeen++;

        save();
    }

    public void markLoggedIn(UUID uuid) {
        Entry entry = get(uuid);
        if (entry == null) return;

        entry.lastLogin = java.lang.System.currentTimeMillis();
        save();
    }

    public Entry findByLogoutLocation(int x, int y, int z, int radius) {
        String server = ServerUtils.serverAddress();
        long now = java.lang.System.currentTimeMillis();

        Entry best = null;
        double bestDistance = Double.MAX_VALUE;

        for (Entry entry : entries) {
            if (!entry.server.equals(server)) continue;
            if (entry.logoutTime <= 0) continue;
            if (now - entry.logoutTime > 1000L * 60 * 60 * 12) continue;

            double dx = entry.logoutX - x;
            double dy = entry.logoutY - y;
            double dz = entry.logoutZ - z;
            double distance = dx * dx + dy * dy + dz * dz;

            if (distance <= (double) radius * radius && distance < bestDistance) {
                best = entry;
                bestDistance = distance;
            }
        }

        return best;
    }

    private void trim(String server) {
        List<Entry> serverEntries = new ArrayList<>();
        for (Entry entry : entries) {
            if (entry.server.equals(server)) serverEntries.add(entry);
        }

        if (serverEntries.size() <= MAX_ENTRIES_PER_SERVER) return;

        serverEntries.sort(Comparator.comparingLong(e -> e.lastSeen));
        int toRemove = serverEntries.size() - MAX_ENTRIES_PER_SERVER;
        entries.removeAll(serverEntries.subList(0, toRemove));
    }

    public int clearCurrentServer() {
        String server = ServerUtils.serverAddress();
        int before = entries.size();
        entries.removeIf(entry -> entry.server.equals(server));

        int removed = before - entries.size();
        if (removed > 0) save();
        return removed;
    }

    @Override
    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        class_2499 list = new class_2499();

        for (Entry entry : entries) list.add(entry.toTag());
        tag.method_10566("entries", list);

        return tag;
    }

    @Override
    public PlayerTracker fromTag(class_2487 tag) {
        entries.clear();

        class_2499 list = tag.method_68569("entries");
        for (class_2520 element : list) {
            if (element instanceof class_2487 compound) {
                Entry entry = Entry.fromTag(compound);
                if (entry != null) entries.add(entry);
            }
        }

        return this;
    }

    public static class Entry {
        public UUID uuid;
        public String name;
        public String server;
        public String dimension = "unknown";

        public int firstX, firstY, firstZ;
        public int lastX, lastY, lastZ;

        public int logoutX, logoutY, logoutZ;
        public String logoutDimension = "unknown";
        public long logoutTime;
        public long lastLogin;

        public long firstSeen;
        public long lastSeen;
        public int sightings;


        public int sessionsSeen;
        public boolean notifiedNearby;

        public Entry(UUID uuid, String name, String server) {
            this.uuid = uuid;
            this.name = name;
            this.server = server;
            this.firstSeen = java.lang.System.currentTimeMillis();
            this.lastSeen = this.firstSeen;
        }

        public boolean hasLogoutSpot() {
            return logoutTime > 0;
        }

        public int logoutDistanceTo(int x, int y, int z) {
            double dx = logoutX - x;
            double dy = logoutY - y;
            double dz = logoutZ - z;
            return (int) Math.sqrt(dx * dx + dy * dy + dz * dz);
        }

        public String logoutCoords() {
            return "%d, %d, %d".formatted(logoutX, logoutY, logoutZ);
        }

        public String firstCoords() {
            return "%d, %d, %d".formatted(firstX, firstY, firstZ);
        }

        public String lastCoords() {
            return "%d, %d, %d".formatted(lastX, lastY, lastZ);
        }

        public class_2487 toTag() {
            class_2487 tag = new class_2487();

            tag.method_10582("uuid", uuid.toString());
            tag.method_10582("name", name);
            tag.method_10582("server", server);
            tag.method_10582("dimension", dimension);

            tag.method_10539("first", new int[] {firstX, firstY, firstZ});
            tag.method_10539("last", new int[] {lastX, lastY, lastZ});
            tag.method_10539("logout", new int[] {logoutX, logoutY, logoutZ});

            tag.method_10582("logoutDimension", logoutDimension);
            tag.method_10544("logoutTime", logoutTime);
            tag.method_10544("lastLogin", lastLogin);

            tag.method_10544("firstSeen", firstSeen);
            tag.method_10544("lastSeen", lastSeen);
            tag.method_10569("sightings", sightings);
            tag.method_10569("sessionsSeen", sessionsSeen);

            return tag;
        }

        public static Entry fromTag(class_2487 tag) {
            String rawUuid = tag.method_68564("uuid", "");
            if (rawUuid.isBlank()) return null;

            UUID uuid;
            try {
                uuid = UUID.fromString(rawUuid);
            } catch (IllegalArgumentException e) {
                return null;
            }

            Entry entry = new Entry(uuid, tag.method_68564("name", "unknown"), tag.method_68564("server", "unknown"));

            entry.dimension = tag.method_68564("dimension", "unknown");
            entry.logoutDimension = tag.method_68564("logoutDimension", "unknown");

            int[] first = tag.method_10561("first").orElse(new int[0]);
            int[] last = tag.method_10561("last").orElse(new int[0]);
            int[] logout = tag.method_10561("logout").orElse(new int[0]);

            if (first.length == 3) {
                entry.firstX = first[0];
                entry.firstY = first[1];
                entry.firstZ = first[2];
            }

            if (last.length == 3) {
                entry.lastX = last[0];
                entry.lastY = last[1];
                entry.lastZ = last[2];
            }

            if (logout.length == 3) {
                entry.logoutX = logout[0];
                entry.logoutY = logout[1];
                entry.logoutZ = logout[2];
            }

            entry.logoutTime = tag.method_68080("logoutTime", 0);
            entry.lastLogin = tag.method_68080("lastLogin", 0);
            entry.firstSeen = tag.method_68080("firstSeen", entry.firstSeen);
            entry.lastSeen = tag.method_68080("lastSeen", entry.lastSeen);
            entry.sightings = tag.method_68083("sightings", 0);
            entry.sessionsSeen = tag.method_68083("sessionsSeen", 0);

            return entry;
        }
    }
}
