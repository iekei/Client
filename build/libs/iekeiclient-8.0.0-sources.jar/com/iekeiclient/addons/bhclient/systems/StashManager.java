package com.iekeiclient.addons.bhclient.systems;

import com.iekeiclient.addons.bhclient.utils.ServerUtils;
import com.iekeiclient.engine.systems.System;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

/**
 * Persistent record of every stash, base and new-chunk cluster the client has seen.
 *
 * <p>Entries are keyed by server so travelling between anarchy servers does not mix their coordinates up.
 * The store is deliberately append-mostly: a stash that is seen again is merged and its counters refreshed
 * rather than duplicated.
 */
public class StashManager extends System<StashManager> {
    private final List<Stash> stashes = new ArrayList<>();

    public StashManager() {
        super("base-hunting-stashes");
    }

    public static StashManager get() {
        return com.iekeiclient.engine.systems.Systems.get(StashManager.class);
    }

    public List<Stash> getAll() {
        return stashes;
    }

    public List<Stash> forCurrentServer() {
        String server = ServerUtils.serverAddress();
        List<Stash> result = new ArrayList<>();

        for (Stash stash : stashes) {
            if (stash.server.equals(server)) result.add(stash);
        }

        result.sort(Comparator.comparingInt((Stash s) -> -s.score()));
        return result;
    }

    /** Adds the stash or merges it into the closest existing entry. Returns the stored instance. */
    public Stash addOrMerge(Stash stash, int mergeRadius) {
        Stash existing = findNearby(stash.server, stash.pos, mergeRadius);

        if (existing != null) {
            existing.merge(stash);
            save();
            return existing;
        }

        stashes.add(stash);
        save();
        return stash;
    }

    public Stash findNearby(String server, class_2338 pos, int radius) {
        Stash best = null;
        double bestDistance = Double.MAX_VALUE;

        for (Stash stash : stashes) {
            if (!stash.server.equals(server)) continue;

            double distance = stash.pos.method_10262(pos);
            if (distance <= (double) radius * radius && distance < bestDistance) {
                best = stash;
                bestDistance = distance;
            }
        }

        return best;
    }

    public int removeWhere(java.util.function.Predicate<Stash> predicate) {
        int before = stashes.size();
        stashes.removeIf(predicate);
        int removed = before - stashes.size();

        if (removed > 0) save();
        return removed;
    }

    public void clearCurrentServer() {
        String server = ServerUtils.serverAddress();
        removeWhere(stash -> stash.server.equals(server));
    }

    @Override
    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        class_2499 list = new class_2499();

        for (Stash stash : stashes) list.add(stash.toTag());
        tag.method_10566("stashes", list);

        return tag;
    }

    @Override
    public StashManager fromTag(class_2487 tag) {
        stashes.clear();

        class_2499 list = tag.method_68569("stashes");
        for (class_2520 element : list) {
            if (element instanceof class_2487 compound) {
                Stash stash = Stash.fromTag(compound);
                if (stash != null) stashes.add(stash);
            }
        }

        return this;
    }

    public enum Kind {
        Stash,
        Base,
        NewChunks,
        Manual
    }

    public static class Stash {
        public String server;
        public class_2338 pos;
        public Kind kind;
        public String dimension;

        public int chests;
        public int barrels;
        public int shulkers;
        public int enderChests;
        public int furnaces;
        public int hoppers;
        public int dispensers;
        public int spawners;

        public long firstSeen;
        public long lastSeen;

        public Stash(String server, class_2338 pos, Kind kind) {
            this.server = server;
            this.pos = pos;
            this.kind = kind;
            this.dimension = ServerUtils.dimension();
            this.firstSeen = java.lang.System.currentTimeMillis();
            this.lastSeen = this.firstSeen;
        }

        public int totalStorage() {
            return chests + barrels + shulkers + enderChests + furnaces + hoppers + dispensers;
        }

        public int score() {
            return chests * 2 + barrels * 2 + shulkers * 8 + enderChests + furnaces + hoppers + dispensers + spawners * 4;
        }

        public void merge(Stash other) {
            // Counters are peaks, not sums: the same chunk is re-sent on every re-visit.
            chests = Math.max(chests, other.chests);
            barrels = Math.max(barrels, other.barrels);
            shulkers = Math.max(shulkers, other.shulkers);
            enderChests = Math.max(enderChests, other.enderChests);
            furnaces = Math.max(furnaces, other.furnaces);
            hoppers = Math.max(hoppers, other.hoppers);
            dispensers = Math.max(dispensers, other.dispensers);
            spawners = Math.max(spawners, other.spawners);

            lastSeen = java.lang.System.currentTimeMillis();
            dimension = other.dimension;
        }

        public String describeCounts() {
            StringBuilder builder = new StringBuilder();

            appendCount(builder, "chest", chests);
            appendCount(builder, "barrel", barrels);
            appendCount(builder, "shulker", shulkers);
            appendCount(builder, "ender chest", enderChests);
            appendCount(builder, "furnace", furnaces);
            appendCount(builder, "hopper", hoppers);
            appendCount(builder, "dispenser", dispensers);
            appendCount(builder, "spawner", spawners);

            return builder.isEmpty() ? "none" : builder.toString();
        }

        private static void appendCount(StringBuilder builder, String label, int count) {
            if (count <= 0) return;
            if (!builder.isEmpty()) builder.append(", ");
            builder.append(count).append(' ').append(label).append(count == 1 ? "" : "s");
        }

        public class_2487 toTag() {
            class_2487 tag = new class_2487();

            tag.method_10582("server", server);
            tag.method_10539("pos", new int[] {pos.method_10263(), pos.method_10264(), pos.method_10260()});
            tag.method_10582("kind", kind.name());
            tag.method_10582("dimension", dimension);

            tag.method_10569("chests", chests);
            tag.method_10569("barrels", barrels);
            tag.method_10569("shulkers", shulkers);
            tag.method_10569("enderChests", enderChests);
            tag.method_10569("furnaces", furnaces);
            tag.method_10569("hoppers", hoppers);
            tag.method_10569("dispensers", dispensers);
            tag.method_10569("spawners", spawners);

            tag.method_10544("firstSeen", firstSeen);
            tag.method_10544("lastSeen", lastSeen);

            return tag;
        }

        public static Stash fromTag(class_2487 tag) {
            int[] pos = tag.method_10561("pos").orElse(null);
            if (pos == null || pos.length != 3) return null;

            Kind kind;
            try {
                kind = Kind.valueOf(tag.method_68564("kind", "Stash"));
            } catch (IllegalArgumentException e) {
                kind = Kind.Stash;
            }

            Stash stash = new Stash(tag.method_68564("server", "unknown"), new class_2338(pos[0], pos[1], pos[2]), kind);

            stash.dimension = tag.method_68564("dimension", "unknown");
            stash.chests = tag.method_68083("chests", 0);
            stash.barrels = tag.method_68083("barrels", 0);
            stash.shulkers = tag.method_68083("shulkers", 0);
            stash.enderChests = tag.method_68083("enderChests", 0);
            stash.furnaces = tag.method_68083("furnaces", 0);
            stash.hoppers = tag.method_68083("hoppers", 0);
            stash.dispensers = tag.method_68083("dispensers", 0);
            stash.spawners = tag.method_68083("spawners", 0);
            stash.firstSeen = tag.method_68080("firstSeen", stash.firstSeen);
            stash.lastSeen = tag.method_68080("lastSeen", stash.lastSeen);

            return stash;
        }
    }

    /** Convenience for callers that want to mutate a list of stashes without touching the store. */
    public void forEachCurrentServer(Consumer<Stash> consumer) {
        for (Stash stash : forCurrentServer()) consumer.accept(stash);
    }
}
