package com.iekeiclient.addons.rejects.events;

import net.minecraft.class_2561;
import net.minecraft.class_345;

public class RaidStartEvent {
    private final class_345 bossBar;
    private final class_2561 raidName;
    private final float initialProgress;

    public RaidStartEvent(class_345 bossBar, class_2561 raidName, float initialProgress) {
        this.bossBar = bossBar;
        this.raidName = raidName;
        this.initialProgress = initialProgress;
    }

    public class_345 getBossBar() {
        return bossBar;
    }

    public class_2561 getRaidName() {
        return raidName;
    }

    public float getInitialProgress() {
        return initialProgress;
    }

    public String getRaidNameString() {
        return raidName.getString();
    }
}