package com.iekeiclient.addons.rejects.events;

import net.minecraft.class_2561;
import net.minecraft.class_345;

public class RaidEndEvent {
    private final class_345 bossBar;
    private final class_2561 raidName;
    private final boolean wasVictory;
    private final float finalProgress;

    public RaidEndEvent(class_345 bossBar, class_2561 raidName, boolean wasVictory, float finalProgress) {
        this.bossBar = bossBar;
        this.raidName = raidName;
        this.wasVictory = wasVictory;
        this.finalProgress = finalProgress;
    }

    public class_345 getBossBar() {
        return bossBar;
    }

    public class_2561 getRaidName() {
        return raidName;
    }

    public boolean wasVictory() {
        return wasVictory;
    }

    public float getFinalProgress() {
        return finalProgress;
    }

    public String getRaidNameString() {
        return raidName.getString();
    }
}