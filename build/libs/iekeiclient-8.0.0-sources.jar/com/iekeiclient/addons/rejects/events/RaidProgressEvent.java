package com.iekeiclient.addons.rejects.events;

import net.minecraft.class_2561;
import net.minecraft.class_345;

public class RaidProgressEvent {
    private final class_345 bossBar;
    private final class_2561 raidName;
    private final float oldProgress;
    private final float newProgress;

    public RaidProgressEvent(class_345 bossBar, class_2561 raidName, float oldProgress, float newProgress) {
        this.bossBar = bossBar;
        this.raidName = raidName;
        this.oldProgress = oldProgress;
        this.newProgress = newProgress;
    }

    public class_345 getBossBar() {
        return bossBar;
    }

    public class_2561 getRaidName() {
        return raidName;
    }

    public float getOldProgress() {
        return oldProgress;
    }

    public float getNewProgress() {
        return newProgress;
    }

    public String getRaidNameString() {
        return raidName.getString();
    }

    public float getProgressDelta() {
        return newProgress - oldProgress;
    }
}