package com.iekeiclient.addons.rejects.utils.server;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_642;
import net.minecraft.class_644;

public class LegacyServerPinger {
    private static final AtomicInteger threadNumber = new AtomicInteger(0);
    private class_642 server;
    private boolean done = false;
    private boolean failed = false;

    public void ping(String ip) {
        ping(ip, 25565);
    }

    public void ping(String ip, int port) {
        server = new class_642("", ip + ":" + port, class_642.class_8678.field_45611);

        new Thread(() -> pingInCurrentThread(ip, port),
                "Server Pinger #" + threadNumber.incrementAndGet()).start();
    }

    private void pingInCurrentThread(String ip, int port) {
        class_644 pinger = new class_644();
        IekeiRejectsAddon.LOG.info("Pinging {}:{}...", ip, port);

        try {
            pinger.method_3003(server, () -> {}, () -> {}, net.minecraft.class_12239.method_75867(false));
            IekeiRejectsAddon.LOG.info("Ping successful: {}:{}", ip, port);

        } catch (UnknownHostException e) {
            IekeiRejectsAddon.LOG.warn("Unknown host: {}:{}", ip, port);
            failed = true;

        } catch (Exception e2) {
            IekeiRejectsAddon.LOG.warn("Ping failed: {}:{}", ip, port);
            failed = true;
        }

        pinger.method_3004();
        done = true;
    }

    public boolean isStillPinging() {
        return !done;
    }

    public boolean isWorking() {
        return !failed;
    }

    public String getServerIP() {
        return server.field_3761;
    }
}
