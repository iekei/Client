package com.iekeiclient.addons.rejects.utils.player;

import static com.iekeiclient.engine.IekeiClient.mc;

import net.minecraft.class_1739;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class InventoryHelper {

    public static int getSlot() {
        return mc.field_1724.method_31548().method_67532();
    }

    public static Integer getEmptySlots() {
        int emptySlots = 0;
        for (int i = 0; i < 36; i++) {
            class_1799 itemStack = mc.field_1724.method_31548().method_5438(i);
            if (itemStack == null || itemStack.method_7909() instanceof class_1739) emptySlots++;
        }
        return emptySlots;
    }

    public static boolean isEmptySlot(int slotId) {
        class_1799 itemStack = mc.field_1724.method_31548().method_5438(slotId);
        return itemStack == null || itemStack.method_7909() instanceof class_1739;
    }

    public static boolean isOffhandEmpty() {
        class_1799 offhandIem = mc.field_1724.method_6079();
        return offhandIem == null || offhandIem.method_7909() instanceof class_1739;
    }


    public static int findEmptyHotbarSlot() {
        for (int i = 0; i < 9; i++) {
            if (isEmptySlot(i)) return i;
        }
        return -1;
    }

    public static int findEmptyInventorySlot() {
        for (int i = 9; i < 36; i++) {
            if (isEmptySlot(i)) return i;
        }
        return -1;
    }


    public static boolean isInventoryFull() {
        for (int i = 0; i < 36; i++) {
            class_1799 itemStack = mc.field_1724.method_31548().method_5438(i);
            if (itemStack == null || itemStack.method_7909() instanceof class_1739) return false;
        }
        return true;
    }

    public static String getItemName(int slot) {
        return mc.field_1724.method_31548().method_5438(slot).method_7964().toString();
    }


    public static class_1792 getItemFromSlot(Integer slot) {
        if (slot == -1) return null;
        if (slot == 45) return mc.field_1724.method_6079().method_7909();
        return mc.field_1724.method_31548().method_5438(slot).method_7909();
    }

    public static class_1799 getOffhandItemStack() {
        return mc.field_1724.method_6079();
    }

    public static class_1792 getOffhandItem() {
        return getOffhandItemStack().method_7909();
    }

    public static class_1792 getMainhandItem() {
        return mc.field_1724.method_6047().method_7909();
    }

    public static void updateSlot(int newSlot) {
        mc.field_1724.method_31548().method_61496(newSlot);
    }
}
