package com.iekeiclient.addons.rejects.utils.seeds;

import java.util.HashMap;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;
import net.minecraft.class_642;
import com.iekeiclient.addons.rejects.events.SeedChangedEvent;
import com.seedfinding.mccore.version.MCVersion;
import com.iekeiclient.engine.IekeiClient;
import com.iekeiclient.engine.systems.System;
import com.iekeiclient.engine.systems.config.Config;
import com.iekeiclient.engine.utils.Utils;
import com.iekeiclient.engine.utils.player.ChatUtils;

import static com.iekeiclient.engine.IekeiClient.mc;

public class Seeds extends System<Seeds> {
    private static final Seeds INSTANCE = new Seeds();

    public HashMap<String, Seed> seeds = new HashMap<>();

    public Seeds() {
        super("seeds");
        init();
        load(IekeiClient.FOLDER);
    }

    public static Seeds get() {
        return INSTANCE;
    }

    public Seed getSeed() {
        if (mc.method_1496() && mc.method_1576() != null) {
            MCVersion version = MCVersion.fromString(mc.method_1576().method_3827());
            if (version == null)
                version = MCVersion.latest();
            return new Seed(mc.method_1576().method_30002().method_8412(), version);
        }

        return seeds.get(Utils.getWorldName());
    }

    public void setSeed(String seed, MCVersion version) {
        if (mc.method_1496()) return;

        long numSeed = toSeed(seed);
        seeds.put(Utils.getWorldName(), new Seed(numSeed, version));
        IekeiClient.EVENT_BUS.post(SeedChangedEvent.get(numSeed));
    }

    public void setSeed(String seed) {
        if (mc.method_1496()) return;

        class_642 server = mc.method_1558();
        MCVersion ver = null;
        if (server != null)
            ver = MCVersion.fromString(server.field_3760.getString());
        if (ver == null) {
            String targetVer = "unknown";
            if (server != null) targetVer = server.field_3760.getString();
            sendInvalidVersionWarning(seed, targetVer);
            ver = MCVersion.latest();
        }
        setSeed(seed, ver);
    }

    @Override
    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        seeds.forEach((key, seed) -> {
            if (seed == null) return;
            tag.method_10566(key, seed.toTag());
        });
        return tag;
    }

    @Override
    public Seeds fromTag(class_2487 tag) {
        tag.method_10541().forEach(key -> {
            seeds.put(key, Seed.fromTag(tag.method_68568(key)));
        });
        return this;
    }

    // https://minecraft.wiki/w/Seed_(level_generation)#Java_Edition
    private static long toSeed(String inSeed) {
        try {
            return Long.parseLong(inSeed);
        } catch (NumberFormatException e) {
            return inSeed.strip().hashCode();
        }
    }

    private static void sendInvalidVersionWarning(String seed, String targetVer) {
        class_5250 msg = class_2561.method_43470(String.format("Couldn't resolve minecraft version \"%s\". Using %s instead. If you wish to change the version run: ", targetVer, MCVersion.latest().name));
        String cmd = String.format("%sseed %s ", Config.get().prefix, seed);
        class_5250 cmdText = class_2561.method_43470(cmd + "<version>");
        cmdText.method_10862(cmdText.method_10866()
            .method_30938(true)
            .method_10958(new class_2558.class_10610(cmd))
            .method_10949(new class_2568.class_10613(class_2561.method_43470("run command")))
        );
        msg.method_10852(cmdText);
        msg.method_10862(msg.method_10866()
            .method_10977(class_124.field_1054)
        );
        ChatUtils.sendMsg("Seed", msg);
    }
}
