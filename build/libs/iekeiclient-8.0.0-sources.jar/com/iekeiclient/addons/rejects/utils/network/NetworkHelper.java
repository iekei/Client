package com.iekeiclient.addons.rejects.utils.network;

import com.iekeiclient.engine.utils.world.TickRate;
import net.minecraft.class_640;

import static com.iekeiclient.engine.IekeiClient.mc;

public class NetworkHelper {

    public static boolean isLagging() {
        return TickRate.INSTANCE.getTimeSinceLastTick() >= 0.8;
    }

    // can be used for ping compensation in combat modules
    public static int getCurrentPing() {
        class_640 playerListEntry = mc.method_1562().method_2871(mc.field_1724.method_5667());
        if (playerListEntry != null) playerListEntry.method_2959();
        return -1;
    }

    public static String getCurrentPingStr() {
        int ping = getCurrentPing();
        if (ping == -1) return "-1";
        return Integer.toString(ping);
    }

}
