package com.iekeiclient.addons.rejects.utils.general;


import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalBlock;
import com.iekeiclient.engine.pathing.BaritonePathManager;
import net.minecraft.class_1297;
import net.minecraft.class_2338;

import static com.iekeiclient.engine.IekeiClient.mc;

public class BaritoneHelper {

    private static final IBaritone baritone = BaritoneAPI.getProvider().getPrimaryBaritone();
    // iekei's baritone path manager
    private static final BaritonePathManager pathManager = new BaritonePathManager();

    public static void pathToBlockPos(class_2338 pos) {
        baritone.getCustomGoalProcess().setGoalAndPath(new GoalBlock(pos));
    }

    public static void pause() {
        pathManager.pause();
    }

    public static void resume() {
        pathManager.resume();
    }

    public static void stopEverything() {
        stopPathing();
        baritone.getMineProcess().cancel(); // not sure if this is needed too or calling the rest, we'll see.
    }

    public static void stopPathing() {
        baritone.getPathingBehavior().cancelEverything();
        baritone.getPathingBehavior().forceCancel();
    }

    public static void stopFollowing() {
        baritone.getFollowProcess().cancel();
    }


    public static void followEntity(class_1297 e) {

    }

    public static boolean isFollowing() {
        return baritone.getFollowProcess().isActive();
    }

    public static boolean isFarming() {
        return baritone.getFarmProcess().isActive();
    }

    public static boolean hasGoal() {
        return baritone.getPathingBehavior().getGoal() != null;
    }

    public static Goal getGoal() {
        return baritone.getPathingBehavior().getGoal();
    }

    public static boolean isAtGoal() {
        try {
            return getGoal().isInGoal(mc.field_1724.method_24515());
        } catch (Exception ignored) {
            return false;
        }

    }

    public static boolean isPathing() {
        return baritone.getPathingBehavior().isPathing();
    }

    public static boolean hasPath() {
        return baritone.getPathingBehavior().hasPath();
    }
}
