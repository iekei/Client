package com.iekeiclient.addons.rejects.utils;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.utils.seeds.Seeds;
import com.iekeiclient.engine.IekeiClient;
import com.iekeiclient.engine.events.entity.player.PlayerMoveEvent;
import com.iekeiclient.engine.mixininterface.IVec3d;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.utils.PostInit;
import com.iekeiclient.engine.utils.Utils;
import com.iekeiclient.engine.utils.player.PlayerUtils;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_3532;

import static com.iekeiclient.engine.IekeiClient.mc;

public class RejectsUtils {
    @PostInit
    public static void init() {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("saving seeds...");
            RejectsConfig.get().save(IekeiClient.FOLDER);
            Seeds.get().save(IekeiClient.FOLDER);
        }));
    }

    public static String getModuleName(String name) {
        int dupe = 0;
        Modules modules = Modules.get();
        if (modules == null) {
            IekeiRejectsAddon.LOG.warn("Module instantiation before Modules initialized.");
            return name;
        }
        for (Module module : modules.getAll()) {
            if (module.name.equals(name)) {
                dupe++;
                break;
            }
        }
        return dupe == 0 ? name : getModuleName(name + "*".repeat(dupe));
    }

    public static String getRandomPassword(int num) {
        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_";
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < num; i++) {
            int number = random.nextInt(63);
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }

    public static boolean inFov(class_1297 entity, double fov) {
        if (fov >= 360) return true;
        float[] angle = PlayerUtils.calculateAngle(entity.method_5829().method_1005());
        double xDist = class_3532.method_15356(angle[0], mc.field_1724.method_36454());
        double yDist = class_3532.method_15356(angle[1], mc.field_1724.method_36455());
        double angleDistance = Math.hypot(xDist, yDist);
        return angleDistance <= fov;
    }

    public static float fullFlightMove(PlayerMoveEvent event, double speed, boolean verticalSpeedMatch) {
        if (PlayerUtils.isMoving()) {
            double dir = getDir();

            double xDir = Math.cos(Math.toRadians(dir + 90));
            double zDir = Math.sin(Math.toRadians(dir + 90));

            ((IVec3d) event.movement).iekei$setXZ(xDir * speed, zDir * speed);
        } else {
            ((IVec3d) event.movement).iekei$setXZ(0, 0);
        }

        float ySpeed = 0;

        if (mc.field_1690.field_1903.method_1434())
            ySpeed += speed;
        if (mc.field_1690.field_1832.method_1434())
            ySpeed -= speed;
        ((IVec3d) event.movement).iekei$setY(verticalSpeedMatch ? ySpeed : ySpeed / 2);

        return ySpeed;
    }

    private static double getDir() {
        double dir = 0;

        if (Utils.canUpdate()) {
            dir = mc.field_1724.method_36454() + ((mc.field_1724.field_6250 < 0) ? 180 : 0);

            if (mc.field_1724.field_6212 > 0) {
                dir += -90F * ((mc.field_1724.field_6250 < 0) ? -0.5F : ((mc.field_1724.field_6250 > 0) ? 0.5F : 1F));
            } else if (mc.field_1724.field_6212 < 0) {
                dir += 90F * ((mc.field_1724.field_6250 < 0) ? -0.5F : ((mc.field_1724.field_6250 > 0) ? 0.5F : 1F));
            }
        }
        return dir;
    }
}
