package com.iekeiclient.addons.rejects.utils.player;

import static com.iekeiclient.engine.IekeiClient.mc;

import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class ArmorHelper {

    // todo this has some bugs..

    public static class_1799 getArmorItemStack(class_1304 equipmentSlot) {
        return mc.field_1724.method_6118(equipmentSlot);
    }

    public static class_1792 getArmorItem(class_1304 equipmentSlot) {
        return getArmorItemStack(equipmentSlot).method_7909();
    }

    public static boolean checkThreshold(class_1799 i, double threshold) {
        return getDamage(i) <= threshold;
    }

    public static double getDamage(class_1799 i) {
        return (((double) (i.method_7936() - i.method_7919()) / i.method_7936()) * 100);
    }

    public static class_1799 getArmor(int slot) {
        return switch (slot) {
            case 0 -> getFeetItemStack();
            case 1 -> getLegsItemStack();
            case 2 -> getChestItemStack();
            case 3 -> getHeadItemStack();
            default -> class_1799.field_8037;
        };
    }

    public static class_1792 getHeadItem() {
        return getArmorItem(class_1304.field_6169);
    }

    public static class_1799 getHeadItemStack() {
        return getArmorItemStack(class_1304.field_6169);
    }

    public static class_1792 getChestItem() {
        return getArmorItem(class_1304.field_6174);
    }

    public static class_1799 getChestItemStack() {
        return getArmorItemStack(class_1304.field_6174);
    }

    public static class_1792 getLegsItem() {
        return getArmorItem(class_1304.field_6172);
    }

    public static class_1799 getLegsItemStack() {
        return getArmorItemStack(class_1304.field_6172);
    }

    public static class_1792 getFeetItem() {
        return getArmorItem(class_1304.field_6166);
    }

    public static class_1799 getFeetItemStack() {
        return getArmorItemStack(class_1304.field_6166);
    }


    public static boolean hasHelmet() {
        return isHelm(getHeadItemStack());
    }

    public static boolean hasChestplate() {
        return isChest(getChestItemStack());
    }

    public static boolean hasElytra() {
        return getArmorItem(class_1304.field_6174).equals(class_1802.field_8833);
    }

    public static boolean hasLeggings() {
        return isLegs(getLegsItemStack());
    }

    public static boolean hasBoots() {
        return isBoots(getFeetItemStack());
    }


    public static boolean isHelm(class_1799 itemStack) {
        return itemStack != null && (
            itemStack.method_7909() == class_1802.field_22027 ||
                itemStack.method_7909() == class_1802.field_8805 ||
                itemStack.method_7909() == class_1802.field_8862 ||
                itemStack.method_7909() == class_1802.field_8743 ||
                itemStack.method_7909() == class_1802.field_8283 ||
                itemStack.method_7909() == class_1802.field_8267
        );
    }

    public static boolean isChest(class_1799 itemStack) {
        return itemStack != null && (
            itemStack.method_7909() == class_1802.field_22028 ||
                itemStack.method_7909() == class_1802.field_8058 ||
                itemStack.method_7909() == class_1802.field_8678 ||
                itemStack.method_7909() == class_1802.field_8523 ||
                itemStack.method_7909() == class_1802.field_8873 ||
                itemStack.method_7909() == class_1802.field_8577
        );
    }

    public static boolean isLegs(class_1799 itemStack) {
        return itemStack != null && (
            itemStack.method_7909() == class_1802.field_22029 ||
                itemStack.method_7909() == class_1802.field_8348 ||
                itemStack.method_7909() == class_1802.field_8416 ||
                itemStack.method_7909() == class_1802.field_8396 ||
                itemStack.method_7909() == class_1802.field_8218 ||
                itemStack.method_7909() == class_1802.field_8570
        );
    }

    public static boolean isBoots(class_1799 itemStack) {
        return itemStack != null && (
            itemStack.method_7909() == class_1802.field_22030 ||
                itemStack.method_7909() == class_1802.field_8285 ||
                itemStack.method_7909() == class_1802.field_8753 ||
                itemStack.method_7909() == class_1802.field_8660 ||
                itemStack.method_7909() == class_1802.field_8313 ||
                itemStack.method_7909() == class_1802.field_8370
        );
    }
}
