package com.iekeiclient.addons.rejects.utils.seeds;

import com.seedfinding.mccore.version.MCVersion;
import net.minecraft.class_124;
import net.minecraft.class_2487;
import net.minecraft.class_2503;
import net.minecraft.class_2519;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;
import net.minecraft.text.*;

public class Seed {
    public final Long seed;
    public final MCVersion version;

    public Seed(Long seed, MCVersion version) {
        this.seed = seed;
        if (version == null)
            version = MCVersion.latest();
        this.version = version;
    }

    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10566("seed", class_2503.method_23251(seed));
        tag.method_10566("version", class_2519.method_23256(version.name));
        return tag;
    }

    public static Seed fromTag(class_2487 tag) {
        return new Seed(
            tag.method_68080("seed", 0L),
            MCVersion.fromString(tag.method_68564("version", ""))
        );
    }

    public class_2561 toText() {
        class_5250 text = class_2561.method_43470(String.format("[%s%s%s] (%s)",
            class_124.field_1060,
            seed.toString(),
            class_124.field_1068,
            version.toString()
        ));
        text.method_10862(text.method_10866()
            .method_10958(new class_2558.class_10606(seed.toString()))
            .method_10949(new class_2568.class_10613(class_2561.method_43470("Copy to clipboard")))
        );
        return text;
    }
}
