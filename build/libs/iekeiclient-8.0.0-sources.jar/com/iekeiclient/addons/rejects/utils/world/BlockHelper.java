package com.iekeiclient.addons.rejects.utils.world;

import com.iekeiclient.engine.utils.player.Rotations;
import com.iekeiclient.engine.utils.world.CardinalDirection;
import net.minecraft.block.*;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2473;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3609;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.IntStream;

import static com.iekeiclient.addons.rejects.utils.world.DistanceHelper.distanceBetween;
import static com.iekeiclient.engine.IekeiClient.mc;
import static com.iekeiclient.engine.utils.Utils.vec3d;

public class BlockHelper {

    public static List<class_2338> getSphere(class_2338 centerPos, int radius, int height) {
        ArrayList<class_2338> blocks = new ArrayList<>();
        for (int i = centerPos.method_10263() - radius; i < centerPos.method_10263() + radius; i++) {
            for (int j = centerPos.method_10264() - height; j < centerPos.method_10264() + height; j++) {
                for (int k = centerPos.method_10260() - radius; k < centerPos.method_10260() + radius; k++) {
                    class_2338 pos = new class_2338(i, j, k);
                    if (distanceBetween(centerPos, pos) <= radius && !blocks.contains(pos)) blocks.add(pos);
                }
            }
        }
        return blocks;
    }

    public static class_2248 getBlock(class_2338 p) {
        if (p == null) return null;
        return mc.field_1687.method_8320(p).method_26204();
    }

    public static class_2680 getState(class_2338 pos) {
        if (pos == null) return null;
        return mc.field_1687.method_8320(pos);
    }

    public static boolean canPlace(class_2338 pos) {
        if (pos == null) return false;
        if (isSolid(pos) || !class_1937.method_25953(pos) || !canReplace(pos)) return false;
        if (!mc.field_1687.method_8628(mc.field_1687.method_8320(pos), pos, class_3726.method_16194())) return false;
        return mc.field_1687.method_8320(pos).method_26215() || mc.field_1687.method_8320(pos).method_26227().method_15772() instanceof class_3609;
    }

    public static boolean canPlant(class_2338 pos) {
        class_2248 b = getBlock(pos);
        if (b.equals(class_2246.field_10479) || b.equals(class_2246.field_10219) || b.equals(class_2246.field_10566) || b.equals(class_2246.field_10253)) {
            final AtomicBoolean plant = new AtomicBoolean(true);
            IntStream.rangeClosed(1, 5).forEach(i -> {
                // Check above
                class_2338 check = pos.method_10086(i);
                if (!isAirBlock(check)) {
                    plant.set(false);
                    return;
                }
                // Check around
                for (CardinalDirection dir : CardinalDirection.values()) {
                    if (!isAirBlock(check.method_10079(dir.toDirection(), i))) {
                        plant.set(false);
                        return;
                    }
                }
            });
            return plant.get();
        }
        return false;
    }


    public static boolean canReplace(class_2338 pos) {
        return getState(pos).method_45474();
    }

    public static boolean isSolid(class_2338 pos) {
        if (isAirBlock(pos) || isLiquidBlock(pos)) return false;
        return getState(pos).method_26212(mc.field_1687, pos);
    }

    public static boolean isAirBlock(class_2338 pos) {
        class_2248 b = getBlock(pos);
        return b.equals(class_2246.field_10124) || b.equals(class_2246.field_10543) || b.equals(class_2246.field_10243);
    }

    public static boolean isLiquidBlock(class_2338 pos) {
        class_2248 b = getBlock(pos);
        return b.equals(class_2246.field_10382) || b.equals(class_2246.field_10164);
    }

    public static boolean isSaplingBlock(class_2338 pos) {
        return getBlock(pos) instanceof class_2473;
    }

    public static boolean isLeafBlock(class_2338 pos) {
        class_2248 b = getBlock(pos);
        return b.equals(class_2246.field_10098) ||
            b.equals(class_2246.field_10539) ||
            b.equals(class_2246.field_10035) ||
            b.equals(class_2246.field_10335) ||
            b.equals(class_2246.field_10503) ||
            b.equals(class_2246.field_9988) ||
            b.equals(class_2246.field_37551) ||
            b.equals(class_2246.field_42731);
    }

    public static boolean isLogBlock(class_2338 pos) {
        class_2248 b = getBlock(pos);
        return b.equals(class_2246.field_10533) ||
            b.equals(class_2246.field_10511) ||
            b.equals(class_2246.field_10010) ||
            b.equals(class_2246.field_10306) ||
            b.equals(class_2246.field_10431) ||
            b.equals(class_2246.field_10037) ||
            b.equals(class_2246.field_37545) ||
            b.equals(class_2246.field_42729);
    }

    public static class_243 getBestHitPos(class_2338 pos) {
        if (pos == null) return new class_243(0.0, 0.0, 0.0);
        double x = class_3532.method_15350((mc.field_1724.method_23317() - pos.method_10263()), 0.0, 1.0);
        double y = class_3532.method_15350((mc.field_1724.method_23318() - pos.method_10264()), 0.0, 0.6);
        double z = class_3532.method_15350((mc.field_1724.method_23321() - pos.method_10260()), 0.0, 1.0);
        return new class_243(pos.method_10263() + x, pos.method_10264() + y, pos.method_10260() + z);
    }

    public static Vector3d getVector3d(class_2338 pos) {
        return new Vector3d(pos.method_10263(), pos.method_10264(), pos.method_10260());
    }


    public static class BlockPosPlus {
        private class_2338 pos;

        public BlockPosPlus(class_2338 pos) {
            set(pos);
        }

        public class_2338 getBlockPos() {
            return pos;
        }

        public void set(class_2338 pos) {
            this.pos = pos;
        }

        public void offset(CardinalDirection d) {
            this.set(this.pos.method_10093(d.toDirection()));
        }

        public void offset(class_2350 d) {
            this.set(this.pos.method_10093(d));
        }


        public class_2248 getBlock() {
            return BlockHelper.getBlock(this.pos);
        }

        public class_2680 getState() {
            return BlockHelper.getState(this.pos);
        }


        public boolean isAir(class_2338 p) {
            return BlockHelper.isAirBlock(this.pos);
        }

        public boolean isSolid(class_2338 pos) {
            return BlockHelper.isSolid(this.pos);
        }

        public boolean isReplacable(class_2338 pos) {
            return BlockHelper.canReplace(this.pos);
        }


        public class_243 getHitPos() {
            return getBestHitPos(this.pos);
        }

        public class_3965 getHitResult() {
            return new class_3965(this.getHitPos(), class_2350.field_11036, this.pos, false);
        }


        public double getYaw() {
            return Rotations.getYaw(this.pos);
        }

        public double getPitch() {
            return Rotations.getPitch(this.pos);
        }


        public double distanceToSelf() {
            return DistanceHelper.distanceBetween(mc.field_1724.method_24515(), pos);
        }

        public double distanceTo(class_2338 pos) {
            return DistanceHelper.distanceBetween(pos, this.pos);
        }


        // Placement Helpers
        public boolean canPlace(boolean checkSupport) {
            if (!BlockHelper.canPlace(this.pos)) return false;
            return !checkSupport || this.supportBelow();
        }

        public boolean supportBelow() {
            return isSolid(this.pos.method_10074());
        }


        public class_1792 asItem() {
            return this.getBlock().method_8389();
        }

        public class_243 asVec3d() {
            return vec3d(this.pos);
        }

    }


}
