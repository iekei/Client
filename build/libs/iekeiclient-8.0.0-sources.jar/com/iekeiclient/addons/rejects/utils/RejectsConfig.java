package com.iekeiclient.addons.rejects.utils;

import com.iekeiclient.engine.IekeiClient;
import com.iekeiclient.engine.systems.System;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.utils.render.prompts.OkPrompt;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

public class RejectsConfig extends System<RejectsConfig> {
    private static final RejectsConfig INSTANCE = new RejectsConfig();

    public enum HttpAllowed {
        Everything,
        NotIekeiApi,
        NotIekeiPing,
        Nothing
    }

    public HttpAllowed httpAllowed = HttpAllowed.Everything;
    public String httpUserAgent = "Iekei Client";
    public Set<String> hiddenModules = new HashSet<>();
    public boolean loadSystemFonts = true;
    public boolean duplicateModuleNames = false;

    public RejectsConfig() {
        super("rejects-config");
        init();
        load(IekeiClient.FOLDER);
    }

    public static RejectsConfig get() {
        return INSTANCE;
    }

    public void setHiddenModules(List<Module> newList) {
        if (newList.size() < hiddenModules.size()) {
            OkPrompt.create()
                    .title("Hidden Modules")
                    .message("In order to see the modules you have removed from the list you need to restart Minecraft.")
                    .id("hidden-modules-unhide")
                    .show();
        }
        hiddenModules.clear();
        for (Module module : newList) {
            if (module == null) continue;
            if (module.isActive()) module.toggle();
            hiddenModules.add(module.name);
        }
    }

    public List<Module> getHiddenModules() {
        Modules modules = Modules.get();
        if (modules == null) return List.of();
        return hiddenModules.stream().map(modules::get).collect(Collectors.toList());
    }

    @Override
    public class_2487 toTag() {
        class_2487 tag = new class_2487();
        tag.method_10582("httpAllowed", httpAllowed.toString());
        tag.method_10582("httpUserAgent", httpUserAgent);
        tag.method_10556("loadSystemFonts", loadSystemFonts);
        tag.method_10556("duplicateModuleNames", duplicateModuleNames);

        class_2499 modulesTag = new class_2499();
        for (String module : hiddenModules) modulesTag.add(class_2519.method_23256(module));
        tag.method_10566("hiddenModules", modulesTag);

        return tag;
    }

    @Override
    public RejectsConfig fromTag(class_2487 tag) {
        httpAllowed = HttpAllowed.valueOf(tag.method_68564("httpAllowed", HttpAllowed.Everything.name()));
        httpUserAgent = tag.method_68564("httpUserAgent", "");
        loadSystemFonts = tag.method_68566("loadSystemFonts", false);
        duplicateModuleNames = tag.method_68566("duplicateModuleNames", false);

        class_2499 valueTag = tag.method_68569("hiddenModules");
        for (class_2520 tagI : valueTag) {
            hiddenModules.add(tagI.method_68658().orElse(""));
        }

        return this;
    }
}
