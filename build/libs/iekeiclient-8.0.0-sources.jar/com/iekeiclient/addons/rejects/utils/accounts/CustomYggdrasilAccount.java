package com.iekeiclient.addons.rejects.utils.accounts;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import net.minecraft.class_2487;
import net.minecraft.class_320;
import com.iekeiclient.engine.mixin.MinecraftClientAccessor;
import com.iekeiclient.engine.systems.accounts.Account;
import com.iekeiclient.engine.systems.accounts.AccountType;
import com.iekeiclient.engine.utils.misc.NbtException;

import static com.iekeiclient.engine.IekeiClient.mc;

public class CustomYggdrasilAccount extends Account<CustomYggdrasilAccount> {
    private String password, server;

    public CustomYggdrasilAccount(String name, String password, String server) {
        super(AccountType.Cracked, name);
        this.password = password;
        this.server = server;
    }

    @Override
    public boolean fetchInfo() {
        try {
            class_320 session = CustomYggdrasilLogin.login(name, password, server);

            cache.username = session.method_1676();
            cache.uuid = session.method_44717().toString();

            return true;
        } catch (AuthenticationException e) {
            return false;
        }
    }

    @Override
    public boolean login() {
        try {
            CustomYggdrasilLogin.LocalYggdrasilAuthenticationService service = new CustomYggdrasilLogin.LocalYggdrasilAuthenticationService(mc.method_1487(), server);
            MinecraftSessionService sessService = new CustomYggdrasilLogin.LocalYggdrasilMinecraftSessionService(service, service.server);
            applyLoginEnvironment(service);

            class_320 session = CustomYggdrasilLogin.login(name, password, server);
            setSession(session);
            cache.username = session.method_1676();
            cache.loadHead();
            return true;
        } catch (AuthenticationException e) {
            if (e.getMessage().contains("Invalid username or password") || e.getMessage().contains("account migrated"))
                IekeiRejectsAddon.LOG.error("Wrong password.");
            else IekeiRejectsAddon.LOG.error("Failed to contact the authentication server.");
            return false;
        }
    }

    @Override
    public class_2487 toTag() {
        class_2487 tag = super.toTag();

        tag.method_10582("password", password);
        tag.method_10582("server", server);

        return tag;
    }

    @Override
    public CustomYggdrasilAccount fromTag(class_2487 tag) {
        super.fromTag(tag);
        if (!tag.method_10545("password")) throw new NbtException();

        password = tag.method_10558("password").orElse("");
        server = tag.method_10558("server").orElse("");

        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof CustomYggdrasilAccount)) return false;
        return ((CustomYggdrasilAccount) o).name.equals(this.name);
    }
}
