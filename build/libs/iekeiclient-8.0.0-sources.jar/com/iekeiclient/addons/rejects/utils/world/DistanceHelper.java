package com.iekeiclient.addons.rejects.utils.world;

import com.iekeiclient.engine.utils.Utils;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3532;

import static com.iekeiclient.engine.IekeiClient.mc;

public class DistanceHelper {

    public static double distanceTo(class_2338 pos) {
        return distanceBetween(mc.field_1724.method_24515(), pos);
    }

    public static double distanceTo(class_243 vec) {
        return distance(Utils.vec3d(mc.field_1724.method_24515()), vec);
    }

    public static double distanceBetween(class_2338 pos1, class_2338 pos2) {
        double d = pos1.method_10263() - pos2.method_10263();
        double e = pos1.method_10264() - pos2.method_10264();
        double f = pos1.method_10260() - pos2.method_10260();
        return class_3532.method_15355((float) (d * d + e * e + f * f));
    }

    public static double distance(double x1, double y1, double z1, double x2, double y2, double z2) {
        double dX = x2 - x1;
        double dY = y2 - y1;
        double dZ = z2 - z1;
        return Math.sqrt(dX * dX + dY * dY + dZ * dZ);
    }

    public static double distance(double y1, double y2) {
        double dY = y2 - y1;
        return Math.sqrt(dY * dY);
    }

    public static double distance(class_243 vec1, class_243 vec2) {
        double dX = vec2.field_1352 - vec1.field_1352;
        double dY = vec2.field_1351 - vec1.field_1351;
        double dZ = vec2.field_1350 - vec1.field_1350;
        return Math.sqrt(dX * dX + dY * dY + dZ * dZ);
    }

}
