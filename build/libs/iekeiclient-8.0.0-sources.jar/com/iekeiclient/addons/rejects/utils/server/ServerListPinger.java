package com.iekeiclient.addons.rejects.utils.server;

import com.google.common.collect.Lists;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.*;
import net.minecraft.class_156;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2921;
import net.minecraft.class_2923;
import net.minecraft.class_2924;
import net.minecraft.class_2926;
import net.minecraft.class_2935;
import net.minecraft.class_2937;
import net.minecraft.class_6368;
import net.minecraft.class_6370;
import net.minecraft.class_639;
import net.minecraft.class_8676;
import net.minecraft.class_9191;
import net.minecraft.class_9812;

public class ServerListPinger {
    private static final Logger LOGGER = LogManager.getLogger();
    private final List<class_2535> clientConnections = Collections.synchronizedList(Lists.newArrayList());
    private final ArrayList<IServerFinderDisconnectListener> disconnectListeners = new ArrayList<>();
    private boolean notifiedDisconnectListeners = false;
    private boolean failedToConnect = true;

    private static String getPlayerCountLabel(int i, int j) {
        return i + "/" + j;
    }

    public void addServerFinderDisconnectListener(IServerFinderDisconnectListener listener) {
        disconnectListeners.add(listener);
    }

    private void notifyDisconnectListeners() {
        synchronized (this) {
            if (!notifiedDisconnectListeners) {
                notifiedDisconnectListeners = true;
                for (IServerFinderDisconnectListener l : disconnectListeners) {
                    if (l != null) {
                        if (failedToConnect) {
                            l.onServerFailed();
                        } else {
                            l.onServerDisconnect();
                        }
                    }
                }
            }
        }
    }


    public void add(final MServerInfo entry, final Runnable runnable) throws UnknownHostException {
        class_639 serverAddress = class_639.method_2950(entry.address);
        Optional<InetSocketAddress> address = class_6370.field_33745.method_36907(serverAddress).map(class_6368::method_36902);
        if (address.isEmpty()) {
            return;
        }
        final class_2535 clientConnection = class_2535.method_10753(address.get(), net.minecraft.class_12239.method_75867(false), (class_9191) null);

        failedToConnect = false;
        this.clientConnections.add(clientConnection);
        entry.label = "multiplayer.status.pinging";
        entry.ping = -1L;
        entry.playerListSummary = null;
        class_2921 clientQueryPacketListener = new class_2921() {
            private boolean sentQuery;
            private boolean received;
            private long startTime;

            public void method_12667(class_2924 packet) {
                if (this.received) {
                    clientConnection.method_10747(class_2561.method_43471("multiplayer.status.unrequested"));
                    return;
                }
                this.received = true;
                class_2926 serverMetadata = packet.comp_1272();
                if (serverMetadata.comp_1273() != null) {
                    entry.label = serverMetadata.comp_1273().getString();
                } else {
                    entry.label = "";
                }

                entry.version = serverMetadata.comp_1275().map(class_2926.class_2930::comp_1282).orElse("multiplayer.status.old");
                serverMetadata.comp_1274().ifPresentOrElse(players -> {
                    entry.playerCountLabel = ServerListPinger.getPlayerCountLabel(players.comp_1280(), players.comp_1279());
                    entry.playerCount = players.comp_1280();
                    entry.playercountMax = players.comp_1279();
                }, () -> {
                    entry.playerCountLabel = "multiplayer.status.unknown";
                });

                this.startTime = class_156.method_658();
                clientConnection.method_10743(new class_2935(this.startTime));
                this.sentQuery = true;
                notifyDisconnectListeners();
                }

            public void method_12666(class_2923 packet) {
                long l = this.startTime;
                long m = class_156.method_658();
                entry.ping = m - l;
                clientConnection.method_10747(class_2561.method_43471("multiplayer.status.finished"));
            }

            public void onDisconnected(class_2561 reason) {
                if (!this.sentQuery) {
                    ServerListPinger.LOGGER.error("Can't ping {}: {}", entry.address, reason.getString());
                    entry.label = "multiplayer.status.cannot_connect";
                    entry.playerCountLabel = "";
                    entry.playerCount = 0;
                    entry.playercountMax = 0;
                    ServerListPinger.this.ping(entry);
                }
                notifyDisconnectListeners();
            }

            @Override
            public void method_10839(class_9812 info) {

            }

            public boolean method_48106() {
                return clientConnection.method_10758();
            }
        };

        try {
            clientConnection.method_52903(serverAddress.method_2952(), serverAddress.method_2954(), clientQueryPacketListener);
            clientConnection.method_10743(class_2937.field_48259);
        } catch (Throwable var8) {
            LOGGER.error("Failed to ping server {}", serverAddress, var8);
        }

    }

    private void ping(final MServerInfo serverInfo) {
        final class_639 serverAddress = class_639.method_2950(serverInfo.address);
        new Bootstrap().group(net.minecraft.class_12239.method_75867(false).method_75869()).handler(new ChannelInitializer<>() {
            @Override
            protected void initChannel(Channel ch) throws Exception {
                try {
                    ch.config().setOption(ChannelOption.TCP_NODELAY, true);
                } catch (ChannelException ignored) {
                }
                ch.pipeline().addLast(new class_8676(serverAddress, ((protocolVersion, version, label, currentPlayers, maxPlayers) -> {
                    serverInfo.version = version;
                    serverInfo.label = label;
                    serverInfo.playerCountLabel = ServerListPinger.getPlayerCountLabel(currentPlayers, maxPlayers);
                })));
            }
        });
    }

    public void tick() {
        synchronized (this.clientConnections) {
            Iterator<class_2535> iterator = this.clientConnections.iterator();

            while (iterator.hasNext()) {
                class_2535 clientConnection = iterator.next();
                if (clientConnection.method_10758()) {
                    clientConnection.method_10754();
                } else {
                    iterator.remove();
                    clientConnection.method_10768();
                }
            }
        }
    }

    public void cancel() {
        synchronized (this.clientConnections) {
            Iterator<class_2535> iterator = this.clientConnections.iterator();

            while (iterator.hasNext()) {
                class_2535 clientConnection = iterator.next();
                if (clientConnection.method_10758()) {
                    iterator.remove();
                    clientConnection.method_10747(class_2561.method_43471("multiplayer.status.cancelled"));
                }
            }
        }
    }
}