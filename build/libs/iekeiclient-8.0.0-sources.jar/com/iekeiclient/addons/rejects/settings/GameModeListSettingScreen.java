package com.iekeiclient.addons.rejects.settings;

import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.WindowScreen;
import com.iekeiclient.engine.gui.widgets.containers.WTable;
import com.iekeiclient.engine.gui.widgets.pressable.WCheckbox;
import com.iekeiclient.engine.utils.Utils;
import java.util.List;
import net.minecraft.class_1934;

public class GameModeListSettingScreen extends WindowScreen {
    private final GameModeListSetting setting;
    private final WTable table;

    public GameModeListSettingScreen(GuiTheme theme, GameModeListSetting setting) {
        super(theme, "Select Gamemodes");
        this.setting = setting;
        table = super.add(theme.table()).expandX().widget();
    }

    @Override
    public void initWidgets() {
        List<class_1934> gms = setting.get();
        for (class_1934 gameMode : class_1934.values()) {
            table.add(theme.label(Utils.nameToTitle(gameMode.method_8381()))).expandCellX();

            boolean contains = setting.get().contains(gameMode);
            WCheckbox checkbox = table.add(theme.checkbox(contains)).widget();
            checkbox.action = () -> {
                if (contains) {
                    gms.remove(gameMode);
                } else {
                    gms.add(gameMode);
                }
            };

            table.row();
        }
    }
}
