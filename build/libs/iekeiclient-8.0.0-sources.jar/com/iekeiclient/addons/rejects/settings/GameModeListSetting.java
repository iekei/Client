package com.iekeiclient.addons.rejects.settings;

import com.iekeiclient.engine.settings.IVisible;
import com.iekeiclient.engine.settings.Setting;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1934;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

public class GameModeListSetting extends Setting<List<class_1934>> {
    public GameModeListSetting(String name, String description, List<class_1934> defaultValue, Consumer<List<class_1934>> onChanged, Consumer<Setting<List<class_1934>>> onModuleActivated, IVisible visible) {
        super(name, description, defaultValue, onChanged, onModuleActivated, visible);
    }

    @Override
    protected List<class_1934> parseImpl(String str) {
        String[] values = str.split(",");
        List<class_1934> modes = new ArrayList<>(values.length);
        for (String s : values) {
            class_1934 mode = class_1934.method_8385(s);
            if (mode != null) modes.add(mode);
        }
        return modes;
    }

    @Override
    protected boolean isValueValid(List<class_1934> value) {
        return true;
    }

    @Override
    protected void resetImpl() {
        value = new ArrayList<>();
    }

    @Override
    public class_2487 save(class_2487 tag) {
        class_2499 valueTag = new class_2499();
        for (class_1934 mode : get()) {
            valueTag.add(class_2519.method_23256(mode.method_8381()));
        }
        tag.method_10566("value", valueTag);

        return tag;
    }

    @Override
    public List<class_1934> load(class_2487 tag) {
        get().clear();

        class_2499 valueTag = tag.method_10554("value").orElse(new class_2499());
        for (class_2520 tagI : valueTag) {
            class_1934 mode = class_1934.method_8385(tagI.method_68658().orElse(""));
            if (mode != null)
                get().add(mode);
        }

        return get();
    }

    public static class Builder extends SettingBuilder<Builder, List<class_1934>, GameModeListSetting> {
        public Builder() {
            super(new ArrayList<>(0));
        }

        public Builder defaultValue(List<class_1934> map) {
            this.defaultValue = map;
            return this;
        }

        @Override
        public GameModeListSetting build() {
            return new GameModeListSetting(name, description, defaultValue, onChanged, onModuleActivated, visible);
        }
    }
}
