package com.iekeiclient.addons.rejects.mixin.iekei;

import com.iekeiclient.addons.rejects.utils.accounts.CustomYggdrasilAccount;
import com.iekeiclient.engine.systems.accounts.Account;
import com.iekeiclient.engine.systems.accounts.Accounts;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(value = Accounts.class)
public class AccountsMixin {
    @Inject(method = "lambda$fromTag$0", at = @At(value = "INVOKE", target = "Lnet/minecraft/nbt/NbtCompound;getString(Ljava/lang/String;)Ljava/lang/String;"), locals = LocalCapture.CAPTURE_FAILHARD, cancellable = true)
    private static void onFromTag(class_2520 tag1, CallbackInfoReturnable<Account<?>> cir, class_2487 t) {
        if (t.method_10558("type").equals("Yggdrasil")) {
            Account<CustomYggdrasilAccount> account = new CustomYggdrasilAccount(null, null, null).fromTag(t);
            if (account.fetchInfo()) cir.setReturnValue(account);
        }
    }
}
