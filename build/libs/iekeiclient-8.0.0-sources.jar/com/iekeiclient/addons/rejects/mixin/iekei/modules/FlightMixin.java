package com.iekeiclient.addons.rejects.mixin.iekei.modules;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.movement.Flight;
import net.minecraft.class_243;

import static com.iekeiclient.engine.IekeiClient.mc;

@Mixin(Flight.class)
public class FlightMixin {
    @Shadow(remap = false)
    @Final
    private SettingGroup sgGeneral;

    private Setting<Boolean> stopMomentum = null;

    @Inject(method = "<init>", at=@At("TAIL"), remap = false)
    private void onInit(CallbackInfo ci) {
        stopMomentum = sgGeneral.add(new BoolSetting.Builder()
            .name("stop-momentum")
            .description("Stops momentum on flight disable")
            .defaultValue(false)
            .build()
        );
    }

    @Inject(method = "onDeactivate", at=@At("TAIL"), remap = false)
    private void onDeactivate(CallbackInfo ci) {
        if (mc.field_1724 == null || stopMomentum == null || !stopMomentum.get()) return;

        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1913.method_23481(false);
        mc.field_1690.field_1881.method_23481(false);
        mc.field_1690.field_1849.method_23481(false);

        mc.field_1724.method_18799(class_243.field_1353);
    }
}
