package com.iekeiclient.addons.rejects.mixin;

import com.iekeiclient.addons.rejects.events.TeleportParticleEvent;
import com.iekeiclient.engine.IekeiClient;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.iekeiclient.engine.IekeiClient.mc;

@Mixin(class_1309.class)
public class LivingEntityMixin {
    @Inject(method = "handleStatus", at = @At("HEAD"))
    private void onHandleStatus(byte status, CallbackInfo ci) {
        if ((Object) this == mc.field_1724 && status == 46) {
            IekeiClient.EVENT_BUS.post(TeleportParticleEvent.get(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()));
        }
    }
}
