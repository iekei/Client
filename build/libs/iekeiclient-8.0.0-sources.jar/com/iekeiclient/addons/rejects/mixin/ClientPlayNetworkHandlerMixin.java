package com.iekeiclient.addons.rejects.mixin;

import com.iekeiclient.addons.rejects.events.PlayerRespawnEvent;
import com.iekeiclient.engine.IekeiClient;
import net.minecraft.class_2724;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {

    //called on dimension change too
    @Inject(method = "onPlayerRespawn", at = @At("TAIL"))
    public void onPlayerRespawn(class_2724 packet, CallbackInfo ci) {
        IekeiClient.EVENT_BUS.post(PlayerRespawnEvent.get());
    }
}
