package com.iekeiclient.addons.rejects.mixin;

import com.iekeiclient.addons.rejects.modules.bots.elytrabot.events.CancellablePlayerMoveEvent;
import com.iekeiclient.engine.IekeiClient;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.iekeiclient.engine.IekeiClient.mc;


@Mixin(class_1297.class)
public class ElytraBotEntityMixin {
    @Inject(method = "move", at = @At("HEAD"), cancellable = true)
    private void onMove(class_1313 type, class_243 movement, CallbackInfo info) {
        if ((Object) this == mc.field_1724) {
            if (IekeiClient.EVENT_BUS.post(CancellablePlayerMoveEvent.get(type, movement)).isCancelled())
                info.cancel();
        }
    }
}
