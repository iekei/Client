package com.iekeiclient.addons.rejects.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_641;
import net.minecraft.class_642;

@Mixin(class_641.class)
public interface ServerListAccessor {
    @Accessor
    List<class_642> getServers();
}
