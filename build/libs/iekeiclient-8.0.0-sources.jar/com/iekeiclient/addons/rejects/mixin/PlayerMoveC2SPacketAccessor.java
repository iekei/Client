package com.iekeiclient.addons.rejects.mixin;

import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2828.class)
public interface PlayerMoveC2SPacketAccessor {
    @Mutable
    @Accessor("x")
    void iekei$setX(double x);

    @Mutable
    @Accessor("y")
    void iekei$setY(double y);

    @Mutable
    @Accessor("z")
    void iekei$setZ(double z);
}
