package com.iekeiclient.addons.rejects.mixin;

import com.iekeiclient.addons.rejects.events.RaidEndEvent;
import com.iekeiclient.addons.rejects.events.RaidProgressEvent;
import com.iekeiclient.addons.rejects.events.RaidStartEvent;
import com.iekeiclient.engine.IekeiClient;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1259;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_2629;
import net.minecraft.class_337;
import net.minecraft.class_345;
import net.minecraft.class_7417;

@Mixin(class_337.class)
public class BossBarHudMixin {
    @Shadow
    @Final
    private Map<UUID, class_345> bossBars;

    @Inject(method = "handlePacket", at = @At("TAIL"))
    private void onHandlePacket(class_2629 packet, CallbackInfo ci) {
        // Use the packet's accept method to handle different operation types
        packet.method_34091(new class_2629.class_5881() {
            @Override
            public void method_34103(UUID uuid, class_2561 name, float percent, class_1259.class_1260 color, class_1259.class_1261 style, boolean darkenSky, boolean dragonMusic, boolean thickenFog) {
                if (isRaidBossBar(name)) {
                    // Raid started - since we're at TAIL, the boss bar should already be added by vanilla
                    class_345 raidBossBar = bossBars.get(uuid);
                    if (raidBossBar != null) {
                        RaidStartEvent event = new RaidStartEvent(raidBossBar, name, percent);
                        IekeiClient.EVENT_BUS.post(event);
                    } else {
                        // Fallback: create a temporary ClientBossBar for the event
                        // This shouldn't happen if vanilla logic executed properly
                        class_345 tempBossBar = new class_345(uuid, name, percent, color, style, darkenSky, dragonMusic, thickenFog);
                        RaidStartEvent event = new RaidStartEvent(tempBossBar, name, percent);
                        IekeiClient.EVENT_BUS.post(event);
                    }
                }
            }

            @Override
            public void method_34099(UUID uuid) {
                class_345 existingBossBar = bossBars.get(uuid);
                if (existingBossBar != null && isRaidBossBar(existingBossBar.method_5414())) {
                    // Raid ended
                    boolean wasVictory = existingBossBar.method_5412() <= 0.0f;
                    RaidEndEvent event = new RaidEndEvent(
                        existingBossBar, 
                        existingBossBar.method_5414(), 
                        wasVictory, 
                        existingBossBar.method_5412()
                    );
                    IekeiClient.EVENT_BUS.post(event);
                }
            }

            @Override
            public void method_34100(UUID uuid, float percent) {
                class_345 existingBossBar = bossBars.get(uuid);
                if (existingBossBar != null && isRaidBossBar(existingBossBar.method_5414())) {
                    // Raid progress changed
                    float oldProgress = existingBossBar.method_5412();
                    
                    RaidProgressEvent event = new RaidProgressEvent(
                        existingBossBar,
                        existingBossBar.method_5414(),
                        oldProgress,
                        percent
                    );
                    IekeiClient.EVENT_BUS.post(event);
                }
            }

            @Override
            public void method_34102(UUID uuid, class_2561 name) {
                // Not needed for raid detection
            }

            @Override
            public void method_34101(UUID uuid, class_1259.class_1260 color, class_1259.class_1261 style) {
                // Not needed for raid detection
            }

            @Override
            public void method_34104(UUID uuid, boolean darkenSky, boolean dragonMusic, boolean thickenFog) {
                // Not needed for raid detection
            }
        });
    }

    @Unique
    private boolean isRaidBossBar(class_2561 name) {
        if (name == null) return false;
        
        // Check if it's a translatable text with raid-related translation key
        class_7417 content = name.method_10851();
        if (content instanceof class_2588 translatable) {
            String key = translatable.method_11022();
            // Known raid translation keys
            return key.equals("event.minecraft.raid") ||
                   key.equals("event.minecraft.raid.victory") ||
                   key.equals("event.minecraft.raid.defeat") ||
                   key.startsWith("event.minecraft.raid") ||
                   key.contains("raid") ||
                   key.contains("pillager");
        }
        
        // Only use getString as absolute last resort for non-translatable text
        String nameString = name.getString().toLowerCase();
        return nameString.contains("raid") || nameString.contains("pillager") || nameString.contains("illager");
    }
}