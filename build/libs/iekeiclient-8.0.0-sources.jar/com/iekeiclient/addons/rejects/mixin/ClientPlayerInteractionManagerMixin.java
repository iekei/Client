package com.iekeiclient.addons.rejects.mixin;

import com.iekeiclient.addons.rejects.events.StopUsingItemEvent;
import com.iekeiclient.engine.IekeiClient;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {
    @Inject(method = "stopUsingItem", at = @At("HEAD"))
    public void onStopUsingItem(class_1657 player, CallbackInfo ci) {
        IekeiClient.EVENT_BUS.post(StopUsingItemEvent.get(player.method_6047()));
    }
}
