package com.iekeiclient.addons.rejects.mixin;

import com.iekeiclient.addons.rejects.modules.Rendering;
import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2518;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2518.class)
public abstract class StructureVoidBlockMixin extends class_2248 {
	public StructureVoidBlockMixin(class_2251 settings) {
		super(settings);
	}

	@Inject(at = @At("HEAD"), method = "getRenderType", cancellable = true)
	public void getRenderType(class_2680 state, CallbackInfoReturnable<class_2464> info) {
		info.setReturnValue(class_2464.field_11458);
	}

	@Override
	public boolean method_9522(class_2680 state, class_2680 neighbor, class_2350 facing) {
		Rendering renderingModule = Modules.get().get(Rendering.class);
		return !(renderingModule != null && renderingModule.renderStructureVoid());
	}
}
