package com.iekeiclient.addons.rejects.mixin;

import com.iekeiclient.addons.rejects.modules.SilentDisconnect;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.utils.player.ChatUtils;
import net.minecraft.class_2561;
import net.minecraft.class_8673;
import net.minecraft.class_9812;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.iekeiclient.engine.IekeiClient.mc;

@Mixin(class_8673.class)
public class ClientCommonNetwokHandlerMixin {
	@Inject(method = "onDisconnected", at = @At("HEAD"), cancellable = true)
	private void onDisconnected(class_9812 info, CallbackInfo ci) {
		if (Modules.get().isActive(SilentDisconnect.class) && mc.field_1687 != null && mc.field_1724 != null) {
			ChatUtils.info(class_2561.method_43471("disconnect.lost").getString() + ":");
			ChatUtils.sendMsg(info.comp_2853());
			ci.cancel();
		}
	}
}
