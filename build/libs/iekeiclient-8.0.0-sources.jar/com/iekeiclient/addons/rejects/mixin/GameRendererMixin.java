package com.iekeiclient.addons.rejects.mixin;

import com.iekeiclient.addons.rejects.modules.Rendering;
import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.class_279;
import net.minecraft.class_310;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public class GameRendererMixin {
    @Shadow @Final class_310 client;
    @Shadow @Final
    class_9922 pool;

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/WorldRenderer;drawEntityOutlinesFramebuffer()V", ordinal = 0))
	private void renderShader(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        Rendering renderingModule = Modules.get().get(Rendering.class);
        if (renderingModule == null) return;
        class_279 shader = renderingModule.getShaderEffect();

        if (shader != null) {
//            shader.setupDimensions(client.getWindow().getFramebufferWidth(), client.getWindow().getFramebufferHeight());
            shader.method_1258(this.client.method_1522(), this.pool);
        }
    }
}
