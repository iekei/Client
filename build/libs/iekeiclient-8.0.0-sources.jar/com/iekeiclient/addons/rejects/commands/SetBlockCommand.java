package com.iekeiclient.addons.rejects.commands;

import com.iekeiclient.addons.rejects.arguments.ClientPosArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import net.minecraft.class_2247;
import net.minecraft.class_2257;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import com.iekeiclient.engine.commands.Command;

public class SetBlockCommand extends Command {
    public SetBlockCommand() {
        super("setblock", "Sets client side blocks", "sblk");
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(argument("pos", ClientPosArgumentType.pos()).then(argument("block", class_2257.method_9653(REGISTRY_ACCESS)).executes(ctx -> {
            class_243 pos = ClientPosArgumentType.getPos(ctx, "pos");
            class_2680 blockState = ctx.getArgument("block", class_2247.class).method_9494();
            mc.field_1687.method_8501(new class_2338((int) pos.method_10216(), (int) pos.method_10214(), (int) pos.method_10215()), blockState);

            return SINGLE_SUCCESS;
        })));
    }
}
