package com.iekeiclient.addons.rejects.commands;

import com.iekeiclient.addons.rejects.arguments.EnumStringArgumentType;
import com.iekeiclient.addons.rejects.utils.GiveUtils;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.iekeiclient.engine.commands.Command;
import java.util.Collection;
import java.util.UUID;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2172;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9326;
import net.minecraft.class_9334;

import static com.iekeiclient.addons.rejects.utils.accounts.GetPlayerUUID.getUUID;

public class GiveCommand extends Command {

    private final Collection<String> PRESETS = GiveUtils.PRESETS.keySet();

    public GiveCommand() {
        super("give", "Gives items in creative", "item", "kit");
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        // TODO : finish this
        builder.then(literal("egg").executes(ctx -> {
            class_1799 inHand = mc.field_1724.method_6047();
            class_1799 item = new class_1799(class_1802.field_23255);
            class_2487 ct = new class_2487();

            if (inHand.method_7909() instanceof class_1747) {
                ct.method_10569("Time", 1);
                ct.method_10582("id", "minecraft:falling_block");
                class_2487 blockState = new class_2487();
                blockState.method_10582("Name", class_7923.field_41178.method_10221(inHand.method_7909()).toString());
                ct.method_10566("BlockState", blockState);

            } else {
                ct.method_10582("id", "minecraft:item");
                class_2487 itemTag = new class_2487();
                itemTag.method_10582("id", class_7923.field_41178.method_10221(inHand.method_7909()).toString());
                itemTag.method_10569("Count", inHand.method_7947());

                ct.method_10566("Item", itemTag);
            }
            class_2487 t = new class_2487();
            t.method_10566("EntityTag", ct);

            var changes = class_9326.method_57841()
                    .method_57854(class_9334.field_49631, inHand.method_7964())
                    .method_57854(class_9334.field_49628, class_9279.method_57456(t))
                    .method_57852();

            item.method_59692(changes);
            GiveUtils.giveItem(item);
            return SINGLE_SUCCESS;
        }));

        //TODO: allow for custom cords to place oob, though optional args
        builder.then(literal("holo").then(argument("message", StringArgumentType.greedyString()).executes(ctx -> {
            String message = ctx.getArgument("message", String.class).replace("&", "\247");
            class_1799 stack = new class_1799(class_1802.field_23255);
            class_2487 tag = new class_2487();
            class_2499 pos = new class_2499();

            pos.add(class_2489.method_23241(mc.field_1724.method_23317()));
            pos.add(class_2489.method_23241(mc.field_1724.method_23318()));
            pos.add(class_2489.method_23241(mc.field_1724.method_23321()));

            tag.method_10582("id", "minecraft:armor_stand");
            tag.method_10566("Pos", pos);
            tag.method_10556("Invisible", true);
            tag.method_10556("Invulnerable", true);
            tag.method_10556("NoGravity", true);
            tag.method_10556("CustomNameVisible", true);

            class_2487 customData = new class_2487();
            customData.method_10566("EntityTag", tag);

            var changes = class_9326.method_57841()
                    .method_57854(class_9334.field_49631, class_2561.method_43470(message))
                    .method_57854(class_9334.field_49628, class_9279.method_57456(customData))
                    .method_57852();

            stack.method_59692(changes);
            GiveUtils.giveItem(stack);
            return SINGLE_SUCCESS;
        })));

        //TODO, make invisible through potion effect
        builder.then(literal("bossbar").then(argument("message", StringArgumentType.greedyString()).executes(ctx -> {
            String message = ctx.getArgument("message", String.class).replace("&", "\247");
            class_1799 stack = new class_1799(class_1802.field_8727);
            class_2487 tag = new class_2487();
            tag.method_10556("NoAI", true);
            tag.method_10556("Silent", true);
            tag.method_10556("PersistenceRequired", true);
            tag.method_10566("id", class_2519.method_23256("minecraft:wither"));

            class_2487 customData = new class_2487();
            customData.method_10566("EntityTag", tag);

            var changes = class_9326.method_57841()
                    .method_57854(class_9334.field_49631, class_2561.method_43470(message))
                    .method_57854(class_9334.field_49628, class_9279.method_57456(customData))
                    .method_57852();
            stack.method_59692(changes);

            GiveUtils.giveItem(stack);
            return SINGLE_SUCCESS;
        })));

        // TODO : resolve textures, should be easy now that UUID is resolved
        builder.then(literal("head").then(argument("owner", StringArgumentType.greedyString()).executes(ctx -> {
            String playerName = ctx.getArgument("owner", String.class);
            class_1799 itemStack = new class_1799(class_1802.field_8575);
            UUID uuid = getUUID(playerName);
            class_2487 customData = new class_2487();
            customData.method_10566("SkullOwner", createSkullOwner(uuid, playerName, null));
            itemStack.method_57379(class_9334.field_49628, class_9279.method_57456(customData));

            GiveUtils.giveItem(itemStack);
            return SINGLE_SUCCESS;
        })));

        builder.then(literal("preset").then(argument("name", new EnumStringArgumentType(PRESETS)).executes(context -> {
            String name = context.getArgument("name", String.class);
            GiveUtils.giveItem(GiveUtils.getPreset(name));
            return SINGLE_SUCCESS;
        })));
    }

    private static class_2487 createSkullOwner(UUID uuid, String name, String textureValue) {
        class_2487 skullOwner = new class_2487();
        if (uuid != null) skullOwner.method_10582("Id", uuid.toString());
        if (name != null && !name.isEmpty()) skullOwner.method_10582("Name", name);

        if (textureValue != null && !textureValue.isEmpty()) {
            class_2487 properties = new class_2487();
            class_2499 textures = new class_2499();
            class_2487 value = new class_2487();
            value.method_10582("Value", textureValue);
            textures.add(value);
            properties.method_10566("textures", textures);
            skullOwner.method_10566("Properties", properties);
        }

        return skullOwner;
    }
}
