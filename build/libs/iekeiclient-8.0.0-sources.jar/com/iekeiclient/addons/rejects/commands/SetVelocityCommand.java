package com.iekeiclient.addons.rejects.commands;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import com.iekeiclient.engine.commands.Command;

public class SetVelocityCommand extends Command {
    public SetVelocityCommand() {
        super("set-velocity", "Sets player velocity", "velocity", "vel");
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(argument("y", DoubleArgumentType.doubleArg()).executes(ctx -> {
            var currentVelocity = mc.field_1724.method_18798();
            mc.field_1724.method_18800(currentVelocity.field_1352, DoubleArgumentType.getDouble(ctx, "y"), currentVelocity.field_1350);
            return SINGLE_SUCCESS;
        }));

        builder.then(argument("x", DoubleArgumentType.doubleArg()).then(argument("z", DoubleArgumentType.doubleArg()).executes(ctx -> {
            double x = DoubleArgumentType.getDouble(ctx, "x");
            double z = DoubleArgumentType.getDouble(ctx, "z");
            mc.field_1724.method_18800(x, mc.field_1724.method_18798().field_1351, z);
            return SINGLE_SUCCESS;
        })));

        builder.then(argument("x", DoubleArgumentType.doubleArg()).then(argument("y", DoubleArgumentType.doubleArg()).then(argument("z", DoubleArgumentType.doubleArg()).executes(ctx -> {
            double x = DoubleArgumentType.getDouble(ctx, "x");
            double y = DoubleArgumentType.getDouble(ctx, "y");
            double z = DoubleArgumentType.getDouble(ctx, "z");
            mc.field_1724.method_18800(x, y, z);
            return SINGLE_SUCCESS;
        }))));
    }
}
