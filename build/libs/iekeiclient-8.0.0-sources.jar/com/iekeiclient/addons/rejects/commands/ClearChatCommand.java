package com.iekeiclient.addons.rejects.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import com.iekeiclient.engine.commands.Command;

public class ClearChatCommand extends Command {
    public ClearChatCommand() {
        super("clear-chat", "Clears your chat.", "clear", "cls");
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            mc.field_1705.method_1743().method_1808(false);
            return SINGLE_SUCCESS;
        });
    }
}