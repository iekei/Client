package com.iekeiclient.addons.rejects.commands;

import com.iekeiclient.addons.rejects.arguments.ClientPosArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import net.minecraft.class_243;
import com.iekeiclient.engine.commands.Command;

public class TeleportCommand extends Command {


    public TeleportCommand() {
        super("teleport", "Sends a packet to the server with new position. Allows to teleport small distances.", "tp");
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(argument("pos", ClientPosArgumentType.pos()).executes(ctx -> {
            class_243 pos = ClientPosArgumentType.getPos(ctx, "pos");
            mc.field_1724.method_30634(pos.method_10216(), pos.method_10214(), pos.method_10215());
            return SINGLE_SUCCESS;
        }));

        builder.then(argument("pos", ClientPosArgumentType.pos()).then(argument("yaw", FloatArgumentType.floatArg()).then(argument("pitch", FloatArgumentType.floatArg()).executes(ctx -> {
            class_243 pos = ClientPosArgumentType.getPos(ctx, "pos");
            float yaw = FloatArgumentType.getFloat(ctx, "yaw");
            float pitch = FloatArgumentType.getFloat(ctx, "pitch");
            mc.field_1724.method_5641(pos.method_10216(), pos.method_10214(), pos.method_10215(), yaw, pitch);
            return SINGLE_SUCCESS;
        }))));
    }
}
