package com.iekeiclient.addons.rejects.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_639;
import net.minecraft.class_642;
import com.iekeiclient.engine.commands.Command;

public class ReconnectCommand extends Command {
    public ReconnectCommand() {
        super("reconnect", "Reconnects server.");
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            class_642 info = mc.method_1542() ? null : mc.method_1558();
            if (info != null) {
                mc.field_1687.method_8525(class_2561.method_43471("disconnect.genericReason"));
                class_412.method_36877(new class_500(new class_442()), mc,
                        class_639.method_2950(info.field_3761), info, false, null);
            }
            return SINGLE_SUCCESS;
        });
    }
}
