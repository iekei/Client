package com.iekeiclient.addons.rejects.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.iekeiclient.engine.commands.Command;
import org.lwjgl.BufferUtils;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_2561;

public class TerrainExport extends Command {

    private final static SimpleCommandExceptionType IO_EXCEPTION = new SimpleCommandExceptionType(class_2561.method_43470("An IOException occurred"));
    private final PointerBuffer filters;

    public TerrainExport() {
        super("terrain-export", "Export an area to the c++ terrain finder format (very popbob command).");

        filters = BufferUtils.createPointerBuffer(1);

        ByteBuffer txtFilter = MemoryUtil.memASCII("*.txt");

        filters.put(txtFilter);
        filters.rewind();
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.then(argument("distance", IntegerArgumentType.integer(1)).executes(context -> {
            int distance = IntegerArgumentType.getInteger(context, "distance");

            StringBuilder stringBuilder = new StringBuilder();
            for (int x = -distance; x <= distance; x++) {
                for (int z = -distance; z <= distance; z++) {
                    for (int y = distance; y >= -distance; y--) {
                        class_2338 pos = mc.field_1724.method_24515().method_10069(x, y, z);
                        if (mc.field_1687.method_8320(pos).method_26234(mc.field_1687, pos)) {
                            stringBuilder.append(String.format("%d, %d, %d\n", x + distance, y + distance, z + distance));
                        }
                    }
                }
            }

            String path = TinyFileDialogs.tinyfd_saveFileDialog("Save data", null, filters, null);
            if (path == null) throw IO_EXCEPTION.create();
            if (!path.endsWith(".txt"))
                path += ".txt";
            try {
                FileWriter file = new FileWriter(path);
                file.write(stringBuilder.toString().trim());
                file.close();
            } catch (IOException e) {
                throw IO_EXCEPTION.create();
            }

            return SINGLE_SUCCESS;
        }));
    }
}
