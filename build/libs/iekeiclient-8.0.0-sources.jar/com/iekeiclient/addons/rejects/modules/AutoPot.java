package com.iekeiclient.addons.rejects.modules;

//import baritone.api.BaritoneAPI;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import baritone.api.BaritoneAPI;
import com.iekeiclient.engine.events.entity.player.ItemUseCrosshairTargetEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.systems.modules.combat.AnchorAura;
import com.iekeiclient.engine.systems.modules.combat.BedAura;
import com.iekeiclient.engine.systems.modules.combat.CrystalAura;
import com.iekeiclient.engine.systems.modules.combat.KillAura;
import com.iekeiclient.engine.utils.Utils;
import com.iekeiclient.engine.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.List;

public class AutoPot extends Module {
    @SuppressWarnings("unchecked")
    private static final Class<? extends Module>[] AURAS = new Class[]{KillAura.class, CrystalAura.class, AnchorAura.class, BedAura.class};

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<List<class_1291>> usablePotions = sgGeneral.add(new StatusEffectListSetting.Builder()
            .name("potions-to-use")
            .description("The potions to use.")
            .defaultValue(
                class_1294.field_5915.comp_349(),
                class_1294.field_5910.comp_349()
            )
            .build()
    );

    private final Setting<Boolean> useSplashPots = sgGeneral.add(new BoolSetting.Builder()
            .name("splash-potions")
            .description("Allow the use of splash potions")
            .defaultValue(true)
            .build()
    );

    private final Setting<Integer> health = sgGeneral.add(new IntSetting.Builder()
            .name("health")
            .description("If health goes below this point, Healing potions will trigger.")
            .defaultValue(15)
            .min(0)
            .sliderMax(20)
            .build()
    );

    private final Setting<Boolean> pauseAuras = sgGeneral.add(new BoolSetting.Builder()
            .name("pause-auras")
            .description("Pauses all auras when eating.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> pauseBaritone = sgGeneral.add(new BoolSetting.Builder()
            .name("pause-baritone")
            .description("Pause baritone when eating.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> lookDown = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Forces you to rotate downwards when throwing splash potions.")
            .defaultValue(true)
            .build()
    );

    private int slot, prevSlot;
    private boolean drinking, splashing;
    private final List<Class<? extends Module>> wasAura = new ArrayList<>();
    private boolean wasBaritone;

    public AutoPot() {
        super(IekeiRejectsAddon.CATEGORY, "auto-pot", "Automatically Drinks Potions");
    }

    // TODO : Add option to scan whole inv - then either swap item to hotbar if full or just place in first empty slot
    // Note, Sometimes two or multiple splash pots are thrown - since the effect is not instant, the second pot is thrown before the effect of first is applied
    @Override
    public void onDeactivate() {
        stopPotionUsage();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724.method_6115()) return;
        for (class_1291 statusEffect : usablePotions.get()) {
            class_6880<class_1291> registryEntry = class_7923.field_41174.method_47983(statusEffect);
            if (!mc.field_1724.method_6059(registryEntry)) {
                slot = potionSlot(statusEffect);
                if (slot != -1) {
                    if (registryEntry == class_1294.field_5915 && ShouldDrinkHealth()) {
                        startPotionUse();
                        return;
                    } else if (registryEntry == class_1294.field_5915) {
                        return;
                    }
                    startPotionUse();
                }
            }
        }
    }

    @EventHandler
    private void onItemUseCrosshairTarget(ItemUseCrosshairTargetEvent event) {
        if (drinking) event.target = null;
    }

    private void setPressed(boolean pressed) {
        mc.field_1690.field_1904.method_23481(pressed);
    }

    private void drink() {
        changeSlot(slot);
        setPressed(true);
        if (!mc.field_1724.method_6115()) Utils.rightClick();

        drinking = true;
    }

    private void splash() {
        changeSlot(slot);
        setPressed(true);
        splashing = true;
    }

    private void stopPotionUsage() {
        changeSlot(prevSlot);
        setPressed(false);
        drinking = false;
        splashing = false;

        if (pauseAuras.get()) {
            for (Class<? extends Module> klass : AURAS) {
                Module module = Modules.get().get(klass);

                if (wasAura.contains(klass) && !module.isActive()) {
                    module.toggle();
                }
            }
        }
        if (pauseBaritone.get() && wasBaritone) {
            BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute("resume");
        }
    }

    private double trueHealth() {
        assert mc.field_1724 != null;
        return mc.field_1724.method_6032();
    }

    private void changeSlot(int slot) {
        mc.field_1724.method_31548().method_61496(slot);
        this.slot = slot;
    }

    //Sunk 7 hours into these checks, if i die blame checks
    private int potionSlot(class_1291 statusEffect) {
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960()) continue;
            if (stack.method_7909() == class_1802.field_8574 || (stack.method_7909() == class_1802.field_8436 && useSplashPots.get())) {
                class_1844 effects = stack.method_57353().method_58695(class_9334.field_49651, class_1844.field_49274);
                for (class_1293 effectInstance : effects.method_57397()) {
                    if (effectInstance.method_5586().equals(statusEffect.method_5567())) {
                        slot = i;
                        break;
                    }
                }
            }
        }
        return slot;
    }

    private void startPotionUse() {
        prevSlot = mc.field_1724.method_31548().method_67532();

        if (useSplashPots.get()) {
            if (lookDown.get()) {
                Rotations.rotate(mc.field_1724.method_36454(), 90);
                splash();
            } else {
                splash();
            }
        } else {
            drink();
        }
        wasAura.clear();
        if (pauseAuras.get()) {
            for (Class<? extends Module> klass : AURAS) {
                Module module = Modules.get().get(klass);

                if (module.isActive()) {
                    wasAura.add(klass);
                    module.toggle();
                }
            }
        }
        wasBaritone = false;
        if (pauseBaritone.get() && BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().isPathing()) {
            wasBaritone = true;
            BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute("pause");
        }
    }

    private boolean ShouldDrinkHealth() {
        return trueHealth() < health.get();
    }
}
