package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.systems.modules.player.AutoEat;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_12206;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class ObsidianFarm extends Module {

    private boolean allowBreakAgain;
    
    public ObsidianFarm() {
        super(IekeiRejectsAddon.CATEGORY, "obsidian-farm", "Auto obsidian farm(portals).");
    }

    @Override
    public void onActivate() {
        allowBreakAgain = true;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null) return;
        if (mc.field_1687 == null) return;
        if (mc.field_1761 == null) return;
        if (mc.field_1687.method_75598().method_75695(class_12206.field_63757, mc.field_1724.method_73189())) {
            allowBreakAgain = true;
            return;
        }
        if (!allowBreakAgain) return;
        if ((mc.field_1724.method_6115() || Modules.get().get(AutoEat.class).isActive()) && (mc.field_1724.method_6079().method_57826(class_9334.field_50075) || mc.field_1724.method_6047().method_57826(class_9334.field_50075)))
            return;

        if(mc.field_1724.method_6047().method_7909() != class_1802.field_22024 && mc.field_1724.method_6047().method_7909() != class_1802.field_8377) {
            int pickAxe = findPickAxe();
            if (pickAxe == -1) {
                if (this.isActive()) {
                    this.toggle();
                    return;
                }
            }
            mc.field_1724.method_31548().method_61496(pickAxe);
        }

        class_2338 obsidian = findObsidian();
        if (obsidian == null) return;

        mc.field_1761.method_2902(obsidian, class_2350.field_11036);
        mc.field_1724.method_6104(class_1268.field_5808);

        if (mc.field_1724.method_24515().method_10074().equals(obsidian) && mc.field_1687.method_8320(obsidian).method_26204() != class_2246.field_10540) {
            allowBreakAgain = false;
        }
    }

    private class_2338 findObsidian() {
        List<class_2338> blocksList = new ArrayList<>();

        for (int x = -2; x < 3; x++) {
            for (int z = -2; z < 3; z++) {
                int y = 2;
                class_2338 block = new class_2338(mc.field_1724.method_24515().method_10263() + x, mc.field_1724.method_24515().method_10264() + y, mc.field_1724.method_24515().method_10260() + z);
                blocksList.add(block);
            }
        }

        Optional<class_2338> result = blocksList.stream()
                .parallel()
                .filter(blockPos -> mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_10540)
                .min(Comparator.comparingDouble(blockPos -> mc.field_1724.method_5649(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260())));
        if (result.isPresent()) return result.get();

        blocksList.clear();
        for (int x = -2; x < 3; x++) {
            for (int z = -2; z < 3; z++) {
                for (int y = 3; y > -2; y--) {
                    class_2338 block = new class_2338(mc.field_1724.method_24515().method_10263() + x, mc.field_1724.method_24515().method_10264() + y, mc.field_1724.method_24515().method_10260() + z);
                    blocksList.add(block);
                }
            }
        }

        Optional<class_2338> result2 = blocksList.stream()
                .parallel()
                .filter(blockPos -> !mc.field_1724.method_24515().method_10074().equals(blockPos))
                .filter(blockPos -> mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_10540)
                .min(Comparator.comparingDouble(blockPos -> mc.field_1724.method_5649(blockPos.method_10263(), blockPos.method_10264(), blockPos.method_10260())));
        if (result2.isPresent()) return result2.get();

        if (mc.field_1687.method_8320(mc.field_1724.method_24515().method_10074()).method_26204() == class_2246.field_10540)
            return mc.field_1724.method_24515().method_10074();

        return null;
    }

    private int findPickAxe() {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_22024) return i;
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8377) return i;
        }
        return -1;
    }


}
