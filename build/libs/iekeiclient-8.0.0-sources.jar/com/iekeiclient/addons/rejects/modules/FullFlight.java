package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.utils.RejectsUtils;
import com.google.common.collect.Streams;
import com.iekeiclient.engine.events.entity.player.PlayerMoveEvent;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.mixin.ClientPlayerEntityAccessor;
import com.iekeiclient.engine.mixin.PlayerMoveC2SPacketAccessor;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2828;
import net.minecraft.class_4970;
import java.util.stream.Stream;

public class FullFlight extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgAntiKick = settings.createGroup("Anti Kick");

    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
            .name("speed")
            .description("Your speed when flying.")
            .defaultValue(0.3)
            .min(0.0)
            .sliderMax(10)
            .build()
    );

    private final Setting<Boolean> verticalSpeedMatch = sgGeneral.add(new BoolSetting.Builder()
            .name("vertical-speed-match")
            .description("Matches your vertical speed to your horizontal speed, otherwise uses vanilla ratio.")
            .defaultValue(false)
            .build()
    );

    private final Setting<AntiKickMode> antiKickMode = sgAntiKick.add(new EnumSetting.Builder<AntiKickMode>()
            .name("mode")
            .description("The mode for anti kick.")
            .defaultValue(AntiKickMode.PaperNew)
            .build()
    );

    public FullFlight() {
        super(IekeiRejectsAddon.CATEGORY, "fullflight", "FullFlight.");
    }

    private double calculateGround() {
        for (double ground = mc.field_1724.method_23318(); ground > 0D; ground -= 0.05) {
            class_238 box = mc.field_1724.method_5829();
            class_238 adjustedBox = box.method_989(0, ground - mc.field_1724.method_23318(), 0);

            Stream<class_265> blockCollisions = Streams.stream(mc.field_1687.method_20812(mc.field_1724, adjustedBox));

            if (blockCollisions.findAny().isPresent()) return ground + 0.05;
        }

        return 0F;
    }

    // Copied from ServerPlayNetworkHandler#isEntityOnAir
    private boolean isEntityOnAir(class_1297 entity) {
        return entity.method_73183().method_29546(entity.method_5829().method_1014(0.0625).method_1012(0.0, -0.55, 0.0)).allMatch(class_4970.class_4971::method_26215);
    }

    private int delayLeft = 20;
    private double lastPacketY = Double.MAX_VALUE;

    private boolean shouldFlyDown(double currentY, double lastY) {
        if (currentY >= lastY) {
            return true;
        } else return lastY - currentY < 0.03130D;
    }

    private void antiKickPacket(class_2828 packet, double currentY) {
        // maximum time we can be "floating" is 80 ticks, so 4 seconds max
        if (this.delayLeft <= 0 && this.lastPacketY != Double.MAX_VALUE &&
                shouldFlyDown(currentY, this.lastPacketY) && isEntityOnAir(mc.field_1724)) {
            // actual check is for >= -0.03125D, but we have to do a bit more than that
            // due to the fact that it's a bigger or *equal* to, and not just a bigger than
            ((PlayerMoveC2SPacketAccessor) packet).iekei$setY(lastPacketY - 0.03130D);
            lastPacketY -= 0.03130D;
            delayLeft = 20;
        } else {
            lastPacketY = currentY;
            if (!isEntityOnAir(mc.field_1724))
                delayLeft = 20;
        }
        if (delayLeft > 0) delayLeft--;
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (mc.field_1724.method_5854() == null || !(event.packet instanceof class_2828 packet) || antiKickMode.get() != AntiKickMode.PaperNew)
            return;

        double currentY = packet.method_12268(Double.MAX_VALUE);
        if (currentY != Double.MAX_VALUE) {
            antiKickPacket(packet, currentY);
        } else {
            // if the packet is a LookAndOnGround packet or an OnGroundOnly packet then we need to
            // make it a Full packet or a PositionAndOnGround packet respectively, so it has a Y value
            class_2828 fullPacket;
            if (packet.method_36172()) {
                fullPacket = new class_2828.class_2830(
                        mc.field_1724.method_23317(),
                        mc.field_1724.method_23318(),
                        mc.field_1724.method_23321(),
                        packet.method_12271(0),
                        packet.method_12270(0),
                        packet.method_12273(),
                        packet.method_61225()
                );
            } else {
                fullPacket = new class_2828.class_2829(
                        mc.field_1724.method_23317(),
                        mc.field_1724.method_23318(),
                        mc.field_1724.method_23321(),
                        packet.method_12273(),
                        packet.method_61225()
                );
            }
            event.cancel();
            antiKickPacket(fullPacket, mc.field_1724.method_23318());
            mc.method_1562().method_52787(fullPacket);
        }
    }

    private int floatingTicks = 0;

    @EventHandler
    private void onPlayerMove(PlayerMoveEvent event) {
        if (antiKickMode.get() == AntiKickMode.PaperNew) {
            // Resend movement packets
            ((ClientPlayerEntityAccessor) mc.field_1724).iekei$setTicksSinceLastPositionPacketSent(20);
        }
        if (floatingTicks >= 20) {
            switch (antiKickMode.get()) {
                case New -> {
                    class_238 box = mc.field_1724.method_5829();
                    class_238 adjustedBox = box.method_989(0, -0.4, 0);

                    Stream<class_265> blockCollisions = Streams.stream(mc.field_1687.method_20812(mc.field_1724, adjustedBox));

                    if (blockCollisions.findAny().isPresent()) break;

                    mc.method_1562().method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() - 0.4, mc.field_1724.method_23321(), mc.field_1724.method_24828(), mc.field_1724.field_5976));
                    mc.method_1562().method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), mc.field_1724.method_24828(), mc.field_1724.field_5976));
                }
                case Old -> {
                    class_238 box = mc.field_1724.method_5829();
                    class_238 adjustedBox = box.method_989(0, -0.4, 0);

                    Stream<class_265> blockCollisions = Streams.stream(mc.field_1687.method_20812(mc.field_1724, adjustedBox));

                    if (blockCollisions.findAny().isPresent()) break;

                    double ground = calculateGround();
                    double groundExtra = ground + 0.1D;

                    for (double posY = mc.field_1724.method_23318(); posY > groundExtra; posY -= 4D) {
                        mc.method_1562().method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), posY, mc.field_1724.method_23321(), true, mc.field_1724.field_5976));

                        if (posY - 4D < groundExtra) break; // Prevent next step
                    }

                    mc.method_1562().method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), groundExtra, mc.field_1724.method_23321(), true, mc.field_1724.field_5976));

                    for (double posY = groundExtra; posY < mc.field_1724.method_23318(); posY += 4D) {
                        mc.method_1562().method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), posY, mc.field_1724.method_23321(), mc.field_1724.method_24828(), mc.field_1724.field_5976));

                        if (posY + 4D > mc.field_1724.method_23318()) break; // Prevent next step
                    }

                    mc.method_1562().method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), mc.field_1724.method_24828(), mc.field_1724.field_5976));

                }
            }
            floatingTicks = 0;
        }

        float ySpeed = RejectsUtils.fullFlightMove(event, speed.get(), verticalSpeedMatch.get());

        if (floatingTicks < 20)
            if (ySpeed >= -0.1)
                floatingTicks++;
            else if (antiKickMode.get() == AntiKickMode.New)
                floatingTicks = 0;
    }

    public enum AntiKickMode {
        Old,
        New,
        PaperNew,
        None
    }
}