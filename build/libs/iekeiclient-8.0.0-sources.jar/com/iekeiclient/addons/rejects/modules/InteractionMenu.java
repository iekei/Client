package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.gui.screens.InteractionScreen;
import com.iekeiclient.addons.rejects.settings.StringMapSetting;
import com.iekeiclient.engine.gui.utils.StarscriptTextBoxRenderer;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.misc.Keybind;
import com.iekeiclient.engine.utils.misc.IekeiStarscript;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import org.meteordev.starscript.value.Value;
import org.meteordev.starscript.value.ValueMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_863;

public class InteractionMenu extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgStyle = settings.createGroup("Style");

    private final Setting<Set<class_1299<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
            .name("entities")
            .description("Entities")
            .defaultValue(class_1299.field_6097)
            .build()
    );
    public final Setting<Keybind> keybind = sgGeneral.add(new KeybindSetting.Builder()
            .name("keybind")
            .description("The keybind to open.")
            .action(this::onKey)
            .build()
    );
    public final Setting<Boolean> useCrosshairTarget = sgGeneral.add(new BoolSetting.Builder()
            .name("use-crosshair-target")
            .description("Use crosshair target.")
            .defaultValue(false)
            .build()
    );

    // Style
    public final Setting<SettingColor> selectedDotColor = sgStyle.add(new ColorSetting.Builder()
            .name("selected-dot-color")
            .description("Color of the dot when selected.")
            .defaultValue(new SettingColor(76, 255, 0))
            .build()
    );
    public final Setting<SettingColor> dotColor = sgStyle.add(new ColorSetting.Builder()
            .name("dot-color")
            .description("Color of the dot when.")
            .defaultValue(new SettingColor(0, 148, 255))
            .build()
    );
    public final Setting<SettingColor> backgroundColor = sgStyle.add(new ColorSetting.Builder()
            .name("background-color")
            .description("Color of the background.")
            .defaultValue(new SettingColor(128, 128, 128, 128))
            .build()
    );
    public final Setting<SettingColor> borderColor = sgStyle.add(new ColorSetting.Builder()
            .name("border-color")
            .description("Color of the border.")
            .defaultValue(new SettingColor(0, 0, 0))
            .build()
    );
    public final Setting<SettingColor> textColor = sgStyle.add(new ColorSetting.Builder()
            .name("text-color")
            .description("Color of the text.")
            .defaultValue(new SettingColor(255, 255, 255))
            .build()
    );

    public final Setting<Map<String, String>> messages = sgGeneral.add(new StringMapSetting.Builder()
            .name("messages")
            .description("Messages.")
            .renderer(StarscriptTextBoxRenderer.class)
            .build()
    );

    public InteractionMenu() {
        super(IekeiRejectsAddon.CATEGORY, "interaction-menu", "An interaction screen when looking at an entity.");
        IekeiStarscript.ss.set("entity", () -> wrap(InteractionScreen.interactionMenuEntity));
    }

    public void onKey() {
        if (mc.field_1724 == null || mc.field_1755 != null) return;
        class_1297 e = null;
        if (useCrosshairTarget.get()) {
            e = mc.field_1692;
        } else {
            Optional<class_1297> lookingAt = class_863.method_23101(mc.field_1724, 20);
            if (lookingAt.isPresent()) {
                e = lookingAt.get();
            }
        }

        if (e == null) return;
        if (entities.get().contains(e.method_5864())) {
            mc.method_1507(new InteractionScreen(e, this));
        }
    }

    private static Value wrap(class_1297 entity) {
        if (entity == null) {
            return Value.map(new ValueMap()
                    .set("_toString", Value.null_())
                    .set("health", Value.null_())
                    .set("pos", Value.map(new ValueMap()
                            .set("_toString", Value.null_())
                            .set("x", Value.null_())
                            .set("y", Value.null_())
                            .set("z", Value.null_())
                    ))
                    .set("uuid", Value.null_())
            );
        }
        return Value.map(new ValueMap()
                .set("_toString", Value.string(entity.method_5477().getString()))
                .set("health", Value.number(entity instanceof class_1309 e ? e.method_6032() : 0))
                .set("pos", Value.map(new ValueMap()
                        .set("_toString", posString(entity.method_23317(), entity.method_23318(), entity.method_23321()))
                        .set("x", Value.number(entity.method_23317()))
                        .set("y", Value.number(entity.method_23318()))
                        .set("z", Value.number(entity.method_23321()))
                ))
                .set("uuid", Value.string(entity.method_5845()))
        );
    }

    private static Value posString(double x, double y, double z) {
        return Value.string(String.format("X: %.0f Y: %.0f Z: %.0f", x, y, z));
    }
}
