package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.EnumSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_9960;

public class Rendering extends Module {

    public enum Shader {
        None,
        Blur,
        Creeper,
        Invert,
        Spider,
    }

    private final SettingGroup sgInvisible = settings.createGroup("Invisible");
    private final SettingGroup sgFun = settings.createGroup("Fun");

    private final Setting<Boolean> structureVoid = sgInvisible.add(new BoolSetting.Builder()
			.name("structure-void")
			.description("Render structure void blocks.")
			.defaultValue(true)
            .onChanged(onChanged -> {
                if(this.isActive()) {
                    mc.field_1769.method_3279();
                }
            })
			.build()
	);

    private final Setting<Shader> shaderEnum = sgFun.add(new EnumSetting.Builder<Shader>()
        .name("shader")
        .description("Select which shader to use")
        .defaultValue(Shader.None)
        .onChanged(this::onChanged)
        .build()
    );

    private final Setting<Boolean> dinnerbone = sgFun.add(new BoolSetting.Builder()
			.name("dinnerbone")
			.description("Apply dinnerbone effects to all entities")
			.defaultValue(false)
			.build()
	);

    private final Setting<Boolean> deadmau5Ears = sgFun.add(new BoolSetting.Builder()
			.name("deadmau5-ears")
			.description("Add deadmau5 ears to all players")
			.defaultValue(false)
			.build()
	);

    private final Setting<Boolean> christmas = sgFun.add(new BoolSetting.Builder()
			.name("chrismas")
			.description("Chistmas chest anytime")
			.defaultValue(false)
			.build()
	);
    
    private class_279 shader = null;
    
    public Rendering() {
        super(IekeiRejectsAddon.CATEGORY, "rendering", "Various Render Tweaks");
    }

    @Override
    public void onActivate() {
        mc.field_1769.method_3279();
    }

    @Override
    public void onDeactivate() {
        mc.field_1769.method_3279();
    }

    public void onChanged(Shader s) {
        if (mc.field_1687 == null) return;
        String name = s.toString().toLowerCase();

        if (name.equals("none")) {
            this.shader = null;
            return;
        }

        class_2960 shaderID = class_2960.method_60656(name);
        this.shader = mc.method_62887().method_62941(shaderID, class_9960.field_53902);
    }

    public boolean renderStructureVoid() {
        return this.isActive() && structureVoid.get();
    }

    public class_279 getShaderEffect() {
        if (!this.isActive()) return null;
        return shader;
    }

    public boolean dinnerboneEnabled() {
        if (!this.isActive()) return false;
        return dinnerbone.get();
    }

    public boolean deadmau5EarsEnabled() {
        if (!this.isActive()) return false;
        return deadmau5Ears.get();
    }

    public boolean chistmas() {
        if (!this.isActive()) return false;
        return christmas.get();
    }
}
