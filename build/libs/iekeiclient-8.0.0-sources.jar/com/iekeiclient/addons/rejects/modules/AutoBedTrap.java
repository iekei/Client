package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.misc.Pool;
import com.iekeiclient.engine.utils.player.FindItemResult;
import com.iekeiclient.engine.utils.player.InvUtils;
import com.iekeiclient.engine.utils.world.BlockIterator;
import com.iekeiclient.engine.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1747;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AutoBedTrap extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    
    private final Setting<Integer> bpt = sgGeneral.add(new IntSetting.Builder()
            .name("blocks-per-tick")
            .description("How many blocks to place per tick")
            .defaultValue(2)
            .min(1)
            .sliderMax(8)
            .build()
    );
    
    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Rotates when placing")
            .defaultValue(true)
            .build()
    );

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
            .name("range")
            .description("The break range.")
            .defaultValue(4)
            .min(0)
            .build()
    );

    private final Setting<List<class_2248>> blockTypes = sgGeneral.add(new BlockListSetting.Builder()
        .name("blocks")
        .description("The blocks you bedtrap with.")
        .defaultValue(Arrays.asList(class_2246.field_10540))
        .build()
    );

    private final Pool<class_2338.class_2339> blockPosPool = new Pool<>(class_2338.class_2339::new);
    private final List<class_2338.class_2339> blocks = new ArrayList<>();

    int cap = 0;

    public AutoBedTrap() {
        super(IekeiRejectsAddon.CATEGORY, "auto-bed-trap", "Automatically places obsidian around beds");
    }

    @Override
    public void onDeactivate() {
        for (class_2338.class_2339 blockPos : blocks) blockPosPool.free(blockPos);
        blocks.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {

        BlockIterator.register((int) Math.ceil(range.get()), (int) Math.ceil(range.get()), (blockPos, blockState) -> {
            if (!BlockUtils.canBreak(blockPos, blockState)) return;

            if (!(blockState.method_26204() instanceof class_2244)) return;

            blocks.add(blockPosPool.get().method_10101(blockPos));
        });

    }

    @EventHandler
    private void onTickPost(TickEvent.Post event) {
        boolean noBlocks = false;
        for (class_2338 blockPos : blocks) {
            if (!placeTickAround(blockPos)) {
                noBlocks = true;
                break;
            }
        }
        if (noBlocks && isActive()) toggle(); 
    }

    public boolean placeTickAround(class_2338 block) {
        for (class_2338 b : new class_2338[]{
                block.method_10084(), block.method_10067(),
                block.method_10095(), block.method_10072(),
                block.method_10078(), block.method_10074()}) {

            if (cap >= bpt.get()) {
                cap = 0;
                return true;
            }

            if (blockTypes.get().contains(mc.field_1687.method_8320(b).method_26204())) return true;

            FindItemResult findBlock = InvUtils.findInHotbar((item) -> {
                if (!(item.method_7909() instanceof class_1747)) return false;
                class_1747 bitem = (class_1747)item.method_7909();
                return blockTypes.get().contains(bitem.method_7711());
            });
            if (!findBlock.found()) {
                error("No specified blocks found. Disabling.");
                return false;
            }


            if (BlockUtils.place(b, findBlock, rotate.get(), 10, false)) {
                cap++;
                if (cap >= bpt.get()) {
                    return true;
                }
            }
        }
        cap = 0;
        return true;
    }
}
