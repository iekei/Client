package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.mixininterface.IInventoryTweaks;
import com.iekeiclient.engine.IekeiClient;
import com.iekeiclient.engine.events.packets.InventoryEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.systems.modules.misc.InventoryTweaks;
import com.iekeiclient.engine.utils.Utils;
import com.iekeiclient.engine.utils.player.Rotations;
import com.iekeiclient.engine.utils.player.SlotUtils;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.orbit.EventPriority;
import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

public class ChestAura extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Rotates when opening.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
            .name("range")
            .description("The interact range.")
            .defaultValue(4)
            .min(0)
            .build()
    );

    private final Setting<List<class_2591<?>>> blocks = sgGeneral.add(new StorageBlockListSetting.Builder()
            .name("blocks")
            .description("The blocks you open.")
            .defaultValue(class_2591.field_11914)
            .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("Delay between opening chests.")
            .defaultValue(10)
            .sliderMax(20)
            .build()
    );

    private final Setting<Integer> forget = sgGeneral.add(new IntSetting.Builder()
            .name("forget-after")
            .description("How many ticks to wait before forgetting which chest to open. 0 for infinite.")
            .defaultValue(0)
            .min(0)
            .sliderMax(1000)
            .build()
    );

    private final Setting<CloseCondition> closeCondition = sgGeneral.add(new EnumSetting.Builder<CloseCondition>()
            .name("close-condition")
            .defaultValue(CloseCondition.IfEmpty)
            .description("When to close the chest screen.")
            .build()
    );

    private final Map<class_2338, Integer> openedBlocks = new HashMap<>();
    private final CloseListener closeListener = new CloseListener();

    private int timer = 0;

    public ChestAura() {
        super(IekeiRejectsAddon.CATEGORY, "chest-aura", "Automatically open chests in radius");
    }

    @Override
    public void onActivate() {
        timer = 0;
        openedBlocks.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (forget.get() != 0) {
            for (Map.Entry<class_2338, Integer> e : new HashMap<>(openedBlocks).entrySet()) {
                int time = e.getValue();
                if (time > forget.get()) openedBlocks.remove(e.getKey());
                else openedBlocks.replace(e.getKey(), time + 1);
            }
        }

        if (timer > 0 && mc.field_1755 != null) return;

        for (class_2586 block : Utils.blockEntities()) {
            if (!blocks.get().contains(block.method_11017())) continue;
            if (mc.field_1724.method_33571().method_1022(class_243.method_24953(block.method_11016())) >= range.get()) continue;

            class_2338 pos = block.method_11016();
            if (openedBlocks.containsKey(pos)) continue;

            Runnable click = () -> mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, new class_3965(new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260()), class_2350.field_11036, pos, false));
            if (rotate.get()) Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), click);
            else click.run();

            // Double chest compatibility
            class_2680 state = block.method_11010();
            if (state.method_28498(class_2281.field_10770)) {
                class_2350 direction = state.method_11654(class_2281.field_10768);
                switch (state.method_11654(class_2281.field_10770)) {
                    case field_12574 -> openedBlocks.put(pos.method_10093(direction.method_10170()), 0);
                    case field_12571 -> openedBlocks.put(pos.method_10093(direction.method_10160()), 0);
                }
            }

            openedBlocks.put(pos, 0);
            timer = delay.get();
            IekeiClient.EVENT_BUS.subscribe(closeListener);
            break;
        }
        timer--;
    }

    public class CloseListener {
        @EventHandler(priority = EventPriority.HIGH)
        private void onInventory(InventoryEvent event) {
            class_1703 handler = mc.field_1724.field_7512;
            if (event.packet.comp_3837() == handler.field_7763) {
                switch (closeCondition.get()) {
                    case IfEmpty -> {
                        class_2371<class_1799> stacks = class_2371.method_10211();
                        IntStream.range(0, SlotUtils.indexToId(SlotUtils.MAIN_START)).mapToObj(handler.field_7761::get).map(class_1735::method_7677).forEach(stacks::add);
                        if (stacks.stream().allMatch(class_1799::method_7960)) mc.field_1724.method_7346();
                    }
                    case Always -> mc.field_1724.method_7346();
                    case AfterSteal ->
                            ((IInventoryTweaks) Modules.get().get(InventoryTweaks.class)).stealCallback(() -> mc.execute(() -> mc.field_1724.method_7346()));
                }
            }
            IekeiClient.EVENT_BUS.unsubscribe(this);
        }
    }

    public enum CloseCondition {
        Always,
        IfEmpty,
        AfterSteal,
        Never
    }
}
