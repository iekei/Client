package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.DoubleSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_1646;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2304;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import java.util.List;

public class AutoSoup extends Module {
    private static final String desc = "Automatically eats soup when your health is low on some servers.";

    public AutoSoup() {
        super(IekeiRejectsAddon.CATEGORY, "auto-soup", desc);
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<Double> health = sgGeneral.add(new DoubleSetting.Builder()
            .name("health")
            .description("Eats a soup when your health reaches this value or falls below it.")
            .defaultValue(6.5)
            .min(0.5)
            .sliderMin(0.5)
            .sliderMax(9.5)
            .build()
    );

    private int oldSlot = -1;

    @Override
    public void onDeactivate() {
        stopIfEating();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        // sort empty bowls
        for (int i = 0; i < 36; i++) {
            // filter out non-bowl items and empty bowl slot
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack == null || stack.method_7909() != class_1802.field_8428 || i == 9)
                continue;

            // check if empty bowl slot contains a non-bowl item
            class_1799 emptyBowlStack = mc.field_1724.method_31548().method_5438(9);
            boolean swap = !emptyBowlStack.method_7960()
                    && emptyBowlStack.method_7909() != class_1802.field_8428;

            // place bowl in empty bowl slot
            InvUtils.click().slot(i < 9 ? 36 + i : i);
            InvUtils.click().slot(9);

            // place non-bowl item from empty bowl slot in current slot
            if (swap)
                InvUtils.click().slot(i < 9 ? 36 + i : i);
        }

        // search soup in hotbar
        int soupInHotbar = findSoup(0, 9);

        // check if any soup was found
        if (soupInHotbar != -1) {
            // check if player should eat soup
            if (!shouldEatSoup()) {
                stopIfEating();
                return;
            }

            // save old slot
            if (oldSlot == -1)
                oldSlot = mc.field_1724.method_31548().method_67532();

            // set slot
            mc.field_1724.method_31548().method_61496(soupInHotbar);

            // eat soup
            mc.field_1690.field_1904.method_23481(true);
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);

            return;
        }

        stopIfEating();

        // search soup in inventory
        int soupInInventory = findSoup(9, 36);

        // move soup in inventory to hotbar
        if (soupInInventory != -1)
            InvUtils.quickSwap().slot(soupInInventory);
    }

    private int findSoup(int startSlot, int endSlot) {
        List<class_1792> stews = List.of(class_1802.field_8308, class_1802.field_8208, class_1802.field_8515);

        for (int i = startSlot; i < endSlot; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);

            if (stack != null && stews.contains(stack.method_7909()))
                return i;
        }

        return -1;
    }

    private boolean shouldEatSoup() {
        // check health
        if (mc.field_1724.method_6032() > health.get() * 2F)
            return false;

        // check for clickable objects
        return !isClickable(mc.field_1765);
    }

    private boolean isClickable(class_239 hitResult) {
        switch (hitResult) {
            case null -> {
                return false;
            }
            case class_3966 entityHitResult -> {
                class_1297 entity = ((class_3966) mc.field_1765).method_17782();
                return entity instanceof class_1646
                        || entity instanceof class_1321;
            }
            case class_3965 blockHitResult -> {
                class_2338 pos = ((class_3965) mc.field_1765).method_17777();
                if (pos == null)
                    return false;

                class_2248 block = mc.field_1687.method_8320(pos).method_26204();
                return block instanceof class_2237
                        || block instanceof class_2304;
            }
            default -> {
            }
        }

        return false;
    }

    private void stopIfEating() {
        // check if eating
        if (oldSlot == -1)
            return;

        // stop eating
        mc.field_1690.field_1904.method_23481(false);

        // reset slot
        mc.field_1724.method_31548().method_61496(oldSlot);
        oldSlot = -1;
    }

}
