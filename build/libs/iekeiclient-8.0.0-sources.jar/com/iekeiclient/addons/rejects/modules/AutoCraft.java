package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.ItemListSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.Utils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10295;
import net.minecraft.class_10297;
import net.minecraft.class_10363;
import net.minecraft.class_1713;
import net.minecraft.class_1714;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_516;
import java.util.Arrays;
import java.util.List;

public class AutoCraft extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<List<class_1792>> items = sgGeneral.add(new ItemListSetting.Builder()
        .name("items")
        .description("Items you want to get crafted.")
        .defaultValue(List.of())
        .build()
    );

    private final Setting<Boolean> antiDesync = sgGeneral.add(new BoolSetting.Builder()
            .name("anti-desync")
            .description("Try to prevent inventory desync.")
            .defaultValue(false)
            .build()
    );
    
    private final Setting<Boolean> craftAll = sgGeneral.add(new BoolSetting.Builder()
            .name("craft-all")
            .description("Crafts maximum possible amount amount per craft (shift-clicking)")
            .defaultValue(false)
            .build()
    );
    
    private final Setting<Boolean> drop = sgGeneral.add(new BoolSetting.Builder()
            .name("drop")
            .description("Automatically drops crafted items (useful for when not enough inventory space)")
            .defaultValue(false)
            .build()
    );

    public AutoCraft() {
        super(IekeiRejectsAddon.CATEGORY, "auto-craft", "Automatically crafts items.");
    }
    
    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!Utils.canUpdate() || mc.field_1761 == null) return;

        if (items.get().isEmpty()) return;

        if (!(mc.field_1724.field_7512 instanceof class_1714)) return;

        if (antiDesync.get()) 
            mc.field_1724.method_31548().method_7381();

        // Danke schön GhostTypes
        // https://github.com/GhostTypes/orion/blob/main/src/main/java/me/ghosttypes/orion/modules/main/AutoBedCraft.java
        class_1714 currentScreenHandler = (class_1714) mc.field_1724.field_7512;
        List<class_1792> itemList = items.get();
        List<class_516> recipeResultCollectionList  = mc.field_1724.method_3130().method_1393();
        for (class_516 recipeResultCollection : recipeResultCollectionList) {
            // Get craftable recipes only
            List<class_10297> craftRecipes = recipeResultCollection.method_64885(class_516.class_9937.field_52848);
            for (class_10297 recipe : craftRecipes) {
                class_10295 recipeDisplay = recipe.comp_3263();
                List<class_1799> resultStacks = recipeDisplay.comp_3258().method_64738(class_10363.method_65008(mc.field_1687));
                for (class_1799 resultStack : resultStacks) {
                    // Check if the result item is in the item list
                    if (!itemList.contains(resultStack.method_7909())) continue;

                    mc.field_1761.method_2912(currentScreenHandler.field_7763, recipe.comp_3262(), craftAll.get());
                    mc.field_1761.method_2906(currentScreenHandler.field_7763, 0, 1,
                            drop.get() ? class_1713.field_7795 : class_1713.field_7794, mc.field_1724);
                }
            }
        }
    }
}
