package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.utils.RejectsUtils;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.friends.Friends;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.Utils;
import com.iekeiclient.engine.utils.entity.EntityUtils;
import com.iekeiclient.engine.utils.entity.SortPriority;
import com.iekeiclient.engine.utils.entity.Target;
import com.iekeiclient.engine.utils.entity.TargetUtils;
import com.iekeiclient.engine.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_3532;
import org.joml.Vector3d;

import java.util.Set;

public class AimAssist extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgSpeed = settings.createGroup("Aim Speed");

    // General

    private final Setting<Set<class_1299<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
            .name("entities")
            .description("Entities to aim at.")
            .defaultValue(class_1299.field_6097)
            .build()
    );

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
            .name("range")
            .description("The range at which an entity can be targeted.")
            .defaultValue(5)
            .min(0)
            .build()
    );

    private final Setting<Double> fov = sgGeneral.add(new DoubleSetting.Builder()
            .name("fov")
            .description("Will only aim entities in the fov.")
            .defaultValue(360)
            .min(0)
            .max(360)
            .build()
    );

    private final Setting<Boolean> ignoreWalls = sgGeneral.add(new BoolSetting.Builder()
            .name("ignore-walls")
            .description("Whether or not to ignore aiming through walls.")
            .defaultValue(false)
            .build()
    );

    private final Setting<SortPriority> priority = sgGeneral.add(new EnumSetting.Builder<SortPriority>()
            .name("priority")
            .description("How to filter targets within range.")
            .defaultValue(SortPriority.LowestHealth)
            .build()
    );

    private final Setting<Target> bodyTarget = sgGeneral.add(new EnumSetting.Builder<Target>()
            .name("aim-target")
            .description("Which part of the entities body to aim at.")
            .defaultValue(Target.Body)
            .build()
    );

    // Aim Speed

    private final Setting<Boolean> instant = sgSpeed.add(new BoolSetting.Builder()
            .name("instant-look")
            .description("Instantly looks at the entity.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Double> speed = sgSpeed.add(new DoubleSetting.Builder()
            .name("speed")
            .description("How fast to aim at the entity.")
            .defaultValue(5)
            .min(0)
            .visible(() -> !instant.get())
            .build()
    );

    private final Vector3d vec3d1 = new Vector3d();
    private class_1297 target;

    public AimAssist() {
        super(IekeiRejectsAddon.CATEGORY, "aim-assist", "Automatically aims at entities.");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        target = TargetUtils.get(entity -> {
            if (!entity.method_5805()) return false;
            if (!PlayerUtils.isWithin(entity, range.get())) return false;
            if (!ignoreWalls.get() && !PlayerUtils.canSeeEntity(entity)) return false;
            if (entity == mc.field_1724 || !entities.get().contains(entity.method_5864())) return false;
            if (entity instanceof class_1657 && !Friends.get().shouldAttack((class_1657) entity)) return false;
            return RejectsUtils.inFov(entity, fov.get());
        }, priority.get());
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (target != null) aim(target, event.tickDelta, instant.get());
    }

    private void aim(class_1297 target, double delta, boolean instant) {
        Utils.set(vec3d1, target, delta);

        switch (bodyTarget.get()) {
            case Head -> vec3d1.add(0, target.method_18381(target.method_18376()), 0);
            case Body -> vec3d1.add(0, target.method_18381(target.method_18376()) / 2, 0);
        }

        double deltaX = vec3d1.x - mc.field_1724.method_23317();
        double deltaZ = vec3d1.z - mc.field_1724.method_23321();
        double deltaY = vec3d1.y - (mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()));

        // Yaw
        double angle = Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90;
        double deltaAngle;
        double toRotate;

        if (instant) {
            mc.field_1724.method_36456((float) angle);
        } else {
            deltaAngle = class_3532.method_15338(angle - mc.field_1724.method_36454());
            toRotate = speed.get() * (deltaAngle >= 0 ? 1 : -1) * delta;
            if ((toRotate >= 0 && toRotate > deltaAngle) || (toRotate < 0 && toRotate < deltaAngle))
                toRotate = deltaAngle;
            mc.field_1724.method_36456(mc.field_1724.method_36454() + (float) toRotate);
        }

        // Pitch
        double idk = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        angle = -Math.toDegrees(Math.atan2(deltaY, idk));

        if (instant) {
            mc.field_1724.method_36457((float) angle);
        } else {
            deltaAngle = class_3532.method_15338(angle - mc.field_1724.method_36455());
            toRotate = speed.get() * (deltaAngle >= 0 ? 1 : -1) * delta;
            if ((toRotate >= 0 && toRotate > deltaAngle) || (toRotate < 0 && toRotate < deltaAngle))
                toRotate = deltaAngle;
            mc.field_1724.method_36457(mc.field_1724.method_36455() + (float) toRotate);
        }
    }

    @Override
    public String getInfoString() {
        return EntityUtils.getName(target);
    }
}
