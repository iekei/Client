package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1706;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2480;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_342;
import net.minecraft.class_471;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import java.util.List;

public class AutoRename extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<List<class_1792>> items = sgGeneral.add(new ItemListSetting.Builder()
            .name("items")
            .description("Items you want to rename.")
            .defaultValue(List.of())
            .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("How many ticks to wait between actions.")
            .defaultValue(2)
            .min(0)
            .sliderMax(40)
            .build()
    );

    private final Setting<String> name = sgGeneral.add(new StringSetting.Builder()
            .name("name")
            .description("Name for an item, empty for reverting name to default.")
            .defaultValue("")
            .build()
    );

    private final Setting<Boolean> firstItemInContainer = sgGeneral.add(new BoolSetting.Builder()
            .name("first-item-in-container")
            .description("Will rename containers based on name of first item in it.")
            .defaultValue(false)
            .build()
    );

    private final Setting<List<class_1792>> containerItems = sgGeneral.add(new ItemListSetting.Builder()
            .name("container-items")
            .description("Items to treat as containers.")
            .defaultValue(List.of())
            .build()
    );

    public AutoRename() {
        super(IekeiRejectsAddon.CATEGORY, "auto-rename", "Automatically renames items.");
    }

    private int delayLeft = 0;
    @EventHandler
    private void onTick(TickEvent.Post ignoredEvent) {
        if (mc.field_1761 == null) return;
        if (items.get().isEmpty()) return;
        if (!(mc.field_1724.field_7512 instanceof class_1706)) return;

        if (delayLeft > 0) {
            delayLeft--;
            return;
        } else {
            delayLeft = delay.get();
        }

        var slot0 = mc.field_1724.field_7512.method_7611(0);
        var slot1 = mc.field_1724.field_7512.method_7611(1);
        var slot2 = mc.field_1724.field_7512.method_7611(2);
        if (slot1.method_7681()) {
//            info("Slot 1 occupied");
            return; // touching anything
        }
        if (slot2.method_7681()) {
            if (mc.field_1724.field_7520 < 1) {
//                info("No exp");
            } else {
//                info("Extracting named");
                extractNamed();
            }
        } else {
            if (slot0.method_7681()) {
//                info("Renaming");
                renameItem(slot0.method_7677());
            } else {
//                info("Populating");
                populateAnvil();
            }
        }
    }

    private void renameItem(class_1799 s) {
        var setname = "";
        if (firstItemInContainer.get() && containerItems.get().contains(s.method_7909())) {
            setname = getFirstItemName(s);
        } else {
            setname = name.get();
        }
//        info("Renaming");
        if (mc.field_1755 == null || !(mc.field_1755 instanceof class_471)) {
            error("Not anvil screen");
            toggle();
            return;
        }
        var widgets = mc.field_1755.method_25396();
        var input = (class_342)widgets.get(0);
        input.method_1852(setname);
    }

    private String getFirstItemName(class_1799 stack) {
        class_1792 item = stack.method_7909();
        if (!(item instanceof class_1747 && ((class_1747) item).method_7711() instanceof class_2480)) {
            return "";
        }
        class_2487 compound = stack.method_58695(class_9334.field_49628, class_9279.field_49302).method_57461();
        if (compound == null) return "";
        class_2487 blockEntityTag = compound.method_10562("BlockEntityTag").orElse(null);
        if (blockEntityTag == null) return "";
        class_2499 list = blockEntityTag.method_10554("Items").orElse(null);
        if (list == null || list.isEmpty()) return "";
        var minslot = Byte.MAX_VALUE;
        var name = "";
        for (int i = 0; i < list.size(); i++) {
            var invItemOptional = list.method_10602(i);
            if (invItemOptional.isEmpty()) continue;
            var invItem = invItemOptional.get();
            var invSlot = invItem.method_10571("Slot").orElse(Byte.MAX_VALUE);
            if (minslot < invSlot) {
                continue;
            }
            var itemId = invItem.method_10558("id");
            if (itemId.isEmpty()) {
                continue;
            }
            name = String.valueOf(invItem.method_10562("Name"));
            minslot = invSlot;
        }
        return name;
    }

    private void extractNamed() {
        var to = -1;
        var inv = mc.field_1724.field_7512;
        for (int i = 3; i < 38; i++) {
            var sl = inv.method_7611(i);
            if (sl.method_7681()) {
                to = i;
                break;
            }
        }
        if (to == -1) {
//            info("No output slot");
            return;
        }
        var from = 2;
//        info("Shift click %d %d", from, to);
        InvUtils.shiftClick().fromId(from).toId(to);
    }

    private void populateAnvil() {
        var gItems = items.get();
        var from = -1;
        var inv = mc.field_1724.field_7512;
        for (int i = 3; i < 38; i++) {
            var sl = inv.method_7611(i);
            if (!sl.method_7681()) {
                continue;
            }
            var st = sl.method_7677();
            if (gItems.contains(st.method_7909()) && !st.method_57353().method_57832(class_9334.field_49631)) {
                from = i;
                break;
            }
        }
        if (from == -1) {
//            info("Nothing to rename");
            return;
        }
        var to = 0;
//        info("Shift click %d %d", from, to);
        InvUtils.shiftClick().fromId(from).toId(to);
    }
}
