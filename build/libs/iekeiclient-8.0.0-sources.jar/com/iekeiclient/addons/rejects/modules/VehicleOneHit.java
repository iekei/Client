package com.iekeiclient.addons.rejects.modules;


import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1688;
import net.minecraft.class_1690;
import net.minecraft.class_2824;
import net.minecraft.class_3966;

public class VehicleOneHit extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> amount = sgGeneral.add(new IntSetting.Builder()
            .name("amount")
            .description("The number of packets to send.")
            .defaultValue(16)
            .range(1, 100)
            .sliderRange(1, 20)
            .build()
    );

    public VehicleOneHit() {
        super(IekeiRejectsAddon.CATEGORY, "vehicle-one-hit", "Destroy vehicles with one hit.");
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (!(event.packet instanceof class_2824)
            || !(mc.field_1765 instanceof class_3966 ehr)
            || (!(ehr.method_17782() instanceof class_1688) && !(ehr.method_17782() instanceof class_1690))
        ) return;

        for (int i = 0; i < amount.get() - 1; i++) {
            mc.field_1724.field_3944.method_48296().method_10752(event.packet, null);
        }
    }
}