package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.PlaySoundEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1113;
import net.minecraft.class_1146;
import net.minecraft.class_124;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_5250;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SoundLocator extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");
    
    // General
    private final Setting<Boolean> whitelist = sgGeneral.add(new BoolSetting.Builder()
        .name("whitelist")
        .description("Enable sounds filter whitelist.")
        .defaultValue(false)
        .build()
    );
    
    private final Setting<List<class_3414>> sounds = sgGeneral.add(new SoundEventListSetting.Builder()
        .name("sounds")
        .description("Sounds to find.")
        .defaultValue(new ArrayList<>(0))
        .visible(whitelist::get)
        .build()
    );
    
    private final Setting<Boolean> chatActive = sgGeneral.add(new BoolSetting.Builder()
        .name("log-chat")
        .description("Send the position of the sound in the chat.")
        .defaultValue(false)
        .build()
    );
    
    private final Setting<Integer> timeS = sgGeneral.add(new IntSetting.Builder()
        .name("time")
        .description("The time between the sounds verification.")
        .defaultValue(60)
        .build()
    );
    
    // Render
    
    private final Setting<Boolean> renderActive = sgRender.add(new BoolSetting.Builder()
        .name("render-positions")
        .description("Renders boxes where the sound was emitted.")
        .defaultValue(true)
        .build()
    );
    
    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("The side color of the target sound rendering.")
        .defaultValue(new SettingColor(255, 0, 0, 70))
        .build()
    );
    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("The line color of the target sound rendering.")
        .defaultValue(new SettingColor(255, 0, 0))
        .build()
    );

    public SoundLocator() {
        super(IekeiRejectsAddon.CATEGORY, "sound-locator", "Prints locations of sound events.");
    }

    private List<class_243> renderPos = new ArrayList<class_243>();
    private List<Integer> delay = new ArrayList<Integer>();

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        Iterator<Integer> iterator = delay.iterator();

        while (iterator.hasNext()) {
            int time = iterator.next();
            if (time <= 0) {
                iterator.remove();
                renderPos.remove(0);
            } else {
                delay.set(delay.indexOf(time), time - 1);
            }
        }
    }
    
    @EventHandler
    private void onPlaySound(PlaySoundEvent event) {
        if(whitelist.get()) {
            // Whitelist ON
            for (class_3414 sound : sounds.get()) {
                if (sound.comp_3319().equals(event.sound.method_4775())) {
                    printSound(event.sound);
                    break;
                }
            }
        } else {
            // Whitelist OFF (Allow all sounds)
            printSound(event.sound);
        }
    }

    private void printSound(class_1113 sound) {
        class_1146 soundSet = mc.method_1483().method_4869(sound.method_4775());

        class_243 pos = new class_243(sound.method_4784() - 0.5, sound.method_4779() - 0.5, sound.method_4778() - 0.5);
        if(!renderPos.contains(pos)) {
            renderPos.add(pos);
            delay.add(timeS.get());
            
            if(chatActive.get()) {
                class_5250 text;
                if (soundSet == null || soundSet.method_4886() == null) {
                    text = class_2561.method_43470(sound.method_4775().toString());
                } else {
                    text = soundSet.method_4886().method_27661();
                }
                
                
                text.method_27693(String.format("%s at ", class_124.field_1070));
                text.method_10852(ChatUtils.formatCoords(pos));
                text.method_27693(String.format("%s.", class_124.field_1070));
                info(text);
            }
            
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if(renderActive.get()) {
            renderPos.forEach(pos -> {
                event.renderer.box(class_238.method_29968(pos), sideColor.get(), lineColor.get(), shapeMode.get(), 0);
            });
        }
    }
}
