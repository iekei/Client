package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.entity.EntityUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;


public class AntiBot extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgFilters = settings.createGroup("Filters");

    private final Setting<Boolean> removeInvisible = sgGeneral.add(new BoolSetting.Builder()
            .name("remove-invisible")
            .description("Removes bot only if they are invisible.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> gameMode = sgFilters.add(new BoolSetting.Builder()
            .name("null-gamemode")
            .description("Removes players without a gamemode")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> api = sgFilters.add(new BoolSetting.Builder()
            .name("null-entry")
            .description("Removes players without a player entry")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> profile = sgFilters.add(new BoolSetting.Builder()
            .name("null-profile")
            .description("Removes players without a game profile")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> latency = sgFilters.add(new BoolSetting.Builder()
            .name("ping-check")
            .description("Removes players using ping check")
            .defaultValue(false)
            .build()
    );

    private final Setting<Boolean> nullException = sgFilters.add(new BoolSetting.Builder()
            .name("null-exception")
            .description("Removes players if a NullPointerException occurred")
            .defaultValue(false)
            .build()
    );

    public AntiBot() {
        super(IekeiRejectsAddon.CATEGORY, "anti-bot", "Detects and removes bots.");
    }

    @EventHandler
    public void onTick(TickEvent.Post tickEvent) {
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1657 playerEntity)) continue;
            if (removeInvisible.get() && !entity.method_5767()) continue;

            if (isBot(playerEntity)) entity.method_5650(class_1297.class_5529.field_26999);
        }
    }

    private boolean isBot(class_1657 entity) {
        try {
            if (gameMode.get() && EntityUtils.getGameMode(entity) == null) return true;
            if (api.get() &&
                    mc.method_1562().method_2871(entity.method_5667()) == null) return true;
            if (profile.get() &&
                    mc.method_1562().method_2871(entity.method_5667()).method_2966() == null) return true;
            if (latency.get() &&
                    mc.method_1562().method_2871(entity.method_5667()).method_2959() > 1) return true;
        } catch (NullPointerException e) {
            if (nullException.get()) return true;
        }

        return false;
    }
}
