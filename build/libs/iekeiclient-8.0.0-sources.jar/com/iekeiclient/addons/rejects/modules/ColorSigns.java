package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2678;
import net.minecraft.class_2820;
import net.minecraft.class_2877;
import java.util.List;

public class ColorSigns extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> signs = sgGeneral.add(new BoolSetting.Builder()
            .name("signs")
            .description("Allows you to use colors in signs.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> books = sgGeneral.add(new BoolSetting.Builder()
            .name("books")
            .description("Allows you to use colors in books.")
            .defaultValue(false)
            .build()
    );

    public ColorSigns() {
        super(IekeiRejectsAddon.CATEGORY, "color-signs", "Allows you to use colors on signs on NON-PAPER servers (use \"&\" for color symbols)");
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (event.packet instanceof class_2678) {
            checkWarning();
            return;
        }
        if (signs.get() && event.packet instanceof class_2877 packet) {
            for (int line = 0; line < packet.method_12508().length; line++) {
                packet.method_12508()[line] = packet.method_12508()[line]
                        .replaceAll("(?i)(?:&|(?<!§)§)([0-9A-Z])", "§§$1$1");
            }
        }
        if (books.get() && event.packet instanceof class_2820 packet) {
            List<String> newPages = packet.comp_2286().stream().map(text ->
                    text.replaceAll("(?i)&([0-9A-Z])", "§$1")).toList();
            // BookUpdateC2SPacket.pages is final, so we need to create a new packet
            if (!packet.comp_2286().equals(newPages)) {
                assert mc.method_1562() != null;
                mc.method_1562().method_52787(new class_2820(
                        packet.comp_2285(), newPages, packet.comp_2287()));
                event.cancel();
            }
        }
    }

    @Override
    public void onActivate() {
        super.onActivate();
        checkWarning();
    }

    private void checkWarning() {
        if (mc.method_1562() == null) return;
        String brand = mc.method_1562().method_52790();
        if (brand == null) return;
        if (brand.contains("Paper")) warning("You are on a paper server. Color signs won't work here");
    }
}
