package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.utils.WorldUtils;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.FindItemResult;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class MossBot extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> range = sgGeneral.add(new IntSetting.Builder()
            .name("range")
            .description("The bonemeal range.")
            .defaultValue(4)
            .min(0)
            .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Whether or not to rotate towards block while bonemealing.")
            .defaultValue(true)
            .build()
    );

    private final Map<class_2338, Integer> mossMap = new HashMap<>();

    public MossBot() {
        super(IekeiRejectsAddon.CATEGORY, "moss-bot", "Use bonemeal on moss blocks with maximized efficiency.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        mossMap.entrySet().removeIf(e -> e.setValue(e.getValue() - 1) == 0);
        FindItemResult findItemResult = InvUtils.findInHotbar(class_1802.field_8324);
        if (!findItemResult.found()) {
            return;
        }

        class_2338 bestBlock = class_2338.method_25998(class_2338.method_49638(mc.field_1724.method_33571()), range.get(), range.get(), range.get())
                .filter(b -> mc.field_1724.method_33571().method_1022(class_243.method_24953(b)) <= range.get() && !mossMap.containsKey(b))
                .map(b -> Pair.of(b.method_10062(), getMossSpots(b)))
                .filter(p -> p.getRight() > 10)
                .map(Pair::getLeft)
                .max(Comparator.naturalOrder()).orElse(null);

        if (bestBlock != null) {
            if (!mc.field_1687.method_22347(bestBlock.method_10084())) {
                mc.field_1761.method_2902(bestBlock.method_10084(), class_2350.field_11036);
            }

            WorldUtils.interact(bestBlock, findItemResult, rotate.get());
            mossMap.put(bestBlock, 100);
        }
    }

    private int getMossSpots(class_2338 pos) {
        if (mc.field_1687.method_8320(pos).method_26204() != class_2246.field_28681
                || mc.field_1687.method_8320(pos.method_10084()).method_26214(mc.field_1687, pos) != 0f) {
            return 0;
        }

        return (int) class_2338.method_25998(pos, 3, 4, 3)
                .filter(b -> isMossGrowableOn(mc.field_1687.method_8320(b).method_26204()) && mc.field_1687.method_22347(b.method_10084()))
                .count();
    }

    private boolean isMossGrowableOn(class_2248 block) {
        return block == class_2246.field_10340 || block == class_2246.field_10474 || block == class_2246.field_10115 || block == class_2246.field_10508
                || block == class_2246.field_10566 || block == class_2246.field_10253 || block == class_2246.field_10402 || block == class_2246.field_10219
                || block == class_2246.field_10520 || block == class_2246.field_28685;
    }
}