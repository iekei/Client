package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.DoubleSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.engine.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1321;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2673;
import net.minecraft.class_2777;
import net.minecraft.class_5250;
import java.util.UUID;

public class CoordLogger extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgTeleports = settings.createGroup("Teleports");
    private final SettingGroup sgWorldEvents = settings.createGroup("World Events");

    // General
    
    private final Setting<Double> minDistance = sgGeneral.add(new DoubleSetting.Builder()
            .name("minimum-distance")
            .description("Minimum distance to log event.")
            .min(5)
            .max(100)
            .sliderMin(5)
            .sliderMax(100)
            .defaultValue(10)
            .build()
    );
    
    // Teleports
    
    private final Setting<Boolean> players = sgTeleports.add(new BoolSetting.Builder()
            .name("players")
            .description("Logs player teleports.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> wolves = sgTeleports.add(new BoolSetting.Builder()
            .name("wolves")
            .description("Logs wolf teleports.")
            .defaultValue(false)
            .build()
    );

    // World events
    
    private final Setting<Boolean> enderDragons = sgWorldEvents.add(new BoolSetting.Builder()
            .name("ender-dragons")
            .description("Logs killed ender dragons.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Boolean> endPortals = sgWorldEvents.add(new BoolSetting.Builder()
            .name("end-portals")
            .description("Logs opened end portals.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Boolean> withers = sgWorldEvents.add(new BoolSetting.Builder()
            .name("withers")
            .description("Logs wither spawns.")
            .defaultValue(false)
            .build()
    );
    

    private final Setting<Boolean> otherEvents = sgWorldEvents.add(new BoolSetting.Builder()
            .name("other-global-events")
            .description("Logs other global events.")
            .defaultValue(false)
            .build()
    );
    
    public CoordLogger() {
        super(IekeiRejectsAddon.CATEGORY,"coord-logger", "Logs coordinates of various events. Might not work on Spigot/Paper servers.");
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        // Teleports
        if (event.packet instanceof class_2777) {
            class_2777 packet = (class_2777) event.packet;
            
            try {
                class_1297 entity = mc.field_1687.method_8469(packet.comp_3237());
                
                // Player teleport
                if (entity.method_5864().equals(class_1299.field_6097) && players.get()) {
                    class_243 packetPosition = packet.comp_3238().comp_3148();
                    class_243 playerPosition = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());

                    if (playerPosition.method_1022(packetPosition) >= minDistance.get()) {
                        info(formatMessage("Player '" + entity.method_5820() + "' has teleported to ", packetPosition));
                    }
                }

                // World teleport
                else if (entity.method_5864().equals(class_1299.field_6055) && wolves.get()) {
                    class_243 packetPosition = packet.comp_3238().comp_3148();
                    class_243 wolfPosition = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());

                    var ownerRef = ((class_1321) entity).method_66287();
                    UUID ownerUuid = ownerRef != null ? ownerRef.method_66263() : null;

                    if (ownerUuid != null && wolfPosition.method_1022(packetPosition) >= minDistance.get()) {
                        info(formatMessage("Wolf has teleported to ", packetPosition));
                    }
                }
            } catch(NullPointerException ignored) {}
            
        // World events
        } else if (event.packet instanceof class_2673) {
            class_2673 worldEventS2CPacket = (class_2673) event.packet;
            
            if (worldEventS2CPacket.method_11533()) {
                // Min distance
                if (PlayerUtils.distanceTo(worldEventS2CPacket.method_11531()) <= minDistance.get()) return;
                
                switch (worldEventS2CPacket.method_11532()) {
                    case 1023:
                        if (withers.get()) info(formatMessage("Wither spawned at ", worldEventS2CPacket.method_11531()));
                        break;
                    case 1038:
                        if (endPortals.get()) info(formatMessage("End portal opened at ", worldEventS2CPacket.method_11531()));
                        break;
                    case 1028:
                        if (enderDragons.get()) info(formatMessage("Ender dragon killed at ", worldEventS2CPacket.method_11531()));
                        break;
                    default:
                        if (otherEvents.get()) info(formatMessage("Unknown global event at ", worldEventS2CPacket.method_11531()));
                }
            }
        }
    }

    public class_5250 formatMessage(String message, class_243 coords) {
        class_5250 text = class_2561.method_43470(message);
        text.method_10852(ChatUtils.formatCoords(coords));
        text.method_27693(class_124.field_1080 +".");
        return text;
    }

    public class_5250 formatMessage(String message, class_2338 coords) {
        return formatMessage(message, new class_243(coords.method_10263(), coords.method_10264(), coords.method_10260()));
    }
}
