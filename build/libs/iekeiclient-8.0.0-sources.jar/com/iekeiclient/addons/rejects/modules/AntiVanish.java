package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.mojang.brigadier.suggestion.Suggestion;
import com.iekeiclient.engine.events.game.ReceiveMessageEvent;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.widgets.WWidget;
import com.iekeiclient.engine.gui.widgets.containers.WVerticalList;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2639;
import net.minecraft.class_2805;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class AntiVanish extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> interval = sgGeneral.add(new IntSetting.Builder()
            .name("interval")
            .description("Vanish check interval.")
            .defaultValue(100)
            .min(0)
            .sliderMax(300)
            .build()
    );

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("mode")
            .defaultValue(Mode.LeaveMessage)
            .build()
    );

    private final Setting<String> command = sgGeneral.add(new StringSetting.Builder()
            .name("command")
            .description("The completion command to detect player names.")
            .defaultValue("minecraft:msg")
            .visible(() -> mode.get() == Mode.RealJoinMessage)
            .build()
    );

    private Map<UUID, String> playerCache = new HashMap<>();
    private final List<String> messageCache = new ArrayList<>();

    private final Random random = new Random();
    private final List<Integer> completionIDs = new ArrayList<>();
    private List<String> completionPlayerCache = new ArrayList<>();

    private int timer = 0;

    public AntiVanish() {
        super(IekeiRejectsAddon.CATEGORY, "anti-vanish", "Notifies user when a admin uses /vanish");
    }

    @Override
    public void onActivate() {
        timer = 0;
        completionIDs.clear();
        messageCache.clear();
    }

    @Override
    public WWidget getWidget(GuiTheme theme) {
        WVerticalList l = theme.verticalList();
        l.add(theme.label("LeaveMessage: If client didn't receive a quit game message (like essentials)."));
        l.add(theme.label("RealJoinMessage: Tell whether the player is really left by using player name completion."));
        return l;
    }

    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (mode.get() == Mode.RealJoinMessage && event.packet instanceof class_2639 packet) {
            if (completionIDs.contains(packet.comp_2262())) {
                var lastUsernames = completionPlayerCache.stream().toList();

                completionPlayerCache = packet.method_11397().getList().stream()
                        .map(Suggestion::getText)
                        .toList();

                if (lastUsernames.isEmpty()) return;

                Predicate<String> joinedOrQuit = playerName -> lastUsernames.contains(playerName) != completionPlayerCache.contains(playerName);

                for (String playerName : completionPlayerCache) {
                    if (Objects.equals(playerName, mc.field_1724.method_5477().getString())) continue;
                    if (playerName.contains(" ")) continue;
                    if (playerName.length() < 3 || playerName.length() > 16) continue;
                    if (joinedOrQuit.test(playerName)) {
                        info("Player joined: " + playerName);
                    }
                }

                for (String playerName : lastUsernames) {
                    if (Objects.equals(playerName, mc.field_1724.method_5477().getString())) continue;
                    if (playerName.contains(" ")) continue;
                    if (playerName.length() < 3 || playerName.length() > 16) continue;
                    if (joinedOrQuit.test(playerName)) {
                        info("Player left: " + playerName);
                    }
                }

                completionIDs.remove(Integer.valueOf(packet.comp_2262()));
                event.cancel();
            }
        }
    }

    @EventHandler
    private void onReceiveMessage(ReceiveMessageEvent event) {
        messageCache.add(event.getMessage().getString());
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        timer++;
        if (timer < interval.get()) return;

        switch (mode.get()) {
            case LeaveMessage -> {
                Map<UUID, String> oldPlayers = Map.copyOf(playerCache);
                playerCache = mc.method_1562().method_2880().stream().collect(Collectors.toMap(e -> e.method_2966().id(), e -> e.method_2966().name()));

                for (UUID uuid : oldPlayers.keySet()) {
                    if (playerCache.containsKey(uuid)) continue;
                    String name = oldPlayers.get(uuid);
                    if (name.contains(" ")) continue;
                    if (name.length() < 3 || name.length() > 16) continue;
                    if (messageCache.stream().noneMatch(s -> s.contains(name))) {
                        warning(name + " has gone into vanish.");
                    }
                }
            }
            case RealJoinMessage -> {
                int id = random.nextInt(200);
                completionIDs.add(id);
                mc.method_1562().method_52787(new class_2805(id, command.get() + " "));
            }
        }
        timer = 0;
        messageCache.clear();
    }

    public enum Mode {
        LeaveMessage,
        RealJoinMessage//https://github.com/xtrm-en/meteor-antistaff/blob/main/src/main/java/me/xtrm/meteorclient/antistaff/modules/AntiStaff.java
    }
}
