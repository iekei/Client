package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.entity.SortPriority;
import com.iekeiclient.engine.utils.entity.TargetUtils;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import java.util.Random;

// Too much much spaghetti!
// -StormyBytes

public class Confuse extends Module {

    public enum Mode {
        RandomTP,
        Switch,
        Circle
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("mode")
            .defaultValue(Mode.RandomTP)
            .description("Mode")
            .build()
    );

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("Delay")
            .defaultValue(3)
            .min(0)
            .sliderMax(20)
            .build()
    );

    private final Setting<Integer> range = sgGeneral.add(new IntSetting.Builder()
            .name("radius")
            .description("Range to confuse opponents")
            .defaultValue(6)
            .min(0).sliderMax(10)
            .build()
    );

    private final Setting<SortPriority> priority = sgGeneral.add(new EnumSetting.Builder<SortPriority>()
            .name("priority")
            .description("Targetting priority")
            .defaultValue(SortPriority.LowestHealth)
            .build()
    );

    private final Setting<Integer> circleSpeed = sgGeneral.add(new IntSetting.Builder()
            .name("circle-speed")
            .description("Circle mode speed")
            .defaultValue(10)
            .min(1)
            .sliderMax(180)
            .build()
    );

    private final Setting<Boolean> moveThroughBlocks = sgGeneral.add(new BoolSetting.Builder()
            .name("move-through-blocks")
            .defaultValue(false)
            .build()
    );

    private final Setting<Boolean> budgetGraphics = sgGeneral.add(new BoolSetting.Builder()
            .name("budget-graphics")
            .defaultValue(false)
            .build()
    );

    private final Setting<SettingColor> circleColor = sgGeneral.add(new ColorSetting.Builder()
            .name("circle-color")
            .description("Color for circle rendering")
            .defaultValue(new SettingColor(0, 255, 0))
            .visible(budgetGraphics::get)
            .build()
    );


    int delayWaited = 0;
    double circleProgress = 0;
    double addition = 0.0;
    class_1297 target = null;

    public Confuse() {
        super(IekeiRejectsAddon.CATEGORY, "confuse", "Makes your enemies shit themselves");
    }

    @Override
    public void onActivate() {
        delayWaited = 0;
        circleProgress = 0;
        addition = 0.0;
        target = null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {

        // Delay
        delayWaited++;
        if (delayWaited < delay.get()) return;
        delayWaited = 0;


        // Targetting
        target = TargetUtils.getPlayerTarget(range.get(), priority.get());

        if (target == null) return;

        class_243 entityPos = target.method_73189();
        class_243 playerPos = mc.field_1724.method_73189();
        Random r = new Random();
        class_3965 hit;
        int halfRange = range.get() / 2;

        switch (mode.get()) {
            case RandomTP:
                double x = r.nextDouble() * range.get() - halfRange;
                double y = 0;
                double z = r.nextDouble() * range.get() - halfRange;
                class_243 addend = new class_243(x, y, z);
                class_243 goal = entityPos.method_1019(addend);
                if (mc.field_1687.method_8320(class_2338.method_49637(goal.field_1352, goal.field_1351, goal.field_1350)).method_26204() != class_2246.field_10124) {
                    goal = new class_243(x, playerPos.field_1351, z);
                }
                if (mc.field_1687.method_8320(class_2338.method_49637(goal.field_1352, goal.field_1351, goal.field_1350)).method_26204() == class_2246.field_10124) {
                    hit = mc.field_1687.method_17742(new class_3959(mc.field_1724.method_73189(), goal, class_3959.class_3960.field_17558, class_3959.class_242.field_1347, mc.field_1724));
                    if (!moveThroughBlocks.get() && hit.method_17781()) {
                        delayWaited = delay.get() - 1;
                        break;
                    }
                    mc.field_1724.method_30634(goal.field_1352, goal.field_1351, goal.field_1350);
                } else {
                    delayWaited = delay.get() - 1;
                }
                break;

            case Switch:
                class_243 diff = entityPos.method_1020(playerPos);
                class_243 diff1 = new class_243(class_3532.method_15350(diff.field_1352, -halfRange, halfRange), class_3532.method_15350(diff.field_1351, -halfRange, halfRange), class_3532.method_15350(diff.field_1350, -halfRange, halfRange));
                class_243 goal2 = entityPos.method_1019(diff1);
                hit = mc.field_1687.method_17742(new class_3959(mc.field_1724.method_73189(), goal2, class_3959.class_3960.field_17558, class_3959.class_242.field_1347, mc.field_1724));
                if (!moveThroughBlocks.get() && hit.method_17781()) {
                    delayWaited = delay.get() - 1;
                    break;
                }
                mc.field_1724.method_30634(goal2.field_1352, goal2.field_1351, goal2.field_1350);
                break;

            case Circle:
                delay.set(0);
                circleProgress += circleSpeed.get();
                if (circleProgress > 360) circleProgress -= 360;
                double rad = Math.toRadians(circleProgress);
                double sin = Math.sin(rad) * 3;
                double cos = Math.cos(rad) * 3;
                class_243 current = new class_243(entityPos.field_1352 + sin, playerPos.field_1351, entityPos.field_1350 + cos);
                hit = mc.field_1687.method_17742(new class_3959(mc.field_1724.method_73189(), current, class_3959.class_3960.field_17558, class_3959.class_242.field_1347, mc.field_1724));
                if (!moveThroughBlocks.get() && hit.method_17781())
                    break;
                mc.field_1724.method_30634(current.field_1352, current.field_1351, current.field_1350);
                break;
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (target == null) return;

        boolean flag = budgetGraphics.get();
        class_243 last = null;
        addition += flag ? 0 : 1.0;
        if (addition > 360) addition = 0;
        for (int i = 0; i < 360; i += flag ? 7 : 1) {
            Color c1;
            if (flag) c1 = circleColor.get();
            else {
                double rot = (255.0 * 3) * (((((double) i) + addition) % 360) / 360.0);
                int seed = (int) Math.floor(rot / 255.0);
                double current = rot % 255;
                double red = seed == 0 ? current : (seed == 1 ? Math.abs(current - 255) : 0);
                double green = seed == 1 ? current : (seed == 2 ? Math.abs(current - 255) : 0);
                double blue = seed == 2 ? current : (seed == 0 ? Math.abs(current - 255) : 0);
                c1 = new Color((int) red, (int) green, (int) blue);
            }
            class_243 tp = target.method_73189();
            double rad = Math.toRadians(i);
            double sin = Math.sin(rad) * 3;
            double cos = Math.cos(rad) * 3;
            class_243 c = new class_243(tp.field_1352 + sin, tp.field_1351 + target.method_17682() / 2, tp.field_1350 + cos);
            if (last != null) event.renderer.line(last.field_1352, last.field_1351, last.field_1350, c.field_1352, c.field_1351, c.field_1350, c1);
            last = c;
        }
    }
}
