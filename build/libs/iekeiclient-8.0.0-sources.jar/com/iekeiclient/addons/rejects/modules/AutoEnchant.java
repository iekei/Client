package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;

import com.iekeiclient.engine.events.game.OpenScreenEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.utils.network.IekeiExecutor;
import com.iekeiclient.engine.utils.player.FindItemResult;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1718;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import java.util.List;
import java.util.Objects;

public class AutoEnchant extends com.iekeiclient.engine.systems.modules.Module {

    public final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("The tick delay between enchanting items.")
            .defaultValue(50)
            .sliderMax(500)
            .min(0)
            .build()
    );

    private final Setting<Integer> level = sgGeneral.add(new IntSetting.Builder()
            .name("level")
            .description("Choose enchantment levels 1-3")
            .defaultValue(3)
            .max(3)
            .min(1)
            .build()
    );

    private final Setting<Boolean> drop = sgGeneral.add(new BoolSetting.Builder()
            .name("drop")
            .description("Automatically drops enchanted items (useful for when not enough inventory space)")
            .defaultValue(false)
            .build()
    );

    private final Setting<List<class_1792>> itemWhitelist = sgGeneral.add(new ItemListSetting.Builder()
            .name("item-whitelist")
            .description("Item that require enchantment.")
            .defaultValue()
            .filter(item -> item.equals(class_1802.field_8529) || new class_1799(item).method_7963())
            .build()
    );

    public AutoEnchant() {
        super(IekeiRejectsAddon.CATEGORY, "auto-enchant", "Automatically enchanting items.");
    }

    @EventHandler
    private void onOpenScreen(OpenScreenEvent event) {
        if (!(Objects.requireNonNull(mc.field_1724).field_7512 instanceof class_1718))
            return;
        IekeiExecutor.execute(this::autoEnchant);
    }

    private void autoEnchant() {
        if (!(Objects.requireNonNull(mc.field_1724).field_7512 instanceof class_1718 handler))
            return;
        if (mc.field_1724.field_7520 < 30) {
            info("You don't have enough experience levels");
            return;
        }
        while (getEmptySlotCount(handler) > 2 || drop.get()) {
            if (!(mc.field_1724.field_7512 instanceof class_1718)) {
                info("Enchanting table is closed.");
                break;
            }
            if (handler.method_7638() < level.get() && !fillLapisItem()) {
                info("Lapis lazuli is not found.");
                break;
            }
            if (!fillCanEnchantItem()) {
                info("No items found to enchant.");
                break;
            }
            Objects.requireNonNull(mc.field_1761).method_2900(handler.field_7763, level.get() - 1);
            if (getEmptySlotCount(handler) > 2) {
                InvUtils.shiftClick().slotId(0);
            } else if (drop.get() && handler.method_7611(0).method_7681()) {
                // I don't know why an exception LegacyRandomSource is thrown here,
                // so I used the main thread to drop items.
                mc.execute(() -> InvUtils.drop().slotId(0));
            }

            /*
            Although the description here indicates that the tick is the unit,
            the actual delay is not the tick unit,
            but it does not affect the normal operation in the game.
            Perhaps we can ignore it
            */
            try {
                Thread.sleep(delay.get());
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private boolean fillCanEnchantItem() {
        FindItemResult res = InvUtils.find(stack -> itemWhitelist.get().contains(stack.method_7909()) && class_1890.method_57529(stack));
        if (!res.found()) return false;
        InvUtils.shiftClick().slot(res.slot());
        return true;
    }

    private boolean fillLapisItem() {
        FindItemResult res = InvUtils.find(class_1802.field_8759);
        if (!res.found()) return false;
        InvUtils.shiftClick().slot(res.slot());
        return true;
    }

    private int getEmptySlotCount(class_1703 handler) {
        int emptySlotCount = 0;
        for (int i = 0; i < handler.field_7761.size(); i++) {
            if (!handler.field_7761.get(i).method_7677().method_7909().equals(class_1802.field_8162))
                continue;
            emptySlotCount++;
        }
        return emptySlotCount;
    }

}
