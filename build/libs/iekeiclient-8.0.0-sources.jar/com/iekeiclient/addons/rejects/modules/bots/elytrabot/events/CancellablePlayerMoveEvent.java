package com.iekeiclient.addons.rejects.modules.bots.elytrabot.events;

import com.iekeiclient.engine.events.Cancellable;
import net.minecraft.class_1313;
import net.minecraft.class_243;

public class CancellablePlayerMoveEvent extends Cancellable {
    private static final CancellablePlayerMoveEvent INSTANCE = new CancellablePlayerMoveEvent();

    public class_1313 type;
    public class_243 movement;

    public static CancellablePlayerMoveEvent get(class_1313 type, class_243 movement) {
        INSTANCE.setCancelled(false);
        INSTANCE.type = type;
        INSTANCE.movement = movement;
        return INSTANCE;
    }
}
