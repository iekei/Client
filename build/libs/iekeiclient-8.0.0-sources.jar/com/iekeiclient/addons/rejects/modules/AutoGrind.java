package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.game.OpenScreenEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.network.IekeiExecutor;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_3803;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_9636;
import java.util.List;
import java.util.Set;

public class AutoGrind extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("The tick delay between grinding items.")
            .defaultValue(50)
            .sliderMax(500)
            .min(0)
            .build()
    );

    private final Setting<List<class_1792>> itemBlacklist = sgGeneral.add(new ItemListSetting.Builder()
            .name("item-blacklist")
            .description("Items that should be ignored.")
            .defaultValue()
            .filter(Item -> Item.method_57347().method_58694(class_9334.field_49629) != null)
            .build()
    );

    private final Setting<Set<class_5321<class_1887>>> enchantmentBlacklist = sgGeneral.add(new EnchantmentListSetting.Builder()
            .name("enchantment-blacklist")
            .description("Enchantments that should be ignored.")
            .defaultValue()
            .build()
    );

    public AutoGrind() {
        super(IekeiRejectsAddon.CATEGORY, "auto-grind", "Automatically disenchants items.");
    }

    @EventHandler
    private void onOpenScreen(OpenScreenEvent event) {
        if (!(mc.field_1724.field_7512 instanceof class_3803))
            return;

        IekeiExecutor.execute(() -> {
            for (int i = 0; i <= mc.field_1724.method_31548().method_5439(); i++) {
                if (canGrind(mc.field_1724.method_31548().method_5438(i))) {
                    try {
                        Thread.sleep(delay.get());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    if (mc.field_1755 == null) break;

                    InvUtils.shiftClick().slot(i);
                    InvUtils.move().fromId(2).to(i);
                }
            }
        });
    }

    private boolean canGrind(class_1799 stack) {
        if (itemBlacklist.get().contains(stack.method_7909())) return false;

        class_9304 enchantments = class_1890.method_57532(stack);
        int availEnchs = 0;

        for (class_6880<class_1887> enchantment : enchantments.method_57534()) {
            availEnchs++;
            if (class_1890.method_60138(stack, class_9636.field_51551))
                availEnchs--;
            if (enchantmentBlacklist.get().contains(enchantment.comp_349()))
                return false;
        }

        return !enchantments.method_57543() && availEnchs > 0;
    }
}
