package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.utils.WorldUtils;
import com.iekeiclient.engine.events.entity.player.BreakBlockEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.Utils;
import com.iekeiclient.engine.utils.misc.Pool;
import com.iekeiclient.engine.utils.player.FindItemResult;
import com.iekeiclient.engine.utils.player.InvUtils;
import com.iekeiclient.engine.utils.world.BlockIterator;
import com.iekeiclient.engine.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2282;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2350;
import net.minecraft.class_2420;
import net.minecraft.class_2421;
import net.minecraft.class_243;
import net.minecraft.class_2473;
import net.minecraft.class_2492;
import net.minecraft.class_2513;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3830;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5800;
import net.minecraft.class_8237;
import java.util.*;

public class AutoFarm extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgTill = settings.createGroup("Till");
    private final SettingGroup sgHarvest = settings.createGroup("Harvest");
    private final SettingGroup sgPlant = settings.createGroup("Plant");
    private final SettingGroup sgBonemeal = settings.createGroup("Bonemeal");

    private final Map<class_2338, class_1792> replantMap = new HashMap<>();

    private final Setting<Integer> range = sgGeneral.add(new IntSetting.Builder()
            .name("range")
            .description("Auto farm range.")
            .defaultValue(4)
            .min(1)
            .build()
    );

    private final Setting<Integer> bpt = sgGeneral.add(new IntSetting.Builder()
            .name("blocks-per-tick")
            .description("Amount of operations that can be applied in one tick.")
            .min(1)
            .defaultValue(1)
            .build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Whether or not to rotate towards block.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> till = sgTill.add(new BoolSetting.Builder()
            .name("till")
            .description("Turn nearby dirt into farmland.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> moist = sgTill.add(new BoolSetting.Builder()
            .name("moist")
            .description("Only till moist blocks.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> harvest = sgHarvest.add(new BoolSetting.Builder()
            .name("harvest")
            .description("Harvest crops.")
            .defaultValue(true)
            .build()
    );

    private final Setting<List<class_2248>> harvestBlocks = sgHarvest.add(new BlockListSetting.Builder()
            .name("harvest-blocks")
            .description("Which crops to harvest.")
            .defaultValue()
            .filter(this::harvestFilter)
            .build()
    );

    private final Setting<Boolean> plant = sgPlant.add(new BoolSetting.Builder()
            .name("plant")
            .description("Plant crops.")
            .defaultValue(true)
            .build()
    );

    private final Setting<List<class_1792>> plantItems = sgPlant.add(new ItemListSetting.Builder()
            .name("plant-items")
            .description("Which crops to plant.")
            .defaultValue()
            .filter(this::plantFilter)
            .build()
    );

    private final Setting<Boolean> onlyReplant = sgPlant.add(new BoolSetting.Builder()
            .name("only-replant")
            .description("Only replant planted crops.")
            .defaultValue(true)
            .onChanged(b -> replantMap.clear())
            .build()
    );

    private final Setting<Boolean> bonemeal = sgBonemeal.add(new BoolSetting.Builder()
            .name("bonemeal")
            .description("Bonemeal crops.")
            .defaultValue(true)
            .build()
    );

    private final Setting<List<class_2248>> bonemealBlocks = sgBonemeal.add(new BlockListSetting.Builder()
            .name("bonemeal-blocks")
            .description("Which crops to bonemeal.")
            .defaultValue()
            .filter(this::bonemealFilter)
            .build()
    );

    private final Pool<class_2338.class_2339> blockPosPool = new Pool<>(class_2338.class_2339::new);
    private final List<class_2338.class_2339> blocks = new ArrayList<>();

    int actions = 0;

    public AutoFarm() {
        super(IekeiRejectsAddon.CATEGORY, "auto-farm", "All-in-one farm utility.");
    }

    @Override
    public void onDeactivate() {
        replantMap.clear();
    }

    @EventHandler
    private void onBreakBlock(BreakBlockEvent event) {
        class_2680 state = mc.field_1687.method_8320(event.blockPos);
        class_2248 block = state.method_26204();
        if (onlyReplant.get()) {
            class_1792 item = null;
            if (block == class_2246.field_10293) item = class_1802.field_8317;
            else if (block == class_2246.field_10609) item = class_1802.field_8179;
            else if (block == class_2246.field_10247) item = class_1802.field_8567;
            else if (block == class_2246.field_10341) item = class_1802.field_8309;
            else if (block == class_2246.field_9974) item = class_1802.field_8790;
            else if (block == class_2246.field_43228) item = class_1802.field_43195;
            else if (block == class_2246.field_42734) item = class_1802.field_42711;
            if (item != null) replantMap.put(event.blockPos, item);
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        actions = 0;
        BlockIterator.register(range.get(), range.get(), (pos, state) -> {
            if (mc.field_1724.method_33571().method_1022(class_243.method_24953(pos)) <= range.get())
                blocks.add(blockPosPool.get().method_10101(pos));
        });

        BlockIterator.after(() -> {
            blocks.sort(Comparator.comparingDouble(value -> mc.field_1724.method_33571().method_1022(class_243.method_24953(value))));

            for (class_2338 pos : blocks) {
                class_2680 state = mc.field_1687.method_8320(pos);
                class_2248 block = state.method_26204();
                if (till(pos, block) || harvest(pos, state, block) || plant(pos, block) || bonemeal(pos, state, block))
                    actions++;
                if (actions >= bpt.get()) break;
            }

            for (class_2338.class_2339 blockPos : blocks) blockPosPool.free(blockPos);
            blocks.clear();

        });
    }

    private boolean till(class_2338 pos, class_2248 block) {
        if (!till.get()) return false;
        boolean moist = !this.moist.get() || isWaterNearby(mc.field_1687, pos);
        boolean tillable = block == class_2246.field_10219 ||
                block == class_2246.field_10194 ||
                block == class_2246.field_10566 ||
                block == class_2246.field_10253 ||
                block == class_2246.field_28685;
        if (moist && tillable && mc.field_1687.method_8320(pos.method_10084()).method_26215()) {
            FindItemResult hoe = InvUtils.findInHotbar(itemStack -> itemStack.method_7909() instanceof class_1794);
            return WorldUtils.interact(pos, hoe, rotate.get());
        }
        return false;
    }

    private boolean harvest(class_2338 pos, class_2680 state, class_2248 block) {
        if (!harvest.get()) return false;
        if (!harvestBlocks.get().contains(block)) return false;
        if (!isMature(state, block)) return false;
        if (block instanceof class_3830)
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, new class_3965(Utils.vec3d(pos), class_2350.field_11036, pos, false));
        else {
            mc.field_1761.method_2902(pos, class_2350.field_11036);
        }
        return true;
    }

    private boolean plant(class_2338 pos, class_2248 block) {
        if (!plant.get()) return false;
        if (!mc.field_1687.method_22347(pos.method_10084())) return false;
        FindItemResult findItemResult = null;
        if (onlyReplant.get()) {
            for (class_2338 replantPos : replantMap.keySet()) {
                if (replantPos.equals(pos.method_10084())) {
                    findItemResult = InvUtils.find(replantMap.get(replantPos));
                    replantMap.remove(replantPos);
                    break;
                }
            }
        } else if (block instanceof class_2344) {
            findItemResult = InvUtils.find(itemStack -> {
                class_1792 item = itemStack.method_7909();
                return item != class_1802.field_8790 && plantItems.get().contains(item);
            });
        } else if (block instanceof class_2492) {
            findItemResult = InvUtils.find(itemStack -> {
                class_1792 item = itemStack.method_7909();
                return item == class_1802.field_8790 && plantItems.get().contains(class_1802.field_8790);
            });
        }
        if (findItemResult != null && findItemResult.found()) {
            BlockUtils.place(pos.method_10084(), findItemResult, rotate.get(), -100, false);
            return true;
        }
        return false;
    }

    private boolean bonemeal(class_2338 pos, class_2680 state, class_2248 block) {
        if (!bonemeal.get()) return false;
        if (!bonemealBlocks.get().contains(block)) return false;
        if (isMature(state, block)) return false;

        FindItemResult bonemeal = InvUtils.findInHotbar(class_1802.field_8324);
        return WorldUtils.interact(pos, bonemeal, rotate.get());
    }

    private boolean isWaterNearby(class_4538 world, class_2338 pos) {
        for (class_2338 blockPos : class_2338.method_10097(pos.method_10069(-4, 0, -4), pos.method_10069(4, 1, 4))) {
            if (world.method_8316(blockPos).method_15767(class_3486.field_15517)) return true;
        }
        return false;
    }

    private boolean isMature(class_2680 state, class_2248 block) {
        if (block instanceof class_2302 cropBlock) {
            return cropBlock.method_9825(state);
        } else if (block instanceof class_2282 cocoaBlock) {
            return state.method_11654(cocoaBlock.field_10779) >= 2;
        } else if (block instanceof class_2513) {
            return state.method_11654(class_2513.field_11584) == class_2513.field_31255;
        } else if (block instanceof class_3830 sweetBerryBushBlock) {
            return state.method_11654(sweetBerryBushBlock.field_17000) >= 2;
        } else if (block instanceof class_2421 netherWartBlock) {
            return state.method_11654(netherWartBlock.field_11306) >= 3;
        } else if (block instanceof class_8237 pitcherCropBlock) {
            return state.method_11654(pitcherCropBlock.field_43239) >= 4;
        }
        return true;
    }

    private boolean bonemealFilter(class_2248 block) {
        return block instanceof class_2302 ||
                block instanceof class_2513 ||
                block instanceof class_2420 ||
                block instanceof class_5800 ||
                block instanceof class_2473 ||
                block == class_2246.field_10302 ||
                block == class_2246.field_16999 ||
                block == class_2246.field_43228 ||
                block == class_2246.field_42734;
    }

    private boolean harvestFilter(class_2248 block) {
        return block instanceof class_2302 ||
                block == class_2246.field_46282 ||
                block == class_2246.field_46283 ||
                block == class_2246.field_9974 ||
                block == class_2246.field_16999 ||
                block == class_2246.field_10302 ||
                block == class_2246.field_43228 ||
                block == class_2246.field_42734;
    }

    private boolean plantFilter(class_1792 item) {
        return item == class_1802.field_8317 ||
                item == class_1802.field_8179 ||
                item == class_1802.field_8567 ||
                item == class_1802.field_8309 ||
                item == class_1802.field_46249 ||
                item == class_1802.field_46250 ||
                item == class_1802.field_8790 ||
                item == class_1802.field_43195 ||
                item == class_1802.field_42711;
    }
}
