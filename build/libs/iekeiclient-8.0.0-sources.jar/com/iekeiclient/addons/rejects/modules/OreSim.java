package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.events.PlayerRespawnEvent;
import com.iekeiclient.addons.rejects.events.SeedChangedEvent;
import com.iekeiclient.addons.rejects.utils.Ore;
import com.iekeiclient.addons.rejects.utils.seeds.Seed;
import com.iekeiclient.addons.rejects.utils.seeds.Seeds;
import baritone.api.BaritoneAPI;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.BlockUpdateEvent;
import com.iekeiclient.engine.events.world.ChunkDataEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.pathing.BaritoneUtils;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.Utils;
import com.iekeiclient.engine.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2826;
import net.minecraft.class_2902;
import net.minecraft.class_2919;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_638;
import net.minecraft.util.math.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class OreSim extends Module {

    private final Map<Long, Map<Ore, Set<class_243>>> chunkRenderers = new ConcurrentHashMap<>();
    private Seed worldSeed = null;
    private Map<class_5321<class_1959>, List<Ore>> oreConfig;
    public List<class_2338> oreGoals = new ArrayList<>();

    public enum AirCheck {
        ON_LOAD,
        RECHECK,
        OFF
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> horizontalRadius = sgGeneral.add(new IntSetting.Builder()
            .name("chunk-range")
            .description("Taxi cap distance of chunks being shown.")
            .defaultValue(5)
            .min(1)
            .sliderMax(10)
            .build()
    );

    private final Setting<AirCheck> airCheck = sgGeneral.add(new EnumSetting.Builder<AirCheck>()
            .name("air-check-mode")
            .description("Checks if there is air at a calculated ore pos.")
            .defaultValue(AirCheck.RECHECK)
            .build()
    );

    private final Setting<Boolean> baritone = sgGeneral.add(new BoolSetting.Builder()
            .name("baritone")
            .description("Set baritone ore positions to the simulated ones.")
            .defaultValue(false)
            .build()
    );


    public OreSim() {
        super(IekeiRejectsAddon.CATEGORY, "ore-sim", "Xray on crack.");
        SettingGroup sgOres = settings.createGroup("Ores");
        Ore.oreSettings.forEach(sgOres::add);
    }

    public boolean baritone() {
        return isActive() && baritone.get() && BaritoneUtils.IS_AVAILABLE;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1724 == null || oreConfig == null) {
            return;
        }
        if (Seeds.get().getSeed() != null) {
            int chunkX = mc.field_1724.method_31476().field_9181;
            int chunkZ = mc.field_1724.method_31476().field_9180;

            int rangeVal = horizontalRadius.get();
            for (int range = 0; range <= rangeVal; range++) {
                for (int x = -range + chunkX; x <= range + chunkX; x++) {
                    renderChunk(x, chunkZ + range - rangeVal, event);
                }
                for (int x = (-range) + 1 + chunkX; x < range + chunkX; x++) {
                    renderChunk(x, chunkZ - range + rangeVal + 1, event);
                }
            }
        }

    }

    private void renderChunk(int x, int z, Render3DEvent event) {
        long chunkKey = class_1923.method_8331(x,z);

        if (chunkRenderers.containsKey(chunkKey)) {
            Map<Ore, Set<class_243>> chunk = chunkRenderers.get(chunkKey);

            for (Map.Entry<Ore, Set<class_243>> oreRenders : chunk.entrySet()) {
                if (oreRenders.getKey().active.get()) {
                    for (class_243 pos : oreRenders.getValue()) {
                        event.renderer.boxLines(pos.field_1352, pos.field_1351, pos.field_1350, pos.field_1352 + 1, pos.field_1351 + 1, pos.field_1350 + 1, oreRenders.getKey().color, 0);
                    }
                }
            }
        }
    }

    @EventHandler
    private void onBlockUpdate(BlockUpdateEvent event) {
        if (airCheck.get() != AirCheck.RECHECK || event.newState.method_26225()) return;

        long chunkKey = class_1923.method_37232(event.pos);
        if (chunkRenderers.containsKey(chunkKey)) {
            class_243 pos = class_243.method_24954(event.pos);
            for (var ore : chunkRenderers.get(chunkKey).values()) {
                ore.remove(pos);
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || oreConfig == null) return;

        if (baritone() && BaritoneAPI.getProvider().getPrimaryBaritone().getMineProcess().isActive()) {
            oreGoals.clear();
            var chunkPos = mc.field_1724.method_31476();
            int rangeVal = 4;
            for (int range = 0; range <= rangeVal; ++range) {
                for (int x = -range + chunkPos.field_9181; x <= range + chunkPos.field_9181; ++x) {
                    oreGoals.addAll(addToBaritone(x, chunkPos.field_9180 + range - rangeVal));
                }
                for (int x = -range + 1 + chunkPos.field_9181; x < range + chunkPos.field_9181; ++x) {
                    oreGoals.addAll(this.addToBaritone(x, chunkPos.field_9180 - range + rangeVal + 1));
                }
            }
        }
    }

    private ArrayList<class_2338> addToBaritone(int chunkX, int chunkZ) {
        ArrayList<class_2338> baritoneGoals = new ArrayList<>();
        long chunkKey = class_1923.method_8331(chunkX, chunkZ);
        if (this.chunkRenderers.containsKey(chunkKey)) {
            this.chunkRenderers.get(chunkKey).entrySet().stream()
                    .filter(entry -> entry.getKey().active.get())
                    .flatMap(entry -> entry.getValue().stream())
                    .map(class_2338::method_49638)
                    .forEach(baritoneGoals::add);
        }
        return baritoneGoals;
    }

    @Override
    public void onActivate() {
        if (Seeds.get().getSeed() == null) {
            error("No seed found. To set a seed do .seed <seed>");
            this.toggle();
        }
        reload();
    }

    @Override
    public void onDeactivate() {
        this.chunkRenderers.clear();
        this.oreConfig = null;
    }

    @EventHandler
    private void onSeedChanged(SeedChangedEvent event) {
        reload();
    }

    @EventHandler
    private void onPlayerRespawn(PlayerRespawnEvent event) {
        reload();
    }

    private void loadVisibleChunks() {
        if (mc.field_1724 == null) {
            return;
        }

        for (class_2791 chunk : Utils.chunks(false)) {
            doMathOnChunk(chunk);
        }
    }

    private void reload() {
        Seed seed = Seeds.get().getSeed();
        if (seed == null) return;
        worldSeed = seed;
        oreConfig = Ore.getRegistry(PlayerUtils.getDimension());

        chunkRenderers.clear();
        if (mc.field_1687 != null && worldSeed != null) {
            loadVisibleChunks();
        }
    }

    @EventHandler
    public void onChunkData(ChunkDataEvent event) {
        doMathOnChunk(event.chunk());
    }

    private void doMathOnChunk(class_2791 chunk) {

        var chunkPos = chunk.method_12004();
        long chunkKey = chunkPos.method_8324();

        class_638 world = mc.field_1687;

        if (chunkRenderers.containsKey(chunkKey) || world == null) {
            return;
        }

        Set<class_5321<class_1959>> biomes = new HashSet<>();
        class_1923.method_19280(chunkPos, 1).forEach(chunkPosx -> {
            class_2791 chunkxx = world.method_8402(chunkPosx.field_9181, chunkPosx.field_9180, class_2806.field_12794, false);
            if (chunkxx == null) return;

            for(class_2826 chunkSection : chunkxx.method_12006()) {
                chunkSection.method_38294().method_39793(entry -> biomes.add(entry.method_40230().get()));
            }
        });
        Set<Ore> oreSet = biomes.stream().flatMap(b -> getDefaultOres(b).stream()).collect(Collectors.toSet());

        int chunkX = chunkPos.field_9181 << 4;
        int chunkZ = chunkPos.field_9180 << 4;
        class_2919 random = new class_2919(class_2919.class_6675.field_35143.method_39006(0));

        long populationSeed = random.method_12661(worldSeed.seed, chunkX, chunkZ);
        HashMap<Ore, Set<class_243>> h = new HashMap<>();

        for (Ore ore : oreSet) {

            HashSet<class_243> ores = new HashSet<>();

            random.method_12664(populationSeed, ore.index, ore.step);

            int repeat = ore.count.method_35008(random);

            for (int i = 0; i < repeat; i++) {

                if (ore.rarity != 1F && random.method_43057() >= 1/ore.rarity) {
                    continue;
                }

                int x = random.method_43048(16) + chunkX;
                int z = random.method_43048(16) + chunkZ;
                int y = ore.heightProvider.method_35391(random, ore.heightContext);
                class_2338 origin = new class_2338(x,y,z);

                class_5321<class_1959> biome = chunk.method_16359(x,y,z).method_40230().get();

                if (!getDefaultOres(biome).contains(ore)) {
                    continue;
                }

                if (ore.scattered) {
                    ores.addAll(generateHidden(world, random, origin, ore.size));
                } else {
                    ores.addAll(generateNormal(world, random, origin, ore.size, ore.discardOnAirChance));
                }
            }
            if (!ores.isEmpty()) {
                h.put(ore, ores);
            }
        }
        chunkRenderers.put(chunkKey, h);
    }

    private List<Ore> getDefaultOres(class_5321<class_1959> biomeRegistryKey) {
        if (oreConfig.containsKey(biomeRegistryKey)) {
            return oreConfig.get(biomeRegistryKey);
        } else {
            return this.oreConfig.values().stream().findAny().get();
        }
    }

    // ====================================
    // Mojang code
    // ====================================

    private ArrayList<class_243> generateNormal(class_638 world, class_2919 random, class_2338 blockPos, int veinSize, float discardOnAir) {
        float f = random.method_43057() * 3.1415927F;
        float g = (float) veinSize / 8.0F;
        int i = class_3532.method_15386(((float) veinSize / 16.0F * 2.0F + 1.0F) / 2.0F);
        double d = (double) blockPos.method_10263() + Math.sin(f) * (double) g;
        double e = (double) blockPos.method_10263() - Math.sin(f) * (double) g;
        double h = (double) blockPos.method_10260() + Math.cos(f) * (double) g;
        double j = (double) blockPos.method_10260() - Math.cos(f) * (double) g;
        double l = (blockPos.method_10264() + random.method_43048(3) - 2);
        double m = (blockPos.method_10264() + random.method_43048(3) - 2);
        int n = blockPos.method_10263() - class_3532.method_15386(g) - i;
        int o = blockPos.method_10264() - 2 - i;
        int p = blockPos.method_10260() - class_3532.method_15386(g) - i;
        int q = 2 * (class_3532.method_15386(g) + i);
        int r = 2 * (2 + i);

        for (int s = n; s <= n + q; ++s) {
            for (int t = p; t <= p + q; ++t) {
                if (o <= world.method_8624(class_2902.class_2903.field_13197, s, t)) {
                    return this.generateVeinPart(world, random, veinSize, d, e, h, j, l, m, n, o, p, q, r, discardOnAir);
                }
            }
        }

        return new ArrayList<>();
    }

    private ArrayList<class_243> generateVeinPart(class_638 world, class_2919 random, int veinSize, double startX, double endX, double startZ, double endZ, double startY, double endY, int x, int y, int z, int size, int i, float discardOnAir) {

        BitSet bitSet = new BitSet(size * i * size);
        class_2338.class_2339 mutable = new class_2338.class_2339();
        double[] ds = new double[veinSize * 4];

        ArrayList<class_243> poses = new ArrayList<>();

        int n;
        double p;
        double q;
        double r;
        double s;
        for (n = 0; n < veinSize; ++n) {
            float f = (float) n / (float) veinSize;
            p = class_3532.method_16436(f, startX, endX);
            q = class_3532.method_16436(f, startY, endY);
            r = class_3532.method_16436(f, startZ, endZ);
            s = random.method_43058() * (double) veinSize / 16.0D;
            double m = ((double) (class_3532.method_15374(3.1415927F * f) + 1.0F) * s + 1.0D) / 2.0D;
            ds[n * 4] = p;
            ds[n * 4 + 1] = q;
            ds[n * 4 + 2] = r;
            ds[n * 4 + 3] = m;
        }

        for (n = 0; n < veinSize - 1; ++n) {
            if (!(ds[n * 4 + 3] <= 0.0D)) {
                for (int o = n + 1; o < veinSize; ++o) {
                    if (!(ds[o * 4 + 3] <= 0.0D)) {
                        p = ds[n * 4] - ds[o * 4];
                        q = ds[n * 4 + 1] - ds[o * 4 + 1];
                        r = ds[n * 4 + 2] - ds[o * 4 + 2];
                        s = ds[n * 4 + 3] - ds[o * 4 + 3];
                        if (s * s > p * p + q * q + r * r) {
                            if (s > 0.0D) {
                                ds[o * 4 + 3] = -1.0D;
                            } else {
                                ds[n * 4 + 3] = -1.0D;
                            }
                        }
                    }
                }
            }
        }

        for (n = 0; n < veinSize; ++n) {
            double u = ds[n * 4 + 3];
            if (!(u < 0.0D)) {
                double v = ds[n * 4];
                double w = ds[n * 4 + 1];
                double aa = ds[n * 4 + 2];
                int ab = Math.max(class_3532.method_15357(v - u), x);
                int ac = Math.max(class_3532.method_15357(w - u), y);
                int ad = Math.max(class_3532.method_15357(aa - u), z);
                int ae = Math.max(class_3532.method_15357(v + u), ab);
                int af = Math.max(class_3532.method_15357(w + u), ac);
                int ag = Math.max(class_3532.method_15357(aa + u), ad);

                for (int ah = ab; ah <= ae; ++ah) {
                    double ai = ((double) ah + 0.5D - v) / u;
                    if (ai * ai < 1.0D) {
                        for (int aj = ac; aj <= af; ++aj) {
                            double ak = ((double) aj + 0.5D - w) / u;
                            if (ai * ai + ak * ak < 1.0D) {
                                for (int al = ad; al <= ag; ++al) {
                                    double am = ((double) al + 0.5D - aa) / u;
                                    if (ai * ai + ak * ak + am * am < 1.0D) {
                                        int an = ah - x + (aj - y) * size + (al - z) * size * i;
                                        if (!bitSet.get(an)) {
                                            bitSet.set(an);
                                            mutable.method_10103(ah, aj, al);
                                            if (aj >= -64 && aj < 320 && (airCheck.get() == AirCheck.OFF || world.method_8320(mutable).method_26225())) {
                                                if (shouldPlace(world, mutable, discardOnAir, random)) {
                                                    poses.add(new class_243(ah, aj, al));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return poses;
    }

    private boolean shouldPlace(class_638 world, class_2338 orePos, float discardOnAir, class_2919 random) {
        if (discardOnAir == 0F || (discardOnAir != 1F && random.method_43057() >= discardOnAir)) {
            return true;
        }

        for (class_2350 direction : class_2350.values()) {
            if (!world.method_8320(orePos.method_10081(direction.method_62675())).method_26225() && discardOnAir != 1F) {
                return false;
            }
        }
        return true;
    }

    private ArrayList<class_243> generateHidden(class_638 world, class_2919 random, class_2338 blockPos, int size) {

        ArrayList<class_243> poses = new ArrayList<>();

        int i = random.method_43048(size + 1);

        for (int j = 0; j < i; ++j) {
            size = Math.min(j, 7);
            int x = this.randomCoord(random, size) + blockPos.method_10263();
            int y = this.randomCoord(random, size) + blockPos.method_10264();
            int z = this.randomCoord(random, size) + blockPos.method_10260();
            if (airCheck.get() == AirCheck.OFF || world.method_8320(new class_2338(x, y, z)).method_26225()) {
                if (shouldPlace(world, new class_2338(x, y, z), 1F, random)) {
                    poses.add(new class_243(x, y, z));
                }
            }
        }

        return poses;
    }

    private int randomCoord(class_2919 random, int size) {
        return Math.round((random.method_43057() - random.method_43057()) * (float) size);
    }
}
