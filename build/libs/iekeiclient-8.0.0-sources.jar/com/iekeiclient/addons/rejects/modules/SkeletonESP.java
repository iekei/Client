package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.systems.modules.render.Freecam;
import com.iekeiclient.engine.utils.player.PlayerUtils;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_5498;
import net.minecraft.class_742;
import java.util.List;

public class SkeletonESP extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<SettingColor> colorSetting = sgGeneral.add(new ColorSetting.Builder()
        .name("color")
        .description("Color of the skeleton.")
        .defaultValue(new SettingColor(255, 255, 255, 255))
        .build()
    );

    private final Setting<Boolean> distanceColors = sgGeneral.add(new BoolSetting.Builder()
        .name("distance-colors")
        .description("Change skeleton color based on distance.")
        .defaultValue(false)
        .build()
    );

    private final Freecam freecam;

    public SkeletonESP() {
        super(IekeiRejectsAddon.CATEGORY, "skeleton-esp", "Renders player skeletons.");
        freecam = Modules.get().get(Freecam.class);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        List<class_742> players = mc.field_1687.method_18456();

        for (class_742 player : players) {
            // Skip self in first-person unless freecam is active
            if (!freecam.isActive() && mc.field_1690.method_31044() == class_5498.field_26664 && player == mc.field_1724) {
                continue;
            }

            Color skeletonColor = distanceColors.get()
                ? getColorFromDistance(player)
                : PlayerUtils.getPlayerColor((class_1657) player, colorSetting.get());

            drawPlayerSkeleton(event, player, skeletonColor);
        }
    }

    private void drawPlayerSkeleton(Render3DEvent event, class_742 player, Color color) {
        class_243 basePos = player.method_30950(event.tickDelta);
        float yawRad = (float) Math.toRadians(-player.method_73188());

        boolean sneaking = player.method_5715();

        // Skeleton dimensions
        double shoulderWidth = 0.35;
        double hipWidth = 0.15;
        double armLength = 0.55;
        double legLength = 0.7;

        // Vertical positions
        double pelvisHeight = sneaking ? 0.6 : 0.7;
        double chestHeight = sneaking ? 1.05 : 1.35;
        double headTopHeight = sneaking ? 1.4 : 1.7;

        // Forward offset for sneaking
        class_243 sneakOffset = sneaking ? new class_243(0, 0, 0.25).method_1024(yawRad) : class_243.field_1353;

        // Core positions
        class_243 pelvisCenter = basePos.method_1031(0, pelvisHeight, 0).method_1019(sneakOffset);
        class_243 chestCenter = basePos.method_1031(0, chestHeight, 0);
        class_243 headTop = basePos.method_1031(0, headTopHeight, 0);

        // Shoulders (rotated with body)
        class_243 leftShoulder = chestCenter.method_1019(new class_243(-shoulderWidth, 0, 0).method_1024(yawRad));
        class_243 rightShoulder = chestCenter.method_1019(new class_243(shoulderWidth, 0, 0).method_1024(yawRad));

        // Arms (hang straight down from shoulders)
        class_243 leftHand = leftShoulder.method_1031(0, -armLength, 0);
        class_243 rightHand = rightShoulder.method_1031(0, -armLength, 0);

        // Hips (rotated with body)
        class_243 leftHip = pelvisCenter.method_1019(new class_243(-hipWidth, 0, 0).method_1024(yawRad));
        class_243 rightHip = pelvisCenter.method_1019(new class_243(hipWidth, 0, 0).method_1024(yawRad));

        // Feet (at ground level, aligned with hips)
        class_243 leftFoot = basePos.method_1019(new class_243(-hipWidth, 0, 0).method_1024(yawRad)).method_1019(sneakOffset);
        class_243 rightFoot = basePos.method_1019(new class_243(hipWidth, 0, 0).method_1024(yawRad)).method_1019(sneakOffset);

        // === Draw Skeleton ===

        // Spine (pelvis to chest)
        event.renderer.line(pelvisCenter.field_1352, pelvisCenter.field_1351, pelvisCenter.field_1350,
            chestCenter.field_1352, chestCenter.field_1351, chestCenter.field_1350, color);

        // Head (chest to top of head)
        event.renderer.line(chestCenter.field_1352, chestCenter.field_1351, chestCenter.field_1350,
            headTop.field_1352, headTop.field_1351, headTop.field_1350, color);

        // Shoulders
        event.renderer.line(leftShoulder.field_1352, leftShoulder.field_1351, leftShoulder.field_1350,
            rightShoulder.field_1352, rightShoulder.field_1351, rightShoulder.field_1350, color);

        // Left arm
        event.renderer.line(leftShoulder.field_1352, leftShoulder.field_1351, leftShoulder.field_1350,
            leftHand.field_1352, leftHand.field_1351, leftHand.field_1350, color);

        // Right arm
        event.renderer.line(rightShoulder.field_1352, rightShoulder.field_1351, rightShoulder.field_1350,
            rightHand.field_1352, rightHand.field_1351, rightHand.field_1350, color);

        // Pelvis
        event.renderer.line(leftHip.field_1352, leftHip.field_1351, leftHip.field_1350,
            rightHip.field_1352, rightHip.field_1351, rightHip.field_1350, color);

        // Left leg
        event.renderer.line(leftHip.field_1352, leftHip.field_1351, leftHip.field_1350,
            leftFoot.field_1352, leftFoot.field_1351, leftFoot.field_1350, color);

        // Right leg
        event.renderer.line(rightHip.field_1352, rightHip.field_1351, rightHip.field_1350,
            rightFoot.field_1352, rightFoot.field_1351, rightFoot.field_1350, color);
    }

    private Color getColorFromDistance(class_742 player) {
        class_243 playerPos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());
        double distance = mc.field_1773.method_19418().method_71156().method_1022(playerPos);
        double percent = Math.min(1.0, distance / 60.0);

        int r, g;

        if (percent < 0.5) {
            r = 255;
            g = (int) (255 * percent / 0.5);
        } else {
            g = 255;
            r = 255 - (int) (255 * (percent - 0.5) / 0.5);
        }

        return new Color(r, g, 0, 255);
    }
}
