package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.Cancellable;
import com.iekeiclient.engine.events.iekei.MouseClickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.systems.modules.combat.KillAura;
import com.iekeiclient.engine.utils.misc.input.KeyAction;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2879;
import net.minecraft.class_3966;

import static org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT;

public class ShieldBypass extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> ignoreAxe = sgGeneral.add(new BoolSetting.Builder()
            .name("ignore-axe")
            .description("Ignore if you are holding an axe.")
            .defaultValue(true)
            .build()
    );

    public ShieldBypass() {
        super(IekeiRejectsAddon.CATEGORY, "shield-bypass", "Attempts to teleport you behind enemies to bypass shields.");
    }

    @EventHandler
    private void onMouseButton(MouseClickEvent event) {
        if (Modules.get().isActive(KillAura.class)) return;
        if (mc.field_1755 == null && !mc.field_1724.method_6115() && event.action == KeyAction.Press && event.button() == GLFW_MOUSE_BUTTON_LEFT) {
            if (mc.field_1765 instanceof class_3966 result) {
                bypass(result.method_17782(), event);
            }
        }
    }

    private boolean isBlocked(class_243 pos, class_1309 target) {
        class_243 vec3d3 = pos.method_1035(new class_243(target.method_23317(), target.method_23318(), target.method_23321())).method_1029();
        return new class_243(vec3d3.field_1352, 0.0d, vec3d3.field_1350).method_1026(target.method_5828(1.0f)) >= 0.0d;
    }

    public void bypass(class_1297 target, Cancellable event) {
        if (target instanceof class_1309 e && e.method_6039()) {
            if (ignoreAxe.get() && InvUtils.testInMainHand(i -> i.method_7909() instanceof class_1743)) return;

            // Shield check
            if (isBlocked(new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()), e)) return;

            class_243 offset = class_243.method_1030(0, mc.field_1724.method_36454()).method_1029().method_1021(2);
            class_243 newPos = new class_243(e.method_23317(), e.method_23318(), e.method_23321()).method_1019(offset);

            // Move up to prevent tping into blocks
            boolean inside = false;
            for (float i = 0; i < 4; i += 0.25) {
                class_243 targetPos = newPos.method_1031(0, i, 0);

                boolean collides = !mc.field_1687.method_8587(null, e.method_5829().method_997(offset).method_997(targetPos.method_1020(newPos)));

                if (!inside && collides) {
                    inside = true;
                } else if (inside && !collides) {
                    newPos = targetPos;
                    break;
                }
            }

            if (!isBlocked(newPos, e)) return;

            event.cancel();

            mc.method_1562().method_52787(new class_2828.class_2829(newPos.method_10216(), newPos.method_10214(), newPos.method_10215(), true, false));

            mc.method_1562().method_52787(class_2824.method_34206(e, mc.field_1724.method_5715()));
            mc.method_1562().method_52787(new class_2879(mc.field_1724.method_6058()));
            mc.field_1724.method_75203();

            mc.method_1562().method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), true, mc.field_1724.field_5976));
        }
    }
}
