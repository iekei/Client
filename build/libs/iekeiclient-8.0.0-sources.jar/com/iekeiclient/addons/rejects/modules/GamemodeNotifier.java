package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.settings.GameModeListSetting;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1934;
import net.minecraft.class_2703;
import net.minecraft.class_640;
import java.util.List;

public class GamemodeNotifier extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<List<class_1934>> gamemodes = sgGeneral.add(new GameModeListSetting.Builder()
            .name("gamemode")
            .description("Which gamemodes to notify.")
            .build()
    );

    public GamemodeNotifier() {
        super(IekeiRejectsAddon.CATEGORY, "gamemode-notifier", "Notifies user a player's gamemode was changed.");
    }

    @EventHandler
    public void onPacket(PacketEvent.Receive event) {
        if (event.packet instanceof class_2703 packet) {
            for (class_2703.class_2705 entry : packet.method_46329()) {
                if (!packet.method_46327().contains(class_2703.class_5893.field_29137)) continue;
                class_640 entry1 = mc.method_1562().method_2871(entry.comp_1106());
                if (entry1 == null) continue;
                class_1934 gameMode = entry.comp_1110();
                if (entry1.method_2958() != gameMode) {
                    if (!gamemodes.get().contains(gameMode)) continue;
                    info("Player %s changed gamemode to %s", entry1.method_2966().name(), entry.comp_1110());
                }
            }
        }
    }
}


