package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.FindItemResult;
import com.iekeiclient.engine.utils.player.InvUtils;
import com.iekeiclient.engine.utils.player.Rotations;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;


public class Lavacast extends Module {

    private enum Stage {
        None,
        LavaDown,
        LavaUp,
        WaterDown,
        WaterUp
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgShape = settings.createGroup("Shape", false);
    private final Setting<Integer> tickInterval = sgGeneral.add(new IntSetting.Builder()
            .name("tick-interval")
            .description("Interval")
            .defaultValue(2)
            .min(0)
            .sliderMax(20)
            .build()
    );

    private final Setting<Integer> distMin = sgShape.add(new IntSetting.Builder()
            .name("minimum-distance")
            .description("Top plane cutoff")
            .defaultValue(5)
            .min(0)
            .sliderMax(10)
            .build()
    );
    private final Setting<Integer> lavaDownMult = sgShape.add(new IntSetting.Builder()
            .name("lava-down-mulipiler")
            .description("Controlls the shape of the cast")
            .defaultValue(40)
            .min(1)
            .sliderMax(100)
            .build()
    );
    private final Setting<Integer> lavaUpMult = sgShape.add(new IntSetting.Builder()
            .name("lava-up-mulipiler")
            .description("Controlls the shape of the cast")
            .defaultValue(8)
            .min(1)
            .sliderMax(100)
            .build()
    );
    private final Setting<Integer> waterDownMult = sgShape.add(new IntSetting.Builder()
            .name("water-down-mulipiler")
            .description("Controlls the shape of the cast")
            .defaultValue(4)
            .min(1)
            .sliderMax(100)
            .build()
    );
    private final Setting<Integer> waterUpMult = sgShape.add(new IntSetting.Builder()
            .name("water-up-mulipiler")
            .description("Controlls the shape of the cast")
            .defaultValue(1)
            .min(1)
            .sliderMax(100)
            .build()
    );
    
    private int dist;
    private class_2338 placeFluidPos;
    private int tick;
    private Stage stage = Stage.None;

    public Lavacast() {
        super(IekeiRejectsAddon.CATEGORY, "lavacast", "Automatically Lavacasts");
    }

    @Override
    public void onActivate() {
        if (mc.field_1724 == null || mc.field_1687 == null) toggle();
        tick = 0;
        stage = Stage.None;
        placeFluidPos = getTargetBlockPos();
        if (placeFluidPos == null) {
            placeFluidPos = mc.field_1724.method_24515().method_10087(2);
        } else {
            placeFluidPos = placeFluidPos.method_10084();
        }
        dist=-1;
        getDistance(new class_2382(1,0,0));
        getDistance(new class_2382(-1,0,0));
        getDistance(new class_2382(0,0,1));
        getDistance(new class_2382(1,0,-1));
        if (dist<1) {
            error("Couldn't locate bottom.");
            toggle();
            return;
        }
        info("Distance: (highlight)%d(default).", dist);
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        tick++;
        if (shouldBreakOnTick()) return;
        if (dist < distMin.get()) toggle();
        tick = 0;
        if (checkMineBlock()) return;
        switch (stage) {
            case None: {
                Rotations.rotate(Rotations.getYaw(placeFluidPos),Rotations.getPitch(placeFluidPos),100, this::placeLava);
                stage = Stage.LavaDown;
                break;
            }
            case LavaDown: {
                Rotations.rotate(Rotations.getYaw(placeFluidPos),Rotations.getPitch(placeFluidPos),100, this::pickupLiquid);
                stage = Stage.LavaUp;
                break;
            }
            case LavaUp: {
                Rotations.rotate(Rotations.getYaw(placeFluidPos),Rotations.getPitch(placeFluidPos),100, this::placeWater);
                stage = Stage.WaterDown;
                break;
            }
            case WaterDown: {
                Rotations.rotate(Rotations.getYaw(placeFluidPos),Rotations.getPitch(placeFluidPos),100, this::pickupLiquid);
                stage = Stage.WaterUp;
                break;
            }
            case WaterUp: {
                dist--;
                Rotations.rotate(Rotations.getYaw(placeFluidPos),Rotations.getPitch(placeFluidPos),100, this::placeLava);
                stage = Stage.LavaDown;
                break;
            }
            default:
                break;
        }
    }

    private boolean shouldBreakOnTick() {
        if (stage == Stage.LavaDown && tick < dist*lavaDownMult.get()) return true;
        if (stage == Stage.LavaUp && tick < dist*lavaUpMult.get()) return true;
        if (stage == Stage.WaterDown && tick < dist*waterDownMult.get()) return true;
        if (stage == Stage.WaterUp && tick < dist*waterUpMult.get()) return true;
        if (tick < tickInterval.get()) return true;
        return false;
    }

    private boolean checkMineBlock() {
        if (stage == Stage.None && mc.field_1687.method_8320(placeFluidPos).method_26204() != class_2246.field_10124) {
            Rotations.rotate(Rotations.getYaw(placeFluidPos), Rotations.getPitch(placeFluidPos), 100, this::updateBlockBreakingProgress);
            return true;
        }
        return false;
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (placeFluidPos == null) return;
        double x1 = placeFluidPos.method_10263();
        double y1 = placeFluidPos.method_10264();
        double z1 = placeFluidPos.method_10260();
        double x2 = x1+1;
        double y2 = y1+1;
        double z2 = z1+1;

        SettingColor color = new SettingColor(128, 128, 128);
        if (stage == Stage.LavaDown) color = new SettingColor(255, 180, 10);
        if (stage == Stage.LavaUp) color = new SettingColor(255, 180, 128);
        if (stage == Stage.WaterDown) color = new SettingColor(10, 10, 255);
        if (stage == Stage.WaterUp) color = new SettingColor(128, 128, 255);
        SettingColor color1 = color;
        color1.a = 75;

        event.renderer.box(x1, y1, z1, x2, y2, z2, color1, color, ShapeMode.Both, 0);
    }

    private void placeLava() {
        FindItemResult findItemResult = InvUtils.findInHotbar(class_1802.field_8187);
        if (!findItemResult.found()) {
            error("No lava bucket found.");
            toggle();
            return;
        }
        int prevSlot = mc.field_1724.method_31548().method_67532();
        mc.field_1724.method_31548().method_61496(findItemResult.slot());
        mc.field_1761.method_2919(mc.field_1724,class_1268.field_5808);
        mc.field_1724.method_31548().method_61496(prevSlot);
    }

    private void placeWater() {
        FindItemResult findItemResult = InvUtils.findInHotbar(class_1802.field_8705);
        if (!findItemResult.found()) {
            error("No water bucket found.");
            toggle();
            return;
        }
        int prevSlot = mc.field_1724.method_31548().method_67532();
        mc.field_1724.method_31548().method_61496(findItemResult.slot());
        mc.field_1761.method_2919(mc.field_1724,class_1268.field_5808);
        mc.field_1724.method_31548().method_61496(prevSlot);
    }

    private void pickupLiquid() {
        FindItemResult findItemResult = InvUtils.findInHotbar(class_1802.field_8550);
        if (!findItemResult.found()) {
            error("No bucket found.");
            toggle();
            return;
        }
        int prevSlot = mc.field_1724.method_31548().method_67532();
        mc.field_1724.method_31548().method_61496(findItemResult.slot());
        mc.field_1761.method_2919(mc.field_1724,class_1268.field_5808);
        mc.field_1724.method_31548().method_61496(prevSlot);
    }

    private void updateBlockBreakingProgress() {
        mc.field_1761.method_2902(placeFluidPos,class_2350.field_11036);
    }

    private class_2338 getTargetBlockPos() {
        class_239 blockHit = mc.field_1765;
        if (blockHit.method_17783() != class_239.class_240.field_1332) {
            return null;
        }
        return ((class_3965) blockHit).method_17777();
    }

    private void getDistance(class_2382 offset) {
        class_2338 pos = placeFluidPos.method_10074().method_10081(offset);
        int new_dist;
        final class_3965 result = mc.field_1687.method_17742(new class_3959(
                class_243.method_24953(pos), class_243.method_24953(pos.method_10087(250)), class_3959.class_3960.field_17558, class_3959.class_242.field_1347, mc.field_1724
        ));
        if (result == null || result.method_17783() != class_239.class_240.field_1332) {
            return;
        }
        new_dist = placeFluidPos.method_10264() - result.method_17777().method_10264();
        if (new_dist>dist) dist = new_dist;
    }

    @Override
    public String getInfoString() {
        return stage.toString();
    }
}
