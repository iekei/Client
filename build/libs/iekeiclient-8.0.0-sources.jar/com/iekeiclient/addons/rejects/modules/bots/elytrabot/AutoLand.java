package com.iekeiclient.addons.rejects.modules.bots.elytrabot;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1304;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AutoLand extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgAdvanced = settings.createGroup("Advanced");

    // General settings
    private final Setting<Boolean> autoActivate = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-activate")
        .description("Automatically activates when ground is detected within landing distance.")
        .defaultValue(false)
        .build());

    private final Setting<Integer> landingDistance = sgGeneral.add(new IntSetting.Builder()
        .name("landing-distance")
        .description("Distance to ground at which to start landing (in blocks).")
        .defaultValue(30)
        .min(5)
        .sliderMax(100)
        .visible(autoActivate::get)
        .build());

    private final Setting<LandingMode> landingMode = sgGeneral.add(new EnumSetting.Builder<LandingMode>()
        .name("landing-mode")
        .description("How the landing should be performed.")
        .defaultValue(LandingMode.Gradual)
        .build());

    private final Setting<Integer> landingPitch = sgGeneral.add(new IntSetting.Builder()
        .name("landing-pitch")
        .description("Pitch angle to maintain during landing (higher = steeper).")
        .defaultValue(10)
        .range(0, 90)
        .sliderMax(90)
        .visible(() -> landingMode.get() == LandingMode.Fixed)
        .build());

    private final Setting<Boolean> stopMovement = sgGeneral.add(new BoolSetting.Builder()
        .name("stop-movement")
        .description("Completely stops all horizontal movement when landing.")
        .defaultValue(false)
        .build());

    // Advanced settings
    private final Setting<Boolean> safetyCheck = sgAdvanced.add(new BoolSetting.Builder()
        .name("safety-check")
        .description("Checks for safe landing spot before beginning descent.")
        .defaultValue(true)
        .build());

    private final Setting<Double> minSpeed = sgAdvanced.add(new DoubleSetting.Builder()
        .name("minimum-speed")
        .description("Minimum speed to maintain during landing (to prevent stalling).")
        .defaultValue(0.2)
        .min(0.05)
        .sliderMax(1.0)
        .build());

    private final Setting<Boolean> debug = sgAdvanced.add(new BoolSetting.Builder()
        .name("debug")
        .description("Logs debug information in chat.")
        .defaultValue(false)
        .build());

    private boolean isLanding = false;
    private double distanceToGround = 0;
    private int tickCounter = 0;

    public AutoLand() {
        super(IekeiRejectsAddon.CATEGORY, "auto-land", "Automatically helps you land safely when flying with elytra");
    }

    @Override
    public void onActivate() {
        isLanding = false;
        if (debug.get()) info("ElytraLand activated");

        if (!isWearingElytra()) {
            if (debug.get()) error("Not wearing elytra, deactivating");
            toggle();
            return;
        }

        if (!mc.field_1724.method_6128()) {
            if (debug.get()) error("Not currently flying with elytra, deactivating");
            toggle();
            return;
        }

        isLanding = true;
        if (debug.get()) info("Beginning landing sequence");
    }

    @Override
    public void onDeactivate() {
        isLanding = false;
        if (debug.get()) info("ElytraLand deactivated");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        tickCounter++;

        // Only run every other tick to reduce performance impact
        if (tickCounter % 2 != 0) return;

        // Auto-activate check
        if (!isLanding && autoActivate.get() && isWearingElytra() && mc.field_1724.method_6128()) {
            distanceToGround = getDistanceToGround();
            if (distanceToGround <= landingDistance.get() && isValidLandingSpot()) {
                isLanding = true;
                if (debug.get()) info("Auto-activated landing at height: " + String.format("%.1f", distanceToGround));
            }
        }

        // Main landing logic
        if (isLanding) {
            // Check if we're still flying
            if (!isWearingElytra() || !mc.field_1724.method_6128()) {
                if (debug.get()) info("Landing complete or interrupted");
                toggle();
                return;
            }

            distanceToGround = getDistanceToGround();
            if (debug.get() && tickCounter % 20 == 0) {
                info("Distance to ground: " + String.format("%.1f", distanceToGround) + " blocks");
            }

            // Execute landing based on selected mode
            executeLanding();
        }
    }

    private void executeLanding() {
        // Calculate speed
        class_243 velocity = mc.field_1724.method_18798();
        double horizontalSpeed = Math.sqrt(velocity.field_1352 * velocity.field_1352 + velocity.field_1350 * velocity.field_1350);

        // Determine target pitch
        float targetPitch;

        if (landingMode.get() == LandingMode.Fixed) {
            targetPitch = landingPitch.get();
        } else {
            // Gradual mode - adjust pitch based on height
            if (distanceToGround > 20) {
                targetPitch = 0; // Level flight when high
            } else if (distanceToGround > 10) {
                targetPitch = 5; // Slight descent
            } else if (distanceToGround > 5) {
                targetPitch = 15; // Moderate descent
            } else {
                targetPitch = 30; // Steeper descent when close to ground
            }
        }

        // Apply rotation
        Rotations.rotate(mc.field_1724.method_36454(), targetPitch);

        // Stop movement if needed
        if (stopMovement.get()) {
            // Cancel horizontal movement but maintain minimal forward momentum to prevent stalling
            if (horizontalSpeed > minSpeed.get()) {
                double slowDownFactor = minSpeed.get() / horizontalSpeed;
                class_243 newVelocity = new class_243(
                    velocity.field_1352 * slowDownFactor,
                    velocity.field_1351,
                    velocity.field_1350 * slowDownFactor
                );
                mc.field_1724.method_18799(newVelocity);
                if (debug.get() && tickCounter % 20 == 0) {
                    info("Reducing speed: " + String.format("%.2f", horizontalSpeed) + " → " +
                        String.format("%.2f", horizontalSpeed * slowDownFactor));
                }
            }
        }

        // If very close to ground, prepare for impact
        if (distanceToGround < 2) {
            // Level out to avoid crash landing
            Rotations.rotate(mc.field_1724.method_36454(), 0);
        }
    }

    private double getDistanceToGround() {
        if (mc.field_1687 == null || mc.field_1724 == null) return 0;

        double maxDistance = 100; // Maximum distance to check
        class_243 start = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        class_243 end = start.method_1031(0, -maxDistance, 0);

        // Raycast to find ground
        class_3965 result = mc.field_1687.method_17742(new class_3959(
            start,
            end,
            class_3959.class_3960.field_17559,
            class_3959.class_242.field_1347,
            mc.field_1724
        ));

        if (result != null && result.method_17783() == class_3965.Type.field_1332) {
            return Math.sqrt(mc.field_1724.method_5707(result.method_17784()));
        }

        return maxDistance;
    }

    private boolean isValidLandingSpot() {
        if (!safetyCheck.get()) return true;

        class_243 playerPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        class_243 lookDir = mc.field_1724.method_5720();

        // Check ground ahead of player
        for (int i = 2; i < 10; i++) {
            class_243 checkPos = playerPos.method_1019(lookDir.method_1021(i));
            class_2338 blockPos = new class_2338((int) checkPos.field_1352, (int) checkPos.field_1351 - 1, (int) checkPos.field_1350);

            if (mc.field_1687.method_8320(blockPos).method_26215()) {
                // Found a gap in potential landing area
                if (debug.get()) info("Unsafe landing spot detected ahead");
                return false;
            }
        }

        return true;
    }

    private boolean isWearingElytra() {
        return mc.field_1724 != null &&
            mc.field_1724.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8833;
    }

    public enum LandingMode {
        Gradual, // Automatically adjusts pitch based on height
        Fixed    // Uses a fixed pitch angle for landing
    }
}
