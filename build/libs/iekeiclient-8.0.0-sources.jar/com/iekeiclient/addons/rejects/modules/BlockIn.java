package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.FindItemResult;
import com.iekeiclient.engine.utils.player.InvUtils;
import com.iekeiclient.engine.utils.player.PlayerUtils;
import com.iekeiclient.engine.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1313;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_243;

public class BlockIn extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    
    private final Setting<Boolean> multiPlace = sgGeneral.add(new BoolSetting.Builder()
            .name("multi-place")
            .description("Whether to place all blocks in a single tick")
            .defaultValue(false)
            .build()
    );
    
    private final Setting<Boolean> center = sgGeneral.add(new BoolSetting.Builder()
            .name("center")
            .description("Whether to center to avoid obstructing placement")
            .defaultValue(true)
            .build()
    );
    
    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Whether to rotate towards block placements.")
            .defaultValue(true)
            .build()
    );
    
    private final Setting<Boolean> turnOff = sgGeneral.add(new BoolSetting.Builder()
            .name("turn-off")
            .description("Whether to turn off after finished placing.")
            .defaultValue(true)
            .build()
    );
    
    private final Setting<Boolean> onlyOnGround = sgGeneral.add(new BoolSetting.Builder()
            .name("only-on-ground")
            .description("Only places when you are standing on blocks (not in midair).")
            .defaultValue(true)
            .build()
    );
    
    private final class_2338.class_2339 bp = new class_2338.class_2339();
    private boolean return_;
    private double sY;
    
    public BlockIn() {
        super(IekeiRejectsAddon.CATEGORY, "block-in", "Block yourself in using any block.");
    }
    
    @Override
    public void onActivate() {
        sY = mc.field_1724.method_23318();
    }
    
    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (mc.field_1724.method_24828() && mc.field_1724.method_23318()>Math.floor(mc.field_1724.method_23318()+0.2)) mc.field_1690.field_1832.method_23481(true);
        if (return_ && mc.field_1690.field_1832.method_1434()) mc.field_1690.field_1832.method_23481(false);
        if (center.get()) {
            if (!onlyOnGround.get()) {
                mc.field_1724.method_18800(0,0,0);
                mc.field_1724.method_5784(class_1313.field_6308, new class_243(0, -(sY-Math.floor(sY)), 0));
            }
            PlayerUtils.centerPlayer();
        }
        if (onlyOnGround.get() && !mc.field_1724.method_24828()) return;
        
        return_ = false;
        
        // Multiplace
        if (multiPlace.get()) {
            // Bottom
            boolean p1 = place(0, -1, 0);
            // Lower sides
            boolean p2 = place(1, 0, 0);
            boolean p3 = place(-1, 0, 0);
            boolean p4 = place(0, 0, 1);
            boolean p5 = place(0, 0, -1);
            // Upper sides
            boolean p6 = place(1, 1, 0);
            boolean p7 = place(-1, 1, 0);
            boolean p8 = place(0, 1, 1);
            boolean p9 = place(0, 1, -1);
            // Top
            boolean p10 = place(0, 2, 0);
            
            // Turn off
            if (turnOff.get() && p1 && p2 && p3 && p4 && p5 && p6 && p7 && p8 && p9 && p10) toggle();
            
            // No multiplace
        } else {
            // Bottom
            boolean p1 = place(0, -1, 0);
            if (return_) return;
            // Lower sides
            boolean p2 = place(1, 0, 0);
            if (return_) return;
            boolean p3 = place(-1, 0, 0);
            if (return_) return;
            boolean p4 = place(0, 0, 1);
            if (return_) return;
            boolean p5 = place(0, 0, -1);
            if (return_) return;
            // Upper sides
            boolean p6 = place(1, 1, 0);
            if (return_) return;
            boolean p7 = place(-1, 1, 0);
            if (return_) return;
            boolean p8 = place(0, 1, 1);
            if (return_) return;
            boolean p9 = place(0, 1, -1);
            if (return_) return;
            // Top
            boolean p10 = place(0, 2, 0);
            
            // Turn off
            if (turnOff.get() && p1 && p2 && p3 && p4 && p5 && p6 && p7 && p8 && p9 && p10) toggle();
        }
    }
    
    private boolean place(int x, int y, int z) {
        setBlockPos(x, y, z);
        FindItemResult findItemResult = InvUtils.findInHotbar(itemStack -> validItem(itemStack, bp));
        if (!BlockUtils.canPlace(bp)) return true;
        
        if (BlockUtils.place(bp, findItemResult, rotate.get(), 100, true)) {
            return_ = true;
        }
        
        return false;
    }
    
    private void setBlockPos(int x, int y, int z) {
        bp.method_10102(mc.field_1724.method_23317() + x, mc.field_1724.method_23318() + y, mc.field_1724.method_23321() + z);
    }
    
    private boolean validItem(class_1799 itemStack, class_2338 pos) {
        if (!(itemStack.method_7909() instanceof class_1747)) return false;
        class_2248 block = ((class_1747) itemStack.method_7909()).method_7711();
        
        if (!class_2248.method_9614(block.method_9564().method_26220(mc.field_1687, pos))) return false;
        return !(block instanceof class_2346) || !class_2346.method_10128(mc.field_1687.method_8320(pos));
    }
}
