package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_12206;
import net.minecraft.class_1268;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2885;

public class AntiSpawnpoint extends Module {

    private SettingGroup sgDefault = settings.getDefaultGroup();

    private Setting<Boolean> fakeUse = sgDefault.add(new BoolSetting.Builder()
            .name("fake-use")
            .description("Fake using the bed or anchor.")
            .defaultValue(true)
            .build()
    );

    public AntiSpawnpoint() {
        super(IekeiRejectsAddon.CATEGORY, "anti-spawnpoint", "Protects the player from losing the respawn point.");
    }

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (mc.field_1687 == null) return;
        if(!(event.packet instanceof class_2885)) return;


        class_2338 blockPos = ((class_2885) event.packet).method_12543().method_17777();
        boolean IsOverWorld = mc.field_1687.method_75598().method_75697(class_12206.field_63756, blockPos).method_75644(mc.field_1687);
        boolean IsNetherWorld = mc.field_1687.method_75598().method_75697(class_12206.field_63757, blockPos);
        boolean BlockIsBed = mc.field_1687.method_8320(blockPos).method_26204() instanceof class_2244;
        boolean BlockIsAnchor = mc.field_1687.method_8320(blockPos).method_26204().equals(class_2246.field_23152);

        if (fakeUse.get()) {
            if (BlockIsBed && IsOverWorld) {
                mc.field_1724.method_6104(class_1268.field_5808);
                mc.field_1724.method_30634(blockPos.method_10263(),blockPos.method_10084().method_10264(),blockPos.method_10260());
            }
            else if (BlockIsAnchor && IsNetherWorld) {
                mc.field_1724.method_6104(class_1268.field_5808);
            }
        }

        if((BlockIsBed && IsOverWorld)||(BlockIsAnchor && IsNetherWorld)) {
            event.cancel();
        }
    }
}
