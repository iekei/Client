package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.utils.WorldUtils;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.Utils;
import com.iekeiclient.engine.utils.player.FindItemResult;
import com.iekeiclient.engine.utils.player.InvUtils;
import com.iekeiclient.engine.utils.player.PlayerUtils;
import com.iekeiclient.engine.utils.player.Rotations;
import com.iekeiclient.engine.utils.world.CardinalDirection;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2473;
import net.minecraft.class_2885;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.IntStream;

public class TreeAura extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> rotation = sgGeneral.add(new BoolSetting.Builder().name("rotate").description("rotate for block interactions").defaultValue(false).build());
    private final Setting<Integer> plantDelay = sgGeneral.add(new IntSetting.Builder().name("plant-delay").description("delay between planting trees").defaultValue(6).min(0).sliderMax(25).build());
    private final Setting<Integer> bonemealDelay = sgGeneral.add(new IntSetting.Builder().name("bonemeal-delay").description("delay between placing bonemeal on trees").defaultValue(3).min(0).sliderMax(25).build());
    private final Setting<Integer> rRange = sgGeneral.add(new IntSetting.Builder().name("radius").description("how far you can place horizontally").defaultValue(4).min(1).sliderMax(5).build());
    private final Setting<Integer> yRange = sgGeneral.add(new IntSetting.Builder().name("y-range").description("how far you can place vertically").defaultValue(3).min(1).sliderMax(5).build());
    private final Setting<SortMode> sortMode = sgGeneral.add(new EnumSetting.Builder<SortMode>().name("sort-mode").description("how to sort nearby trees/placements.").defaultValue(SortMode.Farthest).build());

    private int bonemealTimer, plantTimer;


    public TreeAura() { // CopeTypes
        super(IekeiRejectsAddon.CATEGORY, "tree-aura", "Plants trees around you");
    }

    @Override
    public void onActivate() {
        bonemealTimer = 0;
        plantTimer = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {

        plantTimer--;
        bonemealTimer--;

        if (plantTimer <= 0) {
            class_2338 plantPos = findPlantLocation();
            if (plantPos == null) return;
            doPlant(plantPos);
            plantTimer = plantDelay.get();
        }

        if (bonemealTimer <= 0) {
            class_2338 p = findPlantedSapling();
            if (p == null) return;
            doBonemeal(p);
            bonemealTimer = bonemealDelay.get();
        }
    }


    private FindItemResult findBonemeal() {
        return InvUtils.findInHotbar(class_1802.field_8324);
    }

    private FindItemResult findSapling() {
        return InvUtils.findInHotbar(itemStack -> class_2248.method_9503(itemStack.method_7909()) instanceof class_2473);
    }

    private boolean isSapling(class_2338 pos) {
        return mc.field_1687.method_8320(pos).method_26204() instanceof class_2473;
    }

    private void doPlant(class_2338 plantPos) {
        FindItemResult sapling = findSapling();
        if (!sapling.found()) {
            error("No saplings in hotbar");
            toggle();
            return;
        }
        InvUtils.swap(sapling.slot(), false);
        if (rotation.get())
            Rotations.rotate(Rotations.getYaw(plantPos), Rotations.getPitch(plantPos), () -> mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, new class_3965(Utils.vec3d(plantPos), class_2350.field_11036, plantPos, false), 0)));
        else
            mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, new class_3965(Utils.vec3d(plantPos), class_2350.field_11036, plantPos, false), 0));
    }

    private void doBonemeal(class_2338 sapling) {
        FindItemResult bonemeal = findBonemeal();
        if (!bonemeal.found()) {
            error("No bonemeal in hotbar");
            toggle();
            return;
        }
        InvUtils.swap(bonemeal.slot(), false);
        if (rotation.get())
            Rotations.rotate(Rotations.getYaw(sapling), Rotations.getPitch(sapling), () -> mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, new class_3965(Utils.vec3d(sapling), class_2350.field_11036, sapling, false), 0)));
        else
            mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, new class_3965(Utils.vec3d(sapling), class_2350.field_11036, sapling, false), 0));
    }

    private boolean canPlant(class_2338 pos) {
        class_2248 b = mc.field_1687.method_8320(pos).method_26204();
        if (b.equals(class_2246.field_10479) || b.equals(class_2246.field_10219) || b.equals(class_2246.field_10566) || b.equals(class_2246.field_10253)) {
            final AtomicBoolean plant = new AtomicBoolean(true);
            IntStream.rangeClosed(1, 5).forEach(i -> {
                // Check above
                class_2338 check = pos.method_10086(i);
                if (!mc.field_1687.method_8320(check).method_26204().equals(class_2246.field_10124)) {
                    plant.set(false);
                    return;
                }
                // Check around
                for (CardinalDirection dir : CardinalDirection.values()) {
                    if (!mc.field_1687.method_8320(check.method_10079(dir.toDirection(), i)).method_26204().equals(class_2246.field_10124)) {
                        plant.set(false);
                        return;
                    }
                }
            });
            return plant.get();
        }
        return false;
    }

    private List<class_2338> findSaplings(class_2338 centerPos, int radius, int height) {
        ArrayList<class_2338> blocc = new ArrayList<>();
        List<class_2338> blocks = WorldUtils.getSphere(centerPos, radius, height);
        for (class_2338 b : blocks) if (isSapling(b)) blocc.add(b);
        return blocc;
    }

    private class_2338 findPlantedSapling() {
        List<class_2338> saplings = findSaplings(mc.field_1724.method_24515(), rRange.get(), yRange.get());
        if (saplings.isEmpty()) return null;
        saplings.sort(Comparator.comparingDouble(PlayerUtils::distanceTo));
        if (sortMode.get().equals(SortMode.Farthest)) Collections.reverse(saplings);
        return saplings.get(0);
    }

    private List<class_2338> getPlantLocations(class_2338 centerPos, int radius, int height) {
        ArrayList<class_2338> blocc = new ArrayList<>();
        List<class_2338> blocks = WorldUtils.getSphere(centerPos, radius, height);
        for (class_2338 b : blocks) if (canPlant(b)) blocc.add(b);
        return blocc;
    }

    private class_2338 findPlantLocation() {
        List<class_2338> nearby = getPlantLocations(mc.field_1724.method_24515(), rRange.get(), yRange.get());
        if (nearby.isEmpty()) return null;
        nearby.sort(Comparator.comparingDouble(PlayerUtils::distanceTo));
        if (sortMode.get().equals(SortMode.Farthest)) Collections.reverse(nearby);
        return nearby.get(0);
    }

    private double distanceBetween(class_2338 pos1, class_2338 pos2) {
        double d = pos1.method_10263() - pos2.method_10263();
        double e = pos1.method_10264() - pos2.method_10264();
        double f = pos1.method_10260() - pos2.method_10260();
        return class_3532.method_15355((float) (d * d + e * e + f * f));
    }

    public enum SortMode {Closest, Farthest}

}