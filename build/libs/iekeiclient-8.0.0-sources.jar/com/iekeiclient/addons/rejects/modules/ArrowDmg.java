package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.events.StopUsingItemEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_746;

public class ArrowDmg extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<Integer> packets = sgGeneral.add(new IntSetting.Builder()
            .name("packets")
            .description("Amount of packets to send. More packets = higher damage.")
            .defaultValue(200)
            .min(2)
            .sliderMax(2000)
            .build()
    );

    public final Setting<Boolean> tridents = sgGeneral.add(new BoolSetting.Builder()
            .name("tridents")
            .description("When enabled, tridents fly much further. Doesn't seem to affect damage or Riptide. WARNING: You can easily lose your trident by enabling this option!")
            .defaultValue(false)
            .build()
    );


    public ArrowDmg() {
        super(IekeiRejectsAddon.CATEGORY, "arrow-damage", "Massively increases arrow damage, but also consumes a lot of hunger and reduces accuracy. Does not work with crossbows and seems to be patched on Paper servers.");
    }

    @EventHandler
    private void onStopUsingItem(StopUsingItemEvent event) {
        if (!isValidItem(event.itemStack.method_7909()))
            return;

        class_746 p = mc.field_1724;

        p.field_3944.method_52787(
                new class_2848(p, class_2848.class_2849.field_12981));

        double x = p.method_23317();
        double y = p.method_23318();
        double z = p.method_23321();

        for (int i = 0; i < packets.get() / 2; i++) {
            p.field_3944.method_52787(new class_2828.class_2829(x,
                    y - 1e-10, z, true, mc.field_1724.field_5976));
            p.field_3944.method_52787(new class_2828.class_2829(x,
                    y + 1e-10, z, false, mc.field_1724.field_5976));
        }
    }

    private boolean isValidItem(class_1792 item) {
        return tridents.get() && item == class_1802.field_8547 || item == class_1802.field_8102;
    }
}
