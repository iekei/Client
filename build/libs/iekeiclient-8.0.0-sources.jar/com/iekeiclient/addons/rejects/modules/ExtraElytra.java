package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_3532;

public class ExtraElytra extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> instantFly = sgGeneral.add(new BoolSetting.Builder()
            .name("instant-fly")
            .description("Jump to fly, no weird double-jump needed!")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> speedCtrl = sgGeneral.add(new BoolSetting.Builder()
            .name("speed-ctrl")
            .description("""
                    Control your speed with the Forward and Back keys.
                    (default: W and S)
                    No fireworks needed!""")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> heightCtrl = sgGeneral.add(new BoolSetting.Builder()
            .name("height-ctrl")
            .description("""
                    Control your height with the Jump and Sneak keys.
                    (default: Spacebar and Shift)
                    No fireworks needed!""")
            .defaultValue(false)
            .build()
    );

    private final Setting<Boolean> stopInWater = sgGeneral.add(new BoolSetting.Builder()
            .name("stop-in-water")
            .description("Stop flying in water")
            .defaultValue(true)
            .build()
    );

    private int jumpTimer;

    @Override
    public void onActivate() {
        jumpTimer = 0;
    }

    public ExtraElytra() {
        super(IekeiRejectsAddon.CATEGORY, "extra-elytra", "Easier elytra");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (jumpTimer > 0)
            jumpTimer--;

        class_1799 chest = mc.field_1724.method_6118(class_1304.field_6174);
        if (chest.method_7909() != class_1802.field_8833)
            return;

        if (mc.field_1724.method_6128()) {
            if (stopInWater.get() && mc.field_1724.method_5799()) {
                sendStartStopPacket();
                return;
            }
            controlSpeed();
            controlHeight();
            return;
        }

        if (chest.method_7919() < chest.method_7936() - 1 && mc.field_1690.field_1903.method_1434())
            doInstantFly();
    }

    private void sendStartStopPacket() {
        class_2848 packet = new class_2848(mc.field_1724,
                class_2848.class_2849.field_12982);
        mc.field_1724.field_3944.method_52787(packet);
    }

    private void controlHeight() {
        if (!heightCtrl.get())
            return;

        class_243 v = mc.field_1724.method_18798();

        if (mc.field_1690.field_1903.method_1434())
            mc.field_1724.method_18800(v.field_1352, v.field_1351 + 0.08, v.field_1350);
        else if (mc.field_1690.field_1832.method_1434())
            mc.field_1724.method_18800(v.field_1352, v.field_1351 - 0.04, v.field_1350);
    }

    private void controlSpeed() {
        if (!speedCtrl.get())
            return;

        float yaw = (float) Math.toRadians(mc.field_1724.method_36454());
        class_243 forward = new class_243(-class_3532.method_15374(yaw) * 0.05, 0,
                class_3532.method_15362(yaw) * 0.05);

        class_243 v = mc.field_1724.method_18798();

        if (mc.field_1690.field_1894.method_1434())
            mc.field_1724.method_18799(v.method_1019(forward));
        else if (mc.field_1690.field_1881.method_1434())
            mc.field_1724.method_18799(v.method_1020(forward));
    }

    private void doInstantFly() {
        if (!instantFly.get())
            return;

        if (jumpTimer <= 0) {
            jumpTimer = 20;
            mc.field_1724.method_6100(false);
            mc.field_1724.method_5728(true);
            mc.field_1724.method_6043();
        }

        sendStartStopPacket();
    }
}
