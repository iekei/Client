package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.PlayerUtils;
import com.iekeiclient.engine.utils.player.Rotations;
import com.iekeiclient.engine.utils.world.BlockIterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_12206;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.concurrent.atomic.AtomicInteger;

public class AutoExtinguish extends Module {
    private final SettingGroup sgGeneral = settings.createGroup("Extinguish Fire around you");
    private final SettingGroup sgBucket = settings.createGroup("Extinguish yourself");

    private final Setting<Boolean> extinguish = sgGeneral.add(new BoolSetting.Builder()
            .name("extinguish")
            .description("Automatically extinguishes fire around you.")
            .defaultValue(false)
            .build()
    );
    private final Setting<Integer> horizontalRadius = sgGeneral.add(new IntSetting.Builder()
            .name("horizontal-radius")
            .description("Horizontal radius in which to search for fire.")
            .defaultValue(4)
            .min(0)
            .sliderMax(6)
            .build()
    );

    private final Setting<Integer> verticalRadius = sgGeneral.add(new IntSetting.Builder()
            .name("vertical-radius")
            .description("Vertical radius in which to search for fire.")
            .defaultValue(4)
            .min(0)
            .sliderMax(6)
            .build()
    );
    private final Setting<Integer> maxBlockPerTick = sgGeneral.add(new IntSetting.Builder()
            .name("block-per-tick")
            .description("Maximum amount of Blocks to extinguish per tick.")
            .defaultValue(5)
            .min(1)
            .sliderMax(50)
            .build()
    );
    private final Setting<Boolean> waterBucket = sgBucket.add(new BoolSetting.Builder()
            .name("water")
            .description("Automatically places water when you are on fire (and don't have fire resistance).")
            .defaultValue(false)
            .build()
    );
    private final Setting<Boolean> center = sgBucket.add(new BoolSetting.Builder()
            .name("center")
            .description("Automatically centers you when placing water.")
            .defaultValue(false)
            .build()
    );
    private final Setting<Boolean> onGround = sgBucket.add(new BoolSetting.Builder()
            .name("on-ground")
            .description("Only place when you are on ground.")
            .defaultValue(false)
            .build()
    );

    private boolean hasPlacedWater = false;
    private class_2338 blockPos = null;
    private boolean doesWaterBucketWork = true;

    private static final class_1291 FIRE_RESISTANCE = class_7923.field_41174.method_63535(class_2960.method_60654("fire_resistance"));

    public AutoExtinguish() {
        super(IekeiRejectsAddon.CATEGORY, "auto-extinguish", "Automatically extinguishes fire around you");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1687.method_75598().method_75695(class_12206.field_63757, mc.field_1724.method_73189())) {
            if (doesWaterBucketWork) {
                warning("Water Buckets don't work in this dimension!");
                doesWaterBucketWork = false;

            }
        } else {
            if (!doesWaterBucketWork) {
                warning("Enabled Water Buckets!");
                doesWaterBucketWork = true;
            }
        }
        if (onGround.get() && !mc.field_1724.method_24828()) {
            return;
        }

        if (waterBucket.get() && doesWaterBucketWork) {
            if (hasPlacedWater) {
                final int slot = findSlot(class_1802.field_8550);
                blockPos = mc.field_1724.method_24515();
                place(slot);
                hasPlacedWater = false;

            } else if (!mc.field_1724.method_6059(class_7923.field_41174.method_47983(FIRE_RESISTANCE)) && mc.field_1724.method_5809()) {
                blockPos = mc.field_1724.method_24515();
                final int slot = findSlot(class_1802.field_8705);
                if (mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_10036 || mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_22089) {
                    float yaw = mc.field_1773.method_19418().method_19330() % 360;
                    float pitch = mc.field_1773.method_19418().method_19329() % 360;
                    if (center.get()) {
                        PlayerUtils.centerPlayer();
                    }
                    Rotations.rotate(yaw, 90);
                    mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12968, blockPos, class_2350.field_11036));
                    mc.field_1724.method_6104(class_1268.field_5808);
                    mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12973, blockPos, class_2350.field_11036));

                    Rotations.rotate(yaw, pitch);
                }
                place(slot);
                hasPlacedWater = true;
            }
        }

        if (extinguish.get()) {
            AtomicInteger blocksPerTick = new AtomicInteger();
            BlockIterator.register(horizontalRadius.get(), verticalRadius.get(), (blockPos, blockState) -> {
                if (blocksPerTick.get() <= maxBlockPerTick.get()) {
                    if (blockState.method_26204() == class_2246.field_10036 || mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_22089) {
                        extinguishFire(blockPos);
                        blocksPerTick.getAndIncrement();
                    }
                }
            });
        }
    }

    private void place(int slot) {
        if (slot != -1) {
            final int preSlot = mc.field_1724.method_31548().method_67532();
            if (center.get()) {
                PlayerUtils.centerPlayer();
            }
            mc.field_1724.method_31548().method_61496(slot);
            float yaw = mc.field_1773.method_19418().method_19330() % 360;
            float pitch = mc.field_1773.method_19418().method_19329() % 360;

            Rotations.rotate(yaw, 90);
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            mc.field_1724.method_31548().method_61496(preSlot);
            Rotations.rotate(yaw, pitch);

        }
    }

    private void extinguishFire(class_2338 blockPos) {
        mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12968, blockPos, net.minecraft.class_2350.field_11036));
        mc.field_1724.method_6104(class_1268.field_5808);
        mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12973, blockPos, net.minecraft.class_2350.field_11036));
    }

    private int findSlot(class_1792 item) {
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            class_1799 block = mc.field_1724.method_31548().method_5438(i);
            if (block.method_7909() == item) {
                slot = i;
                break;
            }
        }

        return slot;
    }

}
