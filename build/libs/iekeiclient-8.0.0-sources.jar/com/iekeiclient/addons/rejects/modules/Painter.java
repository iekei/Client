package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.utils.WorldUtils;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.FindItemResult;
import com.iekeiclient.engine.utils.player.InvUtils;
import com.iekeiclient.engine.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class Painter extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    
    private final Setting<class_2248> block = sgGeneral.add(new BlockSetting.Builder()
            .name("block")
            .description("Block to use for painting")
            .defaultValue(class_2246.field_10494)
            .build()
    );
    
    private final Setting<Integer> range = sgGeneral.add(new IntSetting.Builder()
            .name("range")
            .description("Range of placement")
            .min(0)
            .defaultValue(0)
            .build()
    );
    
    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("Delay between block placement (in ticks)")
            .min(0)
            .defaultValue(0)
            .build()
    );

    private final Setting<Integer> bpt = sgGeneral.add(new IntSetting.Builder()
            .name("blocks-per-tick")
            .description("Amount of blocks that can be placed in one tick")
            .min(1)
            .defaultValue(1)
            .build()
    );
    
    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("rotate")
            .description("Whether or not to rotate towards block while placing")
            .defaultValue(true)
            .build()
    );
    
    private final Setting<Boolean> topSurfaces = sgGeneral.add(new BoolSetting.Builder()
            .name("top-surface")
            .description("Whether or not to cover top surfaces")
            .defaultValue(true)
            .build()
    );
    
    private final Setting<Boolean> sideSurfaces = sgGeneral.add(new BoolSetting.Builder()
            .name("side-surface")
            .description("Whether or not to cover side surfaces")
            .defaultValue(true)
            .build()
    );
    
    private final Setting<Boolean> bottomSurfaces = sgGeneral.add(new BoolSetting.Builder()
            .name("bottom-surface")
            .description("Whether or not to cover bottom surfaces")
            .defaultValue(true)
            .build()
    );
    
    private final Setting<Boolean> oneBlockHeight = sgGeneral.add(new BoolSetting.Builder()
            .name("one-block-height")
            .description("Whether or not to cover in one block high gaps")
            .defaultValue(true)
            .build()
    );

    private int ticksWaited;
    
    public Painter() {
        super(IekeiRejectsAddon.CATEGORY, "painter", "Automatically paints/covers surfaces (good for trolling)");
    }
    
    @EventHandler
    private void onTick(TickEvent.Post event) {
        // Tick delay
        if (delay.get() != 0 && ticksWaited < delay.get() - 1) {
            ticksWaited++;
            return;
        }
        else ticksWaited = 0;
        
        // Get slot
        FindItemResult findItemResult = InvUtils.findInHotbar(itemStack -> block.get() == class_2248.method_9503(itemStack.method_7909()));
        if (!findItemResult.found()) {
            error("No selected blocks in hotbar");
            toggle();
            return;
        }
        
        // Find spots
        int placed = 0;
        for (class_2338 blockPos : WorldUtils.getSphere(mc.field_1724.method_24515(), range.get(), range.get())) {
            if (shouldPlace(blockPos, block.get())) {
                BlockUtils.place(blockPos, findItemResult, rotate.get(), -100, false);
                placed++;

                // Delay 0
                if (delay.get() != 0 && placed >= bpt.get()) break;
            }
        }
    }
    
    private boolean shouldPlace(class_2338 blockPos, class_2248 useBlock) {
        // Self
        if (!mc.field_1687.method_8320(blockPos).method_45474()) return false;
    
        // One block height
        if (!oneBlockHeight.get() &&
                !mc.field_1687.method_8320(blockPos.method_10084()).method_45474() &&
                !mc.field_1687.method_8320(blockPos.method_10074()).method_45474()) return false;
    
    
        boolean north = true;
        boolean south = true;
        boolean east = true;
        boolean west = true;
        boolean up = true;
        boolean bottom = true;
        class_2680 northState = mc.field_1687.method_8320(blockPos.method_10095());
        class_2680 southState = mc.field_1687.method_8320(blockPos.method_10072());
        class_2680 eastState = mc.field_1687.method_8320(blockPos.method_10078());
        class_2680 westState = mc.field_1687.method_8320(blockPos.method_10067());
        class_2680 upState = mc.field_1687.method_8320(blockPos.method_10084());
        class_2680 bottomState = mc.field_1687.method_8320(blockPos.method_10074());
    
        // Top surface
        if (topSurfaces.get()) {
            if (upState.method_45474() || upState.method_26204() == useBlock) up = false;
        }
        
        // Side surfaces
        if (sideSurfaces.get()) {
            
            if (northState.method_45474() || northState.method_26204() == useBlock) north = false;
            if (southState.method_45474() || southState.method_26204() == useBlock) south = false;
            if (eastState.method_45474() || eastState.method_26204() == useBlock) east = false;
            if (westState.method_45474() || westState.method_26204() == useBlock) west = false;
        }
        
        // Bottom surface
        if (bottomSurfaces.get()) {
            if (bottomState.method_45474() || bottomState.method_26204() == useBlock) bottom = false;
        }
    
        return north || south || east || west || up || bottom;
    }
}
