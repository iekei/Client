package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import java.util.ArrayList;
import java.util.List;

//TODO: add settings to find/use shovel, delay, range ?
//https://github.com/DustinRepo/JexClient/blob/main/src/main/java/me/dustin/jex/feature/mod/impl/world/LawnBot.java
public class LawnBot extends Module {
    private final ArrayList<class_2338> myceliumSpots = new ArrayList<>();
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<List<class_2248>> blockWhitelist = sgGeneral.add(new BlockListSetting.Builder()
            .name("block-whitelist")
            .description("Which blocks to replace with grass.")
            .defaultValue()
            .filter(this::grassFilter)
            .build()
    );

    public LawnBot() {
        super(IekeiRejectsAddon.CATEGORY, "lawnbot", "Replace a variety of dirt-type blocks with grass");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        class_1792 grassBlockItem = class_1802.field_8270;
        int grassCount = InvUtils.find(grassBlockItem).count();
        if (grassCount == 0) {
            return;
        }

        int grassHotbarSlot = InvUtils.findInHotbar((itemStack -> itemStack.method_7909() == grassBlockItem)).slot();
        if (grassHotbarSlot == -1) {
            int grassInvSlot = InvUtils.find((itemStack -> itemStack.method_7909() == grassBlockItem)).slot();
            if (grassInvSlot == -1)
                return;

            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, grassInvSlot < 9 ? grassInvSlot + 36 : grassInvSlot, 8, class_1713.field_7791, mc.field_1724);
            return;
        }
        for (int i = 0; i < myceliumSpots.size(); i++) {
            class_2338 pos = myceliumSpots.get(i);
            class_2248 block = mc.field_1687.method_8320(pos).method_26204();
            double distance = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()).method_1022(new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260()));
            if (block == class_2246.field_10124 && distance <= 5) {
                mc.field_1724.method_31548().method_61496(grassHotbarSlot);
                mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, new class_3965(new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260()), class_2350.field_11036, pos, false));
                return;
            } else if (!blockWhitelist.get().contains(block)) {
                myceliumSpots.remove(i);
            }
        }
        for (int i = 0; i < myceliumSpots.size(); i++) {
            class_2338 pos = myceliumSpots.get(i);
            class_2248 block = mc.field_1687.method_8320(pos).method_26204();
            double distance = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()).method_1022(new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260()));
            if (blockWhitelist.get().contains(block) && distance <= 5) {
                mc.field_1761.method_2902(pos, class_2350.field_11036);
                return;
            }
        }
        myceliumSpots.clear();
        for (int x = -5; x < 5; x++) {
            for (int y = -3; y < 3; y++) {
                for (int z = -5; z < 5; z++) {
                    class_2338 pos = mc.field_1724.method_24515().method_10069(x, y, z);
                    if (blockWhitelist.get().contains(mc.field_1687.method_8320(pos).method_26204())) {
                        myceliumSpots.add(pos);
                    }
                }
            }
        }
    }

    private boolean grassFilter(class_2248 block) {
        return  block == class_2246.field_10402 ||
                block == class_2246.field_10520 ||
                block == class_2246.field_10194 ||
                block == class_2246.field_10253 ||
                block == class_2246.field_28685;
    }
}
