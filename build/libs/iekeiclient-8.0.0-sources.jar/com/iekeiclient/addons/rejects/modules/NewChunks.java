package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2672;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_3610;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/*
    Ported from: https://github.com/BleachDrinker420/BleachHack/blob/master/BleachHack-Fabric-1.16/src/main/java/bleach/hack/module/mods/NewChunks.java
*/
public class NewChunks extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
	private final SettingGroup sgRender = settings.createGroup("Render");

	// general

	private final Setting<Boolean> remove = sgGeneral.add(new BoolSetting.Builder()
        .name("remove")
        .description("Removes the cached chunks when disabling the module.")
        .defaultValue(true)
        .build()
    );

	// render
	public final Setting<Integer> renderHeight = sgRender.add(new IntSetting.Builder()
			.name("render-height")
			.description("The height at which new chunks will be rendered")
			.defaultValue(0)
			.min(-64)
			.sliderRange(-64,319)
			.build()
	);

	private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
			.name("shape-mode")
			.description("How the shapes are rendered.")
			.defaultValue(ShapeMode.Both)
			.build()
	);

	private final Setting<SettingColor> newChunksSideColor = sgRender.add(new ColorSetting.Builder()
			.name("new-chunks-side-color")
			.description("Color of the chunks that are (most likely) completely new.")
			.defaultValue(new SettingColor(255, 0, 0, 75))
			.visible(() -> shapeMode.get() == ShapeMode.Sides || shapeMode.get() == ShapeMode.Both)
			.build()
	);

	private final Setting<SettingColor> oldChunksSideColor = sgRender.add(new ColorSetting.Builder()
			.name("old-chunks-side-color")
			.description("Color of the chunks that have (most likely) been loaded before.")
			.defaultValue(new SettingColor(0, 255, 0, 75))
			.visible(() -> shapeMode.get() == ShapeMode.Sides || shapeMode.get() == ShapeMode.Both)
			.build()
	);

	private final Setting<SettingColor> newChunksLineColor = sgRender.add(new ColorSetting.Builder()
			.name("new-chunks-line-color")
			.description("Color of the chunks that are (most likely) completely new.")
			.defaultValue(new SettingColor(255, 0, 0, 255))
			.visible(() -> shapeMode.get() == ShapeMode.Lines || shapeMode.get() == ShapeMode.Both)
			.build()
	);

	private final Setting<SettingColor> oldChunksLineColor = sgRender.add(new ColorSetting.Builder()
			.name("old-chunks-line-color")
			.description("Color of the chunks that have (most likely) been loaded before.")
			.defaultValue(new SettingColor(0, 255, 0, 255))
			.visible(() -> shapeMode.get() == ShapeMode.Lines || shapeMode.get() == ShapeMode.Both)
			.build()
	);

    private final Set<class_1923> newChunks = Collections.synchronizedSet(new HashSet<>());
    private final Set<class_1923> oldChunks = Collections.synchronizedSet(new HashSet<>());
    private static final class_2350[] searchDirs = new class_2350[] { class_2350.field_11034, class_2350.field_11043, class_2350.field_11039, class_2350.field_11035, class_2350.field_11036 };
	private final Executor taskExecutor = Executors.newSingleThreadExecutor();

    public NewChunks() {
        super(IekeiRejectsAddon.CATEGORY,"new-chunks", "Detects completely new chunks using certain traits of them");
    }

	@Override
	public void onDeactivate() {
		if (remove.get()) {
			newChunks.clear();
			oldChunks.clear();
		}
		super.onDeactivate();
	}

	@EventHandler
	private void onRender(Render3DEvent event) {
		if (newChunksLineColor.get().a > 5 || newChunksSideColor.get().a > 5) {
			synchronized (newChunks) {
				for (class_1923 c : newChunks) {
					if (mc.method_1560().method_24515().method_19771(c.method_8323(), 1024)) {
						render(new class_238(class_243.method_24954(c.method_8323()), class_243.method_24954(c.method_8323().method_10069(16, renderHeight.get(), 16))), newChunksSideColor.get(), newChunksLineColor.get(), shapeMode.get(), event);
					}
				}
			}
		}

		if (oldChunksLineColor.get().a > 5 || oldChunksSideColor.get().a > 5){
			synchronized (oldChunks) {
				for (class_1923 c : oldChunks) {
					if (mc.method_1560().method_24515().method_19771(c.method_8323(), 1024)) {
						render(new class_238(class_243.method_24954(c.method_8323()), class_243.method_24954(c.method_8323().method_10069(16, renderHeight.get(), 16))), oldChunksSideColor.get(), oldChunksLineColor.get(), shapeMode.get(), event);
					}
				}
			}
		}
	}

	private void render(class_238 box, Color sides, Color lines, ShapeMode shapeMode, Render3DEvent event) {
		event.renderer.box(
			box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, sides, lines, shapeMode, 0);
	}

	@EventHandler
	private void onReadPacket(PacketEvent.Receive event) {
		if (event.packet instanceof class_2637) {
			class_2637 packet = (class_2637) event.packet;

			packet.method_30621((pos, state) -> {
				if (!state.method_26227().method_15769() && !state.method_26227().method_15771()) {
					class_1923 chunkPos = new class_1923(pos);

					for (class_2350 dir: searchDirs) {
						if (mc.field_1687.method_8320(pos.method_10093(dir)).method_26227().method_15771() && !oldChunks.contains(chunkPos)) {
							newChunks.add(chunkPos);
							return;
						}
					}
				}
			});
		}

		else if (event.packet instanceof class_2626) {
			class_2626 packet = (class_2626) event.packet;

			if (!packet.method_11308().method_26227().method_15769() && !packet.method_11308().method_26227().method_15771()) {
				class_1923 chunkPos = new class_1923(packet.method_11309());

				for (class_2350 dir: searchDirs) {
					if (mc.field_1687.method_8320(packet.method_11309().method_10093(dir)).method_26227().method_15771() && !oldChunks.contains(chunkPos)) {
						newChunks.add(chunkPos);
						return;
					}
				}
			}
		}

		else if (event.packet instanceof class_2672 && mc.field_1687 != null) {
			class_2672 packet = (class_2672) event.packet;

			class_1923 pos = new class_1923(packet.method_11523(), packet.method_11524());

			if (!newChunks.contains(pos) && mc.field_1687.method_2935().method_12246(packet.method_11523(), packet.method_11524()) == null) {
				class_2818 chunk = new class_2818(mc.field_1687, pos);
				try {
					Map<class_2902.class_2903, long[]> heightmaps = new EnumMap<>(class_2902.class_2903.class);
					class_2902.class_2903 type = class_2902.class_2903.field_13197;
					long[] emptyHeightmapData = new long[37];
					heightmaps.put(type, emptyHeightmapData);

					taskExecutor.execute(() -> chunk.method_12224(packet.method_38598().method_38586(), heightmaps, packet.method_38598().method_38587(packet.method_11523(), packet.method_11524())));
				} catch (ArrayIndexOutOfBoundsException e) {
					return;
				}


				for (int x = 0; x < 16; x++) {
					for (int z = 0; z < 16; z++) {
						for (int y = mc.field_1687.method_31607(); y < mc.field_1687.method_8624(class_2902.class_2903.field_13197, x, z); y++) {
							class_3610 fluid = chunk.method_12234(x, y, z);

							if (!fluid.method_15769() && !fluid.method_15771()) {
								oldChunks.add(pos);
								return;
							}
						}
					}
				}
			}
		}
	}
}
