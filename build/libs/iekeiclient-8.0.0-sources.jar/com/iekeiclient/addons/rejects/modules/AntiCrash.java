package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2604;
import net.minecraft.class_2664;
import net.minecraft.class_2675;
import net.minecraft.class_2708;
import net.minecraft.class_2716;
import net.minecraft.class_2743;
import net.minecraft.class_2749;
import java.util.LinkedList;
import java.util.Queue;

public class AntiCrash extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> log = sgGeneral.add(new BoolSetting.Builder()
            .name("log")
            .description("Logs when crash packet detected.")
            .defaultValue(false)
            .build()
    );

    private final Queue<Long> explosionTimestamps = new LinkedList<>();
    private static final int MAX_EXPLOSIONS_PER_SECOND = 20;
    private static final float MAX_EXPLOSION_RADIUS = 20.0f;
    private static final double MAX_KNOCKBACK_COMPONENT = 50.0;

    public AntiCrash() {
        super(IekeiRejectsAddon.CATEGORY, "anti-crash", "Attempts to cancel packets that may crash the client.");
    }

    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        if (event.packet instanceof class_2664 packet) {//ExplodeBypass Fix
            class_243 explodePos = packet.comp_2883();
            class_243 playerKnockback = new class_243(0, 0, 0);
            if(packet.comp_2884().isPresent()) {
                playerKnockback = packet.comp_2884().get();
            }

            long currentTime = System.currentTimeMillis();
            explosionTimestamps.add(currentTime);

            while (!explosionTimestamps.isEmpty() && explosionTimestamps.peek() < currentTime - 1000) {
                explosionTimestamps.poll();
            }

            if (explosionTimestamps.size() > MAX_EXPLOSIONS_PER_SECOND) {
                cancel(event, "explosion spam (" + explosionTimestamps.size() + "/s)");
                return;
            }

            if (packet.comp_4594() > MAX_EXPLOSION_RADIUS) {
                cancel(event, "high explosion radius (" + String.format("%.2f", packet.comp_4594()) + ")");
                return;
            }

            double maxKnockback = Math.max(Math.abs(playerKnockback.field_1352),
                                          Math.max(Math.abs(playerKnockback.field_1351), Math.abs(playerKnockback.field_1350)));
            if (maxKnockback > MAX_KNOCKBACK_COMPONENT) {
                cancel(event, "extreme knockback (" + String.format("%.2f", maxKnockback) + ")");
                return;
            }

            if (explodePos.method_10216() > 30_000_000 || explodePos.method_10214() > 30_000_000 || explodePos.method_10215() > 30_000_000 ||
                explodePos.method_10216() < -30_000_000 || explodePos.method_10214() < -30_000_000 || explodePos.method_10215() < -30_000_000) {
                cancel(event, "explosion outside world border");
                return;
            }

            if (playerKnockback.field_1352 > 30_000_000 || playerKnockback.field_1351 > 30_000_000 || playerKnockback.field_1350 > 30_000_000 ||
                playerKnockback.field_1352 < -30_000_000 || playerKnockback.field_1351 < -30_000_000 || playerKnockback.field_1350 < -30_000_000) {
                cancel(event, "knockback outside world border");
                return;
            }
        } else if (event.packet instanceof class_2675 packet) {
            // too many particles
            if (packet.method_11545() > 100_000) {
                cancel(event, "particle spam (" + packet.method_11545() + " particles)");
            }
        } else if (event.packet instanceof class_2708 packet) {
            class_243 playerPos = packet.comp_3228().comp_3148();
            // out of world movement
            if (playerPos.field_1352 > 30_000_000 || playerPos.field_1351 > 30_000_000 || playerPos.field_1350 > 30_000_000 ||
                playerPos.field_1352 < -30_000_000 || playerPos.field_1351 < -30_000_000 || playerPos.field_1350 < -30_000_000) {
                cancel(event, "position outside world border");
            }
        } else if (event.packet instanceof class_2743 packet) {
            class_243 velocity = packet.method_73085();
            if (velocity.method_10216() > 30_000_000 || velocity.method_10214() > 30_000_000 || velocity.method_10215() > 30_000_000 ||
                velocity.method_10216() < -30_000_000 || velocity.method_10214() < -30_000_000 || velocity.method_10215() < -30_000_000) {
                cancel(event, "velocity outside world border");
            }
        } else if (event.packet instanceof class_2716 packet) {
            //DestroySelf Fix
            if (mc.field_1724 != null) {
                int playerId = mc.field_1724.method_5628();
                for (int entityId : packet.method_36548().toIntArray()) {
                    if (entityId == playerId) {
                        cancel(event, "attempted to destroy player entity (DestroySelf exploit)");
                        return;
                    }
                }
            }
        } else if (event.packet instanceof class_2604 packet) {
            if (mc.field_1724 != null && packet.method_11167() == mc.field_1724.method_5628()) {
                cancel(event, "attempted to spawn entity with player ID (DestroySelf exploit)");
            }
        } else if (event.packet instanceof class_2749 packet) {
            //IllegalHealthUpdate Fix
            float health = packet.method_11833();
            int food = packet.method_11831();
            float saturation = packet.method_11834();

            if (Float.isNaN(health) || Float.isInfinite(health)) {
                cancel(event, "illegal health value (NaN/Infinite)");
                return;
            }

            if (Float.isNaN(saturation) || Float.isInfinite(saturation)) {
                cancel(event, "illegal saturation value (NaN/Infinite)");
                return;
            }

            if (health < 0) {
                cancel(event, "negative health (" + health + ")");
                return;
            }

            if (food < 0) {
                cancel(event, "negative food (" + food + ")");
                return;
            }

            if (saturation < 0) {
                cancel(event, "negative saturation (" + saturation + ")");
                return;
            }
        }
    }

    private void cancel(PacketEvent.Receive event, String reason) {
        if (log.get()) {
            warning("Cancelled crash packet: " + reason);
        }
        event.cancel();
    }
}
