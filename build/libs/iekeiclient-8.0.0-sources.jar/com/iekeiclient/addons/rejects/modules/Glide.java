package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.events.OffGroundSpeedEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.DoubleSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_746;


public class Glide extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<Double> fallSpeed = sgGeneral.add(new DoubleSetting.Builder()
            .name("fall-speed")
            .description("Fall speed.")
            .defaultValue(0.125)
            .min(0.005)
            .sliderRange(0.005, 0.25)
            .build()
    );

    public final Setting<Double> moveSpeed = sgGeneral.add(new DoubleSetting.Builder()
            .name("move-speed")
            .description("Horizontal movement factor.")
            .defaultValue(1.2)
            .min(1)
            .sliderRange(1, 5)
            .build()
    );

    public final Setting<Double> minHeight = sgGeneral.add(new DoubleSetting.Builder()
            .name("min-height")
            .description("Won't glide when you are too close to the ground.")
            .defaultValue(0)
            .min(0)
            .sliderRange(0, 2)
            .build()
    );

    public Glide() {
        super(IekeiRejectsAddon.CATEGORY, "glide", "Yeehaw!");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        class_746 player = mc.field_1724;
        class_243 v = player.method_18798();

        if (player.method_24828() || player.method_5799() || player.method_5771() || player.method_6101() || v.field_1351 >= 0)
            return;

        if (minHeight.get() > 0) {
            class_238 box = player.method_5829();
            box = box.method_991(box.method_989(0, -minHeight.get(), 0));
            if (!mc.field_1687.method_18026(box)) return;
        }

        player.method_18800(v.field_1352, Math.max(v.field_1351, -fallSpeed.get()), v.field_1350);
    }

    @EventHandler
    private void onOffGroundSpeed(OffGroundSpeedEvent event) {
        event.speed *= moveSpeed.get().floatValue();
    }
}