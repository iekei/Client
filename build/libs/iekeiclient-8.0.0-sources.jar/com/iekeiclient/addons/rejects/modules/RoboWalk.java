package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.mixin.PlayerMoveC2SPacketAccessor;
import com.iekeiclient.addons.rejects.mixin.VehicleMoveC2SPacketAccessor;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2833;

public class RoboWalk extends Module {
    public RoboWalk() {
        super(IekeiRejectsAddon.CATEGORY, "robo-walk", "Bypasses LiveOverflow movement check.");
    }

    private double smooth(double d) {
        double temp = (double) Math.round(d * 100) / 100;
        return Math.nextAfter(temp, temp + Math.signum(d));
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (event.packet instanceof class_2828 packet) {
            if (!packet.method_36171()) return;

            double x = smooth(packet.method_12269(0));
            double z = smooth(packet.method_12274(0));

            ((PlayerMoveC2SPacketAccessor) packet).iekei$setX(x);
            ((PlayerMoveC2SPacketAccessor) packet).iekei$setZ(z);
        } else if (event.packet instanceof class_2833 packet) {
            class_243 pos = ((VehicleMoveC2SPacketAccessor) (Object) packet).getPosition();
            double x = smooth(pos.method_10216());
            double z = smooth(pos.method_10215());

            event.packet = VehicleMoveC2SPacketAccessor.create(new class_243(x, pos.method_10214(), z), packet.comp_3351(), packet.comp_3352(), packet.comp_3353());
        }
    }
}
