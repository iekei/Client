package com.iekeiclient.addons.rejects.modules;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.utils.CaptchaHelper;
import com.iekeiclient.engine.events.game.OpenScreenEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.DoubleSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.systems.modules.combat.KillAura;
import com.iekeiclient.engine.utils.Utils;
import com.iekeiclient.engine.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_465;

public class CaptchaSolver extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> autoDisable = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-disable")
        .description("Automatically disable the module if no match is found.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> fuzzyMatching = sgGeneral.add(new BoolSetting.Builder()
        .name("fuzzy-matching")
        .description("Enable fuzzy matching for items like 'Bed' -> 'Yellow Bed'.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Double> solveDelay = sgGeneral.add(new DoubleSetting.Builder()
        .name("solve-delay")
        .description("How long before solving the captcha (in seconds).")
        .defaultValue(1.0)
        .min(0.0)
        .max(5.0)
        .sliderMin(0.0)
        .sliderMax(5.0)
        .build()
    );

    public CaptchaSolver() {
        super(IekeiRejectsAddon.CATEGORY, "captcha-solver", "Automatically solves captcha screens by matching item names.");
    }

    private int solveTimer = 0;
    private boolean solving = false;
    private boolean disabledKA = false;

    public boolean isSolving() {
        return solving;
    }

    @Override
    public void onActivate() {
        solving = false;
        resetSolveTimer();
        disabledKA = false;
    }

    private void resetSolveTimer() {
        solveTimer = (int) (solveDelay.get() * 20);
    }

    @EventHandler
    private void onScreenOpen(OpenScreenEvent event) {
        if (event.screen == null) return;
        if (event.screen.method_25440().getString().contains("CAPTCHA")) {
            solving = true;
            KillAura ka = Modules.get().get(KillAura.class);
            if (ka.isActive()) {
                ka.toggle();
                disabledKA = true;
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!Utils.canUpdate() || mc.field_1724 == null || mc.field_1761 == null) return;
        if (!solving) {
            if (disabledKA) {
                KillAura ka = Modules.get().get(KillAura.class);
                if (!ka.isActive()) ka.toggle();
                disabledKA = false;
            }
            return;
        }
        if (solveTimer > 0) solveTimer--;

        if (needsSolve()) solveCaptcha();
    }

    private boolean needsSolve() {
        if (mc.field_1755 instanceof class_465<?> screen) return screen.method_25440().getString().contains("CAPTCHA");
        return false;
    }

    private void solveCaptcha() {
        if (mc.field_1755 instanceof class_465<?> screen) {
            String[] parts = screen.method_25440().getString().split("Click ");
            String targetItem = parts[1].trim();

            var screenHandler = screen.method_17577();
            if (screenHandler == null) return;

            int totalSlots = screenHandler.field_7761.size();
            int containerSlots = Math.max(0, totalSlots - 36);

            for (int i = 0; i < containerSlots; i++) {
                class_1799 stack = screenHandler.method_7611(i).method_7677();

                if (stack.method_7960()) continue;
                String itemName = getItemDisplayName(stack);

                if (CaptchaHelper.checkCaptchaItem(itemName, targetItem, fuzzyMatching.get())) {
                    mc.field_1761.method_2906(screenHandler.field_7763, i, 0, class_1713.field_7790, mc.field_1724);
                    ChatUtils.info("Captcha solved for " + itemName + " !");

                    resetSolveTimer();
                    solving = false;
                    return;
                }
            }

            if (autoDisable.get()) {
                ChatUtils.error("Failed to solve the captcha.");
                toggle();
            }

            resetSolveTimer();
            solving = false;
            mc.field_1724.method_7346();
        }
    }

    private String getItemDisplayName(class_1799 stack) {
        class_2561 displayName = stack.method_7964();
        return displayName.getString();
    }
}
