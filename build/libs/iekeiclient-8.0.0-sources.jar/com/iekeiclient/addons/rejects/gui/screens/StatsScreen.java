package com.iekeiclient.addons.rejects.gui.screens;

import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1078;
import net.minecraft.class_1292;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_2477;
import com.iekeiclient.engine.IekeiClient;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.utils.world.TickRate;
import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.GuiThemes;
import com.iekeiclient.engine.gui.WindowScreen;
import com.iekeiclient.engine.gui.widgets.containers.WSection;

public class StatsScreen extends WindowScreen {
    public final class_1297 entity;
    private boolean effectListExpanded = true;
    private boolean attribListExpanded = true;
    private boolean dimensionExpanded = true;
    public StatsScreen(class_1297 e) {
        super(GuiThemes.get(),e.method_5477().getString());
        this.entity = e;
        updateData();
        IekeiClient.EVENT_BUS.subscribe(this);
    }

    @Override
    protected void onClosed() {
        IekeiClient.EVENT_BUS.unsubscribe(this);
        super.onClosed();
    }

    private void updateData() {
        clear();
        GuiTheme theme = GuiThemes.get();
        class_2477 lang = class_1078.method_10517();
        add(theme.label(String.format("Type: %s", lang.method_48307(entity.method_5864().method_5882()))));
        add(theme.label(String.format("Age: %d", entity.field_6012)));
        add(theme.label(String.format("UUID: %s", entity.method_5845())));
        if (entity instanceof class_1309 liv) {
            add(theme.label(String.format("Health: %.2f/%.2f", liv.method_6032(), liv.method_6063())));
            add(theme.label(String.format("Armor: %d/20", liv.method_6096())));

            WSection effectList = add(theme.section("Status Effects", effectListExpanded)).expandX().widget();
            effectList.action = () -> effectListExpanded = effectList.isExpanded();
            liv.method_6088().forEach((effect, instance) -> {
                String status = lang.method_48307(effect.comp_349().method_5567());
                float tps = TickRate.INSTANCE.getTickRate();
                if (instance.method_5578() != 0) {
                    status += (String.format(" %d (%s)", instance.method_5578()+1, class_1292.method_5577(instance, 1, tps)));
                } else {
                    status += (String.format(" (%s)", class_1292.method_5577(instance, 1, tps)));
                }
                effectList.add(theme.label(status)).expandX();
            });
            if (liv.method_6088().isEmpty()) {
                effectList.add(theme.label("No effects")).expandX();
            }

            WSection attribList = add(theme.section("Attributes", attribListExpanded)).expandX().widget();
            attribList.action = () -> attribListExpanded = attribList.isExpanded();
            liv.method_6127().method_60497().forEach((attrib) -> attribList.add(theme.label(String.format("%s: %.2f",
                lang.method_48307(attrib.method_6198().comp_349().method_26830()),
                attrib.method_6194()
            ))).expandX());
        }
        WSection dimension = add(theme.section("Dimensions", dimensionExpanded)).expandX().widget();
        dimension.action = () -> dimensionExpanded = dimension.isExpanded();
        dimension.add(theme.label(String.format("Position: %.2f, %.2f, %.2f", entity.method_23317(), entity.method_23318(), entity.method_23321()))).expandX();
        dimension.add(theme.label(String.format("Yaw: %.2f, Pitch: %.2f", entity.method_36454(), entity.method_36455()))).expandX();
        class_238 box = entity.method_5829();
        dimension.add(theme.label(String.format("Bounding Box: %.2f, %.2f, %.2f",
            box.field_1320-box.field_1323, box.field_1325-box.field_1322, box.field_1324-box.field_1321
        ))).expandX();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        updateData();
    }

    @Override
    public void initWidgets() {}
}
