package com.iekeiclient.addons.rejects.gui.servers;

import com.iekeiclient.addons.rejects.mixin.MultiplayerScreenAccessor;
import com.iekeiclient.addons.rejects.utils.server.LegacyServerPinger;
import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.WindowScreen;
import com.iekeiclient.engine.gui.widgets.WLabel;
import com.iekeiclient.engine.gui.widgets.containers.WTable;
import com.iekeiclient.engine.gui.widgets.input.WIntEdit;
import com.iekeiclient.engine.gui.widgets.input.WTextBox;
import com.iekeiclient.engine.gui.widgets.pressable.WButton;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_642;

public class LegacyServerFinderScreen extends WindowScreen {
    private final class_500 multiplayerScreen;
    private final WTextBox ipBox;
    private final WIntEdit maxThreadsBox;
    private final WButton searchButton;
    private final WLabel stateLabel;
    private final WLabel checkedLabel;
    private final WLabel workingLabel;
    private ServerFinderState state;
    private int maxThreads;
    private int checked;
    private int working;

    public LegacyServerFinderScreen(GuiTheme theme, class_500 multiplayerScreen, class_437 parent) {
        super(theme, "Legacy Server Discovery");
        this.multiplayerScreen = multiplayerScreen;
        this.parent = parent;
        ipBox = theme.textBox("127.0.0.1");
        maxThreadsBox = theme.intEdit(128, 1, 256, 1, 256);
        stateLabel = theme.label("");
        checkedLabel = theme.label("");
        workingLabel = theme.label("");
        searchButton = theme.button("Search");
        state = ServerFinderState.NOT_RUNNING;
    }

    @Override
    public void initWidgets() {
        add(theme.label("This will search for servers with similar IPs"));
        add(theme.label("to the IP you type into the field below."));
        add(theme.label("The servers it finds will be added to your server list."));
        WTable table = add(new WTable()).expandX().widget();
        table.add(theme.label("Server address:"));
        table.add(ipBox).expandX();
        table.row();
        table.add(theme.label("Max. Threads:"));
        table.add(maxThreadsBox);
        add(stateLabel);
        add(checkedLabel);
        add(workingLabel);
        add(searchButton).expandX();
        searchButton.action = this::searchOrCancel;
    }

    private void searchOrCancel() {
        if (state.isRunning()) {
            state = ServerFinderState.CANCELLED;
            return;
        }

        state = ServerFinderState.RESOLVING;
        maxThreads = maxThreadsBox.get();
        checked = 0;
        working = 0;

        new Thread(this::findServers, "Server Discovery").start();
    }

    private void findServers() {
        try {
            InetAddress addr =
                    InetAddress.getByName(ipBox.get().split(":")[0].trim());

            int[] ipParts = new int[4];
            for (int i = 0; i < 4; i++)
                ipParts[i] = addr.getAddress()[i] & 0xff;

            state = ServerFinderState.SEARCHING;
            ArrayList<LegacyServerPinger> pingers = new ArrayList<>();
            int[] changes = {0, 1, -1, 2, -2, 3, -3};
            for (int change : changes)
                for (int i2 = 0; i2 <= 255; i2++) {
                    if (state == ServerFinderState.CANCELLED)
                        return;

                    int[] ipParts2 = ipParts.clone();
                    ipParts2[2] = ipParts[2] + change & 0xff;
                    ipParts2[3] = i2;
                    String ip = ipParts2[0] + "." + ipParts2[1] + "."
                            + ipParts2[2] + "." + ipParts2[3];

                    LegacyServerPinger pinger = new LegacyServerPinger();
                    pinger.ping(ip);
                    pingers.add(pinger);
                    while (pingers.size() >= maxThreads) {
                        if (state == ServerFinderState.CANCELLED)
                            return;

                        updatePingers(pingers);
                    }
                }
            while (!pingers.isEmpty()) {
                if (state == ServerFinderState.CANCELLED)
                    return;

                updatePingers(pingers);
            }
            state = ServerFinderState.DONE;

        } catch (UnknownHostException e) {
            state = ServerFinderState.UNKNOWN_HOST;

        } catch (Exception e) {
            e.printStackTrace();
            state = ServerFinderState.ERROR;
        }
    }

    @Override
    public void method_25393() {
        searchButton.set(state.isRunning() ? "Cancel" : "Search");
        if (state.isRunning()) {
            ipBox.setFocused(false);
            maxThreadsBox.set(maxThreads);
        }
        stateLabel.set(state.toString());
        checkedLabel.set("Checked: " + checked + " / 1792");
        workingLabel.set("Working: " + working);
        searchButton.visible = !ipBox.get().isEmpty();
    }

    private boolean isServerInList(String ip) {
        for (int i = 0; i < multiplayerScreen.method_2529().method_2984(); i++)
            if (multiplayerScreen.method_2529().method_2982(i).field_3761.equals(ip))
                return true;

        return false;
    }

    private void updatePingers(ArrayList<LegacyServerPinger> pingers) {
        for (int i = 0; i < pingers.size(); i++)
            if (!pingers.get(i).isStillPinging()) {
                checked++;
                if (pingers.get(i).isWorking()) {
                    working++;

                    if (!isServerInList(pingers.get(i).getServerIP())) {
                        multiplayerScreen.method_2529()
                                .method_2988(new class_642("Server discovery " + working,
                                        pingers.get(i).getServerIP(), class_642.class_8678.field_45611), false);
                        multiplayerScreen.method_2529().method_2987();
                        ((MultiplayerScreenAccessor) multiplayerScreen).getServerListWidget()
                                .method_20122(null);
                        ((MultiplayerScreenAccessor) multiplayerScreen).getServerListWidget()
                                .method_20125(multiplayerScreen.method_2529());
                    }
                }
                pingers.remove(i);
            }
    }

    @Override
    public void method_25419() {
        state = ServerFinderState.CANCELLED;
        super.method_25419();
    }

    enum ServerFinderState {
        NOT_RUNNING(""),
        SEARCHING("Searching..."),
        RESOLVING("Resolving..."),
        UNKNOWN_HOST("Unknown Host!"),
        CANCELLED("Cancelled!"),
        DONE("Done!"),
        ERROR("An error occurred!");

        private final String name;

        ServerFinderState(String name) {
            this.name = name;
        }

        public boolean isRunning() {
            return this == SEARCHING || this == RESOLVING;
        }

        @Override
        public String toString() {
            return name;
        }
    }
}
