package com.iekeiclient.addons.rejects.gui.screens;

import com.iekeiclient.addons.rejects.mixin.EntityAccessor;
import com.iekeiclient.addons.rejects.modules.InteractionMenu;
import com.iekeiclient.engine.IekeiClient;
import com.iekeiclient.engine.events.iekei.KeyEvent;
import com.iekeiclient.engine.events.iekei.MouseClickEvent;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.utils.misc.IekeiStarscript;
import com.iekeiclient.engine.utils.render.PeekScreen;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10185;
import net.minecraft.class_10799;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1560;
import net.minecraft.class_1657;
import net.minecraft.class_1693;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2824;
import net.minecraft.class_2851;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_9334;
import com.iekeiclient.engine.utils.misc.input.KeyAction;
import org.meteordev.starscript.compiler.Compiler;
import org.meteordev.starscript.compiler.Parser;
import org.meteordev.starscript.utils.Error;
import org.meteordev.starscript.utils.StarscriptError;
import org.joml.Vector2f;
import org.lwjgl.glfw.GLFW;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/*
    Ported from: https://github.com/BleachDrinker420/BleachHack/pull/211
*/
public class InteractionScreen extends class_437 {

    public static class_1297 interactionMenuEntity;

    private final class_1297 entity;
    private String focusedString = null;
    private int crosshairX, crosshairY, focusedDot = -1;
    private float yaw, pitch;
    private final Map<String, Consumer<class_1297>> functions;
    private final Map<String, String> msgs;

    private final class_2960 GUI_ICONS_TEXTURE = class_2960.method_60654("textures/gui/icons.png");

    private final StaticListener shiftListener = new StaticListener();

    // Style
    private final int selectedDotColor;
    private final int dotColor;
    private final int backgroundColor;
    private final int borderColor;
    private final int textColor;

    public InteractionScreen(class_1297 e) {
        this(e, Modules.get().get(InteractionMenu.class));
    }

    public InteractionScreen(class_1297 entity, InteractionMenu module) {
        super(class_2561.method_43470("Menu Screen"));
        if (module == null) closeScreen();

        selectedDotColor = module.selectedDotColor.get().getPacked();
        dotColor = module.dotColor.get().getPacked();
        backgroundColor = module.backgroundColor.get().getPacked();
        borderColor = module.borderColor.get().getPacked();
        textColor = module.textColor.get().getPacked();

        this.entity = entity;
        functions = new HashMap<>();
        functions.put("Stats", (class_1297 e) -> {
            closeScreen();
            field_22787.method_1507(new StatsScreen(e));
        });
        switch (entity) {
            case class_1657 playerEntity -> functions.put("Open Inventory", (class_1297 e) -> {
                closeScreen();
                field_22787.method_1507(new class_490((class_1657) e));
            });
            case class_1496 abstractHorseEntity -> functions.put("Open Inventory", (class_1297 e) -> {
                closeScreen();
                if (field_22787.field_1724.method_3144()) {
//                    client.player.networkHandler.sendPacket(new PlayerInputC2SPacket(0, 0, false, true));
                    field_22787.field_1724.field_3944.method_52787(new class_2851(new class_10185(false, false, false, false, false, true, false)));

                }
                field_22787.field_1724.field_3944.method_52787(class_2824.method_34207(entity, true, class_1268.field_5808));
                field_22787.field_1724.method_5660(false);
            });
            case class_1693 storageMinecartEntity -> functions.put("Open Inventory", (class_1297 e) -> {
                closeScreen();
                field_22787.field_1724.field_3944.method_52787(class_2824.method_34207(entity, true, class_1268.field_5808));
            });
            case null, default -> functions.put("Open Inventory", (class_1297 e) -> {
                closeScreen();
                class_1799 container = new class_1799(class_1802.field_8106);
                container.method_57379(class_9334.field_49631, e.method_5477());
                field_22787.method_1507(new PeekScreen(container, getInventory(e)));
            });
        }

        functions.put("Spectate", (class_1297 e) -> {
            class_310.method_1551().method_1504(e);
            field_22787.field_1724.method_7353(class_2561.method_43470("Sneak to un-spectate."), true);
            IekeiClient.EVENT_BUS.subscribe(shiftListener);
            closeScreen();
        });

        if (entity.method_5851()) {
            functions.put("Remove glow", (class_1297 e) -> {
                e.method_5834(false);
                ((EntityAccessor) e).invokeSetFlag(6, false);
                closeScreen();
            });
        } else {
            functions.put("Glow", (class_1297 e) -> {
                e.method_5834(true);
                ((EntityAccessor) e).invokeSetFlag(6, true);
                closeScreen();
            });
        }
        if (entity.field_5960) {
            functions.put("Disable NoClip", (class_1297 e) -> {
                entity.field_5960 = false;
                closeScreen();
            });
        } else {
            functions.put("NoClip", (class_1297 e) -> {
                entity.field_5960 = true;
                closeScreen();
            });
        }
        msgs = Modules.get().get(InteractionMenu.class).messages.get();
        msgs.keySet().forEach((key) -> {
            functions.put(key, (class_1297 e) -> {
                closeScreen();
                interactionMenuEntity = e;
                var result = Parser.parse(msgs.get(key));
                if (result.hasErrors()) {
                    for (Error error : result.errors) IekeiStarscript.printChatError(error);
                    return;
                }
                var script = Compiler.compile(result);
                try {
                    var section = IekeiStarscript.ss.run(script);
                    field_22787.method_1507(new class_408(section.text, false));
                } catch (StarscriptError err) {
                    IekeiStarscript.printChatError(err);
                }
            });
        });
        functions.put("Cancel", (class_1297 e) -> {
            closeScreen();
        });
    }

    private class_1799[] getInventory(class_1297 e) {
        class_1799[] stack = new class_1799[27];
        final int[] index = {0};
        if (e instanceof class_1560 enderman) {
            var carried = enderman.method_7027();
            if (carried != null) {
                stack[index[0]] = carried.method_26204().method_8389().method_7854();
                index[0]++;
            }
        }
        if (e instanceof class_1308 mob && mob.method_66672()) {
            stack[index[0]] = class_1802.field_8175.method_7854();
            index[0]++;
        }
        class_1309 a = (class_1309) e;
        addStack(stack, index, a.method_6118(class_1304.field_6173));
        addStack(stack, index, a.method_6118(class_1304.field_6171));
        addStack(stack, index, a.method_6118(class_1304.field_6169));
        addStack(stack, index, a.method_6118(class_1304.field_6174));
        addStack(stack, index, a.method_6118(class_1304.field_6172));
        addStack(stack, index, a.method_6118(class_1304.field_6166));

        for (int i = index[0]; i < 27; i++) stack[i] = class_1802.field_8162.method_7854();
        return stack;
    }

    public void method_25426() {
        super.method_25426();
        this.cursorMode(GLFW.GLFW_CURSOR_HIDDEN);
        yaw = field_22787.field_1724.method_36454();
        pitch = field_22787.field_1724.method_36455();
    }

    private void cursorMode(int mode) {
        class_304.method_1437();
        double x = (double) this.field_22787.method_22683().method_4480() / 2;
        double y = (double) this.field_22787.method_22683().method_4507() / 2;
        class_3675.method_15984(this.field_22787.method_22683(), mode, x, y);
    }

    public void method_25393() {
        if (Modules.get().get(InteractionMenu.class).keybind.get().isPressed())
            method_25419();
    }

    private void closeScreen() {
        field_22787.method_1507(null);
    }

    public void method_25419() {
        cursorMode(GLFW.GLFW_CURSOR_NORMAL);
        // This makes the magic
        if (focusedString != null) {
            functions.get(focusedString).accept(this.entity);
        } else
            field_22787.method_1507(null);
    }

    public boolean isPauseScreen() {
        return false;
    }

    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25290(class_10799.field_56883, GUI_ICONS_TEXTURE,  crosshairX - 8, crosshairY - 8, 0, 0, 15, 15, 256, 256);

        drawDots(context, (int) (Math.min(field_22790, field_22789) / 2 * 0.75), mouseX, mouseY);
        context.method_51448().pushMatrix();
        context.method_51448().scale(2f, 2f);
        context.method_27534(field_22793, entity.method_5477(), field_22789 / 4, 6, 0xFFFFFFFF);
        context.method_51448().popMatrix();

        Vector2f mouse = getMouseVecs(mouseX, mouseY);

        this.crosshairX = (int) mouse.x + field_22789 / 2;
        this.crosshairY = (int) mouse.y + field_22790 / 2;

        field_22787.field_1724.method_36456(yaw + mouse.x / 3);
        field_22787.field_1724.method_36457(class_3532.method_15363(pitch + mouse.y / 3, -90f, 90f));
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private Vector2f getMouseVecs(int mouseX, int mouseY) {
        int scale = field_22787.field_1690.method_42474().method_41753();
        Vector2f mouse = new Vector2f(mouseX, mouseY);
        Vector2f center = new Vector2f(field_22789 / 2, field_22790 / 2);
        mouse.sub(center).normalize();

        if (scale == 0) scale = 4;

        // Move crossHair based on distance between mouse and center. But with limit
        if (Math.hypot(field_22789 / 2 - mouseX, field_22790 / 2 - mouseY) < 1f / scale * 200f)
            mouse.mul((float) Math.hypot(field_22789 / 2 - mouseX, field_22790 / 2 - mouseY));
        else
            mouse.mul(1f / scale * 200f);
        return mouse;
    }

    private void drawDots(class_332 context, int radius, int mouseX, int mouseY) {
        ArrayList<Point> pointList = new ArrayList<>();
        String[] cache = new String[functions.size()];
        double lowestDistance = Double.MAX_VALUE;
        int i = 0;

        for (String string : functions.keySet()) {
            // Just some fancy calculations to get the positions of the dots
            double s = (double) i / functions.size() * 2 * Math.PI;
            int x = (int) Math.round(radius * Math.cos(s) + field_22789 / 2);
            int y = (int) Math.round(radius * Math.sin(s) + field_22790 / 2);
            drawTextField(context, x, y, string);

            // Calculate lowest distance between mouse and dot
            if (Math.hypot(x - mouseX, y - mouseY) < lowestDistance) {
                lowestDistance = Math.hypot(x - mouseX, y - mouseY);
                focusedDot = i;
            }

            cache[i] = string;
            pointList.add(new Point(x, y));
            i++;
        }

        // Go through all point and if it is focused -> drawing different color, changing closest string value
        for (int j = 0; j < functions.size(); j++) {
            Point point = pointList.get(j);
            if (pointList.get(focusedDot) == point) {
                drawDot(context, point.x - 4, point.y - 4, selectedDotColor);
                this.focusedString = cache[focusedDot];
            } else
                drawDot(context, point.x - 4, point.y - 4, dotColor);
        }
    }

    private void drawRect(class_332 context, int startX, int startY, int width, int height, int colorInner, int colorOuter) {
        context.method_51738(startX, startX + width, startY, colorOuter);
        context.method_51738(startX, startX + width, startY + height, colorOuter);
        context.method_51742(startX, startY, startY + height, colorOuter);
        context.method_51742(startX + width, startY, startY + height, colorOuter);
        context.method_25294(startX + 1, startY + 1, startX + width, startY + height, colorInner);
    }

    private void drawTextField(class_332 context, int x, int y, String key) {
        if (x >= field_22789 / 2) {
            drawRect(context, x + 10, y - 8, field_22793.method_1727(key) + 3, 15, backgroundColor, borderColor);
            context.method_25303(field_22793, key, x + 12, y - 4, textColor);
        } else {
            drawRect(context, x - 14 - field_22793.method_1727(key), y - 8, field_22793.method_1727(key) + 3, 15, backgroundColor, borderColor);
            context.method_25303(field_22793, key, x - 12 - field_22793.method_1727(key), y - 4, textColor);
        }
    }

    // Literally drawing it in code
    private void drawDot(class_332 context, int startX, int startY, int colorInner) {
        // Draw dot itself
        context.method_51738(startX + 2, startX + 5, startY, borderColor);
        context.method_51738(startX + 1, startX + 6, startY + 1, borderColor);
        context.method_51738(startX + 2, startX + 5, startY + 1, colorInner);
        context.method_25294(startX, startY + 2, startX + 8, startY + 6, borderColor);
        context.method_25294(startX + 1, startY + 2, startX + 7, startY + 6, colorInner);
        context.method_51738(startX + 1, startX + 6, startY + 6, borderColor);
        context.method_51738(startX + 2, startX + 5, startY + 6, colorInner);
        context.method_51738(startX + 2, startX + 5, startY + 7, borderColor);

        // Draw light overlay
        context.method_51738(startX + 2, startX + 3, startY + 1, 0x80FFFFFF);
        context.method_51738(startX + 1, startX + 1, startY + 2, 0x80FFFFFF);
    }

    private class StaticListener {
        @EventHandler
        private void onKey(KeyEvent event) {
            if (event.action != KeyAction.Press) return;
            if (field_22787.field_1690.field_1832.method_1417(event.input)) {
                unspectate();
                event.cancel();
            }
        }

        @EventHandler
        private void onMouse(MouseClickEvent event) {
            if (event.action != KeyAction.Press) return;
            if (field_22787.field_1690.field_1832.method_1433(event.click)) {
                unspectate();
                event.cancel();
            }
        }

        private void unspectate() {
            field_22787.method_1504(field_22787.field_1724);
            IekeiClient.EVENT_BUS.unsubscribe(this);
        }
    }

    private static void addStack(class_1799[] stack, int[] index, class_1799 itemStack) {
        if (itemStack == null || itemStack.method_7960()) return;
        stack[index[0]] = itemStack;
        index[0]++;
    }
}
