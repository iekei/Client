package com.iekeiclient.addons.rejects.gui.servers;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.addons.rejects.mixin.MultiplayerScreenAccessor;
import com.iekeiclient.addons.rejects.mixin.ServerListAccessor;
import com.iekeiclient.addons.rejects.utils.server.IPAddress;
import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.WindowScreen;
import com.iekeiclient.engine.gui.widgets.containers.WContainer;
import com.iekeiclient.engine.gui.widgets.containers.WHorizontalList;
import com.iekeiclient.engine.gui.widgets.pressable.WButton;
import com.iekeiclient.engine.utils.misc.IGetter;
import org.lwjgl.BufferUtils;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_370;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_641;
import net.minecraft.class_642;

public class ServerManagerScreen extends WindowScreen {

    private static final PointerBuffer saveFileFilters;

    static {
        saveFileFilters = BufferUtils.createPointerBuffer(1);
        saveFileFilters.put(MemoryUtil.memASCII("*.txt"));
        saveFileFilters.rewind();
    }

    private final class_500 multiplayerScreen;

    public ServerManagerScreen(GuiTheme theme, class_500 multiplayerScreen) {
        super(theme, "Manage Servers");
        this.parent = multiplayerScreen;
        this.multiplayerScreen = multiplayerScreen;
    }

    public static Runnable tryHandle(ThrowingRunnable<?> tr, Consumer<Throwable> handler) {
        return Objects.requireNonNull(tr).addHandler(handler);
    }

    @Override
    public void initWidgets() {
        WHorizontalList l = add(theme.horizontalList()).expandX().widget();
        addButton(l, "Find Servers (new)", () -> new ServerFinderScreen(theme, multiplayerScreen, this));
        addButton(l, "Find Servers (legacy)", () -> new LegacyServerFinderScreen(theme, multiplayerScreen, this));
        addButton(l, "Clean Up", () -> new CleanUpScreen(theme, multiplayerScreen, this));
        l = add(theme.horizontalList()).expandX().widget();
        l.add(theme.button("Save IPs")).expandX().widget().action = tryHandle(() -> {
            String targetPath = TinyFileDialogs.tinyfd_saveFileDialog("Save IPs", null, saveFileFilters, null);
            if (targetPath == null) return;
            if (!targetPath.endsWith(".txt")) targetPath += ".txt";
            Path filePath = Path.of(targetPath);

            int newIPs = 0;

            Set<IPAddress> hashedIPs = new HashSet<>();
            if (Files.exists(filePath)) {
                try {
                    List<String> ips = Files.readAllLines(filePath);
                    for (String ip : ips) {
                        IPAddress parsedIP = IPAddress.fromText(ip);
                        if (parsedIP != null)
                            hashedIPs.add(parsedIP);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            class_641 servers = multiplayerScreen.method_2529();
            for (int i = 0; i < servers.method_2984(); i++) {
                class_642 info = servers.method_2982(i);
                IPAddress addr = IPAddress.fromText(info.field_3761);
                if (addr != null && hashedIPs.add(addr))
                    newIPs++;
            }

            StringBuilder fileOutput = new StringBuilder();
            for (IPAddress ip : hashedIPs) {
                String stringIP = ip.toString();
                if (stringIP != null)
                    fileOutput.append(stringIP).append("\n");
            }

            try {
                Files.writeString(filePath, fileOutput.toString());
            } catch (IOException e) {
                e.printStackTrace();
            }

            toast("Success!", newIPs == 1 ? "Saved %s new IP" : "Saved %s new IPs", newIPs);
        }, e -> {
            IekeiRejectsAddon.LOG.error("Could not save IPs");
            toast("Something went wrong", "The IPs could not be saved, look at the log for details");
        });
        l.add(theme.button("Load IPs")).expandX().widget().action = tryHandle(() -> {
            String targetPath = TinyFileDialogs.tinyfd_openFileDialog("Load IPs", null, saveFileFilters, "", false);
            if (targetPath == null) return;
            Path filePath = Path.of(targetPath);
            if (!Files.exists(filePath)) return;

            List<class_642> servers = ((ServerListAccessor) multiplayerScreen.method_2529()).getServers();
            Set<String> presentAddresses = new HashSet<>();
            int newIPs = 0;
            for (class_642 server : servers) presentAddresses.add(server.field_3761);
            for (String addr : class_310.method_1551().field_1774.method_1460().split("[\r\n]+")) {
                if (presentAddresses.add(addr = addr.split(" ")[0])) {
                    servers.add(new class_642("Server discovery #" + presentAddresses.size(), addr, class_642.class_8678.field_45611));
                    newIPs++;
                }
            }
            multiplayerScreen.method_2529().method_2987();
            ((MultiplayerScreenAccessor) multiplayerScreen).getServerListWidget().method_20122(null);
            ((MultiplayerScreenAccessor) multiplayerScreen).getServerListWidget().method_20125(multiplayerScreen.method_2529());
            toast("Success!", newIPs == 1 ? "Loaded %s new IP" : "Loaded %s new IPs", newIPs);
        }, e -> {
            IekeiRejectsAddon.LOG.error("Could not load IPs");
            toast("Something went wrong", "The IPs could not be loaded, look at the log for details");
        });
    }

    private void toast(String titleKey, String descriptionKey, Object... params) {
        class_370.method_27024(field_22787.method_1566(), class_370.class_9037.field_47584, class_2561.method_43470(titleKey), class_2561.method_43469(descriptionKey, params));
    }

    private void addButton(WContainer c, String text, IGetter<class_437> action) {
        WButton button = c.add(theme.button(text)).expandX().widget();
        button.action = () -> field_22787.method_1507(action.get());
    }

    public interface ThrowingRunnable<TEx extends Throwable> {
        void run() throws TEx;

        default Runnable addHandler(Consumer<Throwable> handler) {
            Objects.requireNonNull(handler);
            return () -> {
                try {
                    this.run();
                } catch (Throwable var3) {
                    handler.accept(var3);
                }
            };
        }
    }

}
