package com.iekeiclient.addons.rejects.gui.servers;

import com.iekeiclient.addons.rejects.mixin.MultiplayerScreenAccessor;
import com.iekeiclient.addons.rejects.mixin.ServerListAccessor;
import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.WindowScreen;
import com.iekeiclient.engine.gui.widgets.containers.WTable;
import com.iekeiclient.engine.gui.widgets.pressable.WCheckbox;
import com.iekeiclient.engine.utils.render.color.Color;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_155;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_642;

public class CleanUpScreen extends WindowScreen {
    private final class_500 multiplayerScreen;
    private final WCheckbox removeAll;
    private final WCheckbox removeFailed;
    private final WCheckbox removeOutdated;
    private final WCheckbox removeUnknown;
    private final WCheckbox removeGriefMe;
    private final WCheckbox removeDuplicates;
    private final WCheckbox rename;

    public CleanUpScreen(GuiTheme theme, class_500 multiplayerScreen, class_437 parent) {
        super(theme, "Clean Up");
        this.multiplayerScreen = multiplayerScreen;
        this.parent = parent;
        removeUnknown = theme.checkbox(true);
        removeOutdated = theme.checkbox(false);
        removeFailed = theme.checkbox(true);
        removeGriefMe = theme.checkbox(false);
        removeAll = theme.checkbox(false);
        removeDuplicates = theme.checkbox(true);
        rename = theme.checkbox(true);
    }

    @Override
    public void initWidgets() {
        WTable table = add(new WTable()).widget();
        table.add(theme.label("Remove:"));
        table.row();
        table.add(theme.label("Unknown Hosts:")).widget().tooltip = "";
        table.add(removeUnknown).widget();
        table.row();
        table.add(theme.label("Outdated Servers:"));
        table.add(removeOutdated).widget();
        table.row();
        table.add(theme.label("Failed Ping:"));
        table.add(removeFailed).widget();
        table.row();
        table.add(theme.label("\"Server discovery\" Servers:"));
        table.add(removeGriefMe).widget();
        table.row();
        table.add(theme.label("Everything:")).widget().color = new Color(255, 0, 0);
        table.add(removeAll).widget();
        table.row();
        table.add(theme.label("Duplicates:"));
        table.add(removeDuplicates).widget();
        table.row();
        table.add(theme.label("Rename all Servers:"));
        table.add(rename).widget();
        table.row();
        table.add(theme.button("Execute!")).expandX().widget().action = this::cleanUp;
    }

    private void cleanUp() {
        Set<String> knownIPs = new HashSet<>();
        List<class_642> servers = ((ServerListAccessor) multiplayerScreen.method_2529()).getServers();
        for (class_642 server : servers.toArray(class_642[]::new)) {
            if (removeAll.checked || shouldRemove(server, knownIPs))
                servers.remove(server);
        }

        if (rename.checked)
            for (int i = 0; i < servers.size(); i++) {
                class_642 server = servers.get(i);
                server.field_3752 = "Server discovery " + (i + 1);
            }

        saveServerList();
        field_22787.method_1507(parent);
    }

    private boolean shouldRemove(class_642 server, Set<String> knownIPs) {
        return server != null && (removeUnknown.checked && isUnknownHost(server)
                || removeOutdated.checked && !isSameProtocol(server)
                || removeFailed.checked && isFailedPing(server)
                || removeGriefMe.checked && isGriefMeServer(server)
                || removeDuplicates.checked && !knownIPs.add(server.field_3761));
    }

    private boolean isUnknownHost(class_642 server) {
        if (server.field_3757 == null || server.field_3757.getString() == null) return false;

        return server.field_3757.getString().equals("\u00a74Can't resolve hostname");
    }

    private boolean isSameProtocol(class_642 server) {
        return server.field_3756 == class_155.method_16673().comp_4027();
    }

    private boolean isFailedPing(class_642 server) {
        return server.field_3758 != -2L && server.field_3758 < 0L;
    }

    private boolean isGriefMeServer(class_642 server) {
        return server.field_3752 != null && server.field_3752.startsWith("Server discovery ");
    }

    private void saveServerList() {
        multiplayerScreen.method_2529().method_2987();

        class_4267 serverListSelector = ((MultiplayerScreenAccessor) multiplayerScreen).getServerListWidget();

        serverListSelector.method_20122(null);
        serverListSelector.method_20125(multiplayerScreen.method_2529());
    }
}
