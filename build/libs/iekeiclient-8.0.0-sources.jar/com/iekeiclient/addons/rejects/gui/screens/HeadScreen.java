package com.iekeiclient.addons.rejects.gui.screens;

import com.iekeiclient.addons.rejects.utils.GiveUtils;
import com.google.common.reflect.TypeToken;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.WindowScreen;
import com.iekeiclient.engine.gui.widgets.containers.WTable;
import com.iekeiclient.engine.gui.widgets.pressable.WButton;
import com.iekeiclient.engine.settings.EnumSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.settings.Settings;
import com.iekeiclient.engine.utils.network.Http;
import com.iekeiclient.engine.utils.network.IekeiExecutor;
import com.iekeiclient.engine.utils.player.ChatUtils;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

import static com.iekeiclient.engine.IekeiClient.mc;

public class HeadScreen extends WindowScreen {

    public enum Categories {
        Alphabet,
        Animals,
        Blocks,
        Decoration,
        Food_Drinks,
        Humanoid,
        Miscellaneous,
        Monsters,
        Plants
    }

    private static final Type gsonType = new TypeToken<List<Map<String, String>>>() {}.getType();

    private final Settings settings = new Settings();
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private static Categories category = Categories.Decoration;
    private final Setting<Categories> categorySetting = sgGeneral.add(new EnumSetting.Builder<Categories>()
        .name("Category")
        .defaultValue(category)
        .description("Category")
        .onChanged((v) -> this.loadHeads())
        .build()
    );

    public HeadScreen(GuiTheme theme) {
        super(theme, "Heads");
        loadHeads();
    }

    private void set() {
        clear();
        add(theme.settings(settings)).expandX();
        add(theme.horizontalSeparator()).expandX();
    }

    private String getCat() {
        category = categorySetting.get();
        return category.toString().replace("_", "-");
    }

    private void loadHeads() {
        IekeiExecutor.execute(() -> {
            List<Map<String, String>> res = Http.get("https://minecraft-heads.com/scripts/api.php?cat="+getCat()).sendJson(gsonType);
            List<class_1799> heads = new ArrayList<>();
            res.forEach(a -> {
                try {
                    heads.add(createHeadStack(a.get("uuid"), a.get("value"), a.get("name")));
                } catch (Exception e) { }
            });

            WTable t = theme.table();
            for (class_1799 head : heads) {
                t.add(theme.item(head));
                t.add(theme.label(head.method_7964().getString()));
                WButton give = t.add(theme.button("Give")).widget();
                give.action = () -> {
                    try {
                        GiveUtils.giveItem(head);
                    } catch (CommandSyntaxException e) {
                        ChatUtils.errorPrefix("Heads", e.getMessage());
                    }
                };
                WButton equip = t.add(theme.button("Equip")).widget();
                equip.tooltip = "Equip client-side.";
                equip.action = () -> mc.field_1724.method_5673(class_1304.field_6169, head.method_7972());
                t.row();
            }
            set();
            add(t).expandX().minWidth(400).widget();
        });
    }

    private class_1799 createHeadStack(String uuid, String value, String name) {
        class_1799 head = class_1802.field_8575.method_7854();
        class_2487 tag = new class_2487();
        tag.method_10566("SkullOwner", createSkullOwnerNbt(uuid, name, value));
        head.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
        head.method_57379(class_9334.field_49631, class_2561.method_43470(name));
        return head;
    }

    @Override
    public void initWidgets() {}

    private static class_2487 createSkullOwnerNbt(String uuidString, String name, String textureValue) {
        class_2487 skullOwner = new class_2487();

        try {
            if (uuidString != null && !uuidString.isEmpty()) skullOwner.method_10582("Id", UUID.fromString(uuidString).toString());
        } catch (IllegalArgumentException ignored) {
        }

        if (name != null && !name.isEmpty()) skullOwner.method_10582("Name", name);

        if (textureValue != null && !textureValue.isEmpty()) {
            class_2487 properties = new class_2487();
            class_2499 textures = new class_2499();
            class_2487 value = new class_2487();
            value.method_10582("Value", textureValue);
            textures.add(value);
            properties.method_10566("textures", textures);
            skullOwner.method_10566("Properties", properties);
        }

        return skullOwner;
    }
}
