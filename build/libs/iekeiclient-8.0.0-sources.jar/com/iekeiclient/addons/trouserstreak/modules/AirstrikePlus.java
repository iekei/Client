package com.iekeiclient.addons.trouserstreak.modules;

import com.iekeiclient.engine.events.game.GameLeftEvent;
import com.iekeiclient.engine.events.game.OpenScreenEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_11580;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1299;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_419;
import net.minecraft.class_7923;
import net.minecraft.class_9326;
import net.minecraft.class_9334;
import com.iekeiclient.addons.trouserstreak.Trouser;

import java.util.Random;

import static com.iekeiclient.addons.trouserstreak.utils.VersionUtils.isVersionLessThan;

public class AirstrikePlus extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgeveryone = settings.createGroup("AIRSTRIKE EVERYONE Command Options");
    private final SettingGroup sgnormal = settings.createGroup("NORMAL Spawn Egg Options");

    private final Setting<Boolean> disconnectdisable = sgGeneral.add(new BoolSetting.Builder()
            .name("Disable on Disconnect")
            .description("Disables module on disconnecting")
            .defaultValue(false)
            .build());
    private final Setting<String> entity = sgGeneral.add(new StringSetting.Builder()
            .name("Entity to Spawn")
            .description("What is created. Ex: fireball, villager, minecart, lightning_bolt, magma_cube, tnt")
            .defaultValue("fireball")
            .build());
    private final Setting<Boolean> mixer = sgGeneral.add(new BoolSetting.Builder()
            .name("Mixer")
            .description("Mixes entities.")
            .defaultValue(false)
            .build());
    private final Setting<String> entity2 = sgGeneral.add(new StringSetting.Builder()
            .name("Entity2 to Spawn")
            .description("What is created. Ex: fireball, villager, minecart, lightning_bolt, magma_cube, tnt")
            .defaultValue("wither")
            .visible(mixer::get)
            .build());
    private final Setting<Boolean> randomPrefix = sgGeneral.add(new BoolSetting.Builder()
            .name("Random Prefix for Name")
            .description("Makes Boss Stacker module not work.")
            .defaultValue(false)
            .build());
    private final Setting<String> nom = sgGeneral.add(new StringSetting.Builder()
            .name("Custom Name")
            .description("Name the Entity")
            .defaultValue("MOUNTAINSOFLAVAINC")
            .build());
    private final Setting<ColorModes> nomcolor = sgGeneral.add(new EnumSetting.Builder<ColorModes>()
            .name("Custom Name Color")
            .description("Color the Name")
            .defaultValue(ColorModes.red)
            .build());
    private enum ColorModes { aqua, black, blue, dark_aqua, dark_blue, dark_gray, dark_green, dark_purple, dark_red, gold, gray, green, italic, light_purple, red, white, yellow }
    public final Setting<Boolean> randomnomcolor = sgGeneral.add(new BoolSetting.Builder()
            .name("Rainbow Name Colors")
            .description("Name Colors are randomly selected.")
            .defaultValue(true)
            .build()
    );
    private final Setting<Integer> minrange = sgGeneral.add(new IntSetting.Builder()
            .name("min-range")
            .description("radius they spawn from the player")
            .defaultValue(0)
            .sliderRange(0, 100)
            .min(0)
            .build()
    );
    private final Setting<Integer> maxrange = sgGeneral.add(new IntSetting.Builder()
            .name("max-range")
            .description("radius they spawn from the player")
            .defaultValue(30)
            .sliderRange(1, 100)
            .min(1)
            .build()
    );
    private final Setting<Integer> height = sgGeneral.add(new IntSetting.Builder()
            .name("HeightAboveHead")
            .description("How far from your Characters Y level to spawn at.")
            .defaultValue(20)
            .sliderRange(-63, 319)
            .build());

    private final Setting<Integer> speed = sgGeneral.add(new IntSetting.Builder()
            .name("speed")
            .description("speed of entities")
            .defaultValue(5)
            .sliderRange(1, 10)
            .min(1)
            .max(10)
            .build());

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("delay")
            .description("its in ticks")
            .defaultValue(2)
            .sliderRange(0, 20)
            .min(0)
            .build());
    private final Setting<Integer> grief = sgGeneral.add(new IntSetting.Builder()
            .name("Concurrent Spawns")
            .description("How many entities to spawn per tick.")
            .defaultValue(1)
            .sliderRange(1, 100)
            .min(1)
            .build());
    private final Setting<Boolean> airstrikeEveryone = sgGeneral.add(new BoolSetting.Builder()
            .name("Airstrike Everyone (OP)")
            .description("REQUIRES OP mode.")
            .defaultValue(false)
            .build());
    public final Setting<Boolean> customname = sgnormal.add(new BoolSetting.Builder()
            .name("CustomNameVisible")
            .description("CustomNameVisible or not.")
            .defaultValue(true)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    private final Setting<Integer> health = sgnormal.add(new IntSetting.Builder()
            .name("Health Points")
            .description("How much health.")
            .defaultValue(1000)
            .min(0)
            .sliderRange(0, 10000)
            .visible(() -> !airstrikeEveryone.get())
            .build());
    private final Setting<Integer> absorption = sgnormal.add(new IntSetting.Builder()
            .name("Absorption Points")
            .description("How much absorption.")
            .defaultValue(1000)
            .min(0)
            .sliderRange(0, 10000)
            .visible(() -> !airstrikeEveryone.get())
            .build());
    public final Setting<Boolean> ageSpecify = sgnormal.add(new BoolSetting.Builder()
            .name("Specify Age")
            .description("Add an Age NBT tag.")
            .defaultValue(false)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    private final Setting<Integer> age = sgnormal.add(new IntSetting.Builder()
            .name("Age")
            .description("It's age, 0 is baby.")
            .defaultValue(1)
            .min(0)
            .sliderRange(0, 100)
            .visible(() -> !airstrikeEveryone.get() && ageSpecify.get())
            .build());
    public final Setting<Boolean> invincible = sgnormal.add(new BoolSetting.Builder()
            .name("Invulnerable")
            .description("Invulnerable or not")
            .defaultValue(true)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    public final Setting<Boolean> persist = sgnormal.add(new BoolSetting.Builder()
            .name("Never Despawn")
            .description("adds PersistenceRequired tag.")
            .defaultValue(true)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    public final Setting<Boolean> noAI = sgnormal.add(new BoolSetting.Builder()
            .name("NoAI")
            .description("NoAI")
            .defaultValue(false)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    public final Setting<Boolean> falsefire = sgnormal.add(new BoolSetting.Builder()
            .name("HasVisualFire")
            .description("HasVisualFire or not")
            .defaultValue(false)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    public final Setting<Boolean> nograv = sgnormal.add(new BoolSetting.Builder()
            .name("NoGravity")
            .description("NoGravity or not")
            .defaultValue(false)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    public final Setting<Boolean> silence = sgnormal.add(new BoolSetting.Builder()
            .name("Silent")
            .description("adds Silent tag.")
            .defaultValue(false)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    public final Setting<Boolean> glow = sgnormal.add(new BoolSetting.Builder()
            .name("Glowing")
            .description("Glowing or not")
            .defaultValue(false)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    public final Setting<Boolean> ignite = sgnormal.add(new BoolSetting.Builder()
            .name("Ignited")
            .description("Pre-ignite creeper or not.")
            .defaultValue(true)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    public final Setting<Boolean> powah = sgnormal.add(new BoolSetting.Builder()
            .name("Charged Creeper")
            .description("powered creeper or not.")
            .defaultValue(false)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    private final Setting<Integer> fuse = sgnormal.add(new IntSetting.Builder()
            .name("Creeper/TNT Fuse")
            .description("In ticks")
            .defaultValue(20)
            .min(0)
            .sliderRange(0, 120)
            .visible(() -> !airstrikeEveryone.get())
            .build());
    private final Setting<Integer> exppower = sgnormal.add(new IntSetting.Builder()
            .name("ExplosionPower/Radius")
            .description("For Creepers and Fireballs")
            .defaultValue(10)
            .min(1)
            .sliderMax(127)
            .visible(() -> !airstrikeEveryone.get())
            .build());
    private final Setting<Integer> size = sgnormal.add(new IntSetting.Builder()
            .name("Slime/Magma Cube Size")
            .description("It's size, 100 is really big.")
            .defaultValue(1)
            .min(0)
            .sliderRange(0, 100)
            .visible(() -> !airstrikeEveryone.get())
            .build());
    public final Setting<Boolean> blockstateSpecify = sgnormal.add(new BoolSetting.Builder()
            .name("Specify falling_block")
            .description("Add an NBT tag defining what is the falling block.")
            .defaultValue(false)
            .visible(() -> !airstrikeEveryone.get())
            .build()
    );
    private final Setting<class_2248> blockstate = sgnormal.add(new BlockSetting.Builder()
            .name("falling_block entity block")
            .description("What is created when specifying falling_block as the entity.")
            .defaultValue(class_2246.field_9987)
            .visible(() -> !airstrikeEveryone.get() && blockstateSpecify.get())
            .build());
    public final Setting<Boolean> Ecustomname = sgeveryone.add(new BoolSetting.Builder()
            .name("CustomNameVisible")
            .description("CustomNameVisible or not.")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    public final Setting<Boolean> EcustomHP = sgeveryone.add(new BoolSetting.Builder()
            .name("Modify Health Points")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    private final Setting<Integer> Ehealth = sgeveryone.add(new IntSetting.Builder()
            .name("Health Points")
            .description("How much health.")
            .defaultValue(100)
            .min(0)
            .sliderRange(0, 10000)
            .visible(() -> airstrikeEveryone.get() && EcustomHP.get())
            .build());
    private final Setting<Integer> Eabsorption = sgeveryone.add(new IntSetting.Builder()
            .name("Absorption Points")
            .description("How much absorption.")
            .defaultValue(0)
            .min(0)
            .sliderRange(0, 10000)
            .visible(airstrikeEveryone::get)
            .build());
    public final Setting<Boolean> EageSpecify = sgeveryone.add(new BoolSetting.Builder()
            .name("Specify Age")
            .description("Add an Age NBT tag.")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    private final Setting<Integer> Eage = sgeveryone.add(new IntSetting.Builder()
            .name("Age")
            .description("It's age, 0 is baby.")
            .defaultValue(1)
            .min(0)
            .sliderRange(0, 100)
            .visible(() -> airstrikeEveryone.get() && EageSpecify.get())
            .build());
    public final Setting<Boolean> Einvincible = sgeveryone.add(new BoolSetting.Builder()
            .name("Invulnerable")
            .description("Invulnerable or not")
            .defaultValue(true)
            .visible(airstrikeEveryone::get)
            .build()
    );
    public final Setting<Boolean> Epersist = sgeveryone.add(new BoolSetting.Builder()
            .name("Never Despawn")
            .description("adds PersistenceRequired tag.")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    public final Setting<Boolean> EnoAI = sgeveryone.add(new BoolSetting.Builder()
            .name("NoAI")
            .description("NoAI")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    public final Setting<Boolean> Efalsefire = sgeveryone.add(new BoolSetting.Builder()
            .name("HasVisualFire")
            .description("HasVisualFire or not")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    public final Setting<Boolean> Enograv = sgeveryone.add(new BoolSetting.Builder()
            .name("NoGravity")
            .description("NoGravity or not")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    public final Setting<Boolean> Esilence = sgeveryone.add(new BoolSetting.Builder()
            .name("Silent")
            .description("adds Silent tag.")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    public final Setting<Boolean> Eglow = sgeveryone.add(new BoolSetting.Builder()
            .name("Glowing")
            .description("Glowing or not")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    public final Setting<Boolean> Eignite = sgeveryone.add(new BoolSetting.Builder()
            .name("Ignited")
            .description("Pre-ignite creeper or not.")
            .defaultValue(true)
            .visible(airstrikeEveryone::get)
            .build()
    );
    public final Setting<Boolean> Epowah = sgeveryone.add(new BoolSetting.Builder()
            .name("Charged Creeper")
            .description("powered creeper or not.")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    private final Setting<Integer> Efuse = sgeveryone.add(new IntSetting.Builder()
            .name("Creeper/TNT Fuse")
            .description("In ticks")
            .defaultValue(20)
            .min(0)
            .sliderRange(0, 120)
            .visible(airstrikeEveryone::get)
            .build());
    private final Setting<Integer> Eexppower = sgeveryone.add(new IntSetting.Builder()
            .name("ExplosionPower/Radius")
            .description("For Creepers and Fireballs")
            .defaultValue(10)
            .min(1)
            .sliderMax(127)
            .visible(airstrikeEveryone::get)
            .build());
    private final Setting<Integer> Esize = sgeveryone.add(new IntSetting.Builder()
            .name("Slime/Magma Cube Size")
            .description("It's size, 100 is really big.")
            .defaultValue(1)
            .min(0)
            .sliderRange(0, 100)
            .visible(airstrikeEveryone::get)
            .build());
    public final Setting<Boolean> EblockstateSpecify = sgeveryone.add(new BoolSetting.Builder()
            .name("Specify falling_block")
            .description("Add an NBT tag defining what is the falling block.")
            .defaultValue(false)
            .visible(airstrikeEveryone::get)
            .build()
    );
    private final Setting<class_2248> Eblockstate = sgeveryone.add(new BlockSetting.Builder()
            .name("falling_block entity block")
            .description("What is created when specifying falling_block as the entity.")
            .defaultValue(class_2246.field_9987)
            .visible(() -> airstrikeEveryone.get() && EblockstateSpecify.get())
            .build());

    public AirstrikePlus() {
        super(Trouser.operator, "Airstrike+", "Rains things down from the sky");
    }

    final Random r = new Random();
    class_243 origin = null;
    int i = 0;
    private int mix=0;
    private String namecolour = nomcolor.get().toString();
    private String entityName = entity.get().trim().replace(" ", "_");
    private String customName = nom.get();

    private final String[] prefixes = {
            "§k111 §r| ",
            "§k222 §r| ",
            "§k333 §r| ",
            "§k444 §r| ",
            "§k555 §r| ",
            "§k666 §r| ",
            "§k777 §r| ",
            "§k888 §r| ",
            "§k999 §r| "
    };
    private class_243 pickRandomPos() {
        double minR = minrange.get();
        double maxR = maxrange.get();

        double angle = r.nextDouble(Math.PI * 2);

        double dist = (maxR > minR)
                ? minR + r.nextDouble(maxR - minR)
                : minR;

        double x = origin.field_1352 + Math.cos(angle) * dist;
        double z = origin.field_1350 + Math.sin(angle) * dist;
        double y = mc.field_1724.method_23318() + height.get();

        return new class_243(x, y, z);
    }
    @EventHandler
    private void onScreenOpen(OpenScreenEvent event) {
        if (disconnectdisable.get() && event.screen instanceof class_419) {
            toggle();
        }
    }
    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        if (disconnectdisable.get())toggle();
    }

    @EventHandler
    public void onTick(TickEvent.Pre event) {
        origin = mc.field_1724.method_73189();
    }

    @EventHandler
    public void onTick(TickEvent.Post event) {
        if (randomPrefix.get()) {
            String randomPrefix = prefixes[r.nextInt(prefixes.length)];
            customName = randomPrefix + nom.get();
        } else {
            customName = nom.get();
        }
        if (mixer.get()) {
            mix = (mix + 1) % 2;
            entityName = (mix == 0 ? entity.get() : entity2.get()).trim().replace(" ", "_");
        } else entityName = entity.get().trim().replace(" ", "_");
        for (int griefs = 0; griefs < grief.get(); griefs++) {
            if (airstrikeEveryone.get()) executeCommandsToCreateEntities();
            else {
                if (randomnomcolor.get()) {
                    String[] colorCodes = {"black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple", "gold", "gray", "dark_gray", "blue", "green", "aqua", "red", "light_purple", "yellow", "white"};
                    int index = r.nextInt(colorCodes.length);
                    namecolour = colorCodes[index];
                } else namecolour = nomcolor.get().toString();
                class_1799 bomb = new class_1799(class_1802.field_8447);
                class_1799 bfr = mc.field_1724.method_6047();
                class_3965 bhr = new class_3965(mc.field_1724.method_73189().method_1031(0, 1, 0), class_2350.field_11036, new class_2338(mc.field_1724.method_24515().method_10069(0, 1, 0)), false);
                i++;
                if (mc.field_1724.method_31549().field_7477) {
                    if (i >= delay.get()) {
                        var changes = class_9326.method_57841()
                                .method_57854(class_9334.field_49631, class_2561.method_43470(customName).method_27692(class_124.valueOf(namecolour.toUpperCase())))
                                .method_57854(class_9334.field_50239, class_2561.method_43470(customName).method_27692(class_124.valueOf(namecolour.toUpperCase())))
                                .method_57854(class_9334.field_49609, createEntityData())
                                .method_57852();
                        bomb.method_59692(changes);
                        mc.field_1761.method_2909(bomb, 36 + mc.field_1724.method_31548().field_7545);
                        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, bhr);
                        mc.field_1761.method_2909(bfr, 36 + mc.field_1724.method_31548().field_7545);
                        i = 0;
                    }
                } else {
                    error("You need to be in creative mode.");
                    toggle();
                }
            }
        }
    }
    private class_11580<class_1299<?>> createEntityData() {
        String fullString = blockstate.get().toString();
        String[] parts = fullString.split(":");
        String block = parts[1];
        String blockName = block.replace("}", "");
        class_2487 entityTag = new class_2487();
        class_2499 pos = new class_2499();
        class_2499 speedlist = new class_2499();
        class_243 cpos = pickRandomPos();

        speedlist.add(class_2489.method_23241(0));
        speedlist.add(class_2489.method_23241(-speed.get()));
        speedlist.add(class_2489.method_23241(0));
        pos.add(class_2489.method_23241(cpos.field_1352));
        pos.add(class_2489.method_23241(mc.field_1724.method_23318() + height.get()));
        pos.add(class_2489.method_23241(cpos.field_1350));

        entityTag.method_10582("id", "minecraft:" + entityName);
        if (entity.get().equals("dragon_fireball") || entity2.get().equals("dragon_fireball") || entity.get().equals("fireball") || entity2.get().equals("fireball") || entity.get().equals("small_fireball") || entity2.get().equals("small_fireball") || entity.get().equals("wither_skull") || entity2.get().equals("wither_skull") || entity.get().equals("wind_projectile") || entity2.get().equals("wind_projectile")) {
            entityTag.method_10566("power", speedlist);
        }
        entityTag.method_10566("Motion", speedlist);
        entityTag.method_10566("Pos", pos);
        entityTag.method_10569("Health", health.get());
        entityTag.method_10569("AbsorptionAmount", absorption.get());
        if (ageSpecify.get()) entityTag.method_10569("Age", age.get());
        entityTag.method_10569("ExplosionPower", exppower.get());
        entityTag.method_10569("ExplosionRadius", exppower.get());
        class_2487 blockState = new class_2487();
        blockState.method_10582("Name", "minecraft:" + blockName);
        entityTag.method_10566("BlockState", blockState);
        class_2487 CustomNameNBT = new class_2487();
        CustomNameNBT.method_10582("text", customName);
        CustomNameNBT.method_10582("color", namecolour);

        if (invincible.get()) entityTag.method_10556("Invulnerable", invincible.get());
        if (silence.get()) entityTag.method_10556("Silent", silence.get());
        if (glow.get()) entityTag.method_10556("Glowing", glow.get());
        if (persist.get()) entityTag.method_10556("PersistenceRequired", persist.get());
        if (nograv.get()) entityTag.method_10556("NoGravity", nograv.get());
        if (noAI.get()) entityTag.method_10556("NoAI", noAI.get());
        if (falsefire.get()) entityTag.method_10556("HasVisualFire", falsefire.get());
        if (powah.get()) entityTag.method_10556("powered", powah.get());
        if (ignite.get()) entityTag.method_10556("ignited", ignite.get());
        entityTag.method_10569("Fuse", fuse.get());
        entityTag.method_10569("Size", size.get());
        if (customname.get()) entityTag.method_10556("CustomNameVisible", customname.get());
        String serverVersion;
        if (mc.method_1496()) {
            serverVersion = mc.method_1576().method_3827();
        } else {
            serverVersion = mc.method_1558().field_3760.method_54160();
        }
        if (serverVersion == null) {
            entityTag.method_10566("CustomName", CustomNameNBT);
        } else {
            if (isVersionLessThan(serverVersion, 1, 21, 5)) {
                entityTag.method_10582("CustomName", "{\"text\":\"" + nom.get() + "\",\"color\":\"" + nomcolor.get().name() + "\"}");
            } else {
                entityTag.method_10566("CustomName", CustomNameNBT);
            }
        }

        class_2960 entityId = class_2960.method_12829("minecraft:" + entityName);
        class_1299<?> entityType = (entityId != null)
                ? class_7923.field_41177.method_63535(entityId)
                : class_1299.field_6066;

        return class_11580.method_72535(entityType, entityTag);
    }
    private void executeCommandsToCreateEntities() {
        class_2499 speedlist = new class_2499();
        if (randomnomcolor.get()){
            String[] colorCodes = {"black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple", "gold", "gray", "dark_gray", "blue", "green", "aqua", "red", "light_purple", "yellow", "white"};
            int index = r.nextInt(colorCodes.length);
            namecolour = colorCodes[index];
        } else namecolour = nomcolor.get().toString();
        speedlist.add(class_2489.method_23241(0));
        speedlist.add(class_2489.method_23241(-speed.get()));
        speedlist.add(class_2489.method_23241(0));
        String nameColor = namecolour;
        int healthPoints = Ehealth.get();
        int absorptionPoints = Eabsorption.get();
        int ageValue = Eage.get();
        int explosionPower = Eexppower.get();
        int explosionRadius = Eexppower.get();
        boolean isInvulnerable = Einvincible.get();
        boolean isSilent = Esilence.get();
        boolean isGlowing = Eglow.get();
        boolean isPersistent = Epersist.get();
        boolean hasNoGravity = Enograv.get();
        boolean hasNoAI = EnoAI.get();
        boolean hasVisualFire = Efalsefire.get();
        boolean isPowered = Epowah.get();
        boolean isIgnited = Eignite.get();
        int fuseTicks = Efuse.get();
        int sizeValue = Esize.get();
        boolean isCustomNameVisible = Ecustomname.get();
        String fullString = Eblockstate.get().toString();
        String[] parts = fullString.split(":");
        String block = parts[1];
        String blockName = block.replace("}", "");
        class_2487 blockState = new class_2487();
        blockState.method_10582("Name", "minecraft:" + blockName);

        String command = "/execute as @a at @s run summon " + entityName + " ";
        double angle = r.nextDouble(Math.PI * 2);
        double dist = minrange.get() + r.nextDouble(maxrange.get() - minrange.get());
        int xOffset = (int) (Math.cos(angle) * dist);
        int zOffset = (int) (Math.sin(angle) * dist);
        command += String.format("~%d ~%d ~%d", xOffset, height.get(), zOffset);
        command += " {";
        if (Ecustomname.get()) {
            String serverVersion;
            if (mc.method_1496()) {
                serverVersion = mc.method_1576().method_3827();
            } else {
                serverVersion = mc.method_1558().field_3760.method_54160();
            }
            if (serverVersion == null) {
                command += "\"CustomName\":[{\"text\":\"" + customName + "\",\"color\":\"" + nameColor + "\"}],";
            } else {
                if (isVersionLessThan(serverVersion, 1, 21, 5)) {
                    command += "\"CustomName\":\"{\\\"text\\\":\\\"" + customName + "\\\",\\\"color\\\":\\\"" + nameColor + "\\\"}\",";
                } else {
                    command += "\"CustomName\":[{\"text\":\"" + customName + "\",\"color\":\"" + nameColor + "\"}],";
                }
            }
        }
        if (EcustomHP.get()) command += "\"Health\":" + healthPoints + ",";
        if (Eabsorption.get() > 0) command += "\"AbsorptionAmount\":" + absorptionPoints + ",";
        if (EageSpecify.get()) command += "\"Age\":" + ageValue + ",";
        if (EblockstateSpecify.get()) command += "\"BlockState\":" + blockState + ",";
        if (entity.get().equals("fireball") || entity2.get().equals("fireball")) command += "\"ExplosionPower\":" + explosionPower + ",";
        if (entity.get().equals("creeper") || entity2.get().equals("creeper")) command += "\"ExplosionRadius\":" + explosionRadius + ",";
        if (Einvincible.get()) command += "\"Invulnerable\":" + isInvulnerable + ",";
        if (Esilence.get()) command += "\"Silent\":" + isSilent + ",";
        if (Eglow.get()) command += "\"Glowing\":" + isGlowing + ",";
        if (Epersist.get()) command += "\"PersistenceRequired\":" + isPersistent + ",";
        if (Enograv.get()) command += "\"NoGravity\":" + hasNoGravity + ",";
        if (EnoAI.get()) command += "\"NoAI\":" + hasNoAI + ",";
        if (Efalsefire.get()) command += "\"HasVisualFire\":" + hasVisualFire + ",";
        if (Epowah.get()) command += "\"powered\":" + isPowered + ",";
        if (Eignite.get() && (entity.get().equals("creeper") || entity2.get().equals("creeper"))) command += "\"ignited\":" + isIgnited + ",";
        if (entity.get().equals("tnt") || entity2.get().equals("tnt") || entity.get().equals("creeper") || entity2.get().equals("creeper")) command += "\"Fuse\":" + fuseTicks + ",";
        if (entity.get().equals("slime") || entity2.get().equals("slime") || entity.get().equals("magma_cube") || entity2.get().equals("magma_cube")) command += "\"Size\":" + sizeValue + ",";
        if (Ecustomname.get()) command += "\"CustomNameVisible\":" + isCustomNameVisible + ",";
        if (entity.get().equals("dragon_fireball") || entity2.get().equals("dragon_fireball") || entity.get().equals("fireball") || entity2.get().equals("fireball") || entity.get().equals("small_fireball") || entity2.get().equals("small_fireball") || entity.get().equals("wither_skull") || entity2.get().equals("wither_skull") || entity.get().equals("wind_projectile") || entity2.get().equals("wind_projectile")) command += "\"power\":" + speedlist + ",";
        command += "\"Motion\":" + speedlist;
        command += "}";
        if (command.length()<=256)ChatUtils.sendPlayerMsg(command);
        else {
            int characterstodelete = command.length() - 256;
            error("The command is too long (" + command + ").");
            error("Shorten it by " + characterstodelete + " characters.");

            toggle();
        }
        i = 0;
    }
}