
package com.iekeiclient.addons.trouserstreak.modules;

import com.iekeiclient.engine.events.game.GameLeftEvent;
import com.iekeiclient.engine.events.game.OpenScreenEvent;
import com.iekeiclient.engine.events.game.ReceiveMessageEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.friends.Friends;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_11580;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_419;
import net.minecraft.class_640;
import net.minecraft.class_7923;
import net.minecraft.class_9326;
import net.minecraft.class_9334;
import com.iekeiclient.addons.trouserstreak.Trouser;
import com.iekeiclient.addons.trouserstreak.utils.PermissionUtils;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.CopyOnWriteArrayList;

public class AutoDisplays extends Module {
    private boolean isIncorrectArgumentError = false;  // Flag to track if error occurred
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgBlock = settings.createGroup("Block Display Options");
    private final SettingGroup sgText = settings.createGroup("Text Display Options");
    private final Setting<Boolean> disconnectdisable = sgGeneral.add(new BoolSetting.Builder()
            .name("Disable on Disconnect")
            .description("Disables module on disconnecting")
            .defaultValue(false)
            .build());
    public final Setting<Boolean> notOP = sgGeneral.add(new BoolSetting.Builder()
            .name("Toggle Module if not OP")
            .description("Turn this off to prevent the bug of module always being turned off when you join server.")
            .defaultValue(true)
            .build()
    );
    public final Setting<Boolean> allAloneToggle = sgGeneral.add(new BoolSetting.Builder()
            .name("Toggle Module if alone")
            .description("Turn this on to prevent the module running if there is no one online.")
            .defaultValue(true)
            .build()
    );
    private final Setting<Boolean> trollfriends = sgGeneral.add(new BoolSetting.Builder()
            .name("Spawn for Friends")
            .description("Whether or not to summon displays for friends.")
            .defaultValue(false)
            .build());
    private final Setting<Boolean> trollyourself = sgGeneral.add(new BoolSetting.Builder()
            .name("Spawn for yourself")
            .description("Whether or not to summon displays for yourself.")
            .defaultValue(false)
            .build());
    private final Setting<Boolean> killEntities = sgGeneral.add(new BoolSetting.Builder()
            .name("Kill Entities")
            .description("Whether to remove existing entities before creating new ones. Reduces lag.")
            .defaultValue(true)
            .build());
    private final Setting<Boolean> useDelay = sgGeneral.add(new BoolSetting.Builder()
            .name("Use Command Delay")
            .description("Adds delay between commands to prevent kicks")
            .defaultValue(false)
            .build());
    private final Setting<Integer> commandDelay = sgGeneral.add(new IntSetting.Builder()
            .name("Command Delay")
            .description("Ticks between each command")
            .defaultValue(2)
            .min(1)
            .sliderMax(20)
            .visible(useDelay::get)
            .build());
    private final Setting<Integer> tickDelay = sgGeneral.add(new IntSetting.Builder()
            .name("Tick Delay")
            .description("Delay in ticks before creating block and text displays.")
            .defaultValue(3)
            .min(0)
            .sliderMax(100)
            .build());
    private final Setting<Integer> killDelay = sgGeneral.add(new IntSetting.Builder()
            .name("Kill Delay")
            .description("Delay in ticks before removing existing entities.")
            .defaultValue(20)
            .min(0)
            .sliderMax(100)
            .build());
    private final Setting<Modes> displayMode = sgGeneral.add(new EnumSetting.Builder<Modes>()
            .name("Display Mode")
            .description("The mode for creating displays.")
            .defaultValue(Modes.TEXT)
            .build());
    private final Setting<class_2248> block = sgBlock.add(new BlockSetting.Builder()
            .name("Block")
            .description("The block to be displayed.")
            .defaultValue(class_2246.field_10458)
            .visible(() -> displayMode.get() == Modes.BLOCK)
            .build());
    private final Setting<Integer> blockbrightness = sgBlock.add(new IntSetting.Builder()
            .name("Block Brightness")
            .description("Light level of the entity.")
            .defaultValue(0)
            .min(0)
            .sliderMax(15)
            .max(15)
            .visible(() -> displayMode.get() == Modes.BLOCK)
            .build());
    private final Setting<Boolean> compatMode = sgGeneral.add(new BoolSetting.Builder()
            .name("Compatibility Mode")
            .description("Use spawn eggs instead of commands (creative only, no OP).")
            .defaultValue(false)
            .visible(() -> displayMode.get() == Modes.TEXT)
            .build()
    );
    private final Setting<String> text = sgText.add(new StringSetting.Builder()
            .name("Custom Text")
            .description("Too much text will get you kicked.")
            .defaultValue("Your server is being renovated! youtube.com/@mountainsoflavainc.6913")
            .visible(() -> displayMode.get() == Modes.TEXT)
            .build());
    private final Setting<Integer> textbrightness = sgText.add(new IntSetting.Builder()
            .name("Text Brightness")
            .description("Light level of the entity.")
            .defaultValue(15)
            .min(0)
            .sliderMax(15)
            .max(15)
            .visible(() -> displayMode.get() == Modes.TEXT)
            .build());
    private final Setting<SettingColor> backgroundColor = sgText.add(new ColorSetting.Builder()
            .name("Background Color")
            .description("The background color with transparency.")
            .defaultValue(new SettingColor(255, 0, 0, 255))
            .visible(() -> displayMode.get() == Modes.TEXT)
            .build()
    );
    private final Setting<Double> distance = sgText.add(new DoubleSetting.Builder()
            .name("Custom Text Distance")
            .description("Distance from the player to render the text display.")
            .defaultValue(2.5)
            .min(1)
            .sliderRange(1, 10)
            .visible(() -> displayMode.get() == Modes.TEXT)
            .build());
    public AutoDisplays() {
        super(Trouser.operator, "auto-displays", "Automatically spam block or text displays around players. Requires operator access.");
    }
    private CopyOnWriteArrayList<class_640> players;
    private int tickTimer = 0;
    private int killTimer = 0;
    private Queue<String> commandQueue = new LinkedList<>();
    @EventHandler
    private void onScreenOpen(OpenScreenEvent event) {
        if (disconnectdisable.get() && event.screen instanceof class_419) {
            toggle();
        }
    }
    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        if (disconnectdisable.get())toggle();
    }
    @Override
    public void onActivate() {
        if (mc.field_1724 == null) return;
        tickTimer = 0;
        killTimer = 0;
        if (notOP.get() && PermissionUtils.getPermissionLevel(mc.field_1724) < 2 && mc.field_1687.method_8393(mc.field_1724.method_31476().field_9181, mc.field_1724.method_31476().field_9180)) {
            toggle();
            error("Must have permission level 2 or higher");
        }
    }
    @EventHandler
    public void onMessageReceive(ReceiveMessageEvent event) {
        if (event.getMessage() != null && mc.field_1724 != null) {
            String message = event.getMessage().getString();

            if (message.contains("Incorrect argument for command")) {
                isIncorrectArgumentError = true;
            }
        }
    }
    @Override
    public void onDeactivate() {
        if (PermissionUtils.getPermissionLevel(mc.field_1724) >= 2 && !compatMode.get()) {
            switch (displayMode.get()) {
                case BLOCK -> {
                    if (killEntities.get()) {
                        if (isIncorrectArgumentError) {
                            ChatUtils.sendPlayerMsg("/execute as @e[type=minecraft:block_display,tag=MOL] run kill @s");
                        } else {
                            ChatUtils.sendPlayerMsg("/execute as @e[type=minecraft:block_display,tag=MOL] run minecraft:kill @s");
                        }
                    }
                }
                case TEXT -> {
                    if (killEntities.get()) {
                        if (isIncorrectArgumentError) {
                            ChatUtils.sendPlayerMsg("/execute as @e[type=minecraft:text_display,tag=MOL] run kill @s");
                        } else {
                            ChatUtils.sendPlayerMsg("/execute as @e[type=minecraft:text_display,tag=MOL] run minecraft:kill @s");
                        }
                    }
                }
            }
        }
    }
    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (compatMode.get() && displayMode.get() == Modes.TEXT) return;
        if (mc.method_1562().method_2880().toArray().length == 1 && allAloneToggle.get()) {
            toggle();
            error("No other players online.");
        }
        if (killTimer >= killDelay.get()) {
            killTimer = 0;

            switch (displayMode.get()) {
                case BLOCK -> {
                    if (killEntities.get()) {
                        if (isIncorrectArgumentError) {
                            ChatUtils.sendPlayerMsg("/execute as @e[type=minecraft:block_display,tag=MOL] run kill @s");
                        } else {
                            ChatUtils.sendPlayerMsg("/execute as @e[type=minecraft:block_display,tag=MOL] run minecraft:kill @s");
                        }
                    }
                }
                case TEXT -> {
                    if (killEntities.get()) {
                        if (isIncorrectArgumentError) {
                            ChatUtils.sendPlayerMsg("/execute as @e[type=minecraft:text_display,tag=MOL] run kill @s");
                        } else {
                            ChatUtils.sendPlayerMsg("/execute as @e[type=minecraft:text_display,tag=MOL] run minecraft:kill @s");
                        }
                    }
                }
            }
        } else {
            killTimer++;
        }
    }
    @EventHandler
    private void onPostTick(TickEvent.Post event) {
        if (compatMode.get() && displayMode.get() == Modes.TEXT) {
            if (tickTimer >= tickDelay.get()) {
                tickTimer = 0;
                if (displayMode.get() == Modes.TEXT) {
                    createTextDisplaysCompat();
                }
            } else {
                tickTimer++;
            }
            return;
        }
        if (!commandQueue.isEmpty() && useDelay.get()) {
            if (tickTimer >= commandDelay.get()) {
                ChatUtils.sendPlayerMsg(commandQueue.poll());
                tickTimer = 0;
            } else {
                tickTimer++;
            }
            return;
        }

        if (tickTimer >= tickDelay.get()) {
            tickTimer = 0;

            switch (displayMode.get()) {
                case BLOCK -> createBlockDisplays();
                case TEXT -> createTextDisplays();
            }
        } else {
            tickTimer++;
        }
    }
    private void createBlockDisplays() {
        for (int y = 2; y >= 0; y--) {
            for (int x = 1; x >= -1; x--) {
                for (int z = 1; z >= -1; z--) {
                    if (x == 0 && z == 0 && y == 1) continue;  // Skip the center position
                    String fullString = block.get().toString();
                    String[] parts = fullString.split(":");
                    String block = parts[1];
                    String blockName = block.replace("}", "");
                    players = new CopyOnWriteArrayList<>(mc.method_1562().method_2880());
                    List<String> friendNames = new ArrayList<>();
                    if (!trollyourself.get())friendNames.add("name=!" + mc.field_1724.method_5477().method_54160());
                    for (class_640 player : players) {
                        if (Friends.get().isFriend(player) && !trollfriends.get())
                            friendNames.add("name=!" + player.method_2966().name());
                    }
                    String friendsString = String.join(",", friendNames);
                    String thecommand = "/execute at @a[" + friendsString + "] run summon minecraft:block_display ~" + (x - 0.5) + " ~" + y + " ~" + (z - 0.5) + " {block_state:{Name:\"minecraft:"+blockName+"\"},brightness:{sky:"+blockbrightness.get()+",block:"+blockbrightness.get()+"},Tags:[\"MOL\"]}";
                    if (thecommand.length()<=257) {
                        if (useDelay.get()) commandQueue.add(thecommand);
                        else ChatUtils.sendPlayerMsg(thecommand);
                    }
                    else {
                        error("Command too long, too many friends are online.");
                        toggle();
                    }
                }
            }
        }
    }
    private void createTextDisplays() {
        int color = (backgroundColor.get().a << 24) | (backgroundColor.get().r << 16) | (backgroundColor.get().g << 8) | backgroundColor.get().b;
        players = new CopyOnWriteArrayList<>(mc.method_1562().method_2880());
        List<String> friendNames = new ArrayList<>();
        if (!trollyourself.get())friendNames.add("name=!" + mc.field_1724.method_5477().method_54160());
        for (class_640 player : players) {
            if (Friends.get().isFriend(player) && !trollfriends.get())
                friendNames.add("name=!" + player.method_2966().name());
        }
        String friendsString = String.join(",", friendNames);
        String thecommand1 = "/execute at @a[" + friendsString + "] run summon text_display ~ ~1 ~-"+distance.get()+" {brightness:{sky:"+textbrightness.get()+",block:"+textbrightness.get()+"},background:" + color + ",text:'" + text.get() + "',Tags:[\"MOL\"],Rotation:[0f, 0f]}";
        String thecommand2 = "/execute at @a[" + friendsString + "] run summon text_display ~ ~1 ~"+distance.get()+" {brightness:{sky:"+textbrightness.get()+",block:"+textbrightness.get()+"},background:" + color + ",text:'" + text.get() + "',Tags:[\"MOL\"],Rotation:[180f, 0f]}";
        String thecommand3 = "/execute at @a[" + friendsString + "] run summon text_display ~"+distance.get()+" ~1 ~ {brightness:{sky:"+textbrightness.get()+",block:"+textbrightness.get()+"},background:" + color + ",text:'" + text.get() + "',Tags:[\"MOL\"],Rotation:[90f, 0f]}";
        String thecommand4 = "/execute at @a[" + friendsString + "] run summon text_display ~-"+distance.get()+" ~1 ~ {brightness:{sky:"+textbrightness.get()+",block:"+textbrightness.get()+"},background:" + color + ",text:'" + text.get() + "',Tags:[\"MOL\"],Rotation:[-90f, 0f]}";
        if (thecommand1.length()<=257 && thecommand2.length()<=257 && thecommand3.length()<=257 && thecommand4.length()<=257){
            if (useDelay.get()) {
                commandQueue.add(thecommand1);
                commandQueue.add(thecommand2);
                commandQueue.add(thecommand3);
                commandQueue.add(thecommand4);
            } else {
                ChatUtils.sendPlayerMsg(thecommand1);
                ChatUtils.sendPlayerMsg(thecommand2);
                ChatUtils.sendPlayerMsg(thecommand3);
                ChatUtils.sendPlayerMsg(thecommand4);
            }
        }
        else {
            int characterstodelete = thecommand1.length()-259;
            error("The command is too long. Shorten it by "+characterstodelete+" characters, or you may also have too many friends online.");
            toggle();
        }
    }
    private void createTextDisplaysCompat() {
        if (!mc.field_1724.method_31549().field_7477) {
            error("You need to be in creative mode for compatibility mode.");
            toggle();
            return;
        }

        int color = (backgroundColor.get().a << 24) | (backgroundColor.get().r << 16)
                | (backgroundColor.get().g << 8) | backgroundColor.get().b;

        class_1799 previous = mc.field_1724.method_6047().method_7972();

        List<class_1657> nearbyPlayers = new ArrayList<>();
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity instanceof class_1657 player) {

                if (Friends.get().isFriend(player) && !trollfriends.get()) continue;
                if (mc.field_1724 == player && !trollyourself.get()) continue;

                nearbyPlayers.add(player);
            }
        }

        for (class_1657 target : nearbyPlayers) {
            class_1799 egg = createTextDisplayEgg(text.get(), textbrightness.get(), color, target.method_24515().method_10084());

            mc.field_1761.method_2909(egg, 36 + mc.field_1724.method_31548().field_7545);

            class_3965 bhr = new class_3965(mc.field_1724.method_33571(), class_2350.field_11033, class_2338.method_49638(mc.field_1724.method_33571()), false);

            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, bhr);

            mc.field_1761.method_2909(previous, 36 + mc.field_1724.method_31548().field_7545);
        }
    }

    private class_1799 createTextDisplayEgg(String text, int brightness, int argbColor, class_2338 pos) {
        class_1799 item = new class_1799(class_1802.field_20413);

        class_2499 Pos = new class_2499();
        Pos.add(class_2489.method_23241(pos.method_10263()));
        Pos.add(class_2489.method_23241(pos.method_10264()));
        Pos.add(class_2489.method_23241(pos.method_10260()));

        class_2487 entityTag = new class_2487();
        entityTag.method_10582("id", "minecraft:text_display");

        entityTag.method_10566("Pos", Pos);

        entityTag.method_10569("background", argbColor);
        class_2487 brightnessTag = new class_2487();
        brightnessTag.method_10569("sky", brightness);
        brightnessTag.method_10569("block", brightness);
        entityTag.method_10566("brightness", brightnessTag);

        entityTag.method_10582("text", text);

        class_2499 tags = new class_2499();
        tags.add(class_2519.method_23256("MOL"));
        entityTag.method_10566("Tags", tags);

        class_2960 entityId = class_2960.method_12829("minecraft:text_display");
        class_1299<?> entityType = class_7923.field_41177.method_63535(entityId);
        if (entityType == null) entityType = class_1299.field_42457;

        class_11580<class_1299<?>> data = class_11580.method_72535(entityType, entityTag);

        var changes = class_9326.method_57841()
                .method_57854(class_9334.field_49609, data)
                .method_57852();

        item.method_59692(changes);
        return item;
    }

    public enum Modes {
        BLOCK,
        TEXT
    }
}