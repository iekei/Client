/*Thank you to [DonKisser](https://github.com/DonKisser) for making the original module for us!
        Their inspiration was this Youtube video by @scilangaming:
        https://www.youtube.com/watch?v=q99eqD_fBqo*/

package com.iekeiclient.addons.trouserstreak.modules;

import com.iekeiclient.engine.events.iekei.MouseClickEvent;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.mixininterface.IPlayerInteractEntityC2SPacket;
import com.iekeiclient.addons.trouserstreak.Trouser;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2846;
import net.minecraft.class_3966;
import net.minecraft.class_7924;

public class AttributeSwap extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<Boolean> autoLunge = sgGeneral.add(new BoolSetting.Builder()
            .name("auto-lunge-swap")
            .description("Swap to a lunge enchanted spear from your hotbar when pressing the attack key for a lunge forward.")
            .defaultValue(false)
            .build());
    private final Setting<Boolean> shieldBreaker = sgGeneral.add(new BoolSetting.Builder()
            .name("shield-breaker")
            .description("Swap to an axe from your hotbar when attacking to disable the shield of someone who is blocking.")
            .defaultValue(false)
            .visible(() -> !autoLunge.get())
            .build());
    private final Setting<Boolean> noswap = sgGeneral.add(new BoolSetting.Builder()
            .name("Shield Breaker No Swap")
            .description("Do not attribute swap to another item after shield is broken")
            .defaultValue(true)
            .visible(() -> !autoLunge.get() && shieldBreaker.get())
            .build());
    private final Setting<Integer> targetSlot = sgGeneral.add(new IntSetting.Builder()
            .name("target-slot")
            .description("The hotbar slot to swap to when attacking.")
            .sliderRange(1, 9)
            .defaultValue(1)
            .min(1)
            .visible(() -> !(noswap.get() && shieldBreaker.get()) && !autoLunge.get())
            .build());
    private final Setting<Boolean> swapBack = sgGeneral.add(new BoolSetting.Builder()
            .name("swap-back")
            .description("Swap back to the original slot after a short delay.")
            .defaultValue(true)
            .build());
    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
            .name("swap-back-delay")
            .description("Delay in ticks before swapping back to the previous slot.")
            .sliderRange(1, 20)
            .defaultValue(1)
            .min(1)
            .visible(swapBack::get)
            .build());

    private int prevSlot = -1;
    private int dDelay = 0;
    private boolean didSwap = false;
    private boolean isSwapping = false;

    public AttributeSwap() {
        super(Trouser.Main, "AttributeSwap", "Swaps attributes of the main hand item with the target slot on attack");
    }

    @EventHandler
    private void onMouseButton(MouseClickEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || !autoLunge.get()) return;
        if (!mc.field_1690.field_1886.method_1434()) return;
        if (swapBack.get()) {
            prevSlot = mc.field_1724.method_31548().field_7545;
        }

        didSwap = false;

        var registryLookup = mc.field_1687.method_30349().method_30530(class_7924.field_41265);
        var lungeEnchant = registryLookup.method_46747(class_1893.field_63420);

        int bestSlot = -1;
        int bestLevel = 0;

        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_67533().get(i);
            int level = class_1890.method_8225(lungeEnchant, stack);
            if (level > 0 && level >= bestLevel) {
                bestSlot = i;
                bestLevel = level;
            }
        }

        if (bestSlot != -1) {
            InvUtils.swap(bestSlot, false);
            didSwap = true;
            mc.field_1724.field_3944.method_52787(new class_2846(
                    class_2846.class_2847.field_63165,
                    mc.field_1724.method_24515(),
                    mc.field_1724.method_58149()
            ));
        }

        if (swapBack.get() && didSwap) {
            dDelay = delay.get();
        }
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (mc.field_1724 == null || mc.field_1687 == null || isSwapping || autoLunge.get()) return;

        if (event.packet instanceof class_2824 interact) {
            int entityId = ((IPlayerInteractEntityC2SPacket) interact).iekei$getEntity().method_5628();

            class_1297 entity = mc.field_1687.method_8469(entityId);

            if (entity != null) {
                interact.method_34209(new class_2824.class_5908() {
                    @Override
                    public void method_34219(class_1268 hand) {}

                    @Override
                    public void method_34220(class_1268 hand, class_243 pos) {}

                    @Override
                    public void method_34218() {
                        performAttributeSwap(entity, false);
                    }
                });
            }
        }

        if (event.packet instanceof class_2846 action) {
            if (action.method_12363() == class_2846.class_2847.field_63165) {
                class_1297 targetEntity = (mc.field_1765 instanceof class_3966 hit) ? hit.method_17782() : null;

                if (targetEntity != null) {
                    performAttributeSwap(targetEntity,true);
                }
            }
        }
    }

    private void performAttributeSwap(class_1297 targetEntity, Boolean stabbed) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        isSwapping = true;
        try {
            if (swapBack.get()) {
                prevSlot = mc.field_1724.method_31548().field_7545;
            }
            didSwap = false;

            if (shieldBreaker.get()) {
                if (targetEntity instanceof class_1657 player) {
                    if (player.method_6039()) {
                        for (int i = 0; i < 9; i++) {
                            class_1799 stack = mc.field_1724.method_31548().method_67533().get(i);
                            if (stack.method_7909() instanceof class_1743) {
                                InvUtils.swap(i, false);
                                if (stabbed) {
                                    mc.method_1562().method_52787(class_2824.method_34206(targetEntity, mc.field_1724.method_5715()));
                                }
                                didSwap = true;
                                break;
                            }
                        }
                    } else if (!noswap.get()) {
                        InvUtils.swap(targetSlot.get() - 1, false);
                        if (stabbed) {
                            mc.method_1562().method_52787(class_2824.method_34206(targetEntity, mc.field_1724.method_5715()));
                        }
                        didSwap = true;
                    }
                } else {
                    InvUtils.swap(targetSlot.get() - 1, false);
                    if (stabbed) {
                        mc.method_1562().method_52787(class_2824.method_34206(targetEntity, mc.field_1724.method_5715()));
                    }
                    didSwap = true;
                }
            } else {
                InvUtils.swap(targetSlot.get() - 1, false);
                if (stabbed) {
                    mc.method_1562().method_52787(class_2824.method_34206(targetEntity, mc.field_1724.method_5715()));
                }
                didSwap = true;
            }

            if (swapBack.get() && didSwap) {
                dDelay = delay.get();
            }
        } finally {
            isSwapping = false;
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (dDelay > 0) {
            dDelay--;
            if (dDelay == 0 && prevSlot != -1) {
                InvUtils.swap(prevSlot, false);
                prevSlot = -1;
            }
        }
    }
}