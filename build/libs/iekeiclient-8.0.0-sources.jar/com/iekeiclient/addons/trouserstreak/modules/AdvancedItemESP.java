// Original MobGearESP module written by windoid,
// sorta based on the esp and tracer code from iekei client
// This was heavily modified by etianl to form this new module.

package com.iekeiclient.addons.trouserstreak.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.engine.utils.player.PlayerUtils;
import com.iekeiclient.engine.utils.render.RenderUtils;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1786;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_1820;
import net.minecraft.class_1835;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_9362;
import net.minecraft.item.*;
import com.iekeiclient.addons.trouserstreak.Trouser;

import java.util.*;

public class AdvancedItemESP extends Module {
    private final SettingGroup sgGeneral = this.settings.getDefaultGroup();
    private final SettingGroup sgColors = settings.createGroup("Colors");

    private final List<class_1792> defaultPlayerItems = new ArrayList<>(List.of(
            class_1802.field_8805,
            class_1802.field_8058,
            class_1802.field_8348,
            class_1802.field_8285,
            class_1802.field_22027,
            class_1802.field_22028,
            class_1802.field_22029,
            class_1802.field_22030,
            class_1802.field_8833,
            class_1802.field_49814,
            class_1802.field_8547,
            class_1802.field_8802,
            class_1802.field_8556,
            class_1802.field_8377,
            class_1802.field_8250,
            class_1802.field_8527,
            class_1802.field_22022,
            class_1802.field_22025,
            class_1802.field_22024,
            class_1802.field_22023,
            class_1802.field_22026,
            class_1802.field_8367,
            class_1802.field_8301,
            class_1802.field_8466,
            class_1802.field_8288,
            class_1802.field_8287,
            class_1802.field_8545,
            class_1802.field_8676,
            class_1802.field_8380,
            class_1802.field_8271,
            class_1802.field_8548,
            class_1802.field_8461,
            class_1802.field_8213,
            class_1802.field_8829,
            class_1802.field_8350,
            class_1802.field_8816,
            class_1802.field_8050,
            class_1802.field_8520,
            class_1802.field_8722,
            class_1802.field_8451,
            class_1802.field_8627,
            class_1802.field_8584,
            class_1802.field_8268
    ));

    public AdvancedItemESP() {
        super(Trouser.baseHunting, "AdvancedItemESP", "ESP Module that highlights only certain items.");
    }

    public final Setting<ShapeMode> shapeMode = sgGeneral.add(new EnumSetting.Builder<ShapeMode>()
            .name("shape-mode")
            .description("How the shapes are rendered.")
            .defaultValue(ShapeMode.Both)
            .build()
    );

    public final Setting<Double> fillOpacity = sgGeneral.add(new DoubleSetting.Builder()
            .name("fill-opacity")
            .description("The opacity of the shape fill.")
            .defaultValue(0.3)
            .range(0, 1)
            .sliderMax(1)
            .build()
    );

    private final Setting<Double> fadeDistance = sgGeneral.add(new DoubleSetting.Builder()
            .name("fade-distance")
            .description("The distance from an entity where the color begins to fade.")
            .defaultValue(3)
            .min(0)
            .sliderMax(12)
            .build()
    );

    private final Setting<List<class_1792>> items = sgGeneral.add(new ItemListSetting.Builder()
            .name("item-checker")
            .description("Items to check for.")
            .defaultValue(defaultPlayerItems)
            .build()
    );

    public final Setting<Boolean> enchants = sgGeneral.add(new BoolSetting.Builder()
            .name("enforce-item-enchants")
            .description("Requires that armor and tools must be enchanted for module to detect.")
            .defaultValue(true)
            .build()
    );

    public final Setting<Boolean> certainenchants = sgGeneral.add(new BoolSetting.Builder()
            .name("find-certain-item-enchants")
            .description("Requires that armor and tools must be enchanted with these enchants.")
            .defaultValue(false)
            .visible(() -> enchants.get())
            .build()
    );
    private final Setting<Set<class_5321<class_1887>>> toolenchants = sgGeneral.add(new EnchantmentListSetting.Builder()
            .name("Mining Tool Enchants")
            .description("List of enchantments required.")
            .visible(() -> enchants.get() && certainenchants.get())
            .defaultValue(class_1893.field_9131, class_1893.field_9119, class_1893.field_9101)
            .build());
    private final Setting<Set<class_5321<class_1887>>> swordenchants = sgGeneral.add(new EnchantmentListSetting.Builder()
            .name("Sword Enchants")
            .description("List of enchantments required.")
            .visible(() -> enchants.get() && certainenchants.get())
            .defaultValue(class_1893.field_9119, class_1893.field_9101)
            .build());
    private final Setting<Set<class_5321<class_1887>>> armorenchants = sgGeneral.add(new EnchantmentListSetting.Builder()
            .name("Armor Enchants")
            .description("List of enchantments required.")
            .visible(() -> enchants.get() && certainenchants.get())
            .defaultValue(class_1893.field_9119, class_1893.field_9101)
            .build());
    private final Setting<Set<class_5321<class_1887>>> maceenchants = sgGeneral.add(new EnchantmentListSetting.Builder()
            .name("Mace Enchants")
            .description("List of enchantments required.")
            .visible(() -> enchants.get() && certainenchants.get())
            .defaultValue(class_1893.field_9119, class_1893.field_9101)
            .build());
    private final Setting<Set<class_5321<class_1887>>> tridentenchants = sgGeneral.add(new EnchantmentListSetting.Builder()
            .name("Trident Enchants")
            .description("List of enchantments required.")
            .visible(() -> enchants.get() && certainenchants.get())
            .defaultValue(class_1893.field_9119, class_1893.field_9101)
            .build());
    private final Setting<Boolean> chatFeedback = sgGeneral.add(new BoolSetting.Builder()
            .name("Chat feedback")
            .description("Display info about items in chat")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> coordsInChat = sgGeneral.add(new BoolSetting.Builder()
            .name("Display coords in chat")
            .description("Display coords of a detected item")
            .visible(chatFeedback::get)
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> tracers = sgGeneral.add(new BoolSetting.Builder()
            .name("Tracers")
            .description("Add tracers to item detected")
            .defaultValue(true)
            .build()
    );
    private final Setting<SettingColor> monstersColor = sgColors.add(new ColorSetting.Builder()
            .name("items-color")
            .description("The item's bounding box and tracer color.")
            .defaultValue(new SettingColor(255, 25, 255, 255))
            .build()
    );
    public final Setting<Boolean> distance = sgColors.add(new BoolSetting.Builder()
            .name("distance-colors")
            .description("Changes the color of tracers depending on distance.")
            .defaultValue(true)
            .build()
    );
    private final Setting<SettingColor> distantColor = sgColors.add(new ColorSetting.Builder()
            .name("distant-color")
            .description("The item's bounding box and tracer color when you are far away.")
            .defaultValue(new SettingColor(25, 255, 255, 255))
            .visible(distance::get)
            .build()
    );
    public final Setting<Integer> distanceInt = sgColors.add(new IntSetting.Builder()
            .name("distance-colors-threshold")
            .description("The max distance for colors to change.")
            .defaultValue(128)
            .min(1)
            .sliderRange(1, 1024)
            .visible(distance::get)
            .build()
    );

    private final Color lineColor = new Color();
    private final Color sideColor = new Color();
    private final Color baseColor = new Color();

    private int count;
    private final Set<class_1297> scannedEntities = Collections.synchronizedSet(new HashSet<>());

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        count = 0;
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1542 itemEntity)) continue;
            if (shouldSkip(itemEntity)) continue;
            if (!scannedEntities.contains(entity)) {
                StringBuilder message = new StringBuilder(itemEntity.method_6983().method_7909().method_63680().getString() + " found ");
                if (chatFeedback.get()) {
                    if (coordsInChat.get()) message.append(" at ").append(entity.method_31477()).append(", ").append(entity.method_31478()).append(", ").append(entity.method_31479());
                    ChatUtils.sendMsg(class_2561.method_30163(message.toString()));
                }
            }
            scannedEntities.add(entity);
            drawBoundingBox(event, entity);
            if (tracers.get()) drawTracer(event, entity);
            count++;
        }
    }

    @Override
    public void onActivate() {
        scannedEntities.clear();
    }
    @Override
    public void onDeactivate() {
        scannedEntities.clear();
    }

    private void drawBoundingBox(Render3DEvent event, class_1297 entity) {
        Color color = getColor(entity);
        if (color != null) {
            lineColor.set(color);
            sideColor.set(color).a((int) (sideColor.a * fillOpacity.get()));
        }

        double x = class_3532.method_16436(event.tickDelta, entity.field_6038, entity.method_23317()) - entity.method_23317();
        double y = class_3532.method_16436(event.tickDelta, entity.field_5971, entity.method_23318()) - entity.method_23318();
        double z = class_3532.method_16436(event.tickDelta, entity.field_5989, entity.method_23321()) - entity.method_23321();
        class_238 box = entity.method_5829();
        event.renderer.box(x + box.field_1323, y + box.field_1322, z + box.field_1321, x + box.field_1320, y + box.field_1325, z + box.field_1324, sideColor, lineColor, shapeMode.get(), 0);
    }

    private void drawTracer(Render3DEvent event, class_1297 entity) {
        if (mc.field_1690.field_1842) return;

        Color baseColor = monstersColor.get();
        if (distance.get()){
            baseColor = getOpposingColor(baseColor, entity);
        }

        double x = entity.field_6014 + (entity.method_23317() - entity.field_6014) * event.tickDelta;
        double y = entity.field_6036 + (entity.method_23318() - entity.field_6036) * event.tickDelta;
        double z = entity.field_5969 + (entity.method_23321() - entity.field_5969) * event.tickDelta;
        double height = entity.method_5829().field_1325 - entity.method_5829().field_1322;
        y += height / 2;

        event.renderer.line(RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350, x, y, z, baseColor);
    }
    private Color getOpposingColor(Color c, class_1297 e) {
        Color interpolatedColor;
        Color oppositeColor = distantColor.get();

        double distance = Math.sqrt(mc.field_1724.method_5858(e));

        double maxDistance = distanceInt.get();
        double percent = class_3532.method_15350(distance / maxDistance, 0, 1);

        int r = (int) (c.r + (oppositeColor.r - c.r) * percent);
        int g = (int) (c.g + (oppositeColor.g - c.g) * percent);
        int b = (int) (c.b + (oppositeColor.b - c.b) * percent);
        int a = c.a;

        interpolatedColor = new Color(r, g, b, a);
        return interpolatedColor;
    }
    public static boolean isTool(class_1799 itemStack) {
        return itemStack.method_31573(class_3489.field_42612) ||
                itemStack.method_31573(class_3489.field_42613) ||
                itemStack.method_31573(class_3489.field_42614) ||
                itemStack.method_31573(class_3489.field_42615) ||
                itemStack.method_7909() instanceof class_1820 ||
                itemStack.method_7909() instanceof class_1786;
    }
    public static boolean isArmor(class_1799 itemStack) {
        return itemStack.method_31573(class_3489.field_48297) ||
                itemStack.method_31573(class_3489.field_48296) ||
                itemStack.method_31573(class_3489.field_48295) ||
                itemStack.method_31573(class_3489.field_48294);
    }
    public boolean shouldSkip(class_1542 entity) {
        boolean skip = false;
        if (enchants.get()) {
            if (!certainenchants.get() && (isTool(entity.method_6983()) || isArmor(entity.method_6983()) || entity.method_6983().method_31573(class_3489.field_42611) || entity.method_6983().method_7909() instanceof class_1787 || entity.method_6983().method_7909() instanceof class_1786 || entity.method_6983().method_7909() instanceof class_9362 || entity.method_6983().method_7909() instanceof class_1820 || entity.method_6983().method_7909() instanceof class_1819 || entity.method_6983().method_7909() instanceof class_1835) && entity.method_6983().method_7923() && entity.method_6983().method_58657().method_57543()) skip = true;
            else if (certainenchants.get()){
                if (isTool(entity.method_6983())){
                    skip = compareEnchants(entity, toolenchants);
                } else if ( entity.method_6983().method_31573(class_3489.field_42611)){
                    skip = compareEnchants(entity, swordenchants);
                } else if (isArmor(entity.method_6983())){
                    skip = compareEnchants(entity, armorenchants);
                } else if (entity.method_6983().method_7909() instanceof class_9362){
                    skip = compareEnchants(entity, maceenchants);
                } else if (entity.method_6983().method_7909() instanceof class_1835){
                    skip = compareEnchants(entity, tridentenchants);
                }
            }
        }
        if (!items.get().contains(entity.method_6983().method_7909())) skip = true;
        return skip;
    }
    private boolean compareEnchants(class_1542 entity, Setting<Set<class_5321<class_1887>>> enchantsetting) {
        boolean skip = false;
        Set<class_5321<class_1887>> itemenchants = new HashSet<>();
        entity.method_6983().method_58657().method_57534().forEach(enchantment -> {
            itemenchants.add(enchantment.method_40230().get());
        });
        for (class_5321<class_1887> enchantKey : enchantsetting.get()) {
            if (!itemenchants.contains(enchantKey)) {
                skip = true;
                break;
            }
        }
        return skip;
    }
    public Color getColor(class_1297 entity) {
        double alpha = getFadeAlpha(entity);
        if (alpha == 0) return null;
        Color color = monstersColor.get();
        if (distance.get()){
            color = getOpposingColor(color, entity);
        }
        return baseColor.set(color.r, color.g, color.b, (int) (color.a * alpha));
    }

    private double getFadeAlpha(class_1297 entity) {
        double dist = PlayerUtils.squaredDistanceToCamera(entity.method_23317() + entity.method_17681() / 2, entity.method_23318() + entity.method_18381(entity.method_18376()), entity.method_23321() + entity.method_17681() / 2);
        double fadeDist = Math.pow(fadeDistance.get(), 2);
        double alpha = 1;
        if (dist <= fadeDist * fadeDist) alpha = (float) (Math.sqrt(dist) / fadeDist);
        if (alpha <= 0.075) alpha = 0;
        return alpha;
    }

    @Override
    public String getInfoString() {
        return Integer.toString(count);
    }
    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (mc.field_1687 != null){
            Iterable<net.minecraft.class_1297> entities = mc.field_1687.method_18112();
            scannedEntities.removeIf(entity -> {
                Set<class_1297> entitySet = new HashSet<>();
                entities.forEach(entity1 -> entitySet.add(entity1));
                return !entitySet.contains(entity);
            });
        }
    }
}