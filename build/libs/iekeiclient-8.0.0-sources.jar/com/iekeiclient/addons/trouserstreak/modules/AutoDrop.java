package com.iekeiclient.addons.trouserstreak.modules;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import net.minecraft.class_10936;
import net.minecraft.class_10938;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1755;
import net.minecraft.class_1786;
import net.minecraft.class_1799;
import net.minecraft.class_1820;
import net.minecraft.class_2813;
import net.minecraft.class_3489;
import net.minecraft.item.*;
import com.iekeiclient.addons.trouserstreak.Trouser;

import meteordevelopment.orbit.EventHandler;
import java.util.ArrayList;
import java.util.List;

public class AutoDrop extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<DropMode> dropMode = sgGeneral.add(new EnumSetting.Builder<DropMode>()
            .name("drop-mode")
            .description("How many hotbar slots are dropped.")
            .defaultValue(DropMode.HeldItem)
            .build()
    );
    private final Setting<Boolean> throwmainhand = sgGeneral.add(new BoolSetting.Builder()
            .name("throw-mainhand")
            .defaultValue(true)
            .visible(() -> dropMode.get() == DropMode.HeldItem)
            .build()
    );
    private final Setting<Boolean> throwoffhand = sgGeneral.add(new BoolSetting.Builder()
            .name("throw-offhand")
            .defaultValue(false)
            .visible(() -> dropMode.get() == DropMode.HeldItem)
            .build()
    );
    private final Setting<DropMethod> dropMethod = sgGeneral.add(new EnumSetting.Builder<DropMethod>()
            .name("drop-method")
            .description("How hotbar slots are dropped each tick.")
            .defaultValue(DropMethod.BURST)
            .visible(() -> dropMode.get() == DropMode.SpecifySlots)
            .build()
    );
    private final Setting<Integer> dropsPerTick = sgGeneral.add(new IntSetting.Builder()
            .name("drops-per-tick")
            .description("Maximum number of hotbar slots to drop per tick (1-9).")
            .defaultValue(9)
            .min(1)
            .sliderMax(9)
            .visible(() -> dropMode.get() == DropMode.SpecifySlots)
            .build()
    );
    private final Setting<Boolean> tool = sgGeneral.add(new BoolSetting.Builder()
            .name("No Throw Tools")
            .description("No Throw tools")
            .defaultValue(false)
            .build()
    );

    private final List<Setting<Boolean>> slots = new ArrayList<>(9);

    public AutoDrop() {
        super(Trouser.Main, "auto-drop", "Drops the stack in your selected slot automatically");

        for (int i = 0; i < 9; i++) {
            final int slot = i;
            slots.add(sgGeneral.add(new BoolSetting.Builder()
                    .name("slot " + slot)
                    .description("Drop items from hotbar slot " + slot + ".")
                    .defaultValue(false)
                    .visible(() -> dropMode.get() == DropMode.SpecifySlots)
                    .build()
            ));
        }
    }

    private int nextSlot = 0;

    public static boolean isTool(class_1799 itemStack) {
        return itemStack.method_31573(class_3489.field_42612) ||
                itemStack.method_31573(class_3489.field_42613) ||
                itemStack.method_31573(class_3489.field_42614) ||
                itemStack.method_31573(class_3489.field_42615) ||
                itemStack.method_7909() instanceof class_1820 ||
                itemStack.method_7909() instanceof class_1786 ||
                itemStack.method_7909() instanceof class_1755;
    }

    private boolean isSlotEnabled(int slot) {
        return slot >= 0 && slot < 9 && slots.get(slot).get();
    }

    @Override
    public void onActivate() {
        nextSlot = 0;
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (mc.field_1724 == null) return;

        switch (dropMode.get()){
            case HeldItem -> {
                if (mc.field_1724 == null) return;
                class_1661 inv = mc.field_1724.method_31548();
                class_1799 offhandStack = inv.method_5438(class_1661.field_30639);

                if (throwmainhand.get() && (!tool.get() || !isTool(inv.method_7391()))) {
                    mc.field_1724.method_7290(true);
                }

                if (throwoffhand.get() && !offhandStack.method_7960() && (!tool.get() || !isTool(offhandStack))) {
                    short offhandSlotId = (short) 45;
                    byte dropButton = (byte) 1;

                    Int2ObjectMap<class_10938> modifiedStacks = new Int2ObjectOpenHashMap<>();

                    class_10936.class_10937 hasher = mc.method_1562().method_68823();

                    class_10938 offhandHash = class_10938.method_68853(offhandStack, hasher);
                    modifiedStacks.put(offhandSlotId, offhandHash);

                    mc.method_1562().method_52787(new class_2813(
                            mc.field_1724.field_7512.field_7763,
                            mc.field_1724.field_7512.method_37421(),
                            offhandSlotId,
                            dropButton,
                            class_1713.field_7795,
                            modifiedStacks,
                            class_10938.field_58176
                    ));
                }
            }
            case SpecifySlots -> {
                int dropped = 0;
                int limit = Math.min(dropsPerTick.get(), 9);
                byte dropButton = (byte) 1;

                if (dropMethod.get() == DropMethod.BURST) {
                    for (int i = 0; i < 9 && dropped < limit; i++) {
                        if (!isSlotEnabled(i)) continue;
                        class_1799 stack = mc.field_1724.method_31548().method_5438(i);
                        if (stack.method_7960()) continue;
                        if (tool.get() && isTool(stack)) continue;
                        short hotbarSlotId = (short) (36 + i);

                        Int2ObjectMap<class_10938> modifiedStacks = new Int2ObjectOpenHashMap<>();

                        class_10936.class_10937 hasher = mc.method_1562().method_68823();

                        class_10938 hotbarHash = class_10938.method_68853(stack, hasher);
                        modifiedStacks.put(hotbarSlotId, hotbarHash);

                        mc.method_1562().method_52787(new class_2813(
                                mc.field_1724.field_7512.field_7763,
                                mc.field_1724.field_7512.method_37421(),
                                hotbarSlotId,
                                dropButton,
                                class_1713.field_7795,
                                modifiedStacks,
                                class_10938.field_58176
                        ));
                        dropped++;
                    }
                } else {
                    int startSlot = nextSlot;
                    for (int i = 0; i < 9 && dropped < limit; i++) {
                        int slot = (startSlot + i) % 9;
                        if (!isSlotEnabled(slot)) continue;
                        class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
                        if (stack.method_7960()) continue;
                        if (tool.get() && isTool(stack)) continue;
                        short hotbarSlotId = (short) (36 + slot);

                        Int2ObjectMap<class_10938> modifiedStacks = new Int2ObjectOpenHashMap<>();

                        class_10936.class_10937 hasher = mc.method_1562().method_68823();

                        class_10938 hotbarHash = class_10938.method_68853(stack, hasher);
                        modifiedStacks.put(hotbarSlotId, hotbarHash);

                        mc.method_1562().method_52787(new class_2813(
                                mc.field_1724.field_7512.field_7763,
                                mc.field_1724.field_7512.method_37421(),
                                hotbarSlotId,
                                dropButton,
                                class_1713.field_7795,
                                modifiedStacks,
                                class_10938.field_58176
                        ));
                        nextSlot = (slot + 1) % 9;
                        dropped++;
                    }
                }
            }
        }
    }
    public enum DropMode {
        HeldItem,
        SpecifySlots
    }
    public enum DropMethod {
        BURST,
        SEQUENTIAL
    }
}