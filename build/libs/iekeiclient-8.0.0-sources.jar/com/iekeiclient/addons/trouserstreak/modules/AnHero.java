package com.iekeiclient.addons.trouserstreak.modules;

import com.iekeiclient.engine.events.game.GameLeftEvent;
import com.iekeiclient.engine.events.game.OpenScreenEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.systems.modules.movement.Flight;
import com.iekeiclient.engine.systems.modules.movement.NoFall;
import com.iekeiclient.engine.systems.modules.world.Timer;
import com.iekeiclient.engine.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_418;
import net.minecraft.class_419;
import com.iekeiclient.addons.trouserstreak.Trouser;

public class AnHero extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    public final Setting<Double> toasterbath = sgGeneral.add(new DoubleSetting.Builder()
            .name("Hero Multiplier")
            .description("The multiplier value for how fast to become an hero.")
            .defaultValue(1)
            .sliderRange(0.5,10)
            .min(0)
            .build()
    );
    public final Setting<Boolean> chatmsg = sgGeneral.add(new BoolSetting.Builder()
            .name("SendAMessage")
            .description("Sends a message before you become an hero.")
            .defaultValue(false)
            .build()
    );
    private final Setting<String> message = sgGeneral.add(new StringSetting.Builder()
            .name("TheMessage")
            .description("What is said before you become an hero.")
            .defaultValue("I Regret Nothing.")
            .visible(chatmsg::get)
            .build());
    public final Setting<Boolean> anHeroPreventionDisable = sgGeneral.add(new BoolSetting.Builder()
            .name("Disable AnHero prevention")
            .description("Ensures that you become an hero. Without it you may not become an hero to us all.")
            .defaultValue(true)
            .build()
    );

    public AnHero() {
        super(Trouser.Main, "AnHero", "Become An Hero!");
    }
    private int ticks;
    private boolean nofallwason;

    @EventHandler
    private void onScreenOpen(OpenScreenEvent event) {
        if (event.screen instanceof class_419) {
            if (nofallwason && !Modules.get().get(NoFall.class).isActive() && anHeroPreventionDisable.get()){
                Modules.get().get(NoFall.class).toggle();
            }
            Modules.get().get(Timer.class).setOverride(Timer.OFF);
            toggle();
        }
        if (event.screen instanceof class_418) {
            if (nofallwason && !Modules.get().get(NoFall.class).isActive() && anHeroPreventionDisable.get()){
                Modules.get().get(NoFall.class).toggle();
            }
            Modules.get().get(Timer.class).setOverride(Timer.OFF);
            toggle();
        }
    }
    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        if (nofallwason && !Modules.get().get(NoFall.class).isActive() && anHeroPreventionDisable.get()){
            Modules.get().get(NoFall.class).toggle();
        }
        Modules.get().get(Timer.class).setOverride(Timer.OFF);
        toggle();
    }
    @Override
    public void onActivate() {
        if (mc.field_1724 == null) return;
        if (chatmsg.get()){
            ChatUtils.sendPlayerMsg(message.get());
        }
        if (Modules.get().get(Flight.class).isActive()) {
            Modules.get().get(Flight.class).toggle();
        }
        if (Modules.get().get(FlightAntikick.class).isActive()) {
            Modules.get().get(FlightAntikick.class).toggle();
        }
        if (Modules.get().get(TPFly.class).isActive()) {
            Modules.get().get(TPFly.class).toggle();
        }
        if (Modules.get().get(NoFall.class).isActive()) {
            nofallwason=true;
            Modules.get().get(NoFall.class).toggle();
        } else if (!Modules.get().get(NoFall.class).isActive()){
            nofallwason=false;
        }
        ticks=0;
    }
    @Override
    public void onDeactivate() {
        if (nofallwason && !Modules.get().get(NoFall.class).isActive()){
            Modules.get().get(NoFall.class).toggle();
        }
        Modules.get().get(Timer.class).setOverride(Timer.OFF);
        ticks=0;
    }
    @EventHandler
    public void onPreTick(TickEvent.Pre event) {
        if (mc.field_1724 == null) return;
        if (mc.field_1724.method_6032()==0) {
            if (nofallwason && !Modules.get().get(NoFall.class).isActive()){
                Modules.get().get(NoFall.class).toggle();
            }
            Modules.get().get(Timer.class).setOverride(Timer.OFF);
            toggle();
            return;
        }
        ticks++;
        Modules.get().get(Timer.class).setOverride(toasterbath.get());
        if (ticks==1){
            mc.field_1724.method_5784(class_1313.field_6308, new class_243(0, +7,0));
        }else if (ticks==2){
            mc.field_1724.method_5784(class_1313.field_6308, new class_243(0, +7,0));
        }else if (ticks==3){
            mc.field_1724.method_5784(class_1313.field_6308, new class_243(0, +7,0));
        }else if (ticks==4){
            mc.field_1724.method_5784(class_1313.field_6308, new class_243(0, +7,0));
        }else if (ticks==5){
            mc.field_1724.method_5784(class_1313.field_6308, new class_243(0, +7,0));
        }else if (ticks>=6 && ticks<20){
            mc.field_1724.method_18800(0.01,-10,0);
        }else if (ticks>=20){
            ticks=0;
        }
    }
}