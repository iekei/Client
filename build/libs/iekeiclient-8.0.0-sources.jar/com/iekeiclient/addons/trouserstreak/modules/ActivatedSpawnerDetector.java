//made by etianl :D
package com.iekeiclient.addons.trouserstreak.modules;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iekeiclient.engine.events.game.GameLeftEvent;
import com.iekeiclient.engine.events.game.OpenScreenEvent;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.widgets.WWidget;
import com.iekeiclient.engine.gui.widgets.containers.WTable;
import com.iekeiclient.engine.gui.widgets.containers.WVerticalList;
import com.iekeiclient.engine.gui.widgets.pressable.WButton;
import com.iekeiclient.engine.gui.widgets.pressable.WMinus;
import com.iekeiclient.engine.pathing.PathManagers;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.BlockListSetting;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.ColorSetting;
import com.iekeiclient.engine.settings.EnumSetting;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.Utils;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.engine.utils.render.RenderUtils;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1694;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2636;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2837;
import net.minecraft.class_3928;
import net.minecraft.class_419;
import net.minecraft.class_8961;
import net.minecraft.class_8967;
import com.iekeiclient.addons.trouserstreak.Trouser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.*;
import java.util.concurrent.atomic.AtomicReferenceArray;

public class ActivatedSpawnerDetector extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");
    private final SettingGroup sgLocations = settings.createGroup("Location Toggles");
    private final SettingGroup locationLogs = settings.createGroup("Location Logs");
    private final Setting<Boolean> trialSpawner = sgLocations.add(new BoolSetting.Builder()
            .name("Trial Spawner Detector")
            .description("Detects activated Trial Spawners.")
            .defaultValue(true)
            .build()
    );
    private final Setting<Boolean> showmoremenu = sgLocations.add(new BoolSetting.Builder()
            .name("Show More Location Toggles")
            .description("Make the options menu bigger or smaller.")
            .defaultValue(false)
            .build());
    private final Setting<Boolean> enableDungeon = sgLocations.add(new BoolSetting.Builder()
            .name("Enable Dungeon")
            .description("Enable detection for dungeons.")
            .defaultValue(true)
            .visible(showmoremenu::get)
            .build());

    private final Setting<Boolean> enableMineshaft = sgLocations.add(new BoolSetting.Builder()
            .name("Enable Mineshaft")
            .description("Enable detection for mineshafts.")
            .defaultValue(true)
            .visible(showmoremenu::get)
            .build());

    private final Setting<Boolean> enableBastion = sgLocations.add(new BoolSetting.Builder()
            .name("Enable Bastion")
            .description("Enable detection for bastions.")
            .defaultValue(true)
            .visible(showmoremenu::get)
            .build());

    private final Setting<Boolean> enableWoodlandMansion = sgLocations.add(new BoolSetting.Builder()
            .name("Enable Woodland Mansion")
            .description("Enable detection for woodland mansions.")
            .defaultValue(true)
            .visible(showmoremenu::get)
            .build());
    private final Setting<Boolean> enableFortress = sgLocations.add(new BoolSetting.Builder()
            .name("Enable Fortress")
            .description("Enable detection for fortresses.")
            .defaultValue(true)
            .visible(showmoremenu::get)
            .build());
    private final Setting<Boolean> enableStronghold = sgLocations.add(new BoolSetting.Builder()
            .name("Enable Stronghold")
            .description("Enable detection for strongholds.")
            .defaultValue(true)
            .visible(showmoremenu::get)
            .build());
    private final Setting<Boolean> chatFeedback = sgGeneral.add(new BoolSetting.Builder()
            .name("Chat feedback")
            .description("Display info about spawners in chat.")
            .defaultValue(true)
            .build()
    );
    private final Setting<Boolean> displaycoords = sgGeneral.add(new BoolSetting.Builder()
            .name("DisplayCoords")
            .description("Displays coords of activated spawners in chat.")
            .defaultValue(true)
            .build()
    );
    private final Setting<Boolean> extramessage = sgGeneral.add(new BoolSetting.Builder()
            .name("Stash Message")
            .description("Toggle the message reminding you about stashes.")
            .defaultValue(true)
            .build()
    );
    private final Setting<Boolean> lessSpam = sgGeneral.add(new BoolSetting.Builder()
            .name("Less Stash Spam")
            .description("Do not display the message reminding you about stashes if NO chests within 16 blocks of spawner.")
            .defaultValue(true)
            .visible(extramessage::get)
            .build()
    );
    private final Setting<Boolean> airChecker = sgGeneral.add(new BoolSetting.Builder()
            .name("Check Air Disturbances")
            .description("Displays spawners as activated if there are disturbances in the air around them. For example if a torch was placed and removed it will detect that. THERE CAN BE SOME FALSE POSITIVES WITH THIS!")
            .defaultValue(false)
            .build()
    );
    private final Setting<Boolean> ignoreGeodes = sgGeneral.add(new BoolSetting.Builder()
            .name("Ignore Geodes")
            .description("Skips air check for spawners near geode blocks to reduce false positives.")
            .defaultValue(true)
            .visible(airChecker::get)
            .build()
    );
    private final Setting<List<class_2248>> blocks = sgGeneral.add(new BlockListSetting.Builder()
            .name("Storage Blocks")
            .description("Storage Blocks the module checks for when considering displaying messages and renders.")
            .defaultValue(class_2246.field_10034, class_2246.field_16328, class_2246.field_10312, class_2246.field_10200)
            .build()
    );
    private final Setting<Boolean> deactivatedSpawner = sgGeneral.add(new BoolSetting.Builder()
            .name("De-Activated Spawner Detector")
            .description("Detects spawners with torches on them.")
            .defaultValue(true)
            .build()
    );
    public final Setting<Integer> deactivatedSpawnerdistance = sgGeneral.add(new IntSetting.Builder()
            .name("Torch Scan distance")
            .description("How many blocks from the spawner to look for blocks that make light")
            .defaultValue(1)
            .min(1)
            .sliderRange(1,10)
            .visible(deactivatedSpawner::get)
            .build()
    );
    private final Setting<Boolean> lessRenderSpam = sgRender.add(new BoolSetting.Builder()
            .name("Less Render Spam")
            .description("Do not render big box if NO chests within range of spawner.")
            .defaultValue(true)
            .build()
    );
    public final Setting<Integer> renderDistance = sgRender.add(new IntSetting.Builder()
            .name("Render-Distance(Chunks)")
            .description("How many chunks from the character to render the detected spawners.")
            .defaultValue(32)
            .min(6)
            .sliderRange(6,1024)
            .build()
    );
    private final Setting<Boolean> removerenderdist = sgRender.add(new BoolSetting.Builder()
            .name("RemoveOutsideRenderDistance")
            .description("Removes the cached block positions when they leave the defined render distance.")
            .defaultValue(true)
            .build()
    );
    private final Setting<Boolean> trcr = sgRender.add(new BoolSetting.Builder()
            .name("Tracers")
            .description("Show tracers to the Spawner.")
            .defaultValue(true)
            .build()
    );
    private final Setting<Boolean> nearesttrcr = sgRender.add(new BoolSetting.Builder()
            .name("Tracer to nearest Spawner Only")
            .description("Show only one tracer to the nearest Spawner.")
            .defaultValue(false)
            .build()
    );
    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
            .name("shape-mode")
            .description("How the shapes are rendered.")
            .defaultValue(ShapeMode.Both)
            .build()
    );
    private final Setting<SettingColor> spawnerSideColor = sgRender.add(new ColorSetting.Builder()
            .name("spawner-side-color")
            .description("Color of the activated spawner.")
            .defaultValue(new SettingColor(251, 5, 5, 70))
            .visible(() -> (shapeMode.get() == ShapeMode.Sides || shapeMode.get() == ShapeMode.Both))
            .build()
    );
    private final Setting<SettingColor> spawnerLineColor = sgRender.add(new ColorSetting.Builder()
            .name("spawner-line-color")
            .description("Color of the activated spawner.")
            .defaultValue(new SettingColor(251, 5, 5, 235))
            .visible(() -> (shapeMode.get() == ShapeMode.Lines || shapeMode.get() == ShapeMode.Both || trcr.get()))
            .build()
    );
    private final Setting<SettingColor> trialSideColor = sgRender.add(new ColorSetting.Builder()
            .name("trial-side-color")
            .description("Color of the activated trial spawner.")
            .defaultValue(new SettingColor(255, 100, 0, 70))
            .visible(() -> trialSpawner.get() && (shapeMode.get() == ShapeMode.Sides || shapeMode.get() == ShapeMode.Both))
            .build()
    );
    private final Setting<SettingColor> trialLineColor = sgRender.add(new ColorSetting.Builder()
            .name("trial-line-color")
            .description("Color of the activated trial spawner.")
            .defaultValue(new SettingColor(255, 100, 0, 235))
            .visible(() -> trialSpawner.get() && (shapeMode.get() == ShapeMode.Lines || shapeMode.get() == ShapeMode.Both || trcr.get()))
            .build()
    );
    private final Setting<SettingColor> despawnerSideColor = sgRender.add(new ColorSetting.Builder()
            .name("deactivated-spawner-side-color")
            .description("Color of the spawner with torches.")
            .defaultValue(new SettingColor(251, 5, 251, 70))
            .visible(() -> deactivatedSpawner.get() && (shapeMode.get() == ShapeMode.Sides || shapeMode.get() == ShapeMode.Both))
            .build()
    );
    private final Setting<SettingColor> despawnerLineColor = sgRender.add(new ColorSetting.Builder()
            .name("deactivated-spawner-line-color")
            .description("Color of the spawner with torches.")
            .defaultValue(new SettingColor(251, 5, 251, 235))
            .visible(() -> deactivatedSpawner.get() && (shapeMode.get() == ShapeMode.Lines || shapeMode.get() == ShapeMode.Both))
            .build()
    );
    private final Setting<Boolean> rangerendering = sgRender.add(new BoolSetting.Builder()
            .name("spawner-range-rendering")
            .description("Renders the rough active range of a mob spawner block.")
            .defaultValue(true)
            .build()
    );
    private final Setting<SettingColor> rangeSideColor = sgRender.add(new ColorSetting.Builder()
            .name("spawner-range-side-color")
            .description("Color of the active spawner range.")
            .defaultValue(new SettingColor(5, 178, 251, 30))
            .visible(() -> rangerendering.get() && (shapeMode.get() == ShapeMode.Sides || shapeMode.get() == ShapeMode.Both))
            .build()
    );
    private final Setting<SettingColor> rangeLineColor = sgRender.add(new ColorSetting.Builder()
            .name("spawner-range-line-color")
            .description("Color of the active spawner range.")
            .defaultValue(new SettingColor(5, 178, 251, 155))
            .visible(() -> rangerendering.get() && (shapeMode.get() == ShapeMode.Lines || shapeMode.get() == ShapeMode.Both))
            .build()
    );
    private final Setting<SettingColor> trangeSideColor = sgRender.add(new ColorSetting.Builder()
            .name("trial-range-side-color")
            .description("Color of the active trial spawner range.")
            .defaultValue(new SettingColor(150, 178, 251, 30))
            .visible(() -> trialSpawner.get() && rangerendering.get() && (shapeMode.get() == ShapeMode.Sides || shapeMode.get() == ShapeMode.Both))
            .build()
    );
    private final Setting<SettingColor> trangeLineColor = sgRender.add(new ColorSetting.Builder()
            .name("trial-range-line-color")
            .description("Color of the active trial spawner range.")
            .defaultValue(new SettingColor(150, 178, 251, 155))
            .visible(() -> trialSpawner.get() && rangerendering.get() && (shapeMode.get() == ShapeMode.Lines || shapeMode.get() == ShapeMode.Both))
            .build()
    );
    private final Setting<Boolean> locLogging = locationLogs.add(new BoolSetting.Builder()
            .name("Enable Location Logging")
            .description("Logs the locations of detected spawners to a csv file as well as a table in this options menu.")
            .defaultValue(false)
            .build()
    );
    private final List<LoggedSpawner> loggedSpawners = new ArrayList<>();
    private final Set<class_2338> loggedSpawnerPositions = new HashSet<>();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Set<class_2338> scannedPositions = Collections.synchronizedSet(new HashSet<>());
    private final Set<class_2338> spawnerPositions = Collections.synchronizedSet(new HashSet<>());
    private final Set<class_2338> trialspawnerPositions = Collections.synchronizedSet(new HashSet<>());
    private final Set<class_2338> deactivatedSpawnerPositions = Collections.synchronizedSet(new HashSet<>());
    private final Set<class_2338> noRenderPositions = Collections.synchronizedSet(new HashSet<>());
    private int closestSpawnerX = 2000000000;
    private int closestSpawnerY = 2000000000;
    private int closestSpawnerZ = 2000000000;
    private double SpawnerDistance = 2000000000;
    private boolean activatedSpawnerFound = false;

    public ActivatedSpawnerDetector() {
        super(Trouser.baseHunting, "ActivatedSpawnerDetector", "Detects if a player has been near a mob spawner in the past. May be useful for finding player made stashes in dungeons, mineshafts, and other places.");
    }
    @Override
    public void onActivate() {
        clearChunkData();
        loadLogs();
    }
    @Override
    public void onDeactivate() {
        clearChunkData();
    }
    @EventHandler
    private void onScreenOpen(OpenScreenEvent event) {
        if (event.screen instanceof class_419 || event.screen instanceof class_3928) clearChunkData();
    }
    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        clearChunkData();
    }
    private void clearChunkData(){
        scannedPositions.clear();
        spawnerPositions.clear();
        deactivatedSpawnerPositions.clear();
        noRenderPositions.clear();
        trialspawnerPositions.clear();
        closestSpawnerX = 2000000000;
        closestSpawnerY = 2000000000;
        closestSpawnerZ = 2000000000;
        SpawnerDistance = 2000000000;
    }
    private static final Set<class_2248> GEODE_BLOCKS = Set.of(
            class_2246.field_27159,
            class_2246.field_27160,
            class_2246.field_27114,
            class_2246.field_29032,
            class_2246.field_27161,
            class_2246.field_27162,
            class_2246.field_27163,
            class_2246.field_27164
    );
    private boolean chunkContainsGeodeBlocks(class_2818 chunk, int sectionsToCheck) {
        class_2826[] sections = chunk.method_12006();
        for (int i = 0; i < sectionsToCheck; i++) {
            class_2826 section = sections[i];
            if (!section.method_38292()) {
                var blockStatesContainer = section.method_12265();
                class_2837<class_2680> blockStatePalette = blockStatesContainer.field_34560.comp_119();
                int blockPaletteLength = blockStatePalette.method_12197();
                for (int i2 = 0; i2 < blockPaletteLength; i2++) {
                    class_2680 blockPaletteEntry = blockStatePalette.method_12288(i2);
                    if (GEODE_BLOCKS.contains(blockPaletteEntry.method_26204())) return true;
                }
            }
        }
        return false;
    }
    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        AtomicReferenceArray<class_2818> chunks = mc.field_1687.method_2935().field_16246.field_16251;
        Set<class_2818> chunkSet = new HashSet<>();

        for (int i = 0; i < chunks.length(); i++) {
            class_2818 chunk = chunks.get(i);
            if (chunk != null) {
                chunkSet.add(chunk);
            }
        }
        chunkSet.forEach(chunk -> {
            List<class_2586> blockEntities = new ArrayList<>(chunk.method_12214().values());

            for (class_2586 blockEntity : blockEntities) {
                if (blockEntity instanceof class_2636 spawner) {
                    activatedSpawnerFound = false;
                    class_2338 pos = spawner.method_11016();
                    String monster = null;
                    if (spawner.method_11390().field_9155 != null && spawner.method_11390().field_9155.method_38093().method_10580("id") != null)
                        monster = spawner.method_11390().field_9155.method_38093().method_10580("id").toString();
                    if (!trialspawnerPositions.contains(pos) && !noRenderPositions.contains(pos) && !deactivatedSpawnerPositions.contains(pos) && !spawnerPositions.contains(pos)) {
                        if (airChecker.get() && (spawner.method_11390().field_9154 == 20 || spawner.method_11390().field_9154 == 0)) {
                            boolean airFound = false;
                            boolean caveAirFound = false;
                            boolean geodeNearby = false;
                            if (ignoreGeodes.get() && chunkContainsGeodeBlocks(chunk, Math.min(chunk.method_12006().length, 20))) { //thank you to FaxHack for this block https://github.com/FaxHack/PathSeeker/commit/a424a743297350147754ec3f90f1a5ee5643b7e7
                                for (int x = -5; x <= 5; x++) {
                                    for (int y = -5; y <= 5; y++) {
                                        for (int z = -5; z <= 5; z++) {
                                            class_2338 bpos = pos.method_10069(x, y, z);
                                            if (GEODE_BLOCKS.contains(mc.field_1687.method_8320(bpos).method_26204())) {
                                                geodeNearby = true;
                                                break;
                                            }
                                        }
                                        if (geodeNearby) break;
                                    }
                                    if (geodeNearby) break;
                                }
                            }
                            if (monster != null && !scannedPositions.contains(pos)) {
                                if (monster.contains("zombie") || monster.contains("skeleton") || monster.contains(":spider")) {
                                    for (int x = -2; x < 2; x++) {
                                        for (int y = -1; y < 3; y++) {
                                            for (int z = -2; z < 2; z++) {
                                                class_2338 bpos = new class_2338(pos.method_10263() + x, pos.method_10264() + y, pos.method_10260() + z);
                                                if (mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10124)
                                                    airFound = true;
                                                if (mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10543)
                                                    caveAirFound = true;
                                                if (caveAirFound && airFound) break;
                                            }
                                        }
                                    }
                                    if (caveAirFound && airFound) {
                                        if (monster.equals(":spider")) displayMessage("dungeon", pos, ":spider");
                                        else displayMessage("dungeon", pos, "null");
                                    }
                                } else if (monster.contains("cave_spider")) {
                                    for (int x = -1; x < 2; x++) {
                                        for (int y = 0; y < 2; y++) {
                                            for (int z = -1; z < 2; z++) {
                                                class_2338 bpos = new class_2338(pos.method_10263() + x, pos.method_10264() + y, pos.method_10260() + z);
                                                if (mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10124)
                                                    airFound = true;
                                                if (mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10543)
                                                    caveAirFound = true;
                                                if (caveAirFound && airFound) break;
                                            }
                                        }
                                    }
                                    if (caveAirFound && airFound) {
                                        displayMessage("cave_spider", pos, "null");
                                    }
                                } else if (monster.contains("silverfish")) {
                                    for (int x = -3; x < 3 + 1; x++) {
                                        for (int y = -2; y < 3 + 1; y++) {
                                            for (int z = -3; z < 3 + 1; z++) {
                                                class_2338 bpos = new class_2338(pos.method_10263() + x, pos.method_10264() + y, pos.method_10260() + z);
                                                if (mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10124)
                                                    airFound = true;
                                                if (mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10543)
                                                    caveAirFound = true;
                                                if (caveAirFound && airFound) break;
                                            }
                                        }
                                    }
                                    if (caveAirFound && airFound) {
                                        displayMessage("silverfish", pos, "null");
                                    }
                                }
                            }
                            scannedPositions.add(pos);
                        } else if (spawner.method_11390().field_9154 != 20) {
                            if (mc.field_1687.method_27983() == class_1937.field_25180 && spawner.method_11390().field_9154 == 0) return;
                            if (chatFeedback.get()) {
                                if (monster != null) {
                                    if (monster.contains("zombie") || monster.contains("skeleton") || monster.contains(":spider")) {
                                        if (monster.equals(":spider")) displayMessage("dungeon", pos, ":spider");
                                        else displayMessage("dungeon", pos, "null");
                                    } else if (monster.contains("cave_spider")) {
                                        displayMessage("cave_spider", pos, "null");
                                    } else if (monster.contains("silverfish")) {
                                        displayMessage("silverfish", pos, "null");
                                    } else if (monster.contains("blaze")) {
                                        displayMessage("blaze", pos, "null");
                                    } else if (monster.contains("magma")) {
                                        displayMessage("magma", pos, "null");
                                    } else {
                                        if (displaycoords.get())
                                            ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated Spawner! Block Position: " + pos));
                                        else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated Spawner!"));
                                        spawnerPositions.add(pos);
                                        activatedSpawnerFound = true;
                                        if (locLogging.get()) logSpawner(pos);
                                    }
                                } else {
                                    if (displaycoords.get())
                                        ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated Spawner! Block Position: " + pos));
                                    else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated Spawner!"));
                                    spawnerPositions.add(pos);
                                    activatedSpawnerFound = true;
                                    if (locLogging.get()) logSpawner(pos);
                                }
                            }
                        }
                        if (activatedSpawnerFound) {
                            if (deactivatedSpawner.get()) {
                                boolean lightsFound = false;
                                for (int x = -deactivatedSpawnerdistance.get(); x < deactivatedSpawnerdistance.get() + 1; x++) {
                                    for (int y = -deactivatedSpawnerdistance.get(); y < deactivatedSpawnerdistance.get() + 1; y++) {
                                        for (int z = -deactivatedSpawnerdistance.get(); z < deactivatedSpawnerdistance.get() + 1; z++) {
                                            class_2338 bpos = new class_2338(pos.method_10263() + x, pos.method_10264() + y, pos.method_10260() + z);
                                            if (mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10336 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_22092 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10523 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10009 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10171 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_22122 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_37572 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_37574 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_37574 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_10174 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_16541 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_22110 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_17350 || mc.field_1687.method_8320(bpos).method_26204() == class_2246.field_23860) {
                                                lightsFound = true;
                                                deactivatedSpawnerPositions.add(pos);
                                                break;
                                            }
                                        }
                                    }
                                }
                                if (chatFeedback.get() && lightsFound)
                                    ChatUtils.sendMsg(class_2561.method_30163("The Spawner has torches or other light blocks!"));
                            }

                            boolean chestfound = false;
                            for (int x = -16; x < 17; x++) {
                                for (int y = -16; y < 17; y++) {
                                    for (int z = -16; z < 17; z++) {
                                        class_2338 bpos = new class_2338(pos.method_10263() + x, pos.method_10264() + y, pos.method_10260() + z);
                                        if (blocks.get().contains(mc.field_1687.method_8320(bpos).method_26204())) {
                                            chestfound = true;
                                            break;
                                        }
                                        class_238 box = new class_238(bpos);
                                        List<class_1694> minecarts = mc.field_1687.method_8390(class_1694.class, box, entity -> true);
                                        if (!minecarts.isEmpty()) {
                                            chestfound = true;
                                            break;
                                        }
                                    }
                                    if (chestfound) break;
                                }
                                if (chestfound) break;
                            }
                            if (!chestfound && lessRenderSpam.get()) {
                                noRenderPositions.add(pos);
                            }
                            if (chatFeedback.get()) {
                                if (lessSpam.get() && chestfound && extramessage.get())
                                    error("There may be stashed items in the storage near the spawners!");
                                else if (!lessSpam.get() && extramessage.get())
                                    error("There may be stashed items in the storage near the spawners!");
                            }
                        }
                    }
                }
                if (blockEntity instanceof class_8961 trialspawner) {
                    class_2338 tPos = trialspawner.method_11016();
                    if (trialSpawner.get() && !trialspawnerPositions.contains(tPos) && !noRenderPositions.contains(tPos) && !deactivatedSpawnerPositions.contains(tPos) && !spawnerPositions.contains(tPos) && trialspawner.method_55151() != class_8967.field_47384) {
                        if (chatFeedback.get()) {
                            if (displaycoords.get())
                                ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cTRIAL§r Spawner! Block Position: " + tPos));
                            else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cTRIAL§r Spawner!"));
                        }
                        trialspawnerPositions.add(tPos);
                        boolean chestfound = false;
                        for (int x = -14; x < 15; x++) {
                            for (int y = -14; y < 15; y++) {
                                for (int z = -14; z < 15; z++) {
                                    class_2338 bpos = new class_2338(tPos.method_10263() + x, tPos.method_10264() + y, tPos.method_10260() + z);
                                    if (blocks.get().contains(mc.field_1687.method_8320(bpos).method_26204())) {
                                        chestfound = true;
                                        break;
                                    }
                                    class_238 box = new class_238(bpos);
                                    List<class_1694> minecarts = mc.field_1687.method_8390(class_1694.class, box, entity -> true);
                                    if (!minecarts.isEmpty()) {
                                        chestfound = true;
                                        break;
                                    }
                                }
                                if (chestfound) break;
                            }
                            if (chestfound) break;
                        }
                        if (!chestfound && lessRenderSpam.get()) {
                            noRenderPositions.add(tPos);
                        }
                        if (chatFeedback.get()) {
                            if (lessSpam.get() && chestfound && extramessage.get())
                                error("There may be stashed items in the storage near the spawners!");
                            else if (!lessSpam.get() && extramessage.get())
                                error("There may be stashed items in the storage near the spawners!");
                        }
                        if (locLogging.get()) logSpawner(tPos);
                    }
                }
            }
        });
        if (nearesttrcr.get()){
            try {
                Set<class_2338> CombinedPositions = Collections.synchronizedSet(new HashSet<>());
                CombinedPositions.addAll(spawnerPositions);
                CombinedPositions.addAll(deactivatedSpawnerPositions);
                CombinedPositions.addAll(trialspawnerPositions);

                if (!CombinedPositions.stream().toList().isEmpty()) {
                    for (int b = 0; b < CombinedPositions.stream().toList().size(); b++) {
                        if (SpawnerDistance > Math.sqrt(Math.pow(CombinedPositions.stream().toList().get(b).method_10263() - mc.field_1724.method_31477(), 2) + Math.pow(CombinedPositions.stream().toList().get(b).method_10260() - mc.field_1724.method_31479(), 2))) {
                            closestSpawnerX = Math.round((float) CombinedPositions.stream().toList().get(b).method_10263());
                            closestSpawnerY = Math.round((float) CombinedPositions.stream().toList().get(b).method_10264());
                            closestSpawnerZ = Math.round((float) CombinedPositions.stream().toList().get(b).method_10260());
                            SpawnerDistance = Math.sqrt(Math.pow(CombinedPositions.stream().toList().get(b).method_10263() - mc.field_1724.method_31477(), 2) + Math.pow(CombinedPositions.stream().toList().get(b).method_10260() - mc.field_1724.method_31479(), 2));
                        }
                    }
                    SpawnerDistance = 2000000000;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (removerenderdist.get()) removeChunksOutsideRenderDistance(chunkSet);
    }
    @EventHandler
    private void onRender(Render3DEvent event) {
        if (spawnerSideColor.get().a > 5 || spawnerLineColor.get().a > 5 || rangeSideColor.get().a > 5 || rangeLineColor.get().a > 5) {
            synchronized (spawnerPositions) {
                for (class_2338 pos : spawnerPositions) {
                    class_2338 playerPos = new class_2338(mc.field_1724.method_31477(), pos.method_10264(), mc.field_1724.method_31479());
                    if (playerPos.method_19771(pos, renderDistance.get() * 16)) {
                        int startX = pos.method_10263();
                        int startY = pos.method_10264();
                        int startZ = pos.method_10260();
                        int endX = pos.method_10263();
                        int endY = pos.method_10264();
                        int endZ = pos.method_10260();
                        if (!nearesttrcr.get()) {
                            if (rangerendering.get() && !lessRenderSpam.get())renderRange(new class_238(new class_243(startX+17, startY+17, startZ+17), new class_243(endX-16, endY-16, endZ-16)), rangeSideColor.get(), rangeLineColor.get(), shapeMode.get(), event);
                            else if (rangerendering.get() && lessRenderSpam.get() && !noRenderPositions.contains(pos))renderRange(new class_238(new class_243(startX+17, startY+17, startZ+17), new class_243(endX-16, endY-16, endZ-16)), rangeSideColor.get(), rangeLineColor.get(), shapeMode.get(), event);
                            if (deactivatedSpawnerPositions.contains(pos)) render(new class_238(new class_243(startX+1, startY+1, startZ+1), new class_243(endX, endY, endZ)), despawnerSideColor.get(), despawnerLineColor.get(), shapeMode.get(), event);
                            else render(new class_238(new class_243(startX+1, startY+1, startZ+1), new class_243(endX, endY, endZ)), spawnerSideColor.get(), spawnerLineColor.get(), shapeMode.get(), event);
                        } else if (nearesttrcr.get()) {
                            if (rangerendering.get() && !lessRenderSpam.get())renderRange(new class_238(new class_243(startX+17, startY+17, startZ+17), new class_243(endX-16, endY-16, endZ-16)), rangeSideColor.get(), rangeLineColor.get(), shapeMode.get(), event);
                            else if (rangerendering.get() && lessRenderSpam.get() && !noRenderPositions.contains(pos))renderRange(new class_238(new class_243(startX+17, startY+17, startZ+17), new class_243(endX-16, endY-16, endZ-16)), rangeSideColor.get(), rangeLineColor.get(), shapeMode.get(), event);
                            if (deactivatedSpawnerPositions.contains(pos)) render(new class_238(new class_243(startX+1, startY+1, startZ+1), new class_243(endX, endY, endZ)), despawnerSideColor.get(), despawnerLineColor.get(), shapeMode.get(), event);
                            else render(new class_238(new class_243(startX+1, startY+1, startZ+1), new class_243(endX, endY, endZ)), spawnerSideColor.get(), spawnerLineColor.get(), shapeMode.get(), event);
                            render2(new class_238(new class_243(closestSpawnerX, closestSpawnerY, closestSpawnerZ), new class_243 (closestSpawnerX, closestSpawnerY, closestSpawnerZ)), spawnerSideColor.get(), spawnerLineColor.get(), event);
                        }
                    }
                }
            }
            synchronized (trialspawnerPositions) {
                for (class_2338 pos : trialspawnerPositions) {
                    class_2338 playerPos = new class_2338(mc.field_1724.method_31477(), pos.method_10264(), mc.field_1724.method_31479());
                    if (playerPos.method_19771(pos, renderDistance.get() * 16)) {
                        int startX = pos.method_10263();
                        int startY = pos.method_10264();
                        int startZ = pos.method_10260();
                        int endX = pos.method_10263();
                        int endY = pos.method_10264();
                        int endZ = pos.method_10260();
                        if (!nearesttrcr.get()) {
                            if (trialSpawner.get() && rangerendering.get() && !lessRenderSpam.get())renderRange(new class_238(new class_243(startX+15, startY+15, startZ+15), new class_243(endX-14, endY-14, endZ-14)), trangeSideColor.get(), trangeLineColor.get(), shapeMode.get(), event);
                            else if (trialSpawner.get() && rangerendering.get() && lessRenderSpam.get() && !noRenderPositions.contains(pos))renderRange(new class_238(new class_243(startX+15, startY+15, startZ+15), new class_243(endX-14, endY-14, endZ-14)), trangeSideColor.get(), trangeLineColor.get(), shapeMode.get(), event);
                            if (deactivatedSpawnerPositions.contains(pos)) render(new class_238(new class_243(startX+1, startY+1, startZ+1), new class_243(endX, endY, endZ)), despawnerSideColor.get(), despawnerLineColor.get(), shapeMode.get(), event);
                            else render(new class_238(new class_243(startX+1, startY+1, startZ+1), new class_243(endX, endY, endZ)), trialSideColor.get(), trialLineColor.get(), shapeMode.get(), event);
                        } else if (nearesttrcr.get()) {
                            if (trialSpawner.get() && rangerendering.get() && !lessRenderSpam.get())renderRange(new class_238(new class_243(startX+15, startY+15, startZ+15), new class_243(endX-14, endY-14, endZ-14)), trangeSideColor.get(), trangeLineColor.get(), shapeMode.get(), event);
                            else if (trialSpawner.get() && rangerendering.get() && lessRenderSpam.get() && !noRenderPositions.contains(pos))renderRange(new class_238(new class_243(startX+15, startY+15, startZ+15), new class_243(endX-14, endY-14, endZ-14)), trangeSideColor.get(), trangeLineColor.get(), shapeMode.get(), event);
                            if (deactivatedSpawnerPositions.contains(pos)) render(new class_238(new class_243(startX+1, startY+1, startZ+1), new class_243(endX, endY, endZ)), despawnerSideColor.get(), despawnerLineColor.get(), shapeMode.get(), event);
                            else render(new class_238(new class_243(startX+1, startY+1, startZ+1), new class_243(endX, endY, endZ)), trialSideColor.get(), trialLineColor.get(), shapeMode.get(), event);
                            render2(new class_238(new class_243(closestSpawnerX, closestSpawnerY, closestSpawnerZ), new class_243 (closestSpawnerX, closestSpawnerY, closestSpawnerZ)), trialSideColor.get(), trialLineColor.get(), event);
                        }
                    }
                }
            }
        }
    }
    private void displayMessage(String key, class_2338 pos, String key2) {
        if (chatFeedback.get()) {
            if (Objects.equals(key, "dungeon")) {
                if (Objects.equals(key2, ":spider")) {
                    if (mc.field_1687.method_8320(pos.method_10074()).method_26204() == class_2246.field_10148 && enableWoodlandMansion.get()) {
                        activatedSpawnerFound = true;
                        spawnerPositions.add(pos);
                        if (displaycoords.get()) ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cWOODLAND MANSION§r Spawner! Block Position: " + pos));
                        else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cWOODLAND MANSION§r Spawner!"));
                    } else {
                        if (enableDungeon.get()) {
                            activatedSpawnerFound = true;
                            spawnerPositions.add(pos);
                            if (displaycoords.get()) ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cDUNGEON§r Spawner! Block Position: " + pos));
                            else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cDUNGEON§r Spawner!"));
                        }
                    }
                } else {
                    if (enableDungeon.get()) {
                        activatedSpawnerFound = true;
                        spawnerPositions.add(pos);
                        if (displaycoords.get()) ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cDUNGEON§r Spawner! Block Position: " + pos));
                        else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cDUNGEON§r Spawner!"));
                    }
                }
            } else if (Objects.equals(key, "cave_spider") && enableMineshaft.get()) {
                activatedSpawnerFound = true;
                spawnerPositions.add(pos);
                if (displaycoords.get()) ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cMINESHAFT§r Spawner! Block Position: " + pos));
                else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cMINESHAFT§r Spawner!"));
            } else if (Objects.equals(key, "silverfish") && enableStronghold.get()) {
                activatedSpawnerFound = true;
                spawnerPositions.add(pos);
                if (displaycoords.get()) ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cSTRONGHOLD§r Spawner! Block Position: " + pos));
                else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cSTRONGHOLD§r Spawner!"));
            } else if (Objects.equals(key, "blaze") && enableFortress.get()) {
                activatedSpawnerFound = true;
                spawnerPositions.add(pos);
                if (displaycoords.get()) ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cFORTRESS§r Spawner! Block Position: " + pos));
                else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cFORTRESS§r Spawner!"));
            } else if (Objects.equals(key, "magma") && enableBastion.get()) {
                activatedSpawnerFound = true;
                spawnerPositions.add(pos);
                if (displaycoords.get()) ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cBASTION§r Spawner! Block Position: " + pos));
                else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated §cBASTION§r Spawner!"));
            } else {
                activatedSpawnerFound = true;
                spawnerPositions.add(pos);
                if (displaycoords.get()) ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated Spawner! Block Position: " + pos));
                else ChatUtils.sendMsg(class_2561.method_30163("§cASD§r | Detected Activated Spawner!"));
            }
            if (locLogging.get())logSpawner(pos);
        }
    }
    private void render(class_238 box, Color sides, Color lines, ShapeMode shapeMode, Render3DEvent event) {
        if (trcr.get())
            if (!nearesttrcr.get())
                event.renderer.line(RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350, box.field_1323+0.5, box.field_1322+((box.field_1325-box.field_1322)/2), box.field_1321+0.5, lines);
        event.renderer.box(box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, sides, new Color(0,0,0,0), shapeMode, 0);
    }
    private void render2(class_238 box, Color sides, Color lines, Render3DEvent event) {
        if (trcr.get())
            event.renderer.line(RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350, box.field_1323+0.5, box.field_1322+((box.field_1325-box.field_1322)/2), box.field_1321+0.5, lines);
        event.renderer.box(box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, sides, new Color(0,0,0,0), ShapeMode.Sides, 0);
    }
    private void renderRange(class_238 box, Color sides, Color lines, ShapeMode shapeMode, Render3DEvent event) {
        event.renderer.box(box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, sides, lines, shapeMode, 0);
    }
    private void removeChunksOutsideRenderDistance(Set<class_2818> chunks) {
        removeBlockPosOutsideRenderDistance(scannedPositions, chunks);
        removeBlockPosOutsideRenderDistance(spawnerPositions, chunks);
        removeBlockPosOutsideRenderDistance(deactivatedSpawnerPositions, chunks);
        removeBlockPosOutsideRenderDistance(trialspawnerPositions, chunks);
        removeBlockPosOutsideRenderDistance(noRenderPositions, chunks);
    }
    private void removeBlockPosOutsideRenderDistance(
            Set<class_2338> blockSet,
            Set<class_2818> worldChunks
    ) {
        if (mc.field_1687 == null) return;

        blockSet.removeIf(blockpos ->
                !worldChunks.contains(mc.field_1687.method_8500(blockpos))
        );
    }
    private void logSpawner(class_2338 pos) {
        if (!loggedSpawnerPositions.contains(pos)) {
            loggedSpawnerPositions.add(pos);
            loggedSpawners.add(new LoggedSpawner(pos.method_10263(), pos.method_10264(), pos.method_10260()));
            saveJson();
            saveCsv();
        }
    }

    private void saveCsv() {
        try {
            File file = getCsvFile();
            file.getParentFile().mkdirs();
            Writer writer = new FileWriter(file);
            writer.write("X,Y,Z\n");
            for (LoggedSpawner ls : loggedSpawners) {
                ls.write(writer);
            }
            writer.close();
        } catch (IOException ignored) {}
    }

    private void saveJson() {
        try {
            File file = getJsonFile();
            file.getParentFile().mkdirs();
            Writer writer = new FileWriter(file);
            GSON.toJson(loggedSpawners, writer);
            writer.close();
        } catch (IOException ignored) {}
    }

    private File getJsonFile() {
        return new File(new File(new File("TrouserStreak", "ActivatedSpawners"), Utils.getFileWorldName()), "spawners.json");
    }

    private File getCsvFile() {
        return new File(new File(new File("TrouserStreak", "ActivatedSpawners"), Utils.getFileWorldName()), "spawners.csv");
    }

    private void loadLogs() {
        File file = getJsonFile();
        boolean loaded = false;
        if (file.exists()) {
            try {
                FileReader reader = new FileReader(file);
                List<LoggedSpawner> data = GSON.fromJson(reader, new TypeToken<List<LoggedSpawner>>() {}.getType());
                reader.close();
                if (data != null) {
                    loggedSpawners.addAll(data);
                    for (LoggedSpawner ls : data) {
                        loggedSpawnerPositions.add(new class_2338(ls.x, ls.y, ls.z));
                    }
                    loaded = true;
                }
            } catch (Exception ignored) {}
        }
        if (!loaded) {
            file = getCsvFile();
            if (file.exists()) {
                try {
                    BufferedReader reader = new BufferedReader(new FileReader(file));
                    reader.readLine();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String[] values = line.split(",");
                        LoggedSpawner ls = new LoggedSpawner(
                                Integer.parseInt(values[0]),
                                Integer.parseInt(values[1]),
                                Integer.parseInt(values[2])
                        );
                        loggedSpawners.add(ls);
                        loggedSpawnerPositions.add(new class_2338(ls.x, ls.y, ls.z));
                    }
                    reader.close();
                } catch (Exception ignored) {}
            }
        }
    }

    @Override
    public WWidget getWidget(GuiTheme theme) {
        // Sort by Y coordinate for display purposes.
        loggedSpawners.sort(Comparator.comparingInt(s -> s.y));
        WVerticalList list = theme.verticalList();
        WButton clear = list.add(theme.button("Clear Logged Positions")).widget();
        WTable table = new WTable();
        if (!loggedSpawners.isEmpty()) list.add(table);
        clear.action = () -> {
            loggedSpawners.clear();
            loggedSpawnerPositions.clear();
            table.clear();
            saveJson();
            saveCsv();
        };
        fillTable(theme, table);
        return list;
    }

    private void fillTable(GuiTheme theme, WTable table) {
        List<LoggedSpawner> spawnerCoords = new ArrayList<>();
        for (LoggedSpawner ls : loggedSpawners) {
            if (!spawnerCoords.contains(ls)) {
                spawnerCoords.add(ls);
                table.add(theme.label("Pos: " + ls.x + ", " + ls.y + ", " + ls.z));
                WButton gotoBtn = table.add(theme.button("Goto")).widget();
                gotoBtn.action = () -> PathManagers.get().moveTo(new class_2338(ls.x, ls.y, ls.z), true);
                WMinus delete = table.add(theme.minus()).widget();
                delete.action = () -> {
                    loggedSpawners.remove(ls);
                    loggedSpawnerPositions.remove(new class_2338(ls.x, ls.y, ls.z));
                    table.clear();
                    fillTable(theme, table);
                    saveJson();
                    saveCsv();
                };
                table.row();
            }
        }
    }

    private static class LoggedSpawner {
        public int x, y, z;

        public LoggedSpawner(int x, int y, int z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public void write(Writer writer) throws IOException {
            writer.write(x + "," + y + "," + z + "\n");
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof LoggedSpawner that)) return false;
            return x == that.x && y == that.y && z == that.z;
        }

        @Override
        public int hashCode() {
            return Objects.hash(x, y, z);
        }
    }
}