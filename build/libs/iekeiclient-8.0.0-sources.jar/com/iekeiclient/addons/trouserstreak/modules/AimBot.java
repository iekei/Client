//skidded from SpearKill by etianl
package com.iekeiclient.addons.trouserstreak.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3966;
import com.iekeiclient.addons.trouserstreak.Trouser;

import java.util.Comparator;
import java.util.List;

public class AimBot extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<Boolean> targetPlayers = sgGeneral.add(new BoolSetting.Builder()
            .name("TargetOnlyPlayers")
            .description("Only lock onto Player entities. False only targets LivingEntity.")
            .defaultValue(false)
            .build()
    );
    private final Setting<Boolean> seek = sgGeneral.add(new BoolSetting.Builder()
            .name("Seek Target")
            .description("Waits until you have crosshair on a target to lock on.")
            .defaultValue(true)
            .build()
    );
    public final Setting<Double> maxrange = sgGeneral.add(new DoubleSetting.Builder()
            .name("Targeting range")
            .description("How far in blocks that targeting is allowed.")
            .defaultValue(256)
            .min(0)
            .sliderRange(0,512)
            .build()
    );
    private final Setting<Boolean> onlyItem = sgGeneral.add(new BoolSetting.Builder()
            .name("Only if holding Item/s.")
            .description("Only aimbot if one of the selected items is in your Main Hand.")
            .defaultValue(false)
            .build()
    );
    private final Setting<List<class_1792>> items = sgGeneral.add(new ItemListSetting.Builder()
            .name("items")
            .description("Only aimbot if one of the selected items is in your Main Hand.")
            .visible(onlyItem::get)
            .build()
    );
    public AimBot() {
        super(Trouser.Main, "Aim Bot", "Locks onto the targeted entity while the module is on.");
    }

    private class_1297 crosshairTarget;
    @Override
    public void onActivate() {
        crosshairTarget = target();
    }
    @Override
    public void onDeactivate() {
        crosshairTarget = null;
    }
    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (onlyItem.get() && !items.get().contains(mc.field_1724.method_6047().method_7909())) return;
        if (seek.get() && crosshairTarget == null) crosshairTarget = target();
        if (crosshairTarget != null && !crosshairTarget.method_5805()) crosshairTarget = null;
        if (crosshairTarget == null || !(crosshairTarget instanceof class_1309)) return;
        if (targetPlayers.get() && !(crosshairTarget instanceof class_1657)) return;

        class_243 playerPos = mc.field_1724.method_33571();
        class_243 targetPos = crosshairTarget.method_5829().method_1005();
        class_243 toTarget = targetPos.method_1020(playerPos).method_1029();

        float yaw = (float) (Math.toDegrees(Math.atan2(toTarget.field_1350, toTarget.field_1352)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.asin(toTarget.field_1351));

        mc.field_1724.method_36456(yaw);
        mc.field_1724.method_5847(yaw);
        mc.field_1724.method_36457(pitch);
    }

    private class_1297 target() {
        if (mc.field_1724 == null || mc.field_1687 == null) return null;
        if (mc.field_1765 instanceof class_3966 hit) {
            if (!targetPlayers.get() || hit.method_17782() instanceof class_1657) return hit.method_17782();
        }

        double maxRange = maxrange.get();
        class_243 eyePos = mc.field_1724.method_33571();
        class_243 lookVec = mc.field_1724.method_5828(1.0f);

        class_239 blockHit = mc.field_1687.method_17742(new class_3959(eyePos,
                eyePos.method_1019(lookVec.method_1021(maxRange)), class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348, mc.field_1724));
        double rayLength = blockHit.method_17783() == class_239.class_240.field_1333 ? maxRange :
                eyePos.method_1022(blockHit.method_17784());

        List<class_1297> candidates = mc.field_1687.method_8333(mc.field_1724,
                mc.field_1724.method_5829().method_18804(lookVec.method_1021(rayLength)),
                e -> e instanceof class_1309 && e.method_5805() && e != mc.field_1724);

        candidates.sort(Comparator.comparingDouble(e ->
                eyePos.method_1025(e.method_5829().method_1005())));

        double coneAngle = 0.999;
        for (class_1297 e : candidates) {
            double dist = eyePos.method_1022(e.method_5829().method_1005());
            if (dist > maxRange) break;

            if (targetPlayers.get() && !(e instanceof class_1657)) continue;

            if (!canSeeTarget(e)) continue;

            class_243 toEntity = e.method_5829().method_1005().method_1020(eyePos).method_1029();

            if (lookVec.method_1026(toEntity) > coneAngle) {
                return e;
            }
        }
        return null;
    }
    private boolean canSeeTarget(class_1297 target) {
        if (mc.field_1724 == null || mc.field_1687 == null) return false;

        class_243 eyePos = mc.field_1724.method_33571();
        class_243 targetCenter = target.method_5829().method_1005();

        class_239 result = mc.field_1687.method_17742(new class_3959(
                eyePos,
                targetCenter,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                mc.field_1724
        ));

        if (result.method_17783() == class_239.class_240.field_1333) return true;
        return eyePos.method_1022(result.method_17784()) >= eyePos.method_1022(targetCenter) - 0.5;
    }
}