package com.iekeiclient.addons.trouserstreak.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import com.iekeiclient.engine.commands.Command;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.addons.trouserstreak.utils.MovementPatch;

public class MovementPatchCommand extends Command {
    public MovementPatchCommand() {
        super("movementpatch26.3", "Toggles tick-end injection before movement packets.");
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            MovementPatch.toggle();

            ChatUtils.sendMsg(class_2561.method_43470("26.3 movement patch is now " + (MovementPatch.isEnabled() ? "enabled" : "disabled") + "."));

            return SINGLE_SUCCESS;
        });
        builder.then(literal("on").executes(context -> {
            MovementPatch.setEnabled(true);
            ChatUtils.sendMsg(class_2561.method_43470("26.3 movement patch enabled."));
            return SINGLE_SUCCESS;
        }));
        builder.then(literal("off").executes(context -> {
            MovementPatch.setEnabled(false);
            ChatUtils.sendMsg(class_2561.method_43470("26.3 movement patch disabled."));
            return SINGLE_SUCCESS;
        }));
        builder.then(literal("status").executes(context -> {
            ChatUtils.sendMsg(class_2561.method_43470("26.3 movement patch is currently " + (MovementPatch.isEnabled() ? "enabled" : "disabled") + "."));
            return SINGLE_SUCCESS;
        }));
    }
}