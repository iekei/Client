package com.iekeiclient.addons.trouserstreak.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.iekeiclient.engine.commands.Command;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.addons.trouserstreak.utils.PermissionUtils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Collection;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_1937;
import net.minecraft.class_2172;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_269;
import net.minecraft.class_2818;
import net.minecraft.class_4208;
import net.minecraft.class_5218;
import net.minecraft.class_9015;

public class WorldInfoCommand extends Command {
    public WorldInfoCommand() {
        super("world", "Tells you the coordinates of each world border, and the spawn location.");
    }

    private static final Set<class_2248> NEW_OVERWORLD_BLOCKS = new HashSet<>();
    static {
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28888);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_27159);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28678);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28682);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28683);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28684);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28675);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28676);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28677);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_27120);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_29221);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_29027);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_29219);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_29030);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_29220);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_29026);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_29028);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_29029);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28411);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_33509);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_33508);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28049);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28681);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28048);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_29032);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_27165);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_27114);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28686);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28685);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28673);
        NEW_OVERWORLD_BLOCKS.add(class_2246.field_28674);
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            class_269 scoreboard = mc.field_1687.method_8428();
            Collection<class_9015> scoreHolders = scoreboard.method_1178();
            StringBuilder namesBuilder = new StringBuilder();
            for (class_9015 holder : scoreHolders) {
                namesBuilder.append(holder.method_5820()).append(", ");
            }
            String getKnownPlayers = namesBuilder.toString();
            int chunkX = (int) mc.field_1724.method_23317() >> 4;
            int chunkZ = (int) mc.field_1724.method_23321() >> 4;
            class_2818 chunk = mc.field_1687.method_8497(chunkX, chunkZ);

            boolean foundAnyOre = false;
            boolean isNewGeneration = false;
            class_2338.class_2339 mutablePos = new class_2338.class_2339();
            outer:
            for (int x = 0; x < 16; x++) {
                for (int y = mc.field_1687.method_31607(); y < mc.field_1687.method_31600(); y++) {
                    for (int z = 0; z < 16; z++) {
                        mutablePos.method_10103(x, y, z);
                        class_2248 block = chunk.method_8320(mutablePos).method_26204();
                        if (!foundAnyOre && isOreBlock(block) && mc.field_1687.method_27983() == class_1937.field_25179) {
                            foundAnyOre = true;
                        }
                        if (!isNewGeneration && y < 260 && y > 5 && NEW_OVERWORLD_BLOCKS.contains(block) && mc.field_1687.method_27983() == class_1937.field_25179) {
                            isNewGeneration = true;
                        }
                        if (foundAnyOre && isNewGeneration) break outer;
                    }
                }
            }

            if (!isNewGeneration) {
                ChatUtils.sendMsg(class_2561.method_30163("This chunk is pre 1.17 generation!"));
            } else {
                ChatUtils.sendMsg(class_2561.method_30163("This chunk is new generation! (post-1.17)"));
            }
            ChatUtils.sendMsg(class_2561.method_30163("East World Border X: "+(int) mc.field_1687.method_8621().method_11963()+", West World Border X: "+(int) mc.field_1687.method_8621().method_11976()+", South World Border Z: "+(int) mc.field_1687.method_8621().method_11977()+", North World Border Z: "+(int) mc.field_1687.method_8621().method_11958()));
            ChatUtils.sendMsg(class_2561.method_30163("WorldSpawn Location: x"+mc.field_1687.method_28104().method_74893().method_74897().method_10263()+" y"+mc.field_1687.method_28104().method_74893().method_74897().method_10264()+" z"+mc.field_1687.method_28104().method_74893().method_74897().method_10260()));
            Optional<class_4208> deathPos = mc.field_1724.method_43122();
            if (deathPos.isPresent()) {
                class_4208 pos = deathPos.get();
                ChatUtils.sendMsg(class_2561.method_30163(
                        "Last Death Location: x" + pos.comp_2208().method_10263() +
                                " y" + pos.comp_2208().method_10264() +
                                " z" + pos.comp_2208().method_10260() +
                                " | Dimension: " + pos.comp_2207().method_29177()
                ));
            } else {
                ChatUtils.sendMsg(class_2561.method_30163("No recorded death location"));
            }
            ChatUtils.sendMsg(class_2561.method_30163("Difficulty: "+mc.field_1687.method_8407().toString()));
            ChatUtils.sendMsg(class_2561.method_30163("Permission Level: "+PermissionUtils.getPermissionLevel(mc.field_1724)));
            ChatUtils.sendMsg(class_2561.method_30163("Simulation Distance (chunks): "+mc.field_1687.method_39024()));
            ChatUtils.sendMsg(class_2561.method_30163("Day Count: "+Math.floor(mc.field_1687.method_75260()/24000)));
            ChatUtils.sendMsg(class_2561.method_30163("KnownPlayers (Names with a period are bedrock players): "+getKnownPlayers));
            return SINGLE_SUCCESS;
        });
        builder.then(literal("save").executes(ctx -> {
            if (!mc.field_1724.method_6047().method_7960()){
                class_269 scoreboard = mc.field_1687.method_8428();
                Collection<class_9015> scoreHolders = scoreboard.method_1178();
                StringBuilder namesBuilder = new StringBuilder();
                for (class_9015 holder : scoreHolders) {
                    namesBuilder.append(holder.method_5820()).append(", ");
                }

                String getKnownPlayers = namesBuilder.toString();
                int chunkX = (int) mc.field_1724.method_23317() >> 4;
                int chunkZ = (int) mc.field_1724.method_23321() >> 4;
                class_2818 chunk = mc.field_1687.method_8497(chunkX, chunkZ);

                boolean foundAnyOre = false;
                boolean isNewGeneration = false;
                for (int x = 0; x < 16; x++) {
                    for (int y = mc.field_1687.method_31607(); y < mc.field_1687.method_31600(); y++) {
                        for (int z = 0; z < 16; z++) {
                            if (!foundAnyOre && isOreBlock(chunk.method_8320(new class_2338(x, y, z)).method_26204()) && mc.field_1687.method_27983().method_29177().toString().toLowerCase().contains("overworld")) {
                                foundAnyOre = true;
                            }
                            if (!isNewGeneration && y < 256 && y >= 0 && (chunk.method_8320(new class_2338(x, y, z)).method_26204() == class_2246.field_27120 || chunk.method_8320(new class_2338(x, y, z)).method_26204() == class_2246.field_29221) && mc.field_1687.method_27983().method_29177().toString().toLowerCase().contains("overworld")) {
                                isNewGeneration = true;
                            }
                        }
                    }
                }

                if (!isNewGeneration) {
                    ChatUtils.sendMsg(class_2561.method_30163("This chunk is pre 1.17 generation!"));
                } else {
                    ChatUtils.sendMsg(class_2561.method_30163("This chunk is new generation! (post-1.17)"));
                }
                ChatUtils.sendMsg(class_2561.method_30163("East World Border X: "+(int) mc.field_1687.method_8621().method_11963()+", West World Border X: "+(int) mc.field_1687.method_8621().method_11976()+", South World Border Z: "+(int) mc.field_1687.method_8621().method_11977()+", North World Border Z: "+(int) mc.field_1687.method_8621().method_11958()));
                ChatUtils.sendMsg(class_2561.method_30163("WorldSpawn Location: x"+mc.field_1687.method_28104().method_74893().method_74897().method_10263()+" y"+mc.field_1687.method_28104().method_74893().method_74897().method_10264()+" z"+mc.field_1687.method_28104().method_74893().method_74897().method_10260()));
                ChatUtils.sendMsg(class_2561.method_30163("Difficulty: "+mc.field_1687.method_8407().toString()));
                ChatUtils.sendMsg(class_2561.method_30163("Permission Level: "+PermissionUtils.getPermissionLevel(mc.field_1724)));
                ChatUtils.sendMsg(class_2561.method_30163("Simulation Distance (chunks): "+mc.field_1687.method_39024()));
                ChatUtils.sendMsg(class_2561.method_30163("Day Count: "+Math.floor(mc.field_1687.method_75260()/24000)));
                ChatUtils.sendMsg(class_2561.method_30163("KnownPlayers (Names with a period are bedrock players): "+getKnownPlayers));

                String serverip;
                if (mc.method_1542()==true){
                    Path worldPath = mc.method_1576().method_27050(class_5218.field_24188);
                    Path savesDir = worldPath.getParent();
                    if (savesDir != null) {
                        Path worldDir = savesDir.getFileName();
                        serverip = (worldDir != null ? worldDir.toString() : "singleplayer")
                                .replaceAll("[^a-zA-Z0-9._-]", "_");
                    } else {
                        serverip = "singleplayer";
                    }
                } else {
                    serverip = mc.method_1558().field_3761.replaceAll("[^a-zA-Z0-9._\\-]", "_");
                }

                try {
                    new File("TrouserStreak/SavedWorldInfo/"+serverip+"/").mkdirs();
                    try (FileWriter writer = new FileWriter("TrouserStreak/SavedWorldInfo/"+serverip+"/WorldInfoData.txt", true)) {
                        if (!isNewGeneration) {
                            writer.write("This chunk is pre 1.17 generation!");
                            writer.write("\r\n");
                        } else {
                            writer.write("This chunk is new generation! (post-1.17)");
                            writer.write("\r\n");
                        }
                        writer.write("East World Border X: "+(int) mc.field_1687.method_8621().method_11963()+", West World Border X: "+(int) mc.field_1687.method_8621().method_11976()+", South World Border Z: "+(int) mc.field_1687.method_8621().method_11977()+", North World Border Z: "+(int) mc.field_1687.method_8621().method_11958());
                        writer.write("\r\n");
                        writer.write("WorldSpawn Location: x"+mc.field_1687.method_28104().method_74893().method_74897().method_10263()+" y"+mc.field_1687.method_28104().method_74893().method_74897().method_10264()+" z"+mc.field_1687.method_28104().method_74893().method_74897().method_10260());
                        writer.write("\r\n");
                        writer.write("Difficulty: "+mc.field_1687.method_8407().toString());
                        writer.write("\r\n");
                        writer.write("Permission Level: "+PermissionUtils.getPermissionLevel(mc.field_1724));
                        writer.write("\r\n");
                        writer.write("Simulation Distance (chunks): "+mc.field_1687.method_39024());
                        writer.write("\r\n");
                        writer.write("Day Count: "+Math.floor(mc.field_1687.method_75260()/24000));
                        writer.write("\r\n");
                        writer.write("KnownPlayers (Names with a period are bedrock players): "+getKnownPlayers);
                        writer.write("\r\n");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else error("No item in main hand.");
            return SINGLE_SUCCESS;
        }));
    }
    private boolean isOreBlock(class_2248 block) {
        return block == class_2246.field_10418
                || block == class_2246.field_27120
                || block == class_2246.field_29221
                || block == class_2246.field_10212
                || block == class_2246.field_29027
                || block == class_2246.field_10571
                || block == class_2246.field_29026
                || block == class_2246.field_10090
                || block == class_2246.field_29028
                || block == class_2246.field_10442
                || block == class_2246.field_29029
                || block == class_2246.field_10080
                || block == class_2246.field_29030
                || block == class_2246.field_10013
                || block == class_2246.field_29220;
    }
}