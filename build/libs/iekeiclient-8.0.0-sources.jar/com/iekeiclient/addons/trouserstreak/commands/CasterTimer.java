package com.iekeiclient.addons.trouserstreak.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import com.iekeiclient.engine.commands.Command;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.addons.trouserstreak.modules.AutoLavaCaster;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class CasterTimer extends Command {
    public CasterTimer() {
        super("castertimer", "Calculates how long this cycle has been going for in AutoLavaCaster.");
    }

    @Override
        public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            AutoLavaCaster a=new AutoLavaCaster();
           int time = a.lavamountainticks/20;
           if (!(time==0)){
            ChatUtils.sendMsg(class_2561.method_30163("This Cycle has been going for "+time+" Seconds."));}
           else if (time==0){
               error("AutoLavaCaster not started. Make more Mountains.");
           }
            return SINGLE_SUCCESS;
        });
        }
}
