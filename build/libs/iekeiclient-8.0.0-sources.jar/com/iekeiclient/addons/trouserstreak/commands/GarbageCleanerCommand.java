package com.iekeiclient.addons.trouserstreak.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import com.iekeiclient.engine.commands.Command;
import com.iekeiclient.engine.utils.player.ChatUtils;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class GarbageCleanerCommand extends Command {
    public GarbageCleanerCommand() {
        super("cleanram", "Clears garbage from RAM."); // Courtesy of youtube.com/@ogmur
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(context -> {
            {
                ChatUtils.sendMsg(class_2561.method_30163("Cleaning RAM."));}
            System.gc();
            {
                ChatUtils.sendMsg(class_2561.method_30163("RAM Cleared."));}
            return SINGLE_SUCCESS;
        });
    }
}