package com.iekeiclient.addons.trouserstreak.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.iekeiclient.engine.commands.Command;
import com.iekeiclient.engine.utils.player.ChatUtils;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import net.minecraft.class_2172;
import net.minecraft.class_2561;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;
import static com.iekeiclient.engine.IekeiClient.mc;

public class ViewNbtCommand extends Command {
    public ViewNbtCommand() {
        super("viewnbt", "Tells you the nbt data of the item in your main hand.");
    }
    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(ctx -> {
            if (!mc.field_1724.method_6047().method_7960()){
                if (mc.field_1724.method_6047().method_57353() == null){
                    error("No NBT data for item.");
                    return SINGLE_SUCCESS;
                }
                ChatUtils.sendMsg(class_2561.method_30163(mc.field_1724.method_6047().method_57353().toString()));
            }
            else error("No item in main hand.");
            return SINGLE_SUCCESS;
        });
        builder.then(literal("save").executes(ctx -> {
            if (!mc.field_1724.method_6047().method_7960()){
                if (mc.field_1724.method_6047().method_57353() == null){
                    error("No NBT data for item.");
                    return SINGLE_SUCCESS;
                }
                ChatUtils.sendMsg(class_2561.method_30163(mc.field_1724.method_6047().method_57353().toString()));
                try {
                    new File("TrouserStreak/SavedNBT/").mkdirs();
                    try (FileWriter writer = new FileWriter("TrouserStreak/SavedNBT/ViewedNBTData.txt", true)) {
                        writer.write(mc.field_1724.method_6047().method_57353().toString());
                        writer.write("\r\n");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else error("No item in main hand.");
            return SINGLE_SUCCESS;
        }));
    }
}