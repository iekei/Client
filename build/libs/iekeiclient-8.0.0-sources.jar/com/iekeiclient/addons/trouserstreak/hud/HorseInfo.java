package com.iekeiclient.addons.trouserstreak.hud;

import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.hud.HudElement;
import com.iekeiclient.engine.systems.hud.HudElementInfo;
import com.iekeiclient.engine.systems.hud.HudRenderer;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import net.minecraft.class_1496;
import net.minecraft.class_310;
import net.minecraft.class_5134;
import com.iekeiclient.addons.trouserstreak.Trouser;

public class HorseInfo extends HudElement {
    public static final HudElementInfo<HorseInfo> INFO = new HudElementInfo<>(
            Trouser.HUD_GROUP, "HorseInfo", "Displays horse stats while riding.", HorseInfo::new
    );

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<SettingColor> textColor = sgGeneral.add(new ColorSetting.Builder()
            .name("text-color")
            .description("Color of the stat text.")
            .defaultValue(new SettingColor(255, 255, 255))
            .build()
    );

    private final Setting<SettingColor> placeholderColor = sgGeneral.add(new ColorSetting.Builder()
            .name("placeholder-color")
            .description("Color of the 'not on a horse' text.")
            .defaultValue(new SettingColor(150, 150, 150))
            .build()
    );

    private final Setting<Boolean> showHealth = sgGeneral.add(new BoolSetting.Builder()
            .name("show-health")
            .description("Show horse health.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> showSpeed = sgGeneral.add(new BoolSetting.Builder()
            .name("show-speed")
            .description("Show horse speed in blocks per second.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> showJump = sgGeneral.add(new BoolSetting.Builder()
            .name("show-jump")
            .description("Show horse jump height in blocks.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> showPlaceholder = sgGeneral.add(new BoolSetting.Builder()
            .name("show-placeholder")
            .description("Show 'Not on a horse' when not riding.")
            .defaultValue(true)
            .build()
    );

    public HorseInfo() {
        super(INFO);
    }

    @Override
    public void render(HudRenderer renderer) {

        class_310 mc = class_310.method_1551();

        if (mc.field_1724 == null || !(mc.field_1724.method_5854() instanceof class_1496 horse)) {
            if (showPlaceholder.get()) {
                renderer.text("Not on a horse", x, y, placeholderColor.get(), true);
                setSize(renderer.textWidth("Not on a horse", true), renderer.textHeight(true));
            }
            return;
        }

        double speed = horse.method_45325(class_5134.field_23719) * 43.17;
        double jump = horse.method_45325(class_5134.field_23728);
        double jumpBlocks = -0.1817584952 * Math.pow(jump, 3) + 3.689713992 * Math.pow(jump, 2) + 2.128599134 * jump - 0.343930367;
        double health = horse.method_6032();
        double maxHealth = horse.method_45325(class_5134.field_23716);

        java.util.List<String> lines = new java.util.ArrayList<>();
        if (showHealth.get()) lines.add(String.format("Health: %.1f / %.1f", health, maxHealth));
        if (showSpeed.get()) lines.add(String.format("Speed:  %.2f bps", speed));
        if (showJump.get()) lines.add(String.format("Jump:   %.2f blocks", jumpBlocks));

        if (lines.isEmpty()) return;

        double lineH = renderer.textHeight(true);
        double maxW = 0;
        for (String line : lines) maxW = Math.max(maxW, renderer.textWidth(line, true));
        setSize(maxW, lineH * lines.size());

        for (int i = 0; i < lines.size(); i++) {
            renderer.text(lines.get(i), x, y + i * lineH, textColor.get(), true);
        }
    }
}