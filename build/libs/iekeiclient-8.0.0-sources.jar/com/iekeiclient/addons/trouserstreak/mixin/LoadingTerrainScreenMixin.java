package com.iekeiclient.addons.trouserstreak.mixin;

import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3928;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import com.iekeiclient.addons.trouserstreak.modules.LoadingTerrainDisconnect;

@Mixin(class_3928.class)
public class LoadingTerrainScreenMixin extends class_437 {
    public LoadingTerrainScreenMixin(class_2561 title) {
        super(title);
    }

    @Override
    protected void method_25426()
    {
        super.method_25426();
        LoadingTerrainDisconnect module = Modules.get().get(LoadingTerrainDisconnect.class);
        if (module != null && module.isActive()) {
            method_37063(new class_4185.class_7840(class_2561.method_43470("Disconnect"), button -> disconnect())
                    .method_46434(this.field_22789 / 2 - module.x.get(), this.field_22790 / 4 + module.y.get() + 12, 200, 20).method_46431()
            );
        }
    }

    private void disconnect() {
        class_310 client = class_310.method_1551();
        if (client.method_1562() != null) {
            client.method_73360(class_2561.method_30163("Disconnected."));
        }
    }
}