package com.iekeiclient.addons.trouserstreak.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.iekeiclient.addons.trouserstreak.Trouser;
import com.iekeiclient.addons.trouserstreak.utils.BoomGuard;

import java.util.function.Consumer;
import net.minecraft.class_2588;
import net.minecraft.class_5348;

/**
 * The first line of defense during the rendering phase: perform an expansion budget check at the entry point, {@code TranslatableTextContent#forEachPart}.
 * Upon a match, replace the entire segment with a placeholder and remove the original method.
 */
@Mixin(class_2588.class)
public class TranslatableContentsMixin {

    @Inject(method = "forEachPart", at = @At("HEAD"), cancellable = true)
    private void whistle$boomGuard(String template, Consumer<class_5348> out, CallbackInfo ci) {
        if (!BoomGuard.isEnabled()) {
            return;
        }
        if (BoomGuard.allow(BoomGuard.countSpecifiers(template))) {
            return;
        }
        int n = BoomGuard.noteBlock();
        if (n <= 3) {
            Trouser.LOG.warn(
                    "[BoomGuard] Intercepted an expansion (occurrence #{}), template length={}, conversion specifier={}",
                    n, template.length(), BoomGuard.countSpecifiers(template));
        }
        out.accept(class_5348.method_29430("[BoomGuard]"));
        ci.cancel();
    }
}