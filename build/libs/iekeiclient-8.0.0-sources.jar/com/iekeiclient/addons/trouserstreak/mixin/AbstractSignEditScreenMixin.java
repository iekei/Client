package com.iekeiclient.addons.trouserstreak.mixin;

import com.iekeiclient.engine.systems.modules.Modules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import com.iekeiclient.addons.trouserstreak.modules.NoModDetection;

import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.class_2561;
import net.minecraft.class_2572;
import net.minecraft.class_2588;
import net.minecraft.class_7743;

@Mixin(class_7743.class)
public abstract class AbstractSignEditScreenMixin {
    @Redirect(
            method = "<init>(Lnet/minecraft/block/entity/SignBlockEntity;ZZLnet/minecraft/text/Text;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/stream/Stream;map(Ljava/util/function/Function;)Ljava/util/stream/Stream;"
            )
    )
    private Stream<String> trouserstreak$filterSignText(
            Stream<class_2561> stream,
            Function<? super class_2561, ? extends String> originalMapper
    ) {
        NoModDetection module = Modules.get().get(NoModDetection.class);

        if (module == null || !module.isActive() || !module.filterSign.get()) {
            return stream.map(originalMapper);
        }

        return stream.map(text -> {
            if (text.method_10851() instanceof class_2588 translatable) {
                String fallback = translatable.method_48323();

                return fallback != null
                        ? fallback
                        : translatable.method_11022();
            }

            if (text.method_10851() instanceof class_2572) {
                return "";
            }

            return text.getString();
        });
    }
}