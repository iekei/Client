package com.iekeiclient.addons.trouserstreak.mixin;

import com.iekeiclient.engine.systems.modules.Modules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.iekeiclient.addons.trouserstreak.modules.NoTelemetry;

import java.util.function.Consumer;
import net.minecraft.class_7965;
import net.minecraft.class_7966;
import net.minecraft.class_7973;

@Mixin(net.minecraft.class_6628.class)
public abstract class TelemetryManagerMixin {

    private static final class_7965 NOOP_SENDER = new class_7965() {
        @Override
        public void send(class_7966 eventType, Consumer<class_7973.class_7974> propertyAdder) {
            System.out.println("[NoTelemetry] Blocked telemetry send: " + eventType);
        }

        @Override
        public class_7965 decorate(Consumer<class_7973.class_7974> decorationAdder) {
            return this;
        }
    };

    @Inject(
            method = "computeSender()Lnet/minecraft/client/session/telemetry/TelemetrySender;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onComputeSenderHead(CallbackInfoReturnable<class_7965> cir) {
        Modules modules = Modules.get();
        if (modules != null && modules.isActive(NoTelemetry.class)) {
            cir.setReturnValue(NOOP_SENDER);
        }
    }

    @Inject(
            method = "getSender()Lnet/minecraft/client/session/telemetry/TelemetrySender;",
            at = @At("RETURN"),
            cancellable = true
    )
    private void onGetSender(CallbackInfoReturnable<class_7965> cir) {
        Modules modules = Modules.get();
        if (modules != null && modules.isActive(NoTelemetry.class)) {
            cir.setReturnValue(NOOP_SENDER);
        }
    }
}