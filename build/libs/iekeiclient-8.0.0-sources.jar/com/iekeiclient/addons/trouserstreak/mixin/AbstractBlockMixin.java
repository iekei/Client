package com.iekeiclient.addons.trouserstreak.mixin;

import com.iekeiclient.addons.trouserstreak.modules.BoatNoclip;
import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.class_1297;
import net.minecraft.class_1690;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_3727;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class)
public class AbstractBlockMixin {
    @Inject(method = "getCollisionShape", at = @At("HEAD"), cancellable = true)
    private void getCollisionShape(class_2680 state, class_1922 world, class_2338 pos, class_3726 context, CallbackInfoReturnable<class_265> cir) {
        if (!(context instanceof class_3727 esc)) return;
        if (esc.method_32480() == null) return;

        class_1297 entity = esc.method_32480();
        if (Modules.get() == null) return;

        if (Modules.get().isActive(BoatNoclip.class)
            && entity instanceof class_1690 boat
            && boat.method_65038()) {
            cir.setReturnValue(class_259.method_1073());
        }
    }
}