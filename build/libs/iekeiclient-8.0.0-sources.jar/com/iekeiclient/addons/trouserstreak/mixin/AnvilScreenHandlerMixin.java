package com.iekeiclient.addons.trouserstreak.mixin;

import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.class_1706;
import net.minecraft.class_2561;
import net.minecraft.class_2572;
import net.minecraft.class_2588;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import com.iekeiclient.addons.trouserstreak.modules.NoModDetection;

@Mixin(class_1706.class)
public abstract class AnvilScreenHandlerMixin {
    @Redirect(
            method = "updateResult",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/text/Text;getString()Ljava/lang/String;"
            )
    )
    private String trouserstreak$filterAnvilResultName(class_2561 text) {
        return trouserstreak$sanitizeAnvilText(text);
    }

    @Unique
    private static String trouserstreak$sanitizeAnvilText(class_2561 text) {
        NoModDetection module = Modules.get().get(NoModDetection.class);

        if (module == null || !module.isActive() || !module.filterAnvil.get()) {
            return text.getString();
        }

        if (text.method_10851() instanceof class_2588 translatable) {
            String fallback = translatable.method_48323();

            return fallback != null
                    ? fallback
                    : translatable.method_11022();
        }

        if (text.method_10851() instanceof class_2572) {
            return "";
        }

        return text.getString();
    }
}