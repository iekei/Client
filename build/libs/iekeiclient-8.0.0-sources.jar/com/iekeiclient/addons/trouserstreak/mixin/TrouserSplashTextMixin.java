package com.iekeiclient.addons.trouserstreak.mixin;

import com.iekeiclient.engine.systems.config.Config;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Random;
import net.minecraft.class_2561;
import net.minecraft.class_4008;
import net.minecraft.class_8519;

@Mixin(class_4008.class)
public class TrouserSplashTextMixin {
    @Unique
    private boolean override = true;
    @Unique
    private int currentIndex = 0;
    @Unique
    private final List<String> TrouserSplashes = getTrouserSplashes();

    @Inject(method = "get", at = @At("HEAD"), cancellable = true)
    private void onApply(CallbackInfoReturnable<class_8519> cir) {
        if (Config.get() == null || !Config.get().titleScreenSplashes.get()) return;

        if (override) {
            currentIndex = new Random().nextInt(TrouserSplashes.size());
            cir.setReturnValue(new class_8519(class_2561.method_30163(TrouserSplashes.get(currentIndex))));
        }
        override = !override;
    }

    @Unique
    private static List<String> getTrouserSplashes() {
        return List.of(
                "Sorry about the turts.",
                "Sponsored by Mountains of Lava Inc!™",
                "Mods tweaked, Trousers streaked.",
                "Grief Bitches, Get Money",
                "Currently raiding your apartment for Illegal Blocks",
                "in ur servers, breaking ur blocks",
                "Steve did nothing wrong.",
                "Make Minecraft Great Again!",
                "Make Mountains, not war.",
                "Old versions of Iekei are not supported! -Iekei Client Discord",
                "Griefing is just love with a little bit of TNT.",
                "The floor is lava, the roof is lava, Everything is lava.",
                "If at first you don't succeed, just use more TNT.",
                "If at first you don't succeed, grief, grief again",
                "Stop and take time to smell the explosions.",
                "wtf is happening to this server today",
                "whos building a lag mashines",
                "!why tps so smalling",
                "Sulfur cube party at 0, 0",
                "fdrgeafqrRESGJTURYKJRTDSRGHR!!!!!!",
                "ehuewifgewiudhyiewqiofyhfliuweqgfouiwq3tgodiwayghfeoiewhjikhlewhfwkuagfdlalihbflo;sdl;pihfehw083yr0328whefoiwuy3prhfjewoiyufhildwshiofc"
        );
    }
}