package com.iekeiclient.addons.trouserstreak.mixin.accessor;

import io.netty.channel.Channel;
import net.minecraft.class_2535;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2535.class)
public interface ClientConnectionAccessor {
    @Accessor
    Channel getChannel();
}
