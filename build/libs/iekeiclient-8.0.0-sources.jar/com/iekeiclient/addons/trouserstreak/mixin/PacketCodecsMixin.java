package com.iekeiclient.addons.trouserstreak.mixin;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_8703;
import net.minecraft.class_9135;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_9135.class)
public interface PacketCodecsMixin {
    @Inject(method = "Lnet/minecraft/network/codec/PacketCodecs;writeCollectionSize(Lio/netty/buffer/ByteBuf;II)V", at = @At("HEAD"), cancellable = true)
    private static void writeCollectionsSize(ByteBuf buf, int size, int maxSize, CallbackInfo ci){
        class_8703.method_53017(buf, size);
        ci.cancel();
    }
}