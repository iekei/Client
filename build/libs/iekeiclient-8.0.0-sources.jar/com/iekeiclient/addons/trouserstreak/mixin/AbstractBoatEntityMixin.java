package com.iekeiclient.addons.trouserstreak.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_10255;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.iekeiclient.addons.trouserstreak.modules.BoatNoclip;
import com.iekeiclient.engine.systems.modules.Modules;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import static com.iekeiclient.engine.IekeiClient.mc;

@Mixin({class_10255.class})
public class AbstractBoatEntityMixin {
    @Inject(method = "collidesWith", at = @At("HEAD"), cancellable = true)
    private void collidesWith(class_1297 other, CallbackInfoReturnable<Boolean> cir) {
        class_10255 boat = (class_10255)(Object)this;

        if (Modules.get().isActive(BoatNoclip.class)
                && boat.method_5642() == mc.field_1724) {
            cir.setReturnValue(false);
        }
    }

    @ModifyExpressionValue(method = "updatePaddles", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/vehicle/AbstractBoatEntity;pressingLeft:Z", opcode = Opcodes.GETFIELD))
    private boolean pressingLeft(boolean original) {
        if (Modules.get().isActive(BoatNoclip.class)) return false;
        return original;
    }

    @ModifyExpressionValue(method = "updatePaddles", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/vehicle/AbstractBoatEntity;pressingRight:Z", opcode = Opcodes.GETFIELD))
    private boolean pressingRight(boolean original) {
        if (Modules.get().isActive(BoatNoclip.class)) return false;
        return original;
    }
}