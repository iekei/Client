package com.iekeiclient.addons.trouserstreak.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.iekeiclient.addons.trouserstreak.utils.MovementPatch;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_8673;
import net.minecraft.class_9836;

@Mixin(class_8673.class)
public abstract class ClientCommonPacketListenerImplMixin {

    @Shadow
    public abstract void sendPacket(class_2596<?> packet);

    @Unique
    private static final ThreadLocal<Boolean> trouser$sendingTickEnd = ThreadLocal.withInitial(() -> false);

    @Unique
    private boolean trouser$positionSentSinceTickEnd;

    @Inject(
            method = "sendPacket(Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD")
    )

    private void trouser$sendTickEndBeforeDuplicatePosition(class_2596<?> packet, CallbackInfo ci) {
        if (packet instanceof class_9836) {
            trouser$positionSentSinceTickEnd = false;
            return;
        }

        if (!MovementPatch.isEnabled()) return;

        if (!(packet instanceof class_2828 movePacket)
                || !movePacket.method_36171()) {
            return;
        }

        if (trouser$sendingTickEnd.get()) return;

        if (!trouser$positionSentSinceTickEnd) {
            trouser$positionSentSinceTickEnd = true;
            return;
        }

        trouser$sendingTickEnd.set(true);

        try {
            sendPacket(class_9836.field_52333);
        } finally {
            trouser$sendingTickEnd.set(false);
        }

        trouser$positionSentSinceTickEnd = true;
    }
}
