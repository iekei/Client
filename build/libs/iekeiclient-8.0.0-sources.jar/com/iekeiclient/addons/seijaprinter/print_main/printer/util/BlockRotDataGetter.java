/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.RotationData;
import net.minecraft.block.*;
import net.minecraft.class_10594;
import net.minecraft.class_11586;
import net.minecraft.class_2199;
import net.minecraft.class_2215;
import net.minecraft.class_2248;
import net.minecraft.class_2276;
import net.minecraft.class_2281;
import net.minecraft.class_2288;
import net.minecraft.class_2312;
import net.minecraft.class_2315;
import net.minecraft.class_2325;
import net.minecraft.class_2333;
import net.minecraft.class_2336;
import net.minecraft.class_2350;
import net.minecraft.class_2363;
import net.minecraft.class_2366;
import net.minecraft.class_2406;
import net.minecraft.class_2508;
import net.minecraft.class_2533;
import net.minecraft.class_2665;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3532;
import net.minecraft.class_3708;
import net.minecraft.class_3715;
import net.minecraft.class_3718;
import net.minecraft.class_3748;
import net.minecraft.class_4481;
import net.minecraft.class_5000;
import net.minecraft.class_5801;
import net.minecraft.class_5808;
import net.minecraft.class_7713;
import net.minecraft.class_7714;
import org.jetbrains.annotations.Nullable;



public class BlockRotDataGetter {
    private static final Printer pri = Printer.getINSTANCE();

    /**
     * get vec
     * 获取强制放置指定方块状态的非法转头方向
     *
     * @param bs bs 需要的State
     * @return {@link RotationData}
     * @see RotationData
     */
    @Nullable
    public static RotationData getRotData(class_2680 bs) {
        if (!pri.bSetIllegalRotate.get()) return null;//没开非法转头就结束
        class_2248 block = bs.method_26204();
        //H rotate YClock
        //Anvil
        if (block instanceof class_2199) {
            return getRotateDataFromDir(bs.method_11654(class_2741.field_12481).method_10160());
        }
        //H opposite
        //Trapdoor Chest EnderChestBlock AbstractFurnaceBlock LecternBlock StonecutterBlock BeehiveBlock
        //RedStoneGate DripLeaf CarVedPumpkin ChiseledBookshelf EndProtalFra FlowerbedBlock
        //GlazedTerracottaBlock JigsawBlock LoomBlock
        if (block instanceof class_2533 || block instanceof class_2281 || block instanceof class_2336
            || block instanceof class_2363 || block instanceof class_3715 || block instanceof class_3718
            || block instanceof class_4481 || block instanceof class_2312
            || block instanceof class_5808 || block instanceof class_5801
            || block instanceof class_2276 || block instanceof class_7714
            || block instanceof class_2333 || block instanceof class_10594
            || block instanceof class_2366 || block instanceof class_3748
            || block instanceof class_2406 || block instanceof class_11586
        ) {
            return getRotateDataFromDir(bs.method_11654(class_2741.field_12481).method_10153());
        }

        //H nor
        //Stair FenceGateBlock CalibratedSculkSensorBlock CampfireBlock Door Bed

        //rotate +=180
        //Sign HSign Banner
        if (block instanceof class_2508
            || block instanceof class_7713 || block instanceof class_2215) {
            return getVecFromRotProp(bs.method_11654(class_2741.field_12532));
        }

        //rotate

        //Fac Oppo
        //PistonBlock DispenserBlock DropperBlock BarrelBlock CommandBlock
        if (block instanceof class_2665 || block instanceof class_2315
            || block instanceof class_2325 || block instanceof class_3708
            || block instanceof class_2288) {
            return getRotateDataFromDir(bs.method_11654(class_2741.field_12525).method_10153());
        }

        //Fac
        //observer


        if (bs.method_28501().contains(class_2741.field_12525)) {
            return getRotateDataFromDir(bs.method_11654(class_2741.field_12525));
        }
        if (bs.method_28501().contains(class_2741.field_12481)) {
            return getRotateDataFromDir(bs.method_11654(class_2741.field_12481));
        }
        if (bs.method_28501().contains(class_2741.field_12532)) {
            return getVecFromRotProp2(bs.method_11654(class_2741.field_12532));
        }
        if (bs.method_28501().contains(class_2741.field_23333)) {

            class_5000 ori = bs.method_11654(class_2741.field_23333);
            if (ori.method_26426().method_10166() != class_2350.class_2351.field_11052)
                return getRotateDataFromDir(ori.method_26426().method_10153());
            return  RotationData.build(getRotateDataFromDir(ori.method_26428().method_10153()).yaw(), getRotateDataFromDir(ori.method_26426().method_10153()).pitch());
        }

        return null;
    }

    public static RotationData getRotateDataFromDir(class_2350 dir) {
        RotationData data =  RotationData.build(0, 0);
        switch (dir) {
            case field_11034 -> data =  RotationData.build(-90, 0);
            case field_11039 -> data =  RotationData.build(90, 0);

            case field_11043 -> data =  RotationData.build(180, 0);

            case field_11035 -> data =  RotationData.build(0, 0);

            case field_11033 -> data =  RotationData.build(0, 90);

            case field_11036 -> data =  RotationData.build(0, -90);

        }
        return data;
    }

    public static RotationData getVecFromRotProp(int prop) {
        return  RotationData.build(class_3532.method_15338(22.5 * prop - 180), 0);
    }

    public static RotationData getVecFromRotProp2(int prop) {
        return  RotationData.build(class_3532.method_15338(22.5 * prop), 0);
    }
}
