/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.getter;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.AbstractDataGetter;
import com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.BlockStateVerify;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.RayTraceUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.RotationData;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.utils.player.ChatUtils;
import net.minecraft.block.*;
import net.minecraft.class_2189;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_5134;

public class BuckedDataGetter extends AbstractDataGetter {
    private static final class_310 mc = class_310.method_1551();

    @Override
    public PlaceData getData(class_2680 needState, DirData dirData) {
        class_2338 placePos = dirData.placePos();
//        BlockState nowState = mc.world.getBlockState(placePos);
        for (class_2350 offsetDir : dirData.dirs()) {
            class_2680 helpState = mc.field_1687.method_8320(placePos.method_10093(offsetDir));
            if (needState.method_26204().equals(class_2246.field_10382) && helpState.method_26204() instanceof class_3737 && !helpState.method_11654(class_2741.field_12508)) {
                continue;
            }
            for (class_243 clickVec : dirData.clickVecs(offsetDir, new DirData.DirDataConfig().setRaytrace(true).setStrictVec(true))) {
                return new PlaceData(placePos.method_10093(offsetDir), offsetDir.method_10153(), clickVec, true,
                    ( RotationData.fromVec(clickVec)), () -> {
                    class_3965 blockHitResult = RayTraceUtil.INSTANCE.rayHitRes
                        (mc.field_1724.method_33571(),  RotationData.build(BlockStateVerify.sendYaw,
                                BlockStateVerify.sendPitch), false,
                            mc.field_1724.method_45325(class_5134.field_47758));
//                    ChatUtils.info(blockHitResult.getType() + "  " + blockHitResult.getBlockPos());
//                    ChatUtils.info();
                    return blockHitResult.method_17783().equals(class_239.class_240.field_1332) && blockHitResult.method_17777().equals(placePos.method_10093(offsetDir));

                });
//                return  PlaceData.newInstance(placePos.offset(offsetDir), offsetDir.getOpposite(), clickVec, true
//                    , (Printer.getINSTANCE().bSetRotate.get() ? null : RotationData.fromVec(clickVec)));
            }
        }
        return PlaceData.NULL;
    }

    @Override
    public boolean isSuitable(class_2680 needState, class_2338 pos) {
        class_2248 block = needState.method_26204();
        class_2680 worldState = mc.field_1687.method_8320(pos);
        return (((block instanceof class_2404)
            && ((bSetEnableWater.get() && block.equals(class_2246.field_10382))
            || (bSetEnableLava.get() && block.equals(class_2246.field_10164)))
            && (needState.method_11654(class_2741.field_12538) == 0))
//            ||((bSetEnablePowderSnow.get()
//            && block.equals(Blocks.POWDER_SNOW)))
        )
            && (worldState.method_26204() instanceof class_2189//空气直接放
            || (worldState.method_26204().equals(block) && worldState.method_11654(class_2741.field_12538) > 0));//同液体非源头
    }

    private final Setting<Boolean> bSetEnableLava = new BoolSetting.Builder().name("EnableLavaPlace")
        .build();
    private final Setting<Boolean> bSetEnableWater = new BoolSetting.Builder().name("EnableWaterPlace").build();
    //private final Setting<Boolean> bSetEnablePowderSnow = new BoolSetting.Builder().name("EnablePowderSnow").build();

    @Override
    public Setting[] getSettings() {
        return new Setting[]{bSetEnableLava, bSetEnableWater};
    }
}
