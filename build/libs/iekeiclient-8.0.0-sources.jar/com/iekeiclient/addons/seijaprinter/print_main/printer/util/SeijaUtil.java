/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.mixin.ClientWorldAccessor;
import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.LongBidirectionalIterator;
import it.unimi.dsi.fastutil.longs.LongSortedSet;
import com.iekeiclient.engine.mixin.EntityTrackingSectionAccessor;
import com.iekeiclient.engine.mixin.SectionedEntityCacheAccessor;
import com.iekeiclient.engine.mixin.SimpleEntityLookupAccessor;
import com.iekeiclient.engine.mixin.WorldAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4050;
import net.minecraft.class_4076;
import net.minecraft.class_5572;
import net.minecraft.class_5573;
import net.minecraft.class_5577;
import net.minecraft.class_5578;
import net.minecraft.class_7202;
import net.minecraft.util.math.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;

public class SeijaUtil {
    public static Printer pri = Printer.getINSTANCE();
    static class_310 mc = class_310.method_1551();

    public static boolean isSneak(){
        return mc.field_1724.method_5715()||pri.bSetSneak.get();
    }

    public static double getEyeHeight() {
        double eyeHeight;
        if (pri.bSetSneak.get()) {

            if (mc.field_1724.method_18381(mc.field_1724.method_18376()) < 1) {
                eyeHeight = mc.field_1724.method_18381(mc.field_1724.method_18376());
            } else eyeHeight = mc.field_1724.method_18381(class_4050.field_18081);
        } else
            eyeHeight = mc.field_1724.method_33571().field_1351 - mc.field_1724.method_73189().field_1351;
        return eyeHeight;
    }

    public static double getYaw(class_243 pos) {

        class_243 pVec = PredictUtility.getPredPlayerVec();
        return mc.field_1724.method_36454() + class_3532.method_15393((float) Math.toDegrees(Math.atan2(pos.method_10215() - pVec.method_10215(), pos.method_10216() - pVec.method_10216())) - 90f - mc.field_1724.method_36454());
    }

    public static double getPitch(class_243 pos) {
        class_243 pVec = PredictUtility.getPredPlayerVec();
        double eyeHeight = getEyeHeight();


        double diffX = pos.method_10216() - pVec.method_10216();
        double diffY = pos.method_10214() - (pVec.method_10214() + eyeHeight);
        double diffZ = pos.method_10215() - pVec.method_10215();

        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        return mc.field_1724.method_36455() + class_3532.method_15393((float) -Math.toDegrees(Math.atan2(diffY, diffXZ)) - mc.field_1724.method_36455());
    }

    public static int getSequence() {
        class_7202 sequence = ((ClientWorldAccessor) mc.field_1687).getPendingUpdateManager().method_41937();
        return sequence.method_41942();
    }


    public static double distanceBetween(class_2338 pos1, class_2338 pos2) {
        double d = pos1.method_10263() - pos2.method_10263();
        double e = pos1.method_10264() - pos2.method_10264();
        double f = pos1.method_10260() - pos2.method_10260();
        return class_3532.method_15355((float) (d * d + e * e + f * f));
    }

    public static boolean intersectsWithEntity(class_238 box, Predicate<class_1297> predicate) {
        class_5577<class_1297> entityLookup = ((WorldAccessor) mc.field_1687).iekei$getEntityLookup();

        // Fast implementation using SimpleEntityLookup that returns on the first intersecting entity
        if (entityLookup instanceof class_5578<class_1297> simpleEntityLookup) {
            class_5573<class_1297> cache = ((SimpleEntityLookupAccessor) simpleEntityLookup).iekei$getCache();
            LongSortedSet trackedPositions = ((SectionedEntityCacheAccessor) cache).iekei$getTrackedPositions();
            Long2ObjectMap<class_5572<class_1297>> trackingSections = ((SectionedEntityCacheAccessor) cache).iekei$getTrackingSections();

            int i = class_4076.method_32204(box.field_1323 - 2);
            int j = class_4076.method_32204(box.field_1322 - 2);
            int k = class_4076.method_32204(box.field_1321 - 2);
            int l = class_4076.method_32204(box.field_1320 + 2);
            int m = class_4076.method_32204(box.field_1325 + 2);
            int n = class_4076.method_32204(box.field_1324 + 2);

            for (int o = i; o <= l; o++) {
                long p = class_4076.method_18685(o, 0, 0);
                long q = class_4076.method_18685(o, -1, -1);
                LongBidirectionalIterator longIterator = trackedPositions.subSet(p, q + 1).iterator();

                while (longIterator.hasNext()) {
                    long r = longIterator.nextLong();
                    int s = class_4076.method_18689(r);
                    int t = class_4076.method_18690(r);

                    if (s >= j && s <= m && t >= k && t <= n) {
                        class_5572<class_1297> entityTrackingSection = trackingSections.get(r);

                        if (entityTrackingSection != null && entityTrackingSection.method_31768().method_31885()) {
                            for (class_1297 entity : ((EntityTrackingSectionAccessor) entityTrackingSection).<class_1297>iekei$getCollection()) {
                                if (entity.method_5829().method_994(box) && predicate.test(entity)) return true;
                            }
                        }
                    }
                }
            }

            return false;
        }

        // Slow implementation that loops every entity if for some reason the EntityLookup implementation is changed
        AtomicBoolean found = new AtomicBoolean(false);

        entityLookup.method_31807(box, entity -> {
            if (!found.get() && predicate.test(entity)) found.set(true);
        });

        return found.get();
    }


    public static class_2350[] getEntityFacingOrder(float yaw, float pitch) {
        class_2350 direction3;
        float f = pitch * ((float) Math.PI / 180);
        float g = -yaw * ((float) Math.PI / 180);
        float h = class_3532.method_15374(f);
        float i = class_3532.method_15362(f);
        float j = class_3532.method_15374(g);
        float k = class_3532.method_15362(g);
        boolean bl = j > 0.0f;
        boolean bl2 = h < 0.0f;
        boolean bl3 = k > 0.0f;
        float l = bl ? j : -j;
        float m = bl2 ? -h : h;
        float n = bl3 ? k : -k;
        float o = l * i;
        float p = n * i;
        class_2350 direction = bl ? class_2350.field_11034 : class_2350.field_11039;
        class_2350 direction2 = bl2 ? class_2350.field_11036 : class_2350.field_11033;
        class_2350 direction4 = direction3 = bl3 ? class_2350.field_11035 : class_2350.field_11043;
        if (l > n) {
            if (m > o) {
                return listClosest(direction2, direction, direction3);
            }
            if (p > m) {
                return listClosest(direction, direction3, direction2);
            }
            return listClosest(direction, direction2, direction3);
        }
        if (m > p) {
            return listClosest(direction2, direction3, direction);
        }
        if (o > m) {
            return listClosest(direction3, direction, direction2);
        }
        return listClosest(direction3, direction2, direction);
    }

    private static class_2350[] listClosest(class_2350 first, class_2350 second, class_2350 third) {
        return new class_2350[]{first, second, third, third.method_10153(), second.method_10153(), first.method_10153()};
    }

    public static class_2350[] getPlacementDirections(class_243 clickVec, class_2338 placePos, class_2350 offsetDir) {
        int i;
        class_2350[] directions = getEntityFacingOrder((float) getYaw(clickVec), (float) getPitch(clickVec));
        if (BlockUtil.canPlaceIn(placePos.method_10093(offsetDir))) {
            return directions;
        }
        class_2350 direction = offsetDir.method_10153();
        for (i = 0; i < directions.length && directions[i] != direction.method_10153(); ++i) {
        }
        if (i > 0) {
            System.arraycopy(directions, 0, directions, 1, i);
            directions[0] = direction.method_10153();
        }
        return directions;
    }
}
