/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.*;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.RotationData;
import com.iekeiclient.engine.events.packets.PacketEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;


import static com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.FakePlacementContext.fakePlayer;
import static com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.FakePlacementContext.setRotate;


public class BlockStateVerify {
    private static final class_310 mc = class_310.method_1551();

    private static Printer pri() {
        return Printer.getINSTANCE();
    }
    public static float sendYaw,sendPitch=0;

    @EventHandler
    private static void onRotation(PacketEvent.Send event) {
        if (event.packet instanceof class_2828 movePacket) {
            float sendYaw = movePacket.method_12271(0);
            float sendPitch = movePacket.method_12270(0);
            if (sendYaw==sendPitch&&sendPitch==0)return;
            BlockStateVerify.sendYaw = sendYaw;
            BlockStateVerify.sendPitch = sendPitch;
        }
    }

    protected static FakePlacementContext getContextVerify(class_243 clickVec, class_2338 placePos, class_2350 offsetDir, class_1799 stack, @Nullable RotationData rdata) {

        fakePlayer.method_33574(mc.field_1724.method_73189());
        if (rdata == null) {
            setRotate(fakePlayer, sendYaw, sendPitch);
            //ChatUtils.sendMsg(Text.of(mc.player.getYaw() + "," + mc.player.getPitch()));
        } else {
            setRotate(fakePlayer, (float) rdata.yaw(), (float) rdata.pitch());
        }
        rdata = RotationData.build(sendYaw,sendPitch);

        FakePlacementContext.setMovementMode(fakePlayer);
        fakePlayer.method_5660(SeijaUtil.isSneak());


        class_3965 hitRes = (pri().bSetRayTrace.get() && pri().bSetRayTrace.isVisible()) ? RayTraceUtil.INSTANCE.rayHitRes(fakePlayer.method_33571(), rdata, pri().bSetIgnoreEntity.get(), pri().dSetPrintingRange.get())
            : BlockUtil.getHitRes(placePos, offsetDir, clickVec);

        return new FakePlacementContext(fakePlayer, class_1268.field_5808, stack, hitRes);
    }

    //用于后检测
    protected static class_2680 genBlockState(class_1750 placeContext, class_2248 b) {

        if (!placeContext.method_7716()) {
            return null;
        }
        class_1747 bItem;
        try {
            bItem = (class_1747) InvUtil.getItemFormBlock(b);
            if (bItem == null) return null;
        } catch (ClassCastException ignore) {
            return null;
        }
        class_2248 needBlock = bItem.method_7711();
        placeContext = bItem.method_16356(placeContext);
        if (placeContext == null) return null;
        if (!needBlock.method_45382(placeContext.method_8045().method_45162())) {
            return null;
        }
        if (!placeContext.method_7716()) {
            return null;
        }//test
        return bItem.method_7707(placeContext);
    }
}
