/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.state_decide;

import com.iekeiclient.engine.settings.Setting;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2745;
import net.minecraft.class_310;

public class ChestDecide implements Decide{
    private static final  class_310 mc = class_310.method_1551();
    @Override
    public boolean isSuit(class_2680 needState, class_2680 nowState, class_2338 placePos) {
        return needState.method_26204().equals(nowState.method_26204())&&(
            needState.method_26204() instanceof class_2281);
    }

    @Override
    public boolean test(class_2680 needState, class_2680 nowState, class_2338 placePos) {
        if (!needState.method_11654(class_2741.field_12481).equals(nowState.method_11654(class_2741.field_12481)))
        {
            return false;
        }//方位判断
        class_2745 needType = needState.method_11654(class_2741.field_12506);
        class_2745 nowType = nowState.method_11654(class_2741.field_12506);
        if ((!needType.equals(nowType))&&nowType.equals(class_2745.field_12569)){
            //特殊情况 旁边的箱子可能没放
            class_2350 chestDir = nowState.method_11654(class_2741.field_12481);
            class_2350 neiOffset = getNeiOffset(chestDir, needType);
            class_2338 neiPos = placePos.method_10093(neiOffset);
            //基本数据
            class_2680 neiState = mc.field_1687.method_8320(neiPos);
            //旁边不是箱子或者旁边是箱子但是方向错误
            return !neiState.method_26204().equals(needState.method_26204())
                || !neiState.method_11654(class_2741.field_12481).equals(chestDir);

        }
        return needType.equals(nowType);
    }
    public class_2350 getNeiOffset(class_2350 cDir, class_2745 t) {
        switch (t) {
            case field_12574 -> {
                return cDir.method_10170();
            }
            case field_12571 -> {
                return cDir.method_10160();
            }
        }
        return null;
    }
    @Override
    public Setting[] getSettings() {
        return new Setting[0];
    }
}
