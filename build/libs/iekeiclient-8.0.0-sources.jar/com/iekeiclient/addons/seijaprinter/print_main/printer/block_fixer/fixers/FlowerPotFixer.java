/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers;

import com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.AbstractFixer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirDataI;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.InvUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceData;
import net.minecraft.class_2189;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2362;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public class FlowerPotFixer extends AbstractFixer {
    public FlowerPotFixer() {
        super("FlowerPotFix");
    }

    @Override
    public int fixBlock(class_2338 pos, class_2680 needState) {

        //block替换 仅自定义替换,不使用内置替换
        DirData dirData = new DirData(pos, BlockUtil.getSortedDirs(pos,true));

        if (InvUtil.findBlock(((class_2362) needState.method_26204()).method_16231())){
            for (class_2350 dir : dirData.dirs()) {
                for (class_243 clickVec : dirData.clickVecsInte(dir)) {
                    if (!InvUtil.switchBlock(((class_2362) needState.method_26204()).method_16231())) {
                        return RETURN;
                    }
                    BlockUtil.interactBlock(PlaceData.newInstance(dirData.placePos(),dir,clickVec,true,null));
                    return SUCCESS;
                }
            }
        }
        return CONTINUE;
    }

    @Override
    public boolean needFix(class_2338 pos, class_2680 needState) {

        class_2680 blockState = mc.field_1687.method_8320(pos);
        return blockState.method_26204() instanceof class_2362
            //仅自定义替换,不使用内置替换规则
            && needState.method_26204() instanceof class_2362
            && ((class_2362) blockState.method_26204()).method_16231() instanceof class_2189
            && (!(((class_2362) needState.method_26204()).method_16231() instanceof class_2189))
            &&((class_2362) blockState.method_26204()).method_16231() instanceof class_2189;
    }
}
