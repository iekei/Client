/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers;

import com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.AbstractFixer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirDataI;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.InvUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceData;
import net.minecraft.block.*;
import net.minecraft.class_1821;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3922;
import java.util.List;

public class CampFireFixer extends AbstractFixer {
    public CampFireFixer() {
        super("CampFireFix");
    }

    @Override
    public int fixBlock(class_2338 pos, class_2680 needState) {
        List<class_2350> interactDir = BlockUtil.getSortedDirs(pos,true);
        DirData dirData = new DirData(pos, interactDir);
        if (!InvUtil.findItem(stack -> stack.method_7909()instanceof class_1821)) {
            return CONTINUE;
        }
        for (class_2350 dir : dirData.dirs()) {
            for (class_243 clickVec : dirData.clickVecsInte(dir)) {
                if (InvUtil.switchItem(stack -> stack.method_7909()instanceof class_1821)) {
                    BlockUtil.interactBlock(PlaceData.newInstance(dirData.placePos(),dir,clickVec,true,null));
                    return SUCCESS;
                }else return RETURN;
            }
        }
        return CONTINUE;
    }

    @Override
    public boolean needFix(class_2338 pos, class_2680 needState) {
        class_2248 block = mc.field_1687.method_8320(pos).method_26204();
        return needState.method_26204() instanceof class_3922
            && needState.method_26204()==block
            && mc.field_1687.method_8320(pos).method_11654(class_2741.field_12548);
    }
}
