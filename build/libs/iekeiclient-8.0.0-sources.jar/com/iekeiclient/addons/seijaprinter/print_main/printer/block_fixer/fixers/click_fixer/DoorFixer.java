/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers.click_fixer;

import net.minecraft.block.*;
import net.minecraft.class_2246;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2741;

public class DoorFixer extends AbstractClickFixer {
    public DoorFixer() {
        super("DoorFix");
    }

    @Override
    public boolean needFix(class_2338 pos, class_2680 needState) {
        if (!super.needFix(pos,needState)) {
            return false;
        }
        class_2680 blockState = mc.field_1687.method_8320(pos);
        if (blockState.method_26204()!= class_2246.field_9973
            &&blockState.method_26204()!= class_2246.field_10453
            &&(blockState.method_26204() instanceof class_2323
            || blockState.method_26204() instanceof class_2349
            || blockState.method_26204() instanceof class_2533)) {
            return needState.method_26204().getClass().equals(blockState.method_26204().getClass())
                &&blockState.method_11654(class_2741.field_12537) != needState.method_11654(class_2741.field_12537);
        }
        return false;
    }
}
