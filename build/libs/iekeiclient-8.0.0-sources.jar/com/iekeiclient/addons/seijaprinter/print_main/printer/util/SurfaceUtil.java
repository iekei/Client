/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import fi.dy.masa.litematica.world.SchematicWorldHandler;
import com.iekeiclient.engine.utils.player.ChatUtils;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class SurfaceUtil {
    private static final Printer pri = Printer.getINSTANCE();

    public static boolean surfaceCheck(class_2338 pos, int c) {
        if (c == 0) return true;
        Set<class_2338> surface;//= getSurfaceManhattan(pos, c);
        switch (pri.eSetSurfaceMode.get()) {
            case MANHATTAN:
                surface = getSurfaceManhattan(pos, c);
                break;
            case CHEBYSHEV:
                surface = getSurfaceChebyshev(pos, c);
                break;
            default:
                surface = new HashSet<>();
                surface.add(pos);
        }
        surface.remove(pos);
        for (class_2338 blockPos : surface) {

            if ((!BlockReplaceUtils.INSTANCE.getScheState(blockPos).method_51367())
                ||(!BlockReplaceUtils.INSTANCE.getScheState(blockPos).method_26234(SchematicWorldHandler.getSchematicWorld(),blockPos))) return true;
        }
        return false;
    }

    public static Set<class_2338> getSurfaceChebyshev(class_2338 pos, int c) {
        Set<class_2338> result = new HashSet<>();

        for (int x = pos.method_10263() - c; x <= pos.method_10263() + c; x++) {
            for (int y = pos.method_10264() - c; y <= pos.method_10264() + c; y++) {
                for (int z = pos.method_10260() - c; z <= pos.method_10260() + c; z++) {
                    result.add(new class_2338(x, y, z));
                }
            }
        }

        return result;
    }

    public static Set<class_2338> getSurfaceManhattan(class_2338 pos, int c) {
        Set<class_2338> result = new HashSet<>();
        result.add(pos);
        for (int i = 0; i < c; i++) {
            result = getSurfaceManhattan(result);
        }
        return result;
    }

    private static Set<class_2338> getSurfaceManhattan(Set<class_2338> set) {
        return set.stream()
            .flatMap(blockPos -> Arrays.stream(class_2350.values())
                .map(blockPos::method_10093)
                .toList().stream())
            .collect(Collectors.toSet());
    }
}
