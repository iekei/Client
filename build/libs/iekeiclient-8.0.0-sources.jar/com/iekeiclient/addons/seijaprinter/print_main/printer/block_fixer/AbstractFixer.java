/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.Settings;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public abstract class AbstractFixer {
    public class_310 mc = class_310.method_1551();

    public AbstractFixer(String name) {
        bSetEnable = new BoolSetting.Builder().name(name).defaultValue(true).build();
    }
    public AbstractFixer( BoolSetting setting) {
        bSetEnable = setting;
    }


    public Printer pri(){
        return Printer.getINSTANCE();
    }

    public BoolSetting bSetEnable;

    /**
     * fix block进行方块修复
     *
     * @param pos pos 修复位置
     * @param needState needState需要的状态
     * @return {@link boolean}是否进行了修复
     */
    public abstract int fixBlock(class_2338 pos, class_2680 needState);
    /**
     * need fix 检测是否需要修复
     *
     * @param pos pos 尝试修复的方块位置
     * @param needState needState 尝试修复的方块状态
     * @return {@link boolean}是否需要修复
     */
    public abstract boolean needFix(class_2338 pos, class_2680 needState);
    public boolean isEnable(){return bSetEnable.get();}


    public static final int CONTINUE = 0;
    public static final int SUCCESS = 1;
    public static final int RETURN = 2;

}
