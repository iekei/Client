/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.engine.IekeiClient;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;

import static com.iekeiclient.engine.IekeiClient.mc;

public class ShadyRotation {
	private static float pitchDifference;
	public static float yawDifference;
	private static int ticks = -1;
	private static int tickCounter = 0;
	private static Runnable callback = null;

	public static boolean running = false;

	private static boolean client = false;

	public static class Rotation {
		public float pitch;
		public float yaw;

		public Rotation(float pitch, float yaw) {
			this.pitch = pitch;
			this.yaw = yaw;
		}
	}


	private static double wrapAngleTo180(double angle) {
		return angle - Math.floor(angle / 360 + 0.5) * 360;
	}

	private static float wrapAngleTo180(float angle) {
		return (float) (angle - Math.floor(angle / 360 + 0.5) * 360);
	}

	public static Rotation getRotationToBlock(class_2338 block) {
		double diffX = block.method_10263() - mc.field_1724.method_73189().field_1352 + 0.5;
		double diffY = block.method_10264() - mc.field_1724.method_73189().field_1351 + 0.5 - mc.field_1724.method_23320();
		double diffZ = block.method_10260() - mc.field_1724.method_73189().field_1350 + 0.5;
		double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);

		float pitch = (float) -Math.atan2(dist, diffY);
		float yaw = (float) Math.atan2(diffZ, diffX);
		pitch = (float) wrapAngleTo180((pitch * 180F / Math.PI + 90)*-1);
		yaw = (float) wrapAngleTo180((yaw * 180 / Math.PI) - 90);

		return new Rotation(pitch, yaw);
	}

	public static Rotation getRotationToEntity(class_1297 entity) {
		double diffX = entity.method_73189().field_1352 - mc.field_1724.method_73189().field_1352;
		double diffY = entity.method_73189().field_1351 + entity.method_33571().field_1351 - mc.field_1724.method_73189().field_1351 - mc.field_1724.method_23320();
		double diffZ = entity.method_73189().field_1350 - mc.field_1724.method_73189().field_1350;
		double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);

		float pitch = (float) -Math.atan2(dist, diffY);
		float yaw = (float) Math.atan2(diffZ, diffX);
		pitch = (float) wrapAngleTo180((pitch * 180F / Math.PI + 90)*-1);
		yaw = (float) wrapAngleTo180((yaw * 180 / Math.PI) - 90);

		return new Rotation(pitch, yaw);
	}

	public static Rotation vec3ToRotation(class_243 vec) {
		double diffX = vec.field_1352 - mc.field_1724.method_73189().field_1352;
		double diffY = vec.field_1351 - mc.field_1724.method_73189().field_1351 - mc.field_1724.method_23320();
		double diffZ = vec.field_1350 - mc.field_1724.method_73189().field_1350;
		double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);

		float pitch = (float) -Math.atan2(dist, diffY);
		float yaw = (float) Math.atan2(diffZ, diffX);
		pitch = (float) wrapAngleTo180((pitch * 180F / Math.PI + 90)*-1);
		yaw = (float) wrapAngleTo180((yaw * 180 / Math.PI) - 90);

		return new Rotation(pitch, yaw);
	}
	public static void smoothLook(Rotation rotation, int ticks, boolean client, Runnable callback) {
		ShadyRotation.client = client;
		if(ticks == 0) {
			look(rotation, client);
			callback.run();
			return;
		}

		ShadyRotation.callback = callback;

		pitchDifference = wrapAngleTo180(rotation.pitch - mc.field_1724.method_36455());
		yawDifference = wrapAngleTo180(rotation.yaw - mc.field_1724.method_36454());

		ShadyRotation.ticks = ticks * 20;
		ShadyRotation.tickCounter = 0;
	}

	public static void smoothLook(RotationUtils.Rotation rotation, int ticks, boolean client, Runnable callback) {
		ShadyRotation.client = client;
		if(ticks == 0) {
			look(new Rotation(rotation.getPitch(), rotation.getYaw()), client);
			callback.run();
			return;
		}

		ShadyRotation.callback = callback;
		if (client) {
			pitchDifference = wrapAngleTo180(rotation.getPitch() - mc.field_1724.method_36455());
			yawDifference = wrapAngleTo180(rotation.getYaw() - mc.field_1724.method_36454());
		} else {
			pitchDifference = wrapAngleTo180(rotation.getPitch() - Rotations.serverPitch);
			yawDifference = wrapAngleTo180(rotation.getYaw() - Rotations.serverYaw);
		}

		ShadyRotation.ticks = ticks * 20;
		ShadyRotation.tickCounter = 0;
	}

	public static void smartLook(Rotation rotation, int ticksPer180, boolean client, Runnable callback) {
		ShadyRotation.client = client;
		float rotationDifference = Math.max(
			Math.abs(rotation.pitch - mc.field_1724.method_36455()),
			Math.abs(rotation.yaw - mc.field_1724.method_36454())
		);
		smoothLook(rotation, (int) (rotationDifference / 180 * ticksPer180), client, callback);
	}

	public static void look(Rotation rotation, boolean client) {
		Rotations.serverYaw = rotation.yaw;
		Rotations.serverPitch = rotation.pitch;
		if (client) {
			mc.field_1724.method_36457(rotation.pitch);
			mc.field_1724.method_36456(rotation.yaw);
		}
	}

	public void Init() {
		IekeiClient.EVENT_BUS.subscribe(this);
	}

	private void rotatorWorker() {
		if(mc.field_1724 == null) return;
		if(tickCounter < ticks) {
			running = true;
			if (client) {
				mc.field_1724.method_36457(mc.field_1724.method_36455() + pitchDifference / ticks);
				mc.field_1724.method_36456(mc.field_1724.method_36454() + yawDifference / ticks);
			}
			else {
				Rotations.setCamRotation(Rotations.serverYaw + yawDifference / ticks, Rotations.serverPitch + pitchDifference / ticks);
				//Rotations.serverYaw = (Rotations.serverYaw + yawDifference / ticks);
				//Rotations.serverPitch = (Rotations.serverPitch + pitchDifference / ticks);
			}
			tickCounter++;
		}
		else
		{
			running = false;
		}
	}

	@EventHandler
	public void onTick(TickEvent.Pre event) {
		rotatorWorker();
	}

	@EventHandler
	public void onTick2(TickEvent.Post event) {
		rotatorWorker();
	}
}
