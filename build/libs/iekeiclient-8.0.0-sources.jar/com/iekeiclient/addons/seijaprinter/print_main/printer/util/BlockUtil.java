/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.task_manager.RotationManager;
import com.iekeiclient.addons.seijaprinter.print_main.printer.task_manager.RotationTask;
import com.iekeiclient.addons.seijaprinter.print_main.printer.task_manager.Task;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceDataPack;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PosInfo;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.RotationData;
import fi.dy.masa.litematica.data.DataManager;
import com.iekeiclient.engine.utils.player.Rotations;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1542;
import net.minecraft.class_1667;
import net.minecraft.class_1755;
import net.minecraft.class_1937;
import net.minecraft.class_2189;
import net.minecraft.class_2199;
import net.minecraft.class_2238;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2260;
import net.minecraft.class_2272;
import net.minecraft.class_2286;
import net.minecraft.class_2288;
import net.minecraft.class_2304;
import net.minecraft.class_2315;
import net.minecraft.class_2320;
import net.minecraft.class_2323;
import net.minecraft.class_2325;
import net.minecraft.class_2328;
import net.minecraft.class_2331;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2362;
import net.minecraft.class_2363;
import net.minecraft.class_2377;
import net.minecraft.class_238;
import net.minecraft.class_2387;
import net.minecraft.class_2401;
import net.minecraft.class_2404;
import net.minecraft.class_2406;
import net.minecraft.class_2428;
import net.minecraft.class_243;
import net.minecraft.class_2457;
import net.minecraft.class_2462;
import net.minecraft.class_2478;
import net.minecraft.class_2480;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2756;
import net.minecraft.class_2828;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3708;
import net.minecraft.class_3709;
import net.minecraft.class_3711;
import net.minecraft.class_3713;
import net.minecraft.class_3715;
import net.minecraft.class_3717;
import net.minecraft.class_3718;
import net.minecraft.class_3736;
import net.minecraft.class_3965;
import net.minecraft.class_4739;
import net.minecraft.class_4770;
import net.minecraft.class_5431;
import net.minecraft.class_5540;
import net.minecraft.class_5819;
import net.minecraft.class_5820;
import net.minecraft.util.math.*;
import java.util.*;
import java.util.stream.Collectors;

public class BlockUtil {
    private static Printer pri = Printer.getINSTANCE();
    private static class_310 mc = class_310.method_1551();



    public static List<Task> genTasks(PlaceDataPack pdp) {
        boolean isPlaceMode = pdp.placeMode();
        boolean isBucket = mc.field_1724.method_6047().method_7909() instanceof class_1755;
        PlaceData data = pdp.data();
        class_243 hitVec = data.hitVec();
        final class_2338.class_2339 pos = new class_2338.class_2339(data.pos().method_10263(), data.pos().method_10264(), data.pos().method_10260());
        class_2350 dir = data.dir();
        ArrayList<Task> tasks = new ArrayList<>();


        Runnable r = () -> {
            boolean sneakToggle = false;
            if (isPlaceMode && pri.bSetSneak.get()) {
                if (!mc.field_1724.method_5715()) {
                    sneakToggle = true;
                    mc.field_1724.method_5660(true);
                }
            }

            if (data.test() == null || data.test().getAsBoolean()) {
                illegalRotate(data.exRotateData());
                if (isBucket) {
                    mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                }

                if (pri.bSetPacketPlace.get()) {
                    mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, getHitRes(pos, dir, hitVec), SeijaUtil.getSequence()));
                    mc.field_1724.field_3944.method_52787(new class_2879(class_1268.field_5808));
                } else {
                    mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, getHitRes(pos, dir, hitVec));
                    mc.field_1724.method_6104(class_1268.field_5808);
                }

                PosInfo blackInfo = isPlaceMode ? RenderHelper.getBlackInfo(pos.method_10093(dir), dir, hitVec, true):
                    RenderHelper.getBlackInfo(pos, dir, hitVec, false);
                pri.blackList.add(blackInfo);
                RenderUtil.renderList.add(blackInfo);
            }

            if (sneakToggle) {
                mc.field_1724.method_5660(false);
            }

        };
        if (pri.bSetRotate.get() || isBucket) {
            tasks.add(new RotationTask(null,RotationData.fromVec(hitVec)));
        }
        if (data.exRotateData()!=null)
            tasks.add(new RotationTask(null,data.exRotateData()));

        tasks.add(new Task(r));
        return tasks;
    }

    public static void applyPlaceData(PlaceDataPack pdp) {

        RotationManager.INSTANCE.addTask(genTasks(pdp));

        if (true)return;
        boolean isPlaceMode = pdp.placeMode();
        boolean isBucket = mc.field_1724.method_6047().method_7909() instanceof class_1755;
        PlaceData data = pdp.data();
        class_243 hitVec = data.hitVec();
        final class_2338.class_2339 pos = new class_2338.class_2339(data.pos().method_10263(), data.pos().method_10264(), data.pos().method_10260());
        class_2350 dir = data.dir();


        Runnable r = () -> {
            boolean sneakToggle = false;
            if (isPlaceMode && pri.bSetSneak.get()) {
                if (!mc.field_1724.method_5715()) {
                    sneakToggle = true;
                    mc.field_1724.method_5660(true);
                }
            }

            if (data.test() == null || data.test().getAsBoolean()) {
                illegalRotate(data.exRotateData());
                if (isBucket) {
                    mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                }

                if (pri.bSetPacketPlace.get()) {
                    mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, getHitRes(pos, dir, hitVec), SeijaUtil.getSequence()));
                    mc.field_1724.field_3944.method_52787(new class_2879(class_1268.field_5808));
                } else {
                    mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, getHitRes(pos, dir, hitVec));
                    mc.field_1724.method_6104(class_1268.field_5808);
                }

                PosInfo blackInfo = isPlaceMode ? RenderHelper.getBlackInfo(pos.method_10093(dir), dir, hitVec, true):
                RenderHelper.getBlackInfo(pos, dir, hitVec, false);
                pri.blackList.add(blackInfo);
                RenderUtil.renderList.add(blackInfo);
            }

            if (sneakToggle) {
                mc.field_1724.method_5660(false);
            }

        };
        if (pri.bSetRotate.get() || isBucket) {
            if (pri.bSetPacketRotate.get()) {
                mc.field_1724.field_3944.method_52787(new class_2828.class_2831((float) SeijaUtil.getYaw(hitVec), (float) SeijaUtil.getPitch(hitVec), mc.field_1724.method_24828(), mc.field_1724.field_5976));
                r.run();
            } else
                Rotations.rotate(SeijaUtil.getYaw(hitVec), SeijaUtil.getPitch(hitVec), r);
        } else {
            r.run();
        }
    }

    public static void interactBlock(PlaceData data) {
        applyPlaceData(new PlaceDataPack(data,false));
//        Vec3d hitVec = data.hitVec();
//        final BlockPos.Mutable pos = new BlockPos.Mutable(data.pos().getX(), data.pos().getY(), data.pos().getZ());
//        Direction dir = data.dir();
//        Runnable r = () -> {
//            if (data.test() == null || data.test().getAsBoolean()) {
//                if (pri.bSetIllegalRotate.get() && data.exRotateData() != null) {
//                    mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround((float) data.exRotateData().yaw(), (float) data.exRotateData().pitch(), mc.player.isOnGround(), mc.player.horizontalCollision));
//                }//非法转头
//                if (pri.bSetPacketPlace.get()) {
//                    mc.player.networkHandler.sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, getHitRes(pos, dir, hitVec), SeijaUtil.getSequence()));
//                    mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
//                } else {
//                    mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, getHitRes(pos, dir, hitVec));
//                    mc.player.swingHand(Hand.MAIN_HAND);
//                }
//
//                PosInfo blackInfo = RenderHelper.getBlackInfo(pos, dir, hitVec, false);
//                pri.blackList.add(blackInfo);
//                RenderUtil.renderList.add(blackInfo);
//            }
//        };
//        if (pri.bSetRotate.get()) {
//            if (pri.bSetPacketRotate.get()) {
//                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround((float) SeijaUtil.getYaw(hitVec), (float) SeijaUtil.getPitch(hitVec), mc.player.isOnGround(), mc.player.horizontalCollision));
//                r.run();
//            } else
//                Rotations.rotate(SeijaUtil.getYaw(hitVec), SeijaUtil.getPitch(hitVec), r);
//        } else r.run();
    }

    public static void placeBlock(PlaceData data) {
        applyPlaceData(new PlaceDataPack(data,true));
//        final BlockPos.Mutable pos = new BlockPos.Mutable(data.pos().getX(), data.pos().getY(), data.pos().getZ());
//
//
//        Direction dir = data.dir();
//        Vec3d hitVec = data.hitVec();
//        final boolean isBucket = mc.player.getMainHandStack().getItem() instanceof BucketItem;
//
//        Runnable r = () -> {
//            boolean sneakToggle = false;
//            if (pri.bSetSneak.get()) {
//                if (!mc.player.isSneaking()) {
//                    sneakToggle = true;
//                    mc.player.setSneaking(true);
//                }
//            }
//            if (data.test() == null || data.test().getAsBoolean()) {
//                //非法转头
//                illegalRotate(data.exRotateData());
//                if (isBucket) {
//                    mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
//                }
//                if (pri.bSetPacketPlace.get()) {
//                    mc.player.networkHandler.sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, getHitRes(pos, dir, hitVec), SeijaUtil.getSequence()));
//                    mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
//                } else {
//                    mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, getHitRes(pos, dir, hitVec));
//                    mc.player.swingHand(Hand.MAIN_HAND);
//                }
//                PosInfo blackInfo = RenderHelper.getBlackInfo(pos.offset(dir), dir, hitVec, true);
//                pri.blackList.add(blackInfo);
//                RenderUtil.renderList.add(blackInfo);
//            }
//            if (sneakToggle) {
//                mc.player.setSneaking(false);
//            }
//
//        };
//        if (pri.bSetRotate.get() || isBucket) {
//            if (pri.bSetPacketRotate.get()) {
//                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround((float) SeijaUtil.getYaw(hitVec), (float) SeijaUtil.getPitch(hitVec), mc.player.isOnGround(), mc.player.horizontalCollision));
//                r.run();
//            } else
//                Rotations.rotate(SeijaUtil.getYaw(hitVec), SeijaUtil.getPitch(hitVec), r);
//        } else {
//            r.run();
//        }

    }
    //t inte f plac
    public static List<class_2350> getSortedDirs(class_2338 pos,boolean mode) {
        List<class_2350> dirs =  mode? getInteractDir(pos) : getDirs(pos);
        return pri.bSetSortDir.get() ?DirSorter.sort(dirs,pos,mode):dirs;
//        if (mode){
//            return pri.bSetSortDir.get() ? DirSorter.sort(getInteractDir(pos), pos) : getInteractDir(pos);
//        }
//        return pri.bSetSortDir.get() ? DirSorter.sort(getDirs(pos), pos) : getDirs(pos);
    }
    public static List<class_2350> getInteractDir(class_2338 pos) {
        if (!mc.field_1687.method_8621().method_11952(pos))return new LinkedList<>();
        return (pri.bSetStrictDir.get() ? canTorchFac(pos) : Arrays.asList(class_2350.values())).stream()
            .filter(dir -> (!pri.bSetStrictDir.get()) || canPlaceIn(pos.method_10093(dir)))
            .filter(dir -> pri.dRangeSetPrintingYRange.get().isInRange(pos.method_46558().method_43206(dir, 0.5).field_1351 - mc.field_1724.method_23318()))
            //高度检测 针对于放置比自己低太多的方块
            .filter(dir -> pos.method_46558().method_43206(dir, 0.5).method_1022(mc.field_1724.method_33571()) <= pri.dSetPrintingRange.get())
            //距离检测

            .collect(Collectors.toList());

    }
    public static List<class_2350> getDirs(class_2338 pos) {
//        if (!mc.world.getBlockState(pos).isReplaceable()){
//            return new ArrayList<>();
//        }
        List<class_2350> validDirs = getValidDirs(pos);
        return validDirs.stream()
//            .filter(dir -> {
//                BlockPos offset = pos.offset(dir);
//                BlockState bs = mc.world.getBlockState(offset);
//                if (pri.bSetAirPlace.get()) return true;
//                if (pri.bSetLiquidInt.get() && bs.getBlock() instanceof FluidBlock) return true;
//                return !bs.isReplaceable();
//            })
            .filter(dir -> !mc.field_1687.method_8320(pos.method_10093(dir)).method_45474())
            //不可被替换
            .filter(dir -> (mc.field_1687.method_8320(pos).method_26215()) || !mc.field_1687.method_8320(pos).method_30368(mc.field_1687, pos, dir, class_5431.field_25822))
            //方块自身阻挡检测
            .filter(dir -> pri.dRangeSetPrintingYRange.get().isInRange(pos.method_46558().method_43206(dir, 0.5).field_1351 - mc.field_1724.method_23318()))
            //高度检测 针对于放置比自己低太多的方块
            .filter(dir -> SeijaUtil.isSneak() || !isCanUseBlock(pos.method_10093(dir), mc.field_1687.method_8320(pos.method_10093(dir)), mc.field_1687))
            //不可交互
            .filter(dir -> pos.method_46558().method_43206(dir, 0.5).method_1022(mc.field_1724.method_33571()) <= pri.dSetPrintingRange.get())
            //距离检测
            .filter(dir-> mc.field_1687.method_8621().method_11952(pos.method_10093(dir)))
            //边境
            .collect(Collectors.toList());
    }


    public static void illegalRotate(RotationData data) {
        if (pri.bSetIllegalRotate.get() && data != null) {
//            if (mc.isInSingleplayer()) {
//                mc.player.lastYaw = (float) data.yaw();
//                PlayerMoveC2SPacket packet = new PlayerMoveC2SPacket.Full(mc.player.getX(), mc.player.getY(), mc.player.getZ(), (float) data.yaw(),
//                    (float) data.pitch(), mc.player.isOnGround(),mc.player.horizontalCollision);
//                mc.player.networkHandler.sendPacket(packet);
//            } else
            mc.field_1724.field_3944.method_52787(new class_2828.class_2831((float) data.yaw(), (float) data.pitch(), mc.field_1724.method_24828(), mc.field_1724.field_5976));
            mc.field_1724.field_3944.method_52787(new class_2828.class_2831((float) data.yaw(), (float) data.pitch(), mc.field_1724.method_24828(), mc.field_1724.field_5976));

        }
    }

    public static class_3965 getHitRes(class_2338 pos, class_2350 dir, class_243 hitVec) {
        class_243 eyes = PredictUtility.getPredPlayerVec().method_43206(class_2350.field_11036, SeijaUtil.getEyeHeight());
        boolean inside = eyes.field_1352 > (double) pos.method_10263() && eyes.field_1352 < (double) (pos.method_10263() + 1) && eyes.field_1351 > (double) pos.method_10264() && eyes.field_1351 < (double) (pos.method_10264() + 1) && eyes.field_1350 > (double) pos.method_10260() && eyes.field_1350 < (double) (pos.method_10260() + 1);
        return new class_3965(hitVec, dir, pos, inside);
    }

    public static List<class_2350> getValidDirs(class_2338 pos) {
        List<class_2350> values = new ArrayList<>(List.of(class_2350.values()));

        if (pri.bSetStrictDir.get()) {
            List<class_2350> directions = canTorchFac(pos);
            for (class_2350 direction : directions) {
                values.remove(direction);
            }
        }
        return values;
    }

    public static List<class_2350> canTorchFac(class_2338 pos) {
        List<class_2350> list = new LinkedList<>();
        if (mc.field_1724.method_33571().method_10214() < pos.method_10264())
            list.add(class_2350.field_11033);
        if (mc.field_1724.method_33571().method_10214() > pos.method_10264() + 1/*||pos.getY()<=mc.player.getEyePos().getY()+1*/)
            list.add(class_2350.field_11036);
        if (mc.field_1724.method_33571().method_10216() < pos.method_10263())
            list.add(class_2350.field_11039);
        if (mc.field_1724.method_33571().method_10216() > pos.method_10263() + 1)
            list.add(class_2350.field_11034);
        if (mc.field_1724.method_33571().method_10215() < pos.method_10260())
            list.add(class_2350.field_11043);
        if (mc.field_1724.method_33571().method_10215() > pos.method_10260() + 1)
            list.add(class_2350.field_11035);
        return list;
    }

    public static boolean canPlaceIn(class_2338 pos) {
        class_2248 block = mc.field_1687.method_8320(pos).method_26204();
        return isCanPlaceInBlock(block);
    }

    public static boolean isCanPlaceInBlock(class_2248 block) {
        return block instanceof class_2404 || block instanceof class_2189 || block instanceof class_4770;
    }

    public static List<class_2338> getSphere(class_2338 centerPos, int radius, int height) {
        ArrayList<class_2338> blocks = new ArrayList<class_2338>();
        for (int i = centerPos.method_10263() - radius; i < centerPos.method_10263() + radius; ++i) {
            for (int j = centerPos.method_10264() - height; j < centerPos.method_10264() + height; ++j) {
                for (int k = centerPos.method_10260() - radius; k < centerPos.method_10260() + radius; ++k) {
                    class_2338 pos = new class_2338(i, j, k);
                    if (!((double) radius > SeijaUtil.distanceBetween(centerPos, pos)) || blocks.contains(pos))
                        continue;
                    blocks.add(pos);
                }
            }
        }
        return blocks;
    }
    //区域内方块迭代 注意down向下要负数
    public static Iterable<class_2338> sphereIterate(class_2338 centerPos, int radius, int up,int down){
        return class_2338.method_10094(centerPos.method_10263()-radius,centerPos.method_10264()+down,centerPos.method_10260()-radius
        ,centerPos.method_10263()+radius,centerPos.method_10264()+up,centerPos.method_10260()+radius);
    }
    public static boolean blockposFilter(class_2338 pos){
        if (!DataManager.getRenderLayerRange().isPositionWithinRange(pos))
            return false;
        // 投影内不可见
        if (BlockUtil.isInBlackList(pos))
            return false;
        //黑名单内
        if (!BlockUtil.isValidState(BlockReplaceUtils.INSTANCE.getScheState(pos), pos))
            return false;
        //床头/上门无法放置
        if (!SurfaceUtil.surfaceCheck(pos, pri.iSetSurfaceSize.get()))
            return false;
        //表面模式检测
        return true;
    }
    //可以交互的方块列表
    public static List<Class<? extends class_2248>> canUseBlcks = new ArrayList<>(Arrays.asList(
        class_4739.class, class_2363.class, class_2304.class,
        class_2401.class,
        class_2323.class, class_2533.class, class_2244.class, class_2457.class,
        class_3736.class,
        class_2377.class, class_2331.class, class_2428.class, class_2387.class,
        class_2272.class,
        class_2349.class, class_2260.class, class_2328.class, class_2288.class,
        class_2238.class, class_2199.class, class_2286.class, class_2462.class,
        class_2325.class, class_2315.class, class_2480.class, class_3715.class,
        class_2362.class, class_3708.class, class_3709.class, class_3717.class,
        class_2406.class, class_3711.class, class_3713.class,
        class_3718.class, class_2478.class, class_5540.class));

    public static boolean isCanUseBlock(class_2338 p, class_2680 state, class_1937 world) {
        class_2248 block = state.method_26204();
        for (Class<? extends class_2248> canUseBlck : canUseBlcks) {
            if (canUseBlck.isInstance(block)) {
                return true;
            }
        }
        return state.method_26196(world, p) != null;
//        if (true)return false;//test
//        return (block instanceof AbstractRedstoneGateBlock
//            || block instanceof BlockWithEntity
//            || block instanceof ScaffoldingBlock
//            || block instanceof DoorBlock
//            || block instanceof TrapdoorBlock
//            || block instanceof FenceGateBlock
//            || block instanceof WallMountedBlock
//            || block instanceof ChestBlock
//            || block instanceof AnvilBlock
//            || block instanceof CraftingTableBlock
//            || block instanceof LoomBlock
//            || block instanceof EnderChestBlock
//            || block instanceof EnchantingTableBlock
//            || block instanceof SmithingTableBlock
//            || block instanceof GrindstoneBlock
//            || block instanceof StonecutterBlock
//
//        )
//            || (state.createScreenHandlerFactory(world, p) != null)
        //调用createScreenHandlerFactory检测对帧率影响极大


    }

    public static boolean isValidState(class_2680 needState, class_2338 pos) {
        if (needState.method_26204() instanceof class_2244) {
            return needState.method_11654(class_2741.field_12483) == class_2742.field_12557;
        } else if (needState.method_26204() instanceof class_2323
            || needState.method_26204() instanceof class_2320) {
            return needState.method_11654(class_2741.field_12533) == class_2756.field_12607;
        }
        return true;
    }

    //Vec扩展 给定方块点击面上的中心Vec 将Vec向四周扩展
    //给的是扩展的量而不是扩张后的坐标
    private static class_5819 random = new class_5820(2335353);

    private static double getRandomOffset() {
        return Printer.getINSTANCE().bSetRandomOffset.get() ?
            class_3532.method_15366(random, -0.15, 0.15) : 0;
    }

    public static class_243 randomOffsetVec(class_243 vec, class_2350 dir) {
        ArrayList<class_2350> extendDir = getExtendDir(dir);
        return vec.method_43206(extendDir.get(0), getRandomOffset()).method_43206(extendDir.get(2), getRandomOffset());
    }

    public static ArrayList<class_243> getExtendVec(class_2350 clickDir, boolean corner) {

        ArrayList<class_2350> extendDir = getExtendDir(clickDir);
        ArrayList<class_243> offVec = new ArrayList<>();
        for (int i = 0; i < extendDir.size(); i++) {
            if (corner) {
                if (i == 0) {
                    offVec.add(randomOffsetVec(
                        new class_243(0, 0, 0).method_43206(extendDir.get(i), 1)
                            .method_43206(extendDir.get(extendDir.size() - 1), 1)
                        , clickDir));
                } else offVec.add(randomOffsetVec(
                    new class_243(0, 0, 0).method_43206(extendDir.get(i - 1), 1)
                        .method_43206(extendDir.get(i), 1)
                    , clickDir));
            } else {
                offVec.add(randomOffsetVec(new class_243(0, 0, 0).method_43206(extendDir.get(i), 1), clickDir));
            }

        }
        return offVec;
    }

    public static ArrayList<class_2350> getExtendDir(class_2350 dir) {
        ArrayList<class_2350> directions = new ArrayList<>(List.of(class_2350.values()));
        directions.remove(dir);
        directions.remove(dir.method_10153());
        return directions;
    }

    public static boolean isStuckPos(class_2338 pos) {
        return SeijaUtil.intersectsWithEntity(new class_238(pos), entity -> !entity.method_7325() && !(entity instanceof class_1542) && !(entity instanceof class_1667));
    }



    /**
     * is in black list 判断某位置投影中的方块是否在黑名单内
     *
     * @param pos pos
     * @return {@link boolean}
     */
    public static boolean isInBlackList(class_2338 pos) {
        if (Printer.getINSTANCE().liSetBlackLists.get().contains(BlockReplaceUtils.INSTANCE.getScheState(pos).method_26204())) {
            return true;
        }
        for (PosInfo info : Printer.getINSTANCE().blackList) {
            if (info.pos().equals(pos)) {
                return true;
            }
        }
        return false;
    }

    //    public static Set<BlockPos> getSurface(BlockPos pos, int c) {
//        HashSet<BlockPos> pos1 = new LinkedHashSet<>();
//        pos1.add(pos);
//        for (int i = 0; i < c; i++) {
//            pos1 = getSurface(pos1);
//        }
//        return pos1;
//    }
//
//    private static HashSet<BlockPos> getSurface(HashSet<BlockPos> set) {
//        HashSet<BlockPos> poss = new HashSet<>();
//        for (BlockPos blockPos : set) {
//            for (Direction dir : Direction.values()) {
//                poss.add(blockPos.offset(dir));
//            }
//        }
//        return poss;
//    }


}


