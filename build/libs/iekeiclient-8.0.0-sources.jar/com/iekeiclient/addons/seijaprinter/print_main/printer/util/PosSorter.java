/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_310;

public class PosSorter {
    static class_310 mc = class_310.method_1551();
    static Printer pri = Printer.getINSTANCE();

    public static List<class_2338> sort(List<class_2338> l) {
        l.sort((pos1, pos2) -> {
            if (BlockReplaceUtils.INSTANCE.getScheState(pos1).method_26204().method_8389()
                .equals(mc.field_1724.method_6047().method_7909()) ^
                BlockReplaceUtils.INSTANCE.getScheState(pos2).method_26204().method_8389()
                    .equals(mc.field_1724.method_6047().method_7909())) {
                return BlockReplaceUtils.INSTANCE.getScheState(pos1).method_26204().method_8389()
                    .equals(mc.field_1724.method_6047().method_7909()) ? -1 : 1;
            }
            int angleVal ;
            switch (pri.eSetAngleSortMode.get()){
                case LOW -> angleVal = sortAngle(pos1, pos2);
                case HIGH -> angleVal = -sortAngle(pos1, pos2);
                default -> angleVal = 0;
            }

            if (angleVal != 0) return angleVal;
            else {
                int distanceVal;
                switch (pri.eSetDistanceSortMode.get()) {
                    case HIGH -> distanceVal = -Integer.compare((int) pos1.method_46558().method_1025(mc.field_1724.method_33571()), Integer.valueOf((int) pos2.method_46558().method_1025(mc.field_1724.method_33571())));
                    case LOW -> distanceVal = Integer.compare((int) pos1.method_46558().method_1025(mc.field_1724.method_33571()), Integer.valueOf((int) pos2.method_46558().method_1025(mc.field_1724.method_33571())));
                    default ->  distanceVal = 0;
                }
                return distanceVal;
            }
        });
        return l;
    }

    private static int sortAngle(class_2338 pos1, class_2338 pos2) {
        double e1yaw = Math.abs(SeijaUtil.getYaw(pos1.method_46558()) - mc.field_1724.method_36454());
        double e2yaw = Math.abs(SeijaUtil.getYaw(pos2.method_46558()) - mc.field_1724.method_36454());

        double e1pitch = Math.floor(Math.abs(SeijaUtil.getPitch(pos1.method_46558()) - mc.field_1724.method_36455())/20);
        double e2pitch = Math.floor(Math.abs(SeijaUtil.getPitch(pos2.method_46558()) - mc.field_1724.method_36455())/20);

        return Double.compare(e1yaw * e1yaw + e1pitch * e1pitch, e2yaw * e2yaw + e2pitch * e2pitch);
    }
}
