/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.state_decide.MainDecide;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockRotDataGetter;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.InvUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.*;
import com.iekeiclient.engine.utils.player.ChatUtils;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_2189;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2482;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4770;
import java.util.function.BooleanSupplier;

public class DataGetter {

    private static final class_310 mc = class_310.method_1551();
    private static final Printer pri = Printer.getINSTANCE();

    public static PlaceDataPack getData(class_2680 needState, DirData data, class_1799 stack) {
        if (needState.method_26204() instanceof class_2404) return PlaceDataPack.NULL;

        PlaceDataPack dataPla = getd(needState, data, stack,false);
        if (dataPla.data().valid()) {
            return dataPla;
        }

        return getd(needState, data, stack,true);
    }

    /**
     * getd
     *
     * @param needState needState
     * @param data      data
     * @param stack     stack
     * @param mode      true: 与自身位置交互 false 与相邻方块交互
     * @return {@link PlaceDataPack}
     * @see PlaceDataPack
     */
    private static PlaceDataPack getd(class_2680 needState, DirData data, class_1799 stack, boolean mode) {
        if (mode)data = new DirData(data.placePos(), BlockUtil.getSortedDirs(data.placePos(),true));
        class_2338 placePos = data.placePos();


        if (needState.method_26204().equals(mc.field_1687.method_8320(placePos).method_26204()))
            return PlaceDataPack.NULL;

        if (mode && !canInte(placePos)) {
            return PlaceDataPack.NULL;
        }
        RotationData rData = BlockRotDataGetter.getRotData(needState);
        fD:
        for (class_2350 offDir : data.dirs()) {
            fV:
            for (class_243 clickVec : mode ? data.clickVecsInte(offDir) : data.clickVecs(offDir)) {
                class_1750 placeContext = mode ? FakePlacementContext.getInstanceInte(clickVec, placePos, offDir, stack, rData)
                    : FakePlacementContext.getInstancePlac(clickVec, placePos, offDir, stack, rData);

                if (!mode && !mc.field_1687.method_8320(data.placePos()).method_26166(placeContext)) {

                    continue fD;
                }

                if (!placeContext.method_7716()) {

                    continue fD;
                }

                class_1747 bItem;
                try {
                    bItem = (class_1747) InvUtil.getItemFormBlock(needState.method_26204());
                    if (bItem == null) {

                        return PlaceDataPack.NULL;
                    }
                } catch (ClassCastException ignore) {
                    return PlaceDataPack.NULL;
                }
                class_2248 needBlock = bItem.method_7711();
                placeContext = bItem.method_16356(placeContext);
                if (placeContext == null) {

                    continue;
                };
                if (!needBlock.method_45382(placeContext.method_8045().method_45162())) {

                    continue;
                }
                if (!placeContext.method_7716()) {

                    continue fD;
                }//test
                class_2680 placementState = bItem.method_7707(placeContext);
                if (placementState == null) {

                    continue;
                }
                if (!MainDecide.INSTANCE.test(needState, placementState, placePos)) {

                    continue fV;
                }
                BooleanSupplier verify = () -> {
                    FakePlacementContext contextVerify = BlockStateVerify.getContextVerify(clickVec, mode ? placePos : placePos.method_10093(offDir), mode ? offDir : offDir.method_10153(), stack, rData);
                    if (contextVerify.method_8037().equals(placePos) && contextVerify.method_8038().equals(mode ? offDir : offDir.method_10153())) {
                        class_2680 currentState = BlockStateVerify.genBlockState(contextVerify, needBlock);
                        if (currentState==null) {
                            return false;
                        }
                        return MainDecide.INSTANCE.test(needState, currentState, placePos);
                    }
                    //ChatUtils.sendMsg(Text.of("RDir " + contextVerify.getSide() + "TDir: " + offDir.getOpposite()));
                    //ChatUtils.sendMsg(Text.of("RPos " + contextVerify.getBlockPos() + "TPos: " + placePos.offset(offDir)));
                    return false;
                };
                if (mode)
                    return PlaceDataPack.inte(new PlaceData(placePos, offDir, clickVec, true, rData, verify));
                else
                    return PlaceDataPack.plac(new PlaceData(placePos.method_10093(offDir), offDir.method_10153(), clickVec, true, rData, verify));
            }
        }

        return PlaceDataPack.NULL;
    }

    private static PlaceDataPack getDataInt(class_2680 needState, DirData data, class_1799 stack) {
        class_2338 placePos = data.placePos();
        if (needState.method_26204().equals(mc.field_1687.method_8320(placePos).method_26204())) {
            return PlaceDataPack.NULL;
        }
        if (!canInte(placePos)) {
            return PlaceDataPack.NULL;
        }

        RotationData rData = BlockRotDataGetter.getRotData(needState);
        fD:
        for (class_2350 offDir : data.dirs()) {
            fV:
            for (class_243 clickVec : data.clickVecsInte(offDir)) {
                class_1750 placeContext = FakePlacementContext.getInstanceInte(clickVec, placePos, offDir, stack, rData);

                if (!mc.field_1687.method_8320(data.placePos()).method_26166(placeContext)) {
                    continue fD;
                }
                class_1747 bItem;
                try {
                    bItem = (class_1747) InvUtil.getItemFormBlock(needState.method_26204());
                    if (bItem == null) return PlaceDataPack.NULL;
                } catch (ClassCastException ignore) {
                    return PlaceDataPack.NULL;
                }
                final class_2248 needBlock = bItem.method_7711();
                placeContext = bItem.method_16356(placeContext);
                //重新赋值 mojang在BlockItem L74这样写的
                if (placeContext == null) continue;
                if (!needBlock.method_45382(placeContext.method_8045().method_45162())) {
                    continue;
                }
                if (!placeContext.method_7716()) {
                    continue fD;
                }//test
                class_2680 placementState = bItem.method_7707(placeContext);
                if (placementState == null) {
                    continue;
                }
                if (!MainDecide.INSTANCE.test(needState, placementState, placePos)) {
                    continue fV;
                }
                BooleanSupplier verify = () -> {
                    FakePlacementContext contextVerify = BlockStateVerify.getContextVerify(clickVec, placePos, offDir, stack, rData);
                    if (contextVerify.method_8037().equals(placePos) && contextVerify.method_8038().equals(offDir)) {
                        class_2680 currentState = BlockStateVerify.genBlockState(contextVerify, needBlock);
                        return MainDecide.INSTANCE.test(needState, currentState, placePos);
                    }
                    ChatUtils.sendMsg(class_2561.method_30163("RDir " + contextVerify.method_8038() + "TDir: " + offDir.method_10153()));
                    ChatUtils.sendMsg(class_2561.method_30163("RPos " + contextVerify.method_8037() + "TPos: " + placePos.method_10093(offDir)));
                    return false;
                };
                return PlaceDataPack.inte(new PlaceData(placePos, offDir, clickVec, true, rData, verify));
            }
        }
        return PlaceDataPack.NULL;
    }

    private static boolean canInte(class_2338 pos) {
        class_2248 block = mc.field_1687.method_8320(pos).method_26204();
        if (((block instanceof class_2189) || (block instanceof class_4770)) && pri.bSetAirPlace.get()) {
            return true;
        }
        if ((block instanceof class_2404) && (pri.bSetAirPlace.get() || pri.bSetLiquidInt.get())) {
            return true;
        }
        return (!BlockUtil.canPlaceIn(pos)) || block instanceof class_2482;
    }

    private static PlaceDataPack getDataPla(class_2680 needState, DirData data, class_1799 stack) {
        class_2338 placePos = data.placePos();


        if (needState.method_26204().equals(mc.field_1687.method_8320(placePos).method_26204()))
            return PlaceDataPack.NULL;
        RotationData rData = BlockRotDataGetter.getRotData(needState);
        fD:
        for (class_2350 offDir : data.dirs()) {
            fV:
            for (class_243 clickVec : data.clickVecs(offDir)) {
                class_1750 placeContext = FakePlacementContext.getInstancePlac(clickVec, placePos, offDir, stack, rData);

                if (!placeContext.method_7716()) {
                    continue fD;
                }

                //检测支撑方块是否会被替换 若会被替换则结束
                class_1747 bItem;
                try {
                    bItem = (class_1747) InvUtil.getItemFormBlock(needState.method_26204());
                    if (bItem == null) return PlaceDataPack.NULL;
                } catch (ClassCastException ignore) {
                    return PlaceDataPack.NULL;
                }
                class_2248 needBlock = bItem.method_7711();
                placeContext = bItem.method_16356(placeContext);
                if (placeContext == null) continue;
                //重新赋值 mojang在BlockItem L74这样写的
                if (!needBlock.method_45382(placeContext.method_8045().method_45162())) {
                    continue;
                }

                class_2680 placementState = bItem.method_7707(placeContext);
                //更换世界后这边会失效 需要更新测试假人
                if (placementState == null) {
                    continue;
                }
                if (!MainDecide.INSTANCE.test(needState, placementState, placePos)) {
                    continue fV;
                }
                BooleanSupplier verify = () -> {
                    FakePlacementContext contextVerify = BlockStateVerify.getContextVerify(clickVec, placePos.method_10093(offDir), offDir.method_10153(), stack, rData);
                    if (contextVerify.method_8037().equals(placePos) && contextVerify.method_8038().equals(offDir.method_10153())) {
                        class_2680 currentState = BlockStateVerify.genBlockState(contextVerify, needBlock);
                        return MainDecide.INSTANCE.test(needState, currentState, placePos);
                    }

                    return false;
                };

                return PlaceDataPack.plac(new PlaceData(placePos.method_10093(offDir), offDir.method_10153(), clickVec, true, rData, verify));
            }
        }
        return PlaceDataPack.NULL;
    }

}
