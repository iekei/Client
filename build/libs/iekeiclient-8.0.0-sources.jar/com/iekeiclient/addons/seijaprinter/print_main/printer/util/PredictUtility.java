/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

// Decompiled with: CFR 0.152
// Class Version: 17
package com.iekeiclient.addons.seijaprinter.print_main.printer.util;


import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.mojang.authlib.GameProfile;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_1293;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class PredictUtility {
    static class_310 mc = class_310.method_1551();
    public static class_1657 predictPlayer(class_1657 entity, int ticks) {
        if (ticks<=0)return entity;
        class_243 posVec = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
        double motionX = entity.method_23317() - entity.field_6014;
        double motionY = entity.method_23318() - entity.field_6036;
        double motionZ = entity.method_23321() - entity.field_5969;
        for (int i = 0; i < ticks; ++i) {
            if (!mc.field_1687.method_22347(class_2338.method_49638(posVec.method_1031(0.0, motionY, 0.0)))) {
                motionY = 0.0;
            }
            if (!mc.field_1687.method_22347(class_2338.method_49638(posVec.method_1031(motionX, 0.0, 0.0))) || !mc.field_1687.method_22347(class_2338.method_49638(posVec.method_1031(motionX, 1.0, 0.0)))) {
                motionX = 0.0;
            }
            if (!mc.field_1687.method_22347(class_2338.method_49638(posVec.method_1031(0.0, 0.0, motionZ))) || !mc.field_1687.method_22347(class_2338.method_49638(posVec.method_1031(0.0, 1.0, motionZ)))) {
                motionZ = 0.0;
            }
            posVec = posVec.method_1031(motionX, motionY, motionZ);
        }
        return PredictUtility.equipAndReturn(entity, posVec);
    }

    public static class_243 getPredPlayerVec(){
        return predictPlayerVec(mc.field_1724, Printer.getINSTANCE().iSetPredTick.get());
    }
    public static class_243 predictPlayerVec(class_1657 entity, int ticks) {
        //if (ticks<=0)return entity;
        class_243 posVec = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
        double motionX = entity.method_23317() - entity.field_6014;
        double motionY = entity.method_23318() - entity.field_6036;
        double motionZ = entity.method_23321() - entity.field_5969;
        for (int i = 0; i < ticks; ++i) {
            if (!mc.field_1687.method_22347(class_2338.method_49638(posVec.method_1031(0.0, motionY, 0.0)))) {
                motionY = 0.0;
            }
            if (!mc.field_1687.method_22347(class_2338.method_49638(posVec.method_1031(motionX, 0.0, 0.0))) || !mc.field_1687.method_22347(class_2338.method_49638(posVec.method_1031(motionX, 1.0, 0.0)))) {
                motionX = 0.0;
            }
            if (!mc.field_1687.method_22347(class_2338.method_49638(posVec.method_1031(0.0, 0.0, motionZ))) || !mc.field_1687.method_22347(class_2338.method_49638(posVec.method_1031(0.0, 1.0, motionZ)))) {
                motionZ = 0.0;
            }
            posVec = posVec.method_1031(motionX, motionY, motionZ);
        }
        return posVec;
        //return PredictUtility.equipAndReturn(entity, posVec);
    }

    public static class_1657 equipAndReturn(class_1657 original, class_243 posVec) {
        class_1657 copyEntity = new class_1657(mc.field_1687, new GameProfile(UUID.fromString("66123666-1234-5432-6666-667563866600"), "PredictEntity339")){


            @Override
            public class_1934 method_68876() {
                return class_1934.field_9215;
            }
        };

        copyEntity.method_33574(posVec);
        copyEntity.method_6033(original.method_6032());
        copyEntity.field_6014 = original.field_6014;
        copyEntity.field_5969 = original.field_5969;
        copyEntity.field_6036 = original.field_6036;
        copyEntity.method_31548().method_7377(original.method_31548());
        copyEntity.method_36456(original.method_36454());
        copyEntity.method_36457(original.method_36455());
        copyEntity.field_5982 = original.field_5982;
        copyEntity.field_6241 = original.field_6241;
        copyEntity.field_6283 = original.field_6283;
        copyEntity.field_6259 = original.field_6259;
        copyEntity.field_6004 = original.field_6004;
        for (class_1293 se : original.method_6026()) {
            copyEntity.method_6092(se);
        }
        return copyEntity;
    }

    public static class_243 clone(class_243 v) {
        return new class_243(v.method_10216(), v.method_10214(), v.method_10215());
    }
}
