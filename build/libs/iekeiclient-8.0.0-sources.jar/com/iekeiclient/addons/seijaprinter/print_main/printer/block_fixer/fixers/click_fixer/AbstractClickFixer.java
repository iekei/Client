/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers.click_fixer;

import com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.AbstractFixer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirDataI;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceData;
import com.iekeiclient.engine.settings.BoolSetting;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public abstract class AbstractClickFixer extends AbstractFixer {
    public AbstractClickFixer(String name) {
        super(name);
    }
    public AbstractClickFixer(BoolSetting setting){
        super(setting);

    }

    @Override
    public int fixBlock(class_2338 pos, class_2680 needState) {

//        BlockUtil.interactBlock(pos,interactDir.get(0));
        DirData dirData = new DirData(pos, BlockUtil.getSortedDirs(pos,true));
        for (class_2350 dir : dirData.dirs()) {
            for (class_243 clickVec : dirData.clickVecsInte(dir)) {
                BlockUtil.interactBlock(PlaceData.newInstance(dirData.placePos(),dir,clickVec,true,null));
                return AbstractFixer.SUCCESS;
            }
        }
        return AbstractFixer.CONTINUE;
    }

    @Override
    public boolean needFix(class_2338 pos, class_2680 needState) {
        List<class_2350> interactDir = BlockUtil.getSortedDirs(pos,true);
        if (interactDir.isEmpty())
            return false;
        return true;
    }
}
