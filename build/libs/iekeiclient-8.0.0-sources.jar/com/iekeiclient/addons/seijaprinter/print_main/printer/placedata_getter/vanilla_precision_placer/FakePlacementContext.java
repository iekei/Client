/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer;

import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.PredictUtility;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.RayTraceUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.SeijaUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.RotationData;
import com.mojang.authlib.GameProfile;
import com.iekeiclient.engine.utils.player.ChatUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;


import java.util.UUID;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public class FakePlacementContext extends class_1750 {


    private static final class_310 mc = class_310.method_1551();

    public static class_1657 getFakePlayer() {
        return fakePlayer;
    }

    protected static class_1657 fakePlayer;

    //        ;= new PlayerEntity(mc.world, BlockPos.ORIGIN, 1, new GameProfile(UUID.fromString("66123666-1234-5432-6666-667563866600"), "PredictEntity339")){
//
//        public boolean isSpectator() {
//            return false;
//        }
//
//        public boolean isCreative() {
//            return false;
//        }
//    };
    public static void updatePlayerEntity() {
        fakePlayer = new class_1657(mc.field_1687, new GameProfile(UUID.fromString("66123666-1234-5432-6666-667563866600"), "PredictEntity339")) {



            @Override
            public void method_5773() {

            }

            @Override
            public @NotNull class_1934 method_68876() {
                return class_1934.field_9215;
            }

        };
    }

    protected static void setRotate(class_1657 e, float yaw, float pitch) {
        e.method_36456(yaw);
        e.method_36457(pitch);
        e.method_5847(yaw);
        e.method_5636(yaw);

        e.field_6259 = yaw;
        e.field_5982 = yaw;
        e.field_6004 = pitch;

    }
    protected static void setMovementMode(class_1657 e){
        e.method_5796(mc.field_1724.method_5681());
        if (mc.field_1724.method_6128()) {
            e.method_23669();
        }else e.method_66281();
    }

    public static FakePlacementContext getInstanceInte(class_243 clickVec, class_2338 placePos, class_2350 offsetDir, class_1799 stack) {
        class_3965 hitRes = BlockUtil.getHitRes(placePos, offsetDir, clickVec);
        fakePlayer.method_33574(PredictUtility.getPredPlayerVec());
        setRotate(fakePlayer,(float) SeijaUtil.getYaw(clickVec),(float) SeijaUtil.getPitch(clickVec));
        setMovementMode(fakePlayer);
        fakePlayer.method_5660(SeijaUtil.isSneak());
        return new FakePlacementContext(fakePlayer, class_1268.field_5808, stack, hitRes);
    }

    public static FakePlacementContext getInstanceInte(class_243 clickVec, class_2338 placePos, class_2350 offsetDir, class_1799 stack, @Nullable RotationData rdata) {
        if (rdata == null) return getInstanceInte(clickVec, placePos, offsetDir, stack);
        class_3965 hitRes = BlockUtil.getHitRes(placePos, offsetDir, clickVec);
        fakePlayer.method_33574(PredictUtility.getPredPlayerVec());
        setRotate(fakePlayer,(float) rdata.yaw(),(float) rdata.pitch());
        setMovementMode(fakePlayer);
        fakePlayer.method_5660(SeijaUtil.isSneak());
        return new FakePlacementContext(fakePlayer, class_1268.field_5808, stack, hitRes);
    }

    public static FakePlacementContext getInstancePlac(class_243 clickVec, class_2338 placePos, class_2350 offsetDir, class_1799 stack) {
        return getInstanceInte(clickVec, placePos.method_10093(offsetDir), offsetDir.method_10153(), stack);

//        BlockHitResult hitRes = BlockUtil.getHitRes(placePos.offset(offsetDir), offsetDir.getOpposite(), clickVec);
//        fakePlayer.setPosition(PredictUtility.getPredPlayerVec());
//        fakePlayer.setYaw((float) SeijaUtil.getYaw(clickVec));
//        fakePlayer.setPitch((float) SeijaUtil.getPitch(clickVec));
//        fakePlayer.setSneaking(SeijaUtil.isSneak());
//        return new FakePlacementContext(fakePlayer,Hand.MAIN_HAND,stack,hitRes);
    }

    //方便使用
    //直接拿get到的方向和要填充方块的坐标带入即可
    public static FakePlacementContext getInstancePlac(class_243 clickVec, class_2338 placePos, class_2350 offsetDir, class_1799 stack, @Nullable RotationData rdata) {
        return getInstanceInte(clickVec, placePos.method_10093(offsetDir), offsetDir.method_10153(), stack, rdata);
    }



    public FakePlacementContext(class_1657 player, class_1268 hand, class_1799 stack, class_3965 hitResult) {
        super(player, hand, stack, hitResult);
        //updatePlayerEntity();
    }

    @Override
    public String toString() {
        return "Vec: " + method_30344().method_17784() + " Block: " + method_30344().method_17777()
            + " Dir: " + method_30344().method_17780();
    }
}
