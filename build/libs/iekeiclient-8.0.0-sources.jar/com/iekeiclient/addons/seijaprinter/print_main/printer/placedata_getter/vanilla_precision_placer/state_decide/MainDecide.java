/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.state_decide;

import com.iekeiclient.addons.seijaprinter.print_main.printer.extra_setting.HasExtraSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.settings.Settings;
import com.iekeiclient.engine.utils.player.ChatUtils;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2769;

public class MainDecide implements HasExtraSetting {
    public static final MainDecide INSTANCE = new MainDecide();
    private final List<Decide> DECIDES = new ArrayList<>();

    private MainDecide() {
        DECIDES.add(new MultifaceGrowthDecide());
        DECIDES.add(new ChestDecide());
        DECIDES.add(new SlabDecide());
        DECIDES.add(new FallingBlockDecide());
    }

    public static class_2769[] props = new class_2769[]{
        class_2741.field_12525, class_2741.field_12481, class_2741.field_12518
        , class_2741.field_12520, class_2741.field_12496, class_2741.field_17104
        , class_2741.field_12545, class_2741.field_12532, class_2741.field_12555
        , class_2741.field_12506, class_2741.field_12485, class_2741.field_23333
    };

    public boolean test(class_2680 needState, class_2680 nowState, class_2338 placePos) {
        for (Decide decide : DECIDES) {
            if (decide.isSuit(needState, nowState, placePos)) {
                return decide.test(needState, nowState, placePos);
            }
        }
        return defaultTest(needState, nowState, placePos);
//        for (Property property : props) {
//            Comparable now = null;
//            Comparable need = null;
//
//            try {
//                now = nowState.get(property);
//            } catch (IllegalArgumentException ignored) {
//            }
//            try {
//                need = needState.get(property);
//            } catch (IllegalArgumentException ignored) {
//            }
//
//            if (now != need) {
////                ChatUtils.sendMsg(Text.of("Now:"+now+"need:"+need));
////                for (Property<?> nowStateProperty : nowState.getProperties()) {
////                    ChatUtils.sendMsg(Text.of(nowStateProperty+" : "+needState.get(nowStateProperty)));
////                }
//                return false;
//            }
//        }
//        return true;
    }

    public static boolean defaultTest(class_2680 needState, class_2680 nowState, class_2338 placePos) {
        for (class_2769 property : props) {
            Comparable now = null;
            Comparable need = null;

            try {
                now = nowState.method_11654(property);
            } catch (IllegalArgumentException ignored) {
            }
            try {
                need = needState.method_11654(property);
            } catch (IllegalArgumentException ignored) {
            }

            if (now != need) {
//                ChatUtils.sendMsg(Text.of("Now:"+now+"need:"+need));
//                for (Property<?> nowStateProperty : nowState.getProperties()) {
//                    ChatUtils.sendMsg(Text.of(nowStateProperty+" : "+needState.get(nowStateProperty)));
//                }
                return false;
            }
        }
        return true;
    }

    @Override
    public SettingGroup getSettingGroup(Settings settings) {
        SettingGroup sgDecide = settings.createGroup("BlockDecide");
        for (Decide decide : DECIDES) {
            for (Setting<?> setting : decide.getSettings()) {
                sgDecide.add(setting);
            }
        }
        return sgDecide;
    }
}
