/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import fi.dy.masa.litematica.world.SchematicWorldHandler;
import com.iekeiclient.engine.utils.player.InvUtils;
import net.minecraft.block.*;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2350;
import net.minecraft.class_2362;
import net.minecraft.class_2369;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 方块替换计算
 * 用于计算投影中某位置方块状态应该替换为啥样的
 */
public class BlockReplaceUtils {
    public static final BlockReplaceUtils INSTANCE = new BlockReplaceUtils();
    Printer pri = Printer.getINSTANCE();

    public static class_2680 getScheStateNonReplace(class_2338 pos){
       return SchematicWorldHandler.getSchematicWorld().method_8320(pos);
    }


    /**
     * 桥模式时计算周围方块是否需要支持时使用
     *
     * @param pos pos
     * @return {@link class_2680}
     * @see class_2680
     */
    public class_2680 getScheState(class_2338 pos) {
        return replaceState(getScheStateNonReplace(pos), pos);
    }

    public class_2680 replaceState(class_2680 state, class_2338 pos) {

        class_2680 repState = needBlockReplace(state, pos, true).method_9564();
        try {
            for (class_2769 property : state.method_28501()) {
                repState = repState.method_11657(property, state.method_11654(property));
            }
        } catch (Exception ignored) {

        }
        return repState;
    }
    public List<class_2248> getReplaceBlocks(class_2248 b){
        for (Map.Entry<List<class_2248>, List<class_2248>> entry : pri.getBlockReplaceMapping().entrySet()) {
            if (entry.getKey().contains(b))
                return entry.getValue();
        }
        return List.of();
    }
    private class_2248 needBlockReplace(class_2680 bs, class_2338 pos, boolean calcBridge) {
        List<class_2248> blocks = null;
//        for (Map.Entry<List<Block>, List<Block>> entry : pri.getBlockReplaceMapping().entrySet()) {
//            if (entry.getKey().contains(bs.getBlock()))
//                blocks = entry.getValue();
//        }
        blocks = getReplaceBlocks(bs.method_26204());
        if (blocks != null && !blocks.isEmpty())
            for (class_2248 b : blocks) {
                if (InvUtils.find(class_1792.field_8003.get(b)).found())
                    return b;
            }
        if (calcBridge) {
            class_2248 bridgedBlockReplace = BlockReplaceUtils.INSTANCE.bridgeBlockReplace(bs, pos);
            if (bridgedBlockReplace != null)
                return bridgedBlockReplace;
        }

        if (blocks == null || blocks.isEmpty()) return bs.method_26204();
        return blocks.getFirst();
    }

    public class_2680 normalReplaceState(class_2680 state) {

        class_2248 replaceBlock = normalReplaceBlock(state);
        if (replaceBlock == null) return state;
        class_2680 repState = replaceBlock.method_9564();
        try {
            for (class_2769 property : state.method_28501()) {
                repState = repState.method_11657(property, state.method_11654(property));
            }
        } catch (Exception ignored) {

        }
        return repState;
    }

    public class_2248 normalReplaceBlock(class_2680 bs) {

        if (bs.method_26204() instanceof class_2362)
            return class_2246.field_10495;
        else if (bs.method_26204() instanceof class_2465 && InvUtil.findItem(stack -> stack.method_7909() instanceof class_1743) && (!InvUtil.findBlock(bs.method_26204()))) {
            return strippedMap.get(bs.method_26204());
        } else if (bs.method_26204() instanceof class_2344 || bs.method_26204() instanceof class_2369) {
            for (class_2248 dirt : DIRTS) {
                if (InvUtil.findBlock(dirt))
                    return dirt;
            }
        }
        return null;
    }

    public static final class_2248[] DIRTS = new class_2248[]{class_2246.field_10566, class_2246.field_10219};


    public class_2248 bridgeBlockReplace(class_2680 bs, class_2338 pos) {
        List<class_2350> interactDir = Collections.emptyList();

        if (
            pri.bSetBridgeMode.get()//开了桥模式
                && BlockUtil.isCanPlaceInBlock(bs.method_26204())//替换的位置原本需要方块为空
                && pos != null
                && BlockUtil.canPlaceIn(pos)//实际也为空
                && (!BlockUtil.getDirs(pos).isEmpty())//有点击方位
                && (! (interactDir = BlockUtil.getSortedDirs(pos,true)).isEmpty())//有用
        )
        {
            for (class_2350 direction : interactDir) {
                if (pri.liSetBridgeDirs.get().contains(direction)//是可以用的方位
                    && !BlockUtil.isCanPlaceInBlock(getScheStateBridegeMode(pos.method_10093(direction)).method_26204())
                    //被支持的方块是投影中是需要放置的方块
                    && BlockUtil.getDirs(pos.method_10093(direction)).isEmpty()//被支持的方块不能直接放置
                    && BlockUtil.canPlaceIn(pos.method_10093(direction))//被支持的方块还没被放置
                ) {
                    //可用支撑
                    for (class_2248 block : pri.liSetBridgeBlocks.get()) {
                        if (InvUtil.findBlock(block)) return block;
                    }
                    return null;
                }
            }

        }
        return null;
    }


    private class_2680 getScheStateBridegeMode(class_2338 pos) {
        class_2680 state = SchematicWorldHandler.getSchematicWorld().method_8320(pos);
        class_2680 repState = needBlockReplace(state, pos, false).method_9564();
        try {
            for (class_2769 property : state.method_28501()) {
                repState = repState.method_11657(property, state.method_11654(property));
            }
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return repState;
    }


    public final Map<class_2248, class_2248> strippedMap = new HashMap<>();

    //把mc的Map反过来 方便查询
    private void initMap() {
        for (Map.Entry<class_2248, class_2248> blockBlockEntry : class_1743.field_7898.entrySet()) {
            strippedMap.put(blockBlockEntry.getValue(), blockBlockEntry.getKey());
        }
    }

    private BlockReplaceUtils() {
        initMap();
    }

}
