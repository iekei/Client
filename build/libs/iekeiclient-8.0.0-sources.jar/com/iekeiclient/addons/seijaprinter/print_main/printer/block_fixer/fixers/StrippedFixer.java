/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers;

import com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.AbstractFixer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirDataI;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.InvUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceData;
import java.util.List;
import net.minecraft.class_1743;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public class StrippedFixer extends AbstractFixer {
    public StrippedFixer() {
        super("LogFix");
    }

    @Override
    public int fixBlock(class_2338 pos, class_2680 needState) {
        List<class_2350> interactDir = BlockUtil.getSortedDirs(pos,true);
        DirData dirData = new DirData(pos, interactDir);
        if (InvUtil.findItem(stack -> stack.method_7909() instanceof class_1743)) {
            for (class_2350 dir : interactDir) {
                for (class_243 clickVec : dirData.clickVecsInte(dir)) {
                    if (InvUtil.switchItem(stack -> stack.method_7909() instanceof class_1743)) {
                        BlockUtil.interactBlock(PlaceData.newInstance(dirData.placePos(),dir,clickVec,true,null));
                        return SUCCESS;
                    }else return RETURN;
                }
            }
        }
        return CONTINUE;
    }

    @Override
    public boolean needFix(class_2338 pos, class_2680 needState) {
        class_2680 blockState = mc.field_1687.method_8320(pos);
        //不用内置规则替换
        class_2248 needBlock = needState.method_26204();
        class_2248 strippedBlock = class_1743.field_7898.get(blockState.method_26204());
        return needBlock.equals(strippedBlock);

    }
}
