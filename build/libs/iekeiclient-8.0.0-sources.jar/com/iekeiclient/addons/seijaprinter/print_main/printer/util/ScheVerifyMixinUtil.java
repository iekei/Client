/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import java.util.*;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2769;

/**
 * sche verify mixin util
 * 用于Mixin投影 让方块替换不爆红
 */
public class ScheVerifyMixinUtil {
    //    public static boolean isReplacedStateEqual(BlockState sche, BlockState client){
//        return isReplacedBlockEqual(sche.getBlock(), client.getBlock())&& propEqual(sche.getProperties(),client.getProperties());
//    }
    //判断方块是否符合需求
    public static boolean isReplacedBlockEqual(class_2248 sche, class_2248 client) {
        //List<Block> blocks = Printer.getINSTANCE().replaceMap.get(sche);
        List<class_2248> blocks = null;
        for (Map.Entry<List<class_2248>, List<class_2248>> entry : Printer.getINSTANCE().getBlockReplaceMapping().entrySet()) {
            if (entry.getKey().contains(sche))
                blocks = entry.getValue();
        }

        //if (blocks!=null)return blocks.contains(client);
        return sche.equals(client) || (blocks != null && blocks.contains(client));
        //实际与投影相等或者在投影中方块有代替方案且实际方块符合代替方案
    }

    //比较2方块的Property是否相等
    public static boolean propEqual(class_2680 sche, class_2680 client) {
        Collection<class_2769<?>> c1 = sche.method_28501();
        Collection<class_2769<?>> c2 = client.method_28501();
        if (c1.size() != c2.size()) return false;
        for (class_2769<?> property : c1) {
            Comparable now = null;
            Comparable need = null;
            try {
                now = client.method_11654(property);
            } catch (IllegalArgumentException ignored) {
            }
            try {
                need = sche.method_11654(property);
            } catch (IllegalArgumentException ignored) {
            }
            if (now != need) {
                return false;
            }
        }
        return true;
    }
}
