/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers;

import com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.AbstractFixer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockRotDataGetter;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.InvUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.SeijaUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirDataI;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PosInfo;
import com.iekeiclient.engine.utils.render.color.Color;
import java.util.List;
import net.minecraft.class_2189;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3736;

public class ScaffoldFixer extends AbstractFixer {


    public ScaffoldFixer() {
        super("ScaffoldFix");
    }

    @Override
    public int fixBlock(class_2338 pos, class_2680 needState) {
        for (class_2350 off : class_2350.values()) {
            if (off == class_2350.field_11036) continue;
            class_2338 helperPos = pos.method_10093(off);
            if (!(mc.field_1687.method_8320(helperPos).method_26204() instanceof class_3736
            &&mc.field_1687.method_8320(helperPos).method_11654(class_3736.field_16495)<6)) continue;
            List<class_2350> dirs = BlockUtil.getSortedDirs(helperPos,true);
            if (off != class_2350.field_11033) {

                if (!dirs.contains(class_2350.field_11036)) continue;
                DirData data = new DirData(helperPos, dirs);

                for (class_243 clickVec : data.clickVecsInte(class_2350.field_11036)) {

                    PlaceData interactData = PlaceData.NULL;
                    if (pri().bSetIllegalRotate.get()) {
                        interactData = PlaceData.newInstance(helperPos, class_2350.field_11036, clickVec, true, BlockRotDataGetter.getRotateDataFromDir(off.method_10153()));
                    } else if (class_2350.method_10150(SeijaUtil.getYaw(clickVec)) == off.method_10153())
                        //1.21 Direction.fromRotation
                    {
                        interactData = PlaceData.newInstance(helperPos, class_2350.field_11036, clickVec, true, null);
                    }
                    if (interactData.valid()){
                        if (InvUtil.switchBlock(class_2246.field_16492)) {
                            BlockUtil.interactBlock(interactData);
                            PosInfo blackInfo = new PosInfo(pos, off, clickVec, false, System.currentTimeMillis(), Color.BLACK);
                            pri().blackList.add(blackInfo);
                            return SUCCESS;
                        }else return RETURN;
                    }
                }
            } else {
                dirs.remove(class_2350.field_11036);
                DirData data = new DirData(helperPos, dirs);
                for (class_2350 clickDir : dirs) {
                    for (class_243 clickVec : data.clickVecsInte(clickDir)) {
                        PlaceData interactData =  PlaceData.newInstance(helperPos, clickDir, clickVec, true, null);
                        if (InvUtil.switchBlock(class_2246.field_16492)) {
                            BlockUtil.interactBlock(interactData);
                            PosInfo blackInfo = new PosInfo(pos, off, clickVec, false, System.currentTimeMillis(), Color.BLACK);
                            pri().blackList.add(blackInfo);
                            return SUCCESS;
                        }else return RETURN;
                    }
                }
            }
        }
        return CONTINUE;
    }

    @Override
    public boolean needFix(class_2338 pos, class_2680 needState) {
        return mc.field_1687.method_8320(pos).method_26204()instanceof class_2189
            &&needState.method_26204()instanceof class_3736;
    }
}
