/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.state_decide;

import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.utils.player.ChatUtils;
import net.minecraft.class_10376;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2769;


public class MultifaceGrowthDecide implements Decide {
    private final class_2769[] facProps = new class_2769[]{
        class_2741.field_12527, class_2741.field_12487, class_2741.field_12519, class_2741.field_12546
        , class_2741.field_12489, class_2741.field_12540
    };

    @Override
    public boolean test(class_2680 needState, class_2680 nowState, class_2338 ignore) {
//        for (Property<?> property : needState.getProperties()) {
//            ChatUtils.sendMsg(Text.of(property.getName()+",,,"+property.getType()+",,,"+property.getClass().getName()));
//        }
        for (class_2769 prop : facProps) {

            try {
                //ChatUtils.sendMsg(Text.of(prop.getName() + needState.get(prop) + "," + nowState.get(prop)));
                if ((needState.method_11654(prop).equals(nowState.method_11654(prop))) && (nowState.method_11654(prop).equals(Boolean.TRUE))) {
                    //ChatUtils.sendMsg(Text.of("Ret"+prop.getName() + needState.get(prop) + "," + nowState.get(prop)));
                    return true;
                }
            } catch (Exception ignored) {
            }
        }
        return false;
    }



    @Override
    public boolean isSuit(class_2680 needState, class_2680 nowState, class_2338 ignore) {
        return needState.method_26204() instanceof class_10376 && nowState.method_26204() instanceof class_10376;
    }
    @Override
    public Setting[] getSettings() {
        return new Setting[0];
    }
}
