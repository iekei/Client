/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.state_decide;

import com.iekeiclient.engine.settings.Setting;
import net.minecraft.class_2338;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2771;

public class SlabDecide implements Decide {
    @Override
    public boolean isSuit(class_2680 needState, class_2680 nowState, class_2338 placePos) {
        return needState.method_26204().equals(nowState.method_26204()) && needState.method_26204() instanceof class_2482;
    }

    @Override
    public boolean test(class_2680 needState, class_2680 nowState, class_2338 placePos) {
        if (needState.method_11654(class_2741.field_12485)== class_2771.field_12682){
            return true;
        }else {
            return needState.method_11654(class_2741.field_12485) == nowState.method_11654(class_2741.field_12485);
        }
    }
    @Override
    public Setting[] getSettings() {
        return new Setting[0];
    }
}
