/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util.records;

import com.iekeiclient.engine.utils.render.color.Color;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

public record PosInfo(class_2338 pos, class_2350 torchDir, class_243 clickVec,boolean isPlaceMode, long timestamp, Color renderColor) {
    }
