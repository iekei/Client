/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.Addon;
import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PosInfo;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.utils.render.color.Color;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.util.math.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RenderUtil {
    public static final List<PosInfo> renderList = Collections.synchronizedList(new ArrayList<>());

    private static final class_310 mc = class_310.method_1551();
    private static final Printer pri = Printer.getINSTANCE();

    public static void updateAniRenderSize(double i) {
        aniRenderSize += i;
        aniRenderSize = class_3532.method_15350(aniRenderSize, 0, 100);
    }

    public static boolean isAniRenderSizeAdd = false;
    private static class_243 aniRenderCenter = class_243.field_1353;
    private static double aniRenderSize = 0;

    public static void render(Render3DEvent event) {
        updateRenderList();
        if (pri.eSetRenderMode.get() == Printer.RenderMode.ANIMATION && !renderList.isEmpty() && aniRenderSize != 0) {
            animationRender(event);
        } else if (pri.eSetRenderMode.get() == Printer.RenderMode.MULTI) {
            multiRender(event);
        }else if (pri.eSetRenderMode.get()== Printer.RenderMode.DEBUG){
            debugRender(event);
        }
    }

    private static final void multiRender(Render3DEvent event) {
        renderList.forEach(pi -> {
            class_2338 pos = pi.pos();
            double per = 1 - (System.currentTimeMillis() - pi.timestamp()) / pri.dSetRenderTime.get();
            class_243 posH1 = pos.method_46558().method_1031(per * 0.5, per * 0.5, per * 0.5);
            class_243 posH2 = pos.method_46558().method_1023(per * 0.5, per * 0.5, per * 0.5);

            if (pri.bSetRenderFill.get()) {
                Color col = pri.colSetFillColor.get().rainbow ? pi.renderColor().a(pri.colSetFillColor.get().a) : new Color(pri.colSetFillColor.get().r, pri.colSetFillColor.get().g, pri.colSetFillColor.get().b, (int) (per * pri.colSetFillColor.get().a));
                event.renderer.box(new class_238(posH1, posH2), col, null, ShapeMode.Sides, 0);
            }
            if (pri.bSetRenderOutline.get()) {
                Color col = pri.colSetOutLineColor.get().rainbow ? pi.renderColor().a(pri.colSetOutLineColor.get().a) : new Color(pri.colSetOutLineColor.get().r, pri.colSetOutLineColor.get().g, pri.colSetOutLineColor.get().b, (int) (per * pri.colSetOutLineColor.get().a));
                RenderHelper.drawBoxOutline(/*pos,*/ new class_238(posH1, posH2), col, event);
            }
        });
    }

    private static void debugRender(Render3DEvent event) {
        renderList.forEach(pi -> {
            class_2350 dir = pi.torchDir();
            class_243 center = pi.clickVec();
            class_243 c1 = pi.clickVec();
            class_243 c2 = pi.clickVec();
            for (class_2350.class_2351 ax : class_2350.class_2351.values()) {
                if (ax.equals(dir.method_10166())) continue;
                c1 = c1.method_43206(class_2350.method_10169(ax, class_2350.class_2352.field_11060), 0.15);
                c2 = c2.method_43206(class_2350.method_10169(ax, class_2350.class_2352.field_11060), -0.15);

            }
            event.renderer.box(new class_238(c1,c2),pri.colSetFillColor.get(),pri.colSetOutLineColor.get(),ShapeMode.Both,1);
            class_243 off = center.method_43206(dir,0.4);
            class_243 centerPos = pi.pos().method_46558();
            event.renderer.line(center.field_1352,center.field_1351,center.field_1350, off.field_1352, off.field_1351, off.field_1350,pi.isPlaceMode()?Color.WHITE:Color.BLACK);
            event.renderer.box(new class_238(centerPos.method_1031(0.05,0.05,0.05),centerPos.method_1031(-0.05,-0.05,-0.05)),Color.ORANGE,pri.colSetOutLineColor.get(),ShapeMode.Both,1);
        });
    }

    private static void animationRender(Render3DEvent event) {
        //更新显示中点
        class_243 placeCenter = renderList.get(renderList.size() - 1).pos().method_46558();
        double distance = aniRenderCenter.method_1022(placeCenter);
        if (distance > 16 || distance < 0.1) {
            aniRenderCenter = placeCenter;
        } else {
            class_243 distanceVec = placeCenter.method_1020(aniRenderCenter);
            aniRenderCenter = aniRenderCenter.method_1019(distanceVec.method_1021(pri.dSetAnimationSpeed.get() / 100));
        }
        //渲染
        class_243 posH1 = aniRenderCenter.method_1031(aniRenderSize / 200, aniRenderSize / 200, aniRenderSize / 200);
        class_243 posH2 = aniRenderCenter.method_1023(aniRenderSize / 200, aniRenderSize / 200, aniRenderSize / 200);
        if (pri.bSetRenderFill.get())
            event.renderer.box(new class_238(posH1, posH2), pri.colSetFillColor.get(), null, ShapeMode.Sides, 0);
        if (pri.bSetRenderOutline.get())
            RenderHelper.drawBoxOutline(new class_238(posH1, posH2), pri.colSetOutLineColor.get(), event);

    }

    private static void updateRenderList() {
        if (pri.eSetRenderMode.get() == Printer.RenderMode.ANIMATION && !renderList.isEmpty()) {
            PosInfo posInfo = renderList.get(renderList.size() - 1);
            renderList.clear();
            renderList.add(posInfo);
            if (isAniRenderSizeAdd)
                updateAniRenderSize(pri.dSetSizeExpandMultiplier.get());
            else
                updateAniRenderSize(-pri.dSetSizeShrinkMultiplier.get());
        }
        renderList.removeIf(b -> System.currentTimeMillis() - b.timestamp() > pri.dSetRenderTime.get());

    }
}
