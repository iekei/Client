/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.state_decide;

import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class FallingBlockDecide implements Decide {
    private static final class_310 mc = class_310.method_1551();
    private final Setting<Boolean> isEnable = new BoolSetting.Builder()
        .name("avoid-block-fall")
        .defaultValue(true)
        .build();

    @Override
    public boolean isSuit(class_2680 needState, class_2680 nowState, class_2338 placePos) {
        return isEnable.get() && needState.method_26204().equals(nowState.method_26204()) && needState.method_26204() instanceof class_2346;
    }

    @Override
    public boolean test(class_2680 needState, class_2680 nowState, class_2338 placePos) {
        return mc.field_1687 != null && !class_2346.method_10128(mc.field_1687.method_8320(placePos.method_10074()))
            && MainDecide.defaultTest(needState, nowState, placePos);
    }

    @Override
    public Setting<?>[] getSettings() {
        return new Setting[]{isEnable};
    }
}
