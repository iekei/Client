/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import com.iekeiclient.engine.IekeiClient;
import com.iekeiclient.engine.mixininterface.IClientPlayerInteractionManager;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.engine.utils.player.FindItemResult;
import com.iekeiclient.engine.utils.player.InvUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_310;


public class InvUtil {
    private final static class_310 mc = class_310.method_1551();
    private final static Printer pri = Printer.getINSTANCE();

    private static void invSwitch(int slot, int hotbarSlot) {
        switch (pri.eSetInvSwitchMode.get()) {
            case SWAP:
//                invSwap(slot, hotbarSlot);
                InvUtils.quickSwap().fromId(hotbarSlot).to(slot);
                break;
            case PICK:
                InvUtils.move().from(slot).to(hotbarSlot);
                break;
        }
    }

//    private static boolean invSwap(int slot, int hotBarSlot) {
//        if (slot >= 0) {
//            ScreenHandler handler = mc.player.currentScreenHandler;
//            Int2ObjectArrayMap stack = new Int2ObjectArrayMap();
//            stack.put(slot, handler.getSlot(slot).getStack());
//            IekeiClient.mc.getNetworkHandler().sendPacket((Packet) new ClickSlotC2SPacket(handler.syncId, handler.getRevision(), slot, hotBarSlot, SlotActionType.SWAP, mc.player.currentScreenHandler.getCursorStack().copy(), (Int2ObjectMap) stack));
//            mc.interactionManager.clickSlot(handler.syncId,slot,);
//            ((IClientPlayerInteractionManager) ((MinecraftClient) IekeiClient.mc).interactionManager).iekei$syncSelected();
//            return true;
//        }
//        return false;
//    }

    public static boolean switchBlock(class_2248 b) {
        return switchItem(stack -> stack.method_7909().equals(getItemFormBlock(b)),b);
    }
    public static boolean switchItem(Predicate<class_1799> p){
        return switchItem(p,null);
    }

    public static boolean switchItem(Predicate<class_1799> p,class_2248 b) {
        FindItemResult resHot = InvUtils.findInHotbar(p);
        if (resHot.found()) {
            InvUtils.swap(resHot.slot(), false);
            if ((!pri.bSetAntiWrongBlock.get()) || p.test(mc.field_1724.method_6047()))
                return true;
            return false;
        }
        if (isCreativeMode()&&b!=null) {

           // mc.player.getInventory().(mc.player.getStackInHand(Hand.MAIN_HAND));
            mc.field_1761.method_2909(new class_1799(b,1),
                36 + getSlot());

        } else {
            FindItemResult res = InvUtils.find(p);
            if (!res.found()) return false;
//        invSwap(res.slot(), getInvSwapSlot());
            invSwitch(res.slot(), getInvSwapSlot());
            //InvUtils.move().from(res.slot()).to(mc.player.getInventory().selectedSlot);

        }
        if (pri.bSetAntiWrongBlock.get() || pri.bSetIndirectInvSwap.get())
            return false;
        return true;
    }

    public static int getInvSwapSlot() {
        int selSlot = mc.field_1724.method_31548().method_67532();
        if (pri.bSetIndirectInvSwap.get()) {
            return getSlot();
        }
        return selSlot;
    }

    //指针位置
    private static int i = 0;

    public static int getSlot() {
        List<Integer> usefulSlots = getUsefulSlots();
        int selSlot = mc.field_1724.method_31548().method_67532();
        if (usefulSlots.size() > 1) usefulSlots.remove(Integer.valueOf(selSlot));
        if (usefulSlots.size() > 0) {
            if (i >= usefulSlots.size()) i = 0;
            return usefulSlots.get(i++);
        }
        return selSlot;
    }

    public static List<Integer> getUsefulSlots() {
        try {
            return getUsefulSlots(pri.sSetInvSwapSlot.get());
        } catch (Exception e) {
            pri.sSetInvSwapSlot.reset();
            ChatUtils.sendMsg(class_2561.method_30163(e.getMessage()));
            ChatUtils.sendMsg(class_2561.method_30163("检测到异常: 数据不符合格式 自动处理:已自动还原为默认数据"));
        }
        return getUsefulSlots(pri.sSetInvSwapSlot.getDefaultValue());
    }

    public static List<Integer> getUsefulSlots(String s) {
        String[] split = pri.sSetInvSwapSlot.get().split(",");
        final ArrayList<Integer> integers = new ArrayList<>();
        Arrays.stream(split).map(Integer::valueOf)
            .filter(i -> i >= 0 && i < 10)
            .forEach(integers::add);
        return integers;
    }

    public static boolean findBlock(class_2248 b) {

        return findItem(stack -> stack.method_7909().equals(getItemFormBlock(b))) || isCreativeMode();
    }

    public static LinkedList<class_1799> getBlockStacks(class_2248 b) {
        final LinkedList<class_1799> stacks = new LinkedList<>();
        if (isCreativeMode()){
            stacks.add(new class_1799(b,1));
            return stacks;
        }
        findItem(stack -> {
            boolean equals = stack.method_7909().equals(getItemFormBlock(b));
            if (equals) {
                stacks.add(stack);
            }
            return equals;
        });
        return stacks;
    }

    public static boolean findItem(Predicate<class_1799> p) {
        return InvUtils.find(p).found();
    }

    public static class_1792 getItemFormBlock(class_2248 b) {
        if (b.equals(class_2246.field_10382)) return class_1802.field_8705;
        if (b.equals(class_2246.field_10164)) return class_1802.field_8187;
        if (b.equals(class_2246.field_27879)) return class_1802.field_27876;
        return class_1792.field_8003.get(b);
    }

    public static boolean isCreativeMode() {
        return mc.field_1724.method_31549().field_7477;
    }
}
