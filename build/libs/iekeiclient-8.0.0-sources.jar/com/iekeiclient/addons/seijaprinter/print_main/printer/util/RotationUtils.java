/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.engine.utils.player.Rotations;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_746;

import static com.iekeiclient.engine.IekeiClient.mc;

public class RotationUtils {
	public static class_243 getEyesPos()
	{
		class_746 player = mc.field_1724;

		return new class_243(player.method_23317(),
			player.method_23318() + player.method_18381(player.method_18376()),
			player.method_23321());
	}

	public static float getAngleDifference(final float a, final float b) {
		return ((((a - b) % 360F) + 540F) % 360F) - 180F;
	}

	public static double getRotationDifference(final Rotation a, final Rotation b) {
		return Math.hypot(getAngleDifference(a.yaw, b.yaw), a.getPitch() - b.getPitch());
	}

	public static Rotation toRotation(final class_243 vec, final boolean predict) {
		final class_243 eyesPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_5829().field_1322 +
			mc.field_1724.method_18381(mc.field_1724.method_18376()), mc.field_1724.method_23321());

		if(predict) {
			if(mc.field_1724.method_24828()) {
				eyesPos.method_1031(mc.field_1724.method_18798().field_1352, 0.0, mc.field_1724.method_18798().field_1350);
			}else eyesPos.method_1031(mc.field_1724.method_18798().field_1352, mc.field_1724.method_18798().field_1351, mc.field_1724.method_18798().field_1350);
		}

		final double diffX = vec.field_1352 - eyesPos.field_1352;
		final double diffY = vec.field_1351 - eyesPos.field_1351;
		final double diffZ = vec.field_1350 - eyesPos.field_1350;

		return new Rotation(
			(float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F,
			(float) (-Math.toDegrees(Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ)))));
	}

	public static class_243 getCenter(final class_238 bb) {
		return new class_243(bb.field_1323 + (bb.field_1320 - bb.field_1323) * 0.5, bb.field_1322 + (bb.field_1325 - bb.field_1322) * 0.5, bb.field_1321 + (bb.field_1324 - bb.field_1321) * 0.5);
	}

	public static Rotation limitAngleChange(final Rotation currentRotation, final Rotation targetRotation, final float turnSpeed) {
		final float yawDifference = getAngleDifference(targetRotation.getYaw(), currentRotation.getYaw());
		final float pitchDifference = getAngleDifference(targetRotation.getPitch(), currentRotation.getPitch());

		return new Rotation(
			currentRotation.getYaw() + (yawDifference > turnSpeed ? turnSpeed : Math.max(yawDifference, -turnSpeed)),
			currentRotation.getPitch() + (pitchDifference > turnSpeed ? turnSpeed : Math.max(pitchDifference, -turnSpeed)
			));
	}

	public static Rotation getNeededRotations(class_243 vec)
	{
		class_243 eyesPos = getEyesPos();

		double diffX = vec.field_1352 - eyesPos.field_1352;
		double diffY = vec.field_1351 - eyesPos.field_1351;
		double diffZ = vec.field_1350 - eyesPos.field_1350;

		double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

		float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F;
		float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));

		return new Rotation(yaw, pitch);
	}


	public static double getAngleToLookVec(class_243 vec)
	{
		Rotation needed = getNeededRotations(vec);

		class_746 player = mc.field_1724;
		float currentYaw = class_3532.method_15393(player.method_36454());
		float currentPitch = class_3532.method_15393(player.method_36455());

		float diffYaw = currentYaw - needed.yaw;
		float diffPitch = currentPitch - needed.pitch;

		return Math.sqrt(diffYaw * diffYaw + diffPitch * diffPitch);
	}

	public static final class Rotation
	{
		private float yaw;
		private float pitch;

		public Rotation(float yaw, float pitch)
		{
			this.yaw = class_3532.method_15393(yaw);
			this.pitch = class_3532.method_15393(pitch);
		}

		public Rotation(double yaw, double pitch)
		{
			this.yaw = class_3532.method_15393((float)yaw);
			this.pitch = class_3532.method_15393((float)pitch);
		}

		public float getYaw()
		{
			return yaw;
		}

		public float getPitch()
		{
			return pitch;
		}

		public void setYaw(float yaw) {
			this.yaw = yaw;
		}

		public void setPitch(float pitch) {
			this.pitch = pitch;
		}
	}
}
