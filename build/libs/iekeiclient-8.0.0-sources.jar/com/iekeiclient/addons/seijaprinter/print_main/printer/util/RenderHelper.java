/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PosInfo;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.RainbowColor;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;


public class RenderHelper {
    public static final RainbowColor COLOR = new RainbowColor();

    public static PosInfo getBlackInfo(class_2338 p, class_2350 clickDir, class_243 clickVec,boolean isPlace) {
        return new PosInfo(p,clickDir,clickVec,isPlace, System.currentTimeMillis(), new Color(COLOR.r, COLOR.g, COLOR.b));
    }

    public static void drawBoxOutline(/*BlockPos pos,*/ class_238 box, Color col, Render3DEvent event) {

        class_265 shape = class_259.method_1078(box);
        shape.method_1104((minX, minY, minZ, maxX, maxY, maxZ) -> {
           // event.renderer.line(pos.getX() + minX, pos.getY() + minY, pos.getZ() + minZ, pos.getX() + maxX, pos.getY() + maxY, pos.getZ() + maxZ, col);
            event.renderer.line(minX, minY, minZ, maxX, maxY, maxZ, col);

        });
    }
}
