/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util.records;

import org.jetbrains.annotations.Nullable;


import java.util.function.BooleanSupplier;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

public record PlaceData(class_2338 pos, class_2350 dir, class_243 hitVec, boolean valid, @Nullable RotationData exRotateData,
                        @Nullable BooleanSupplier test) {
    public static final PlaceData NULL = new PlaceData(null, null, null, false, null,null);

    public static PlaceData newInstance(class_2338 pos, class_2350 dir, class_243 hitVec, boolean valid, @Nullable RotationData exRotateData) {
        return new PlaceData(pos, dir, hitVec, valid, exRotateData,null);
    }
}
