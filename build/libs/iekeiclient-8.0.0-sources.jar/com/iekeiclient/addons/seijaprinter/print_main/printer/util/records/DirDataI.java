/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util.records;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public record DirDataI(class_2338 placePos, List<class_2350> dirs) {
    private static Printer pri = Printer.getINSTANCE();


}
