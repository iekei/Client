/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.RotationData;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.util.math.*;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;

public class RayTraceUtil {
    private static final Printer pri = Printer.getINSTANCE();
    public static RayTraceUtil INSTANCE = new RayTraceUtil();

    private RayTraceUtil() {
        dirmap = new HashMap<>();
        dirmap.put(class_2350.field_11033,new class_243(-3.838728915128419E-18, -1.0, 1.2240450621459233E-16));
        dirmap.put(class_2350.field_11036,new class_243(0.0, 1.0, 0.0));
        dirmap.put(class_2350.field_11034,new class_243(1.0, -0.0, 1.2246468525851679E-16));
        dirmap.put(class_2350.field_11043,new class_243(1.2246468525851679E-16, -0.0, -1.0));
        dirmap.put(class_2350.field_11035,new class_243(0.0, -0.0, 1.0));
        dirmap.put(class_2350.field_11039,new class_243(-1.0, -0.0, 0.0));

    }
    private final HashMap<class_2350,class_243> dirmap;
    private final static class_310 mc = class_310.method_1551();
    /**
     * get strict vec
     *
     * @param vec3d vec 初始粗略的点击点(可能不在支持方块的表面)
     * @param rayDir rayDir 射线计算方向
     * @param includeFluids includeFluids 计算流体
     * @return {@link class_3965}
     * @see class_3965
     */
    public class_3965 getStrictVecResult(class_243 vec3d, class_2350 rayDir, boolean includeFluids,double rayLength){
        class_243 vec3d2 = dirmap.get(rayDir);
        class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * rayLength, vec3d2.field_1351 * rayLength, vec3d2.field_1350 * rayLength);
        return mc.field_1687.method_17742(new class_3959(vec3d, vec3d3, class_3959.class_3960.field_17559, includeFluids ? class_3959.class_242.field_1347 : class_3959.class_242.field_1348, mc.field_1724));
    }

    public static  class_243 getRotationVector(float pitch, float yaw) {
        float f = pitch * ((float) Math.PI / 180);
        float g = -yaw * ((float) Math.PI / 180);
        float h = class_3532.method_15362(g);
        float i = class_3532.method_15374(g);
        float j = class_3532.method_15362(f);
        float k = class_3532.method_15374(f);
        return new class_243(i * j, -k, h * j);
    }
    public boolean rayTrace(@Nullable class_2338 placePos, @Nullable class_2350 offsetDir, class_243 target){
        return rayTrace(placePos,offsetDir, target,pri.bSetRayTrace.isVisible()&&pri.bSetRayTrace.get(),pri.bSetIgnoreEntity.get(), pri.dSetPrintingRange.get());
    }
    public boolean rayTrace(@Nullable class_2338 interactPos,@Nullable class_2350 clickDir, class_243 target, boolean raytrace, boolean ignoreEntity, double rayRange){
        if (!(raytrace))return true;

        class_1297 entity2 = mc.field_1724;
        if (entity2 == null) {
            return false;
        }
        if (mc.field_1687 == null) {
            return false;
        }

        double d =rayRange;
        class_239 crosshairTarget = null;

        //crosshairTarget = entity2.raycast(d, 1, false);
        class_243 vec3d = PredictUtility.getPredPlayerVec().method_43206(class_2350.field_11036,SeijaUtil.getEyeHeight());

        class_243 vec3d2 = getRotationVector((float) SeijaUtil.getPitch(target), (float) SeijaUtil.getYaw(target));//entity2.getRotationVec(1.0f);
        class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * d, vec3d2.field_1351 * d, vec3d2.field_1350 * d);

        crosshairTarget =  mc.field_1687.method_17742(new class_3959(vec3d, vec3d3, class_3959.class_3960.field_17559, false ? class_3959.class_242.field_1347 : class_3959.class_242.field_1348, entity2));


        boolean bl = false;
        int i = 3;
        double e = d;
//        if (mc.interactionManager.hasExtendedReach()) {
//            d = e = 6.0;
//        } else {
//            if (e > 3.0) {
//                bl = true;
//            }
//            d = e;
//        }
        //121
        e *= e;

        if (crosshairTarget != null) {
            e = crosshairTarget.method_17784().method_1025(vec3d);
        }


        if (!ignoreEntity){
            class_238 box = entity2.method_5829().method_18804(vec3d2.method_1021(d)).method_1009(1.0, 1.0, 1.0);
            class_3966 entityHitResult = class_1675.method_18075(entity2, vec3d, vec3d3, box, entity -> !entity.method_7325() && entity.method_5863(), e);
            if (entityHitResult != null) {
                class_243 vec3d4 = entityHitResult.method_17784();
                double g = vec3d.method_1025(vec3d4);
                if (bl && g > 9.0) {
                    crosshairTarget = class_3965.method_17778(vec3d4, class_2350.method_10142(vec3d2.field_1352, vec3d2.field_1351, vec3d2.field_1350), class_2338.method_49638(vec3d4));
                } else if (g < e || crosshairTarget == null) {
                    crosshairTarget = entityHitResult;
                }
            }
        }

        if (crosshairTarget == null)return false;
        if (crosshairTarget.method_17783()!= class_239.class_240.field_1332)return false;
        //ChatUtils.sendMsg(Text.of("pos:"+ crosshairTarget.getPos()+ " dis: "+target.distanceTo(crosshairTarget.getPos())));
        if (clickDir==null||interactPos==null)
            return  target.method_1022(crosshairTarget.method_17784())<=0.1;
        return target.method_1022(crosshairTarget.method_17784())<=0.1
            &&(!(crosshairTarget instanceof class_3965 bhr0) || bhr0.method_17780() == clickDir)
            &&(!(crosshairTarget instanceof class_3965 bhr) ||interactPos.equals(bhr.method_17777()));
    }
    public class_3965 rayHitRes(class_243 start, RotationData rotate, boolean ignoreEntity, double rayRange){


        class_1297 entity2 = mc.field_1724;
        if (entity2 == null) {
            return null;
        }
        if (mc.field_1687 == null) {
            return null;
        }

        double d =rayRange;
        class_239 crosshairTarget = null;

        //crosshairTarget = entity2.raycast(d, 1, false);

        class_243 vec3d2 = getRotationVector((float) rotate.pitch(), (float) rotate.yaw());//entity2.getRotationVec(1.0f);
        class_243 vec3d3 = start.method_1031(vec3d2.field_1352 * d, vec3d2.field_1351 * d, vec3d2.field_1350 * d);

        crosshairTarget =  mc.field_1687.method_17742(new class_3959(start, vec3d3, class_3959.class_3960.field_17559, false ? class_3959.class_242.field_1347 : class_3959.class_242.field_1348, entity2));


        boolean bl = false;
        int i = 3;
        double e = d;
//        if (mc.interactionManager.hasExtendedReach()) {
//            d = e = 6.0;
//        } else {
//            if (e > 3.0) {
//                bl = true;
//            }
//            d = e;
//        }
        //121
        e *= e;

        if (crosshairTarget != null) {
            e = crosshairTarget.method_17784().method_1025(start);
        }


        if (!ignoreEntity){
            class_238 box = entity2.method_5829().method_18804(vec3d2.method_1021(d)).method_1009(1.0, 1.0, 1.0);
            class_3966 entityHitResult = class_1675.method_18075(entity2, start, vec3d3, box, entity -> !entity.method_7325() && entity.method_5863(), e);
            if (entityHitResult != null) {
                class_243 vec3d4 = entityHitResult.method_17784();
                double g = start.method_1025(vec3d4);
                if (bl && g > 9.0) {
                    crosshairTarget = class_3965.method_17778(vec3d4, class_2350.method_10142(vec3d2.field_1352, vec3d2.field_1351, vec3d2.field_1350), class_2338.method_49638(vec3d4));
                } else if (g < e || crosshairTarget == null) {
                    crosshairTarget = entityHitResult;
                }
            }
        }

        if (crosshairTarget == null)return null;
        if (crosshairTarget instanceof class_3965) {
            return (class_3965) crosshairTarget;
        }
        return null;
        //ChatUtils.sendMsg(Text.of("pos:"+ crosshairTarget.getPos()+ " dis: "+target.distanceTo(crosshairTarget.getPos())));

    }
}
