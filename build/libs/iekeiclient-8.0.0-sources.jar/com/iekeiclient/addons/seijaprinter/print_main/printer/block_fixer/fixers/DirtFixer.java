/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers;

import com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.AbstractFixer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirDataI;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.InvUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceData;
import net.minecraft.block.*;
import net.minecraft.class_1794;
import net.minecraft.class_1821;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2350;
import net.minecraft.class_2369;
import net.minecraft.class_243;
import net.minecraft.class_2500;
import net.minecraft.class_2680;

public class DirtFixer extends AbstractFixer {
    public DirtFixer() {
        super("DirtFix");
    }

    @Override
    public int fixBlock(class_2338 pos, class_2680 needState) {

        DirData dirData = new DirData(pos, BlockUtil.getSortedDirs(pos,true));

        dirData.dirs().remove(class_2350.field_11033);
        for (class_2350 dir : dirData.dirs()) {
            for (class_243 clickVec : dirData.clickVecsInte(dir)) {
                if (InvUtil.switchItem(stack -> needState.method_26204() instanceof class_2369
                    ? stack.method_7909() instanceof class_1821 : stack.method_7909() instanceof class_1794)) {
                    BlockUtil.interactBlock(PlaceData.newInstance(dirData.placePos(), dir, clickVec, true, null));
                    return AbstractFixer.SUCCESS;
                } else return AbstractFixer.RETURN;
            }
        }
        return AbstractFixer.CONTINUE;
    }

    @Override
    public boolean needFix(class_2338 pos, class_2680 needState) {
        class_2248 block = mc.field_1687.method_8320(pos).method_26204();
        if (needState.method_26204() instanceof class_2369 && !InvUtil.findItem(stack -> stack.method_7909() instanceof class_1821))
            return false;
        if (needState.method_26204() instanceof class_2344 && !InvUtil.findItem(stack -> stack.method_7909() instanceof class_1794))
            return false;
        return ((needState.method_26204() instanceof class_2369 || needState.method_26204() instanceof class_2344)
            && (block instanceof class_2500 || block.equals(class_2246.field_10566)
            || block.equals(class_2246.field_28685) || block.equals(class_2246.field_10520)));
    }
}
