/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers;

import com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.AbstractFixer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.InvUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirDataI;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceDataPack;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_2189;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2771;

public class SlabFixer extends AbstractFixer {
    public SlabFixer() {
        super("SlabFix");
    }

    @Override
    public int fixBlock(class_2338 pos, class_2680 needState) {

        PlaceDataPack dataPack = null;
        class_2680 blockState = mc.field_1687.method_8320(pos);
        class_2771 slabType = blockState.method_11654(class_2741.field_12485);

        List<class_2350> dirs = new ArrayList<>(BlockUtil.getSortedDirs(pos,false));
        DirData dirData = new DirData(pos, dirs);

        switch (slabType) {
            case field_12679 -> dirs.add(class_2350.field_11033);
            case field_12681 -> dirs.add(class_2350.field_11036);
            //适应com/kijinseija/seija_printer/print_main/printer/util/BlockUtil.java中getDirs的方块阻挡检测
        }
        for (class_2350 dir : dirs) {
            class_2680 helperState = mc.field_1687.method_8320(pos.method_10093(dir));
            if (helperState.method_26204().equals(needState.method_26204())
                && (
                (helperState.method_11654(class_2482.field_11501) != class_2771.field_12682
                    && helperState.method_11654(class_2482.field_11501) == slabType
                    && dir.method_10166() != class_2350.class_2351.field_11052)
                    ||
                    (helperState.method_11654(class_2482.field_11501) != class_2771.field_12682 &&
                        helperState.method_11654(class_2482.field_11501) != slabType
                        && dir.method_10166() == class_2350.class_2351.field_11052))
            ) continue;
            if (dir.method_10166() == class_2350.class_2351.field_11052) {
                DirData data = new DirData(pos, Collections.singletonList(dir));
                for (class_243 clickVec : data.clickVecsInte(dir, 0)) {
                    dataPack = PlaceDataPack.inte( PlaceData.newInstance(pos, dir
                        , clickVec, true, null));
                    break;
                }
                continue;
            }

            for (class_243 clickVec : dirData.clickVecs(dir, slabType == class_2771.field_12681 ? 1 : 2)) {
                dataPack = PlaceDataPack.plac( PlaceData.newInstance(pos.method_10093(dir), dir.method_10153()
                    , clickVec, true, null));
                break;
            }
            break;
        }
        if (dataPack == null) {
            return CONTINUE;
        }

        if (!InvUtil.switchBlock(needState.method_26204())) {
            return AbstractFixer.RETURN;
        }

        if (dataPack.placeMode()) {
            BlockUtil.placeBlock(dataPack.data());//放置
        } else {
            BlockUtil.interactBlock(dataPack.data());
        }


        return AbstractFixer.SUCCESS;

    }

    @Override
    public boolean needFix(class_2338 pos, class_2680 needState) {
        if (!InvUtil.findBlock(needState.method_26204())) return false;
        class_2680 blockState = mc.field_1687.method_8320(pos);
        if (blockState.method_26204() instanceof class_2189 || needState.method_26204() instanceof class_2189)
            return false;
        if ((!(needState.method_26204() instanceof class_2482)) || (!blockState.method_26204().equals(needState.method_26204()))) {
            return false;
        }

        //不同方块,不为台阶则不需要修复
        if (blockState.method_11654(class_2741.field_12485) != class_2771.field_12682
            && needState.method_11654(class_2741.field_12485) == class_2771.field_12682) {
            return true;
        }

        return false;
    }
}
