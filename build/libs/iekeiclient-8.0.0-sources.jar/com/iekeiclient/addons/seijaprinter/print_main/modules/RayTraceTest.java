/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.modules;

import com.iekeiclient.addons.seijaprinter.Addon;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.PredictUtility;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.SeijaUtil;
import com.iekeiclient.addons.seijaprinter.settings.impl.DirectionListSetting;
import com.iekeiclient.engine.settings.DoubleSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.ChatUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.util.math.*;
import java.util.HashMap;
import java.util.List;

public class RayTraceTest extends Module {

    public RayTraceTest() {
        super(Addon.CATEGORY, "RayTest", "");
        dirmap = new HashMap<>();
        dirmap.put(class_2350.field_11033, new class_243(-3.838728915128419E-18, -1.0, 1.2240450621459233E-16));
        dirmap.put(class_2350.field_11036, new class_243(0.0, 1.0, 0.0));
        dirmap.put(class_2350.field_11034, new class_243(1.0, -0.0, 1.2246468525851679E-16));
        dirmap.put(class_2350.field_11043, new class_243(1.2246468525851679E-16, -0.0, -1.0));
        dirmap.put(class_2350.field_11035, new class_243(0.0, -0.0, 1.0));
        dirmap.put(class_2350.field_11039, new class_243(-1.0, -0.0, 0.0));

    }

    HashMap<class_2350, class_243> dirmap;
    SettingGroup sgDefault = settings.getDefaultGroup();
    Setting<Double> x = sgDefault.add(new DoubleSetting.Builder().name("x").build());
    Setting<Double> y = sgDefault.add(new DoubleSetting.Builder().name("y").build());
    Setting<Double> z = sgDefault.add(new DoubleSetting.Builder().name("z").build());

    Setting<List<class_2350>> dirs = sgDefault.add(new DirectionListSetting.Builder().name("Dir").build());

    protected final class_243 getRotationVector(float pitch, float yaw) {
        float f = pitch * ((float) Math.PI / 180);
        float g = -yaw * ((float) Math.PI / 180);
        float h = class_3532.method_15362(g);
        float i = class_3532.method_15374(g);
        float j = class_3532.method_15362(f);
        float k = class_3532.method_15374(f);
        return new class_243(i * j, -k, h * j);
    }

    @Override
    public void onActivate() {
////        crosshairTarget
////        Vec3d vec3d = mc.player.getCameraPosVec(1);
////        Vec3d vec3d2 = mc.player.getRotationVec(1);
////        if (dirs.get().size() == 0) return;
//        Vec3d vec3d = new Vec3d(x.get(), y.get(), z.get());//眼睛位置
////        Vec3d vec3d2 = dirmap.get(dirs.get().get(0));
////        Vec3d vec3d3 = vec3d.add(vec3d2.x * 1, vec3d2.y * 1, vec3d2.z * 1);
//            //虚假转头
//        Vec3d vec3d2 = mc.cameraEntity.getRotationVec(1.0f);
//        Vec3d vec3d3 = vec3d.add(vec3d2.x * 5, vec3d2.y * 5, vec3d2.z * 5);
//        //实际转头
//        //乘数为触摸距离
//
////        // BlockHitResult raycast = mc.world.raycast(new RaycastContext(vec3d, vec3d3, RaycastContext.ShapeType.OUTLINE, false ? RaycastContext.FluidHandling.ANY : RaycastContext.FluidHandling.NONE, mc.player));
////
////        Box box = mc.cameraEntity.getBoundingBox().stretch(vec3d2.multiply(mc.interactionManager.getReachDistance())).expand(1.0, 1.0, 1.0);
////        EntityHitResult entityHitResult = ProjectileUtil.raycast(mc.getCameraEntity(), mc.player.getEyePos(), vec3d3, box, entity -> !entity.isSpectator() && entity.canHit(), 25);
////
////
////        if (entityHitResult.getPos() != null)
////            ChatUtils.sendMsg(Text.of(entityHitResult.getPos() + ":::" + entityHitResult.getType().name()));
////        else  ChatUtils.sendMsg(Text.of( ":::" + entityHitResult.getType().name()));

        class_1297 entity2 = mc.method_1560();
        if (entity2 == null) {
            return;
        }
        if (mc.field_1687 == null) {
            return;
        }

        //double d = mc.interactionManager.getReachDistance();
        double d = Printer.getINSTANCE().dSetPrintingRange.get();
        //121
        class_239 crosshairTarget = null;

        //crosshairTarget = entity2.raycast(d, 1, false);
        class_243 vec3d = PredictUtility.getPredPlayerVec().method_43206(class_2350.field_11036,SeijaUtil.getEyeHeight());
        class_243 targetVec = new class_243(x.get(),y.get(),z.get());
        class_243 vec3d2 = getRotationVector((float) SeijaUtil.getPitch(targetVec), (float) SeijaUtil.getYaw(targetVec));//entity2.getRotationVec(1.0f);
        ChatUtils.sendMsg(class_2561.method_30163("P:" +mc.method_1560().method_36455()+","+ SeijaUtil.getPitch(targetVec)));
        ChatUtils.sendMsg(class_2561.method_30163("Y:" +mc.method_1560().method_36454()+","+ SeijaUtil.getYaw(targetVec)));
        class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * d, vec3d2.field_1351 * d, vec3d2.field_1350 * d);

        crosshairTarget =  mc.field_1687.method_17742(new class_3959(vec3d, vec3d3, class_3959.class_3960.field_17559, false ? class_3959.class_242.field_1347 : class_3959.class_242.field_1348, entity2));


        boolean bl = false;
        int i = 3;
        double e = d;
//        if (mc.interactionManager.hasExtendedReach()) {
//            d = e = 6.0;
//        } else {
//            if (e > 3.0) {
//                bl = true;
//            }
//            d = e;
//        }
        //121
        e *= e;

        if (crosshairTarget != null) {
            e = crosshairTarget.method_17784().method_1025(vec3d);
        }


        class_238 box = entity2.method_5829().method_18804(vec3d2.method_1021(d)).method_1009(1.0, 1.0, 1.0);
        class_3966 entityHitResult = class_1675.method_18075(entity2, vec3d, vec3d3, box, entity -> !entity.method_7325() && entity.method_5863(), e);
        if (entityHitResult != null) {
            class_243 vec3d4 = entityHitResult.method_17784();
            double g = vec3d.method_1025(vec3d4);
            if (bl && g > 9.0) {
                crosshairTarget = class_3965.method_17778(vec3d4, class_2350.method_10142(vec3d2.field_1352, vec3d2.field_1351, vec3d2.field_1350), class_2338.method_49638(vec3d4));
            } else if (g < e || crosshairTarget == null) {
                crosshairTarget = entityHitResult;
            }
        }
        if (crosshairTarget.method_17784() != null)
            ChatUtils.sendMsg(class_2561.method_30163(crosshairTarget.method_17784() + ":::" + crosshairTarget.method_17783().name()));
    }

}
