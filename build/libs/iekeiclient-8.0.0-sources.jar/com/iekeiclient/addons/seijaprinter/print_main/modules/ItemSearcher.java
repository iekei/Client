package com.iekeiclient.addons.seijaprinter.print_main.modules;

import com.iekeiclient.addons.seijaprinter.Addon;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.*;
import com.iekeiclient.addons.seijaprinter.settings.impl.DoubleRangeSetting;
import com.iekeiclient.addons.seijaprinter.settings.obj.DoubleRange;
import fi.dy.masa.litematica.world.SchematicWorldHandler;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.widgets.WWidget;
import com.iekeiclient.engine.gui.widgets.containers.WHorizontalList;
import com.iekeiclient.engine.gui.widgets.containers.WVerticalList;
import com.iekeiclient.engine.gui.widgets.pressable.WButton;
import com.iekeiclient.engine.renderer.Renderer3D;
import com.iekeiclient.engine.settings.BlockPosSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.engine.utils.player.InvUtils;
import com.iekeiclient.engine.utils.player.SlotUtils;
import com.iekeiclient.engine.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1733;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


public class ItemSearcher extends Module {
    public ItemSearcher() {
        super(Addon.CATEGORY, "ItemSearcher", "");
    }

    private final SettingGroup sgDefault = this.settings.getDefaultGroup();

    Setting<class_2338> bpSetPoint1 = sgDefault.add(new BlockPosSetting.Builder()
        .name("block1")
        .build());
    Setting<class_2338> bpSetPoint2 = sgDefault.add(new BlockPosSetting.Builder()
        .name("block2")
        .build());

    Thread scheAnalysis = null;

    @Override
    public WWidget getWidget(GuiTheme theme) {
        WVerticalList list = theme.verticalList();

        WHorizontalList l1 = list.add(theme.horizontalList()).expandX().widget();

        WButton analysis = l1.add(theme.button("Analysis")).expandX().widget();
        analysis.action = () -> {
            if (!isActive()) return;
            if (scheAnalysis != null)
                scheAnalysis.interrupt();

            scheAnalysis = new Thread(this::analysisArea);
            scheAnalysis.start();

        };


        WHorizontalList l2 = list.add(theme.horizontalList()).expandX().widget();

        WButton print = l2.add(theme.button("Print item list")).expandX().widget();
        print.action = () -> {
            if (!isActive()) return;
            blockInfo.forEach((key, count) -> {
                class_5250 blockCount = class_2561.method_43470("Block: ")
                    .method_10852(class_2561.method_43471(key.method_63499()))
                    .method_27693("Count :");
                if (count / 64 > 0) {
                    blockCount
                        .method_27693(count / 64 + "")
                        .method_10852(class_2561.method_43470(" *64 ").method_54663(0x87CAFF))
                        //rgb(135, 202, 255)
                        .method_27693("+ ");
                }


                blockCount.method_27693(count % 64 + "");
                ChatUtils.sendMsg("[AdvancedPrinter]", blockCount);
            });
            //blockInfo.entrySet().forEach(b-> ChatUtils.sendMsg(++" count: "+b.getValue()));

        };
        return list;

    }

    public final Setting<DoubleRange> dRangeSetStealDelay = sgDefault.add(new DoubleRangeSetting.Builder()
        .name("steal-delay")
        .sliderRange(0, 2000)
        .range(0, 2000)
        .defaultValue(100, 200)
        .build());


    Map<class_2248, Integer> blockInfo = new ConcurrentHashMap<>();
//    存储方块信息,方块替换
//    HashMap<Item, Integer> itemInfo = new HashMap<>();


    private void analysisArea() {

        class_2338 min = class_2338.method_58249(bpSetPoint1.get(), bpSetPoint2.get());
        class_2338 max = class_2338.method_58250(bpSetPoint1.get(), bpSetPoint2.get());

        for (class_2338 bp : class_2338.method_10097(min, max)) {
            if (Thread.currentThread().isInterrupted()) {
                ChatUtils.sendMsg("[AdvancedPrinter]", class_2561.method_30163("Analysis stop"));
                break;
            }

            if (!BlockUtil.blockposFilter(bp)) {
                continue;
            }

            // 不是空气、液体等可被填充的
            if (BlockUtil.isCanPlaceInBlock(
                BlockReplaceUtils.getScheStateNonReplace(bp).method_26204())) {
                continue;
            }

            // 方块一致
            if (ScheVerifyMixinUtil.isReplacedBlockEqual(
                BlockReplaceUtils.getScheStateNonReplace(bp).method_26204(),
                mc.field_1687.method_8320(bp).method_26204())) {
                continue;
            }

            class_2248 block = SchematicWorldHandler
                .getSchematicWorld()
                .method_8320(bp)
                .method_26204();

            blockInfo.merge(block, 1, Integer::sum);

        }

        //拿到了需求数量后先减去背包内已有的
        for (int i = 0; i < mc.field_1724.method_31548().method_5439(); i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            class_2248 stealBlock = needSteal(stack.method_7909());
            updateInfo(stealBlock, stack.method_7947());
        }
        ChatUtils.sendMsg("[AdvancedPrinter]", class_2561.method_30163("Analysis complete"));

    }

    //是否需要拿走 需要拿则返回拿的方块类型
    private class_2248 needSteal(class_1792 item) {
        if (item instanceof class_1747) {
            for (Map.Entry<class_2248, Integer> blockIntegerEntry : blockInfo.entrySet()) {
                //方块替换检测
                class_2248 scheBlock = blockIntegerEntry.getKey();
                List<class_2248> replaceBlocks = BlockReplaceUtils.INSTANCE.getReplaceBlocks(scheBlock);
                if (replaceBlocks.isEmpty()) {
                    if (scheBlock.method_8389().equals(item)) return scheBlock;
                } else {
                    for (class_2248 replaceBlock : replaceBlocks) {
                        if (replaceBlock.method_8389().equals(item)) return scheBlock;
                    }
                }

            }
        }
        return null;
    }

    //减少清单内物品数量
    private void updateInfo(class_2248 block, int count) {
        blockInfo.computeIfPresent(block, (b, i) -> {
            int now = i - count;
            return now <= 0 ? null : now;
        });
    }


    @Override
    public void onDeactivate() {
        blockInfo.clear();
        super.onDeactivate();
    }

    SeijaTimer stealTimer = new SeijaTimer(dRangeSetStealDelay.get()::nextRandom);

    private final void tick() {
        class_1703 scrHand = mc.field_1724.field_7512;
        //ChatUtils.sendMsg(Text.of((scrHand instanceof GenericContainerScreenHandler) +"eq?"+ scrHand.getClass().getName()));
        //&&scrHand.getType().equals(ScreenHandlerType.GENERIC_9X3) ||scrHand.getType().equals(ScreenHandlerType.GENERIC_9X6)


        if ((scrHand instanceof class_1707
            || scrHand instanceof class_1733) && InvUtils.findEmpty().found()) {
            if (stealTimer.passed(dRangeSetStealDelay.get().getCurrentRandom())) {
                stealTimer.reset();
                stealChest(scrHand);
            }
            //  ChatUtils.sendMsg(Text.of(stealChest(scrHand)+""));

        } else slot = 0;
    }


    int slot = 0;

    private boolean stealChest(class_1703 scrHand) {

        while (slot < SlotUtils.indexToId(SlotUtils.MAIN_START)) {
            class_1799 stealStack = scrHand.method_7611(slot).method_7677();
            class_2248 stealBlock = needSteal(stealStack.method_7909());
            if (stealBlock != null) {
                updateInfo(stealBlock, stealStack.method_7947());
                InvUtils.shiftClick().slotId(slot);
                slot++;
                return true;
            }
            slot++;
        }
        return false;
    }

    @EventHandler
    public void onRender3d(Render3DEvent e) {
        tick();
        class_2338 p1 = bpSetPoint1.get();
        class_2338 p2 = bpSetPoint2.get();

        if (p1 == null && p2 == null) return;

        // 颜色（浅色 + 半透明）
        Color p1Line = new Color(255, 80, 80, 180);
        Color p1Fill = new Color(255, 80, 80, 60);

        Color p2Line = new Color(80, 80, 255, 180);
        Color p2Fill = new Color(80, 80, 255, 60);

        Color regionLine = new Color(255, 255, 255, 200);

        Renderer3D r = e.renderer;


        // 选点 1（红）
        if (p1 != null) {
            int x = p1.method_10263(), y = p1.method_10264(), z = p1.method_10260();

            r.boxSides(x, y, z, x + 1, y + 1, z + 1, p1Fill, 0);
            r.boxLines(x, y, z, x + 1, y + 1, z + 1, p1Line, 0);
        }

        // 选点 2（蓝）
        if (p2 != null) {
            int x = p2.method_10263(), y = p2.method_10264(), z = p2.method_10260();

            r.boxSides(x, y, z, x + 1, y + 1, z + 1, p2Fill, 0);
            r.boxLines(x, y, z, x + 1, y + 1, z + 1, p2Line, 0);
        }

        // 区域外框（白线）
        if (p1 != null && p2 != null) {
            int minX = Math.min(p1.method_10263(), p2.method_10263());
            int minY = Math.min(p1.method_10264(), p2.method_10264());
            int minZ = Math.min(p1.method_10260(), p2.method_10260());

            int maxX = Math.max(p1.method_10263(), p2.method_10263()) + 1;
            int maxY = Math.max(p1.method_10264(), p2.method_10264()) + 1;
            int maxZ = Math.max(p1.method_10260(), p2.method_10260()) + 1;

            r.boxLines(
                minX, minY, minZ,
                maxX, maxY, maxZ,
                regionLine,
                0
            );
        }

        r.render(e.matrices);
    }
}
