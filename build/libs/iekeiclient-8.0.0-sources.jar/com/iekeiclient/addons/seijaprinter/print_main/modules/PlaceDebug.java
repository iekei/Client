/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.modules;

import com.iekeiclient.addons.seijaprinter.Addon;
import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2561;
import net.minecraft.class_2885;
import net.minecraft.class_3965;

public class PlaceDebug extends Module {

    public PlaceDebug() {
        super(Addon.CATEGORY, "PlaceDebug", "Test");

    }
    @EventHandler
    public void onPacket(PacketEvent.Send send){
        if (send.packet instanceof class_2885) {
            class_2885 packet = (class_2885) send.packet;
            class_3965 bhr = packet.method_12543();

            ChatUtils.sendMsg(class_2561.method_30163(bhr.method_17777()+"  Side:"+bhr.method_17780()+" Vec:"+bhr.method_17784()+"Type:"+bhr.method_17783()));
        }
    }
}
