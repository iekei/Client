/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.state_decide;

import com.iekeiclient.engine.settings.Setting;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jetbrains.annotations.NotNull;

public interface Decide {
    boolean isSuit(class_2680 needState, class_2680 nowState, class_2338 placePos);
    boolean test(class_2680 needState,class_2680 nowState,class_2338 placePos);
    @NotNull
    Setting<?>[] getSettings();
}
