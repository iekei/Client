/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers.click_fixer;

import static net.minecraft.class_2457.*;

import net.minecraft.class_2338;
import net.minecraft.class_2457;
import net.minecraft.class_2680;

public class RedStoneFixer extends AbstractClickFixer{
    public RedStoneFixer() {
        super("RedStondFix");
    }

    @Override
    public boolean needFix(class_2338 pos, class_2680 needState) {
        if (!super.needFix(pos,needState)) {
            return false;
        }
        class_2680 blockState = mc.field_1687.method_8320(pos);
        if (
            blockState.method_26204() instanceof class_2457 &&needState.method_26204()==blockState.method_26204()) {
            return (isFullyConnected(blockState)^isFullyConnected(needState))
                &&(isNotConnected(blockState)^isNotConnected(needState))
                &&(isNotConnected(needState)||isFullyConnected(needState))
//                &&(!Blocks.REDSTONE_WIRE.getPlacementState(FakePlacementContext.getInstancePlac(Vec3d.ZERO,pos, Direction.DOWN,mc.player.getMainHandStack()))
//                .equals(blockState))
                ;
        }
        return false;
    }
    private static boolean isFullyConnected(class_2680 state) {
        return state.method_11654(field_11440).method_27855() && state.method_11654(field_11437).method_27855() && state.method_11654(field_11436).method_27855() && state.method_11654(field_11439).method_27855();
    }

    private static boolean isNotConnected(class_2680 state) {
        return !state.method_11654(field_11440).method_27855() && !state.method_11654(field_11437).method_27855() && !state.method_11654(field_11436).method_27855() && !state.method_11654(field_11439).method_27855();
    }
}
