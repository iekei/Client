/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers.click_fixer;

import net.minecraft.class_2286;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2741;

public class RSTComparatorFixer extends AbstractClickFixer{
    public RSTComparatorFixer() {
        super("ComparatorFix");
    }

    @Override
    public boolean needFix(class_2338 pos, class_2680 needState) {
        if (!super.needFix(pos,needState)) {
            return false;
        }
        class_2680 blockState = mc.field_1687.method_8320(pos);
        if (
            blockState.method_26204() instanceof class_2286&&needState.method_26204()==blockState.method_26204()) {
            return blockState.method_11654(class_2741.field_12534) != needState.method_11654(class_2741.field_12534);
        }
        return false;
    }
}
