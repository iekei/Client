/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.util.records;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.RayTraceUtil;
import java.util.*;
import java.util.stream.Collectors;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3965;

public record DirData(class_2338 placePos, List<class_2350> dirs) {
    private static Printer pri = Printer.getINSTANCE();

    public List<class_243> getClickVec1(class_2350 offsetDir, boolean randOffset, boolean strictVec, boolean raytrace, boolean ignoreEntity, double rayRange) {
        return getClickVec1(offsetDir, 0, randOffset, strictVec, raytrace, ignoreEntity, rayRange);
    }


    public class_243 getClickVec(class_2350 offsetDir, boolean strictVec) {
        //if (i >= dirs.size() - 1) return null;
        class_243 centerVec = placePos.method_46558();
        //Direction offsetDir = dirs.get(i);
        return centerVec.method_43206(offsetDir, strictVec ? -0.1 : 0.5);
    }

    public List<class_243> getClickVecs(final class_2350 offsetDir, boolean randOffset, boolean strictVec, boolean raytrace, boolean ignoreEntity, double rayRange) {
        return getClickVecs(offsetDir, 0, randOffset, strictVec, raytrace, ignoreEntity, rayRange);
    }


    public List<class_243> getClickVec1(class_2350 offsetDir, int mode, boolean randOffset, boolean strictVec, boolean raytrace, boolean ignoreEntity, double rayRange) {
        ArrayList<class_243> res = new ArrayList<>();
        class_2338 clickPos = placePos.method_10093(offsetDir);

        class_243 clickVec = getClickVec(offsetDir, strictVec);// placePos.toCenterPos().offset(offsetDir, pri.strictVec.get()&&pri.strictVec.isVisible() ? -0.1 : 0.5);
        if (randOffset)
            clickVec = BlockUtil.randomOffsetVec(clickVec, offsetDir);
        if (offsetDir.method_10166() != class_2350.class_2351.field_11052)
            switch (mode) {
                case 1:
                    clickVec = clickVec.method_43206(class_2350.field_11036, 0.2);
                    break;
                case 2:
                    clickVec = clickVec.method_43206(class_2350.field_11033, 0.2);

            }

        if (strictVec) {
            class_3965 result = RayTraceUtil.INSTANCE.getStrictVecResult(clickVec, offsetDir, Printer.getINSTANCE().bSetLiquidInt.get(), 1.57);
            if (result.method_17783() == class_239.class_240.field_1333) return res;
            clickVec = result.method_17784();
            if (!RayTraceUtil.INSTANCE.rayTrace(placePos.method_10093(offsetDir), offsetDir.method_10153(), clickVec, raytrace, ignoreEntity, rayRange))
                return res;
            if (!(clickVec.field_1352 <= clickPos.method_10263() + 1 && clickVec.field_1352 >= clickPos.method_10263()
                && clickVec.field_1351 <= clickPos.method_10264() + 1 && clickVec.field_1351 >= clickPos.method_10264()
                && clickVec.field_1350 <= clickPos.method_10260() + 1 && clickVec.field_1350 >= clickPos.method_10260()
            )) return res;
        }
        res.add(clickVec);
        return res;
    }

    //mode 1 上半 2 下半
    public List<class_243> getClickVecs(final class_2350 offsetDir, int mode, boolean randOffset, boolean strictVec,
                                    boolean raytrace, boolean ignoreEntity, double rayRange) {
        class_2338 clickPos = placePos.method_10093(offsetDir);
//        if (i >= dirs.size() - 1) return new ArrayList<>();
        List<class_243> vecList = new LinkedList<>();
        //装可用的Vec
        //final Direction offsetDir = dirs.get(i);//偏移方向

        class_243 clickVec = getClickVec(offsetDir, strictVec);//基础的中心Vec
        if (randOffset) {//随机offset 用于bypass
            vecList.add(BlockUtil.randomOffsetVec(clickVec, offsetDir));
        } else
            vecList.add(clickVec);
        for (class_243 extendVec : BlockUtil.getExtendVec(offsetDir, true)) {
            vecList.add(clickVec.method_1019(extendVec.method_1021(0.4)));
        }
//        BlockUtil.getExtendVec(offsetDir, true)
//            .forEach(vec3d -> vecList.add(clickVec.add(vec3d.multiply(0.4))));
        //获取衍生的Vec偏移量,与基础中心Vec相加,放入列表
        if (strictVec)
            vecList = vecList.stream().map(vec3d -> {
                    class_3965 strictVecResult = RayTraceUtil.INSTANCE.getStrictVecResult(vec3d, offsetDir, Printer.getINSTANCE().bSetLiquidInt.get(), 1.57);
                    if (strictVecResult.method_17783() == class_239.class_240.field_1333) {
                        return null;
                    }
                    if (!RayTraceUtil.INSTANCE.rayTrace(placePos.method_10093(offsetDir), offsetDir.method_10153(), strictVecResult.method_17784(), raytrace, ignoreEntity, rayRange))
                        return null;
                    return strictVecResult.method_17784();
                })
                .filter(Objects::nonNull)
                .filter(vec -> vec.field_1352 <= clickPos.method_10263() + 1.001 && vec.field_1352 >= clickPos.method_10263() - 0.001
                    && vec.field_1351 <= clickPos.method_10264() + 1.001 && vec.field_1351 >= clickPos.method_10264() - 0.001
                    && vec.field_1350 <= clickPos.method_10260() + 1.001 && vec.field_1350 >= clickPos.method_10260() - 0.001

                )
                //判断是否在要放置的方块里面
                .collect(Collectors.toList());
        if (offsetDir.method_10166() != class_2350.class_2351.field_11052)
            switch (mode) {
                case 1 -> vecList.removeIf(vec3d -> vec3d.field_1351 - Math.floor(vec3d.field_1351) <= 0.5);
                case 2 -> vecList.removeIf(vec3d -> vec3d.field_1351 - Math.floor(vec3d.field_1351) >= 0.5);
            }
        return vecList;

    }

    public List<class_243> clickVecs(class_2350 offset, int mode, DirDataConfig cfg) {
        if (cfg.multiVec)
            return getClickVecs(offset, mode, cfg.randOffset, cfg.strictVec, cfg.raytrace, cfg.ignoreEntity, cfg.rayRange);
        return getClickVec1(offset, mode, cfg.randOffset, cfg.strictVec, cfg.raytrace, cfg.ignoreEntity, cfg.rayRange);
    }

    public List<class_243> clickVecs(class_2350 offset, DirDataConfig cfg) {
        return clickVecs(offset, 0, cfg);
    }

    public List<class_243> clickVecs(class_2350 offset) {
        return clickVecs(offset, 0, DirDataConfig.getDefault());
    }

    public List<class_243> clickVecs(class_2350 offset, int mode) {
        return clickVecs(offset, mode, DirDataConfig.getDefault());
    }

    public List<class_243> getClickVecs(class_2350 offsetDir) {
        return getClickVecs(offsetDir, pri.bSetRandomOffset.get(), pri.bSetStrictVec.get() && pri.bSetStrictVec.isVisible(), pri.bSetRayTrace.isVisible() && pri.bSetRayTrace.get(), pri.bSetIgnoreEntity.get(), pri.dSetPrintingRange.get());
    }

    public static class DirDataConfig {
        private static final DirDataConfig DEFAULT = new DirDataConfig();

        public static final DirDataConfig getDefault() {
            DEFAULT.multiVec = pri.bSetMultiVec.get();
            DEFAULT.randOffset = pri.bSetRandomOffset.get();
            DEFAULT.strictVec = pri.bSetStrictVec.get() && pri.bSetStrictVec.isVisible();
            DEFAULT.raytrace = pri.bSetRayTrace.isVisible() && pri.bSetRayTrace.get();
            DEFAULT.ignoreEntity = pri.bSetIgnoreEntity.get();
            DEFAULT.rayRange = pri.dSetPrintingRange.get();
            return DEFAULT;
        }

        public boolean multiVec = pri.bSetMultiVec.get();
        public boolean randOffset = pri.bSetRandomOffset.get();
        public boolean strictVec = pri.bSetStrictVec.get() && pri.bSetStrictVec.isVisible();
        public boolean raytrace = pri.bSetRayTrace.isVisible() && pri.bSetRayTrace.get();
        public boolean ignoreEntity = pri.bSetIgnoreEntity.get();
        public double rayRange = pri.dSetPrintingRange.get();

        public DirDataConfig setMultiVec(boolean multiVec) {
            this.multiVec = multiVec;
            return this;
        }

        public DirDataConfig setRandOffset(boolean randOffset) {
            this.randOffset = randOffset;
            return this;
        }

        public DirDataConfig setStrictVec(boolean strictVec) {
            this.strictVec = strictVec;
            return this;
        }

        public DirDataConfig setRaytrace(boolean raytrace) {
            this.raytrace = raytrace;
            return this;
        }

        public DirDataConfig setIgnoreEntity(boolean ignoreEntity) {
            this.ignoreEntity = ignoreEntity;
            return this;
        }

        public DirDataConfig setRayRange(double rayRange) {
            this.rayRange = rayRange;
            return this;
        }
    }



    public List<class_243> getClickVecInte1(class_2350 offsetDir) {
        return getClickVecInte1(offsetDir, 0);
    }

    public class_243 getClickVecInte(class_2350 offsetDir) {
        //if (i >= dirs.size() - 1) return null;
        class_243 centerVec = placePos.method_46558();
        //Direction offsetDir = dirs.get(i);
        return centerVec.method_43206(offsetDir, pri.bSetStrictVec.get()&&pri.isStrictVecInte()?0.501:0.5);
    }

    public List<class_243> getClickVecsInte(final class_2350 offsetDir) {
        return getClickVecsInte(offsetDir, 0);
    }


    public List<class_243> getClickVecInte1(class_2350 offsetDir, int mode) {
        ArrayList<class_243> res = new ArrayList<>();

        class_243 clickVec = placePos.method_46558().method_43206(offsetDir, pri.bSetStrictVec.get()&&pri.isStrictVecInte()?0.501:0.5);
        if (pri.bSetRandomOffset.get())
            clickVec = BlockUtil.randomOffsetVec(clickVec, offsetDir);
        if (offsetDir.method_10166() != class_2350.class_2351.field_11052)
            clickVec = switch (mode) {
                case 1 -> clickVec.method_43206(class_2350.field_11036, 0.2);
                case 2 -> clickVec.method_43206(class_2350.field_11033, 0.2);
                default -> clickVec;
            };

        if (pri.bSetStrictVec.get()&&pri.isStrictVecInte()) {
            class_3965 result = RayTraceUtil.INSTANCE.getStrictVecResult(clickVec, offsetDir.method_10153(), Printer.getINSTANCE().bSetLiquidInt.get(),1);
            if (result.method_17783() == class_239.class_240.field_1333) return res;
            clickVec = result.method_17784();
            if (!RayTraceUtil.INSTANCE.rayTrace(placePos,offsetDir,clickVec))
                return res;
        }
        res.add(clickVec);
        return res;
    }

    //mode 1 上半 2 下半
    public List<class_243> getClickVecsInte(final class_2350 offsetDir, int mode) {
        List<class_243> vecList = new LinkedList<>();
        //装可用的Vec
        //final Direction offsetDir = dirs.get(i);//偏移方向

        class_243 clickVec = getClickVecInte(offsetDir);//基础的中心Vec
        if (pri.bSetRandomOffset.get()) {//随机offset 用于bypass
            vecList.add(BlockUtil.randomOffsetVec(clickVec, offsetDir));
        } else
            vecList.add(clickVec);

        for (class_243 extendVec : BlockUtil.getExtendVec(offsetDir, true)) {
            vecList.add(clickVec.method_1019(extendVec.method_1021(0.4)));
        }
        //.forEach(vec3d -> vecList.add(clickVec.add(vec3d.multiply(0.4))));
        //获取衍生的Vec偏移量,与基础中心Vec相加,放入列表
        if (pri.bSetStrictVec.get()&&pri.isStrictVecInte())
            vecList = vecList.stream().map(vec3d -> {
                    class_3965 strictVecResult = RayTraceUtil.INSTANCE.getStrictVecResult(vec3d, offsetDir.method_10153(), Printer.getINSTANCE().bSetLiquidInt.get(),1);
                    if (strictVecResult.method_17783() == class_239.class_240.field_1333) {
                        return null;
                    }
                    if (!RayTraceUtil.INSTANCE.rayTrace(placePos,offsetDir,strictVecResult.method_17784()))
                        return null;
                    return strictVecResult.method_17784();
                })
                .filter(Objects::nonNull).collect(Collectors.toList());
        if (offsetDir.method_10166() != class_2350.class_2351.field_11052)
            switch (mode) {
                case 1:
                    vecList.removeIf(vec3d -> vec3d.field_1351 - Math.floor(vec3d.field_1351) <= 0.5);
                    break;
                case 2:
                    vecList.removeIf(vec3d -> vec3d.field_1351 - Math.floor(vec3d.field_1351) >= 0.5);
            }
        return vecList;

    }

    public List<class_243> clickVecsInte(class_2350 offset) {
        return clickVecsInte(offset,0);
    }

    public List<class_243> clickVecsInte(class_2350 offset, int mode) {
        if (pri.bSetMultiVec.get())
            return getClickVecsInte(offset,mode);
        return getClickVecInte1(offset, mode);
    }
}
