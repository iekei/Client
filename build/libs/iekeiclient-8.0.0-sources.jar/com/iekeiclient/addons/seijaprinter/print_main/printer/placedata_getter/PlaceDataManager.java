/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter;

import com.iekeiclient.addons.seijaprinter.print_main.modules.Printer;
import com.iekeiclient.addons.seijaprinter.print_main.printer.extra_setting.HasExtraSetting;
import com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.vanilla_precision_placer.DataGetter;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.BlockUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.InvUtil;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.DirData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceData;
import com.iekeiclient.addons.seijaprinter.print_main.printer.placedata_getter.getter.*;
import com.iekeiclient.addons.seijaprinter.print_main.printer.util.records.PlaceDataPack;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.settings.Settings;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2189;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class PlaceDataManager implements HasExtraSetting {
    private static final PlaceDataManager INSTANCE = new PlaceDataManager();
    public static final PlaceDataManager getInstance(){
        return INSTANCE;
    }


    private static final class_310 mc = class_310.method_1551();

    public PlaceDataPack getPlaceData(class_2338 pos, class_2680 needState) {
        if (!mc.field_1687.method_8320(pos).method_45474())
            return PlaceDataPack.NULL;
        //若某位置已有不可被替换的方块 则返回
        if (needState.method_26215())
            return PlaceDataPack.NULL;
        //若投影中某位置为空气,则返回
        List<class_2350> dirs = BlockUtil.getSortedDirs(pos,false);
        List<class_1799> stacks;
        if (/*dirs.isEmpty() ||*/ needState.method_26204() instanceof class_2189 || (stacks = InvUtil.getBlockStacks(needState.method_26204())).isEmpty()) {
            //没有可用Facing(后移至原版计算(for))//找不到方块//不可放置

            return PlaceDataPack.NULL;

        }
        return getPlaceData(pos, needState, dirs, stacks);
    }

    /**
     * get place data 获取精准放置的数据
     *
     * @param pos       pos 放置位置
     * @param needState needState 需要的方块状态
     * @param dirs      dirs 所有可用支持面
     * @return {@link PlaceData} 返回放置数据
     * @see PlaceData
     */
    public PlaceDataPack getPlaceData(class_2338 pos, class_2680 needState, List<class_2350> dirs, List<class_1799> stacks) {
        DirData dirData = new DirData(pos, dirs);
        //ChatUtils.sendMsg(Text.of("GetData2"));
//        if (true)
//            return DataGetter.getData(needState, new DirData(pos, dirs), stacks.get(0));
        Printer pri = Printer.INSTANCE;
        if (pri.bSetEnablePrecisionPlace.get())//是否启用精准放置
            try {
                for (AbstractDataGetter dataGetter : dataGetters) {
                    //遍历所有数据获取器,以求更加精准的放置数据
                    if (dataGetter.isSuitable(needState, pos)) {
                        //适合则进行数据获取
                        return PlaceDataPack.plac(dataGetter.getData(needState, dirData));
                    }
                }
            } catch (IllegalArgumentException ignore) {
                //异常处理,防止小天才乱玩方块替换
            }
        //默认放置
        if (pri.bSetEnablePrecisionPlace.get() && pri.bSetTryVanillaPrecisionPlace.get()) {
            return DataGetter.getData(needState, new DirData(pos, dirs), stacks.get(0));
        }
        for (class_2350 dir : dirData.dirs()) {
            for (class_243 hitVec : dirData.clickVecs(dir)) {
                return PlaceDataPack.plac( PlaceData.newInstance(pos.method_10093(dir), dir.method_10153()
                    , hitVec, true, null));
            }
        }
        return PlaceDataPack.NULL;

    }

    private final List<AbstractDataGetter> dataGetters = new ArrayList<>();

    private PlaceDataManager() {
        //精准放置规则注册表
        dataGetters.add(new BuckedDataGetter());
//        dataGetters.add(new ClickDirDataGetter());
//        dataGetters.add(new HFaceDirOppositeDataGetter());
//        dataGetters.add(new RedStoneGateDataGetter());
//        dataGetters.add(new BigDripLeafDataGetter());
//        dataGetters.add(new SmallDripDataGetter());
//        dataGetters.add(new PillarDataGetter());
//        dataGetters.add(new PistonDataGetter());
//        dataGetters.add(new SlabDataGetter());
//        dataGetters.add(new StairDataGetter());
//        dataGetters.add(new TrapdoorDataGetter());
//       //dataGetters.add(new WallMountedDataGetter());
//        dataGetters.add(new BedDataGetter());
//        dataGetters.add(new DoorDataGetter());
//        dataGetters.add(new HopperDataGetter());
//        dataGetters.add(new HFaceDirDataGetter());
//        dataGetters.add(new ChestDataGetter());
//        dataGetters.add(new AnvilDataGetter());
//        dataGetters.add(new TorchBlockDataGetter());
//        dataGetters.add(new ObserverDataGetter());
//        dataGetters.add(new SignDataGetter());
//        dataGetters.add(new HangingSignDataGetter());

    }

    @Override
    public SettingGroup getSettingGroup(Settings settings) {
        SettingGroup sgDatagetter = settings.createGroup("PlaceDataGetter");
        for (AbstractDataGetter dataGetter : dataGetters) {
            Arrays.stream(dataGetter.getSettings()).forEach(sgDatagetter::add);
        }
        return sgDatagetter;
    }
}
