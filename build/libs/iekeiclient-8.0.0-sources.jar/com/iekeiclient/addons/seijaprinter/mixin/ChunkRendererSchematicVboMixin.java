/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.mixin;

import com.iekeiclient.addons.seijaprinter.print_main.printer.util.ScheVerifyMixinUtil;
import fi.dy.masa.litematica.render.schematic.ChunkRendererSchematicVbo;
import fi.dy.masa.litematica.util.OverlayType;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value = ChunkRendererSchematicVbo.class,remap = false)
public class ChunkRendererSchematicVboMixin {
    @Shadow
    private boolean ignoreClientWorldFluids;

    /**
     * @author Nippaku_Zanmu
     * @reason 实现方块替换后正常渲染
     */
    @Overwrite
    protected OverlayType getOverlayType(class_2680 stateSchematic, class_2680 stateClient)
    {
        boolean replacedBlockEqual = ScheVerifyMixinUtil.isReplacedBlockEqual(stateSchematic.method_26204(), stateClient.method_26204());
        if (replacedBlockEqual
        &&ScheVerifyMixinUtil.propEqual(stateSchematic,stateClient))
        {
            return OverlayType.NONE;
        }
        else
        {
            boolean clientHasAir = stateClient.method_26215();
            boolean schematicHasAir = stateSchematic.method_26215();

            if (schematicHasAir)
            {
                return (clientHasAir || (this.ignoreClientWorldFluids && stateClient.method_51176())) ? OverlayType.NONE : OverlayType.EXTRA;
            }
            else
            {
                if (clientHasAir || (this.ignoreClientWorldFluids && stateClient.method_51176()))
                {
                    return OverlayType.MISSING;
                }
                // Wrong block
                else if (!replacedBlockEqual)
                {
                    return OverlayType.WRONG_BLOCK;
                }
                // Wrong state
                else
                {
                    return OverlayType.WRONG_STATE;
                }
            }
        }
    }
}
