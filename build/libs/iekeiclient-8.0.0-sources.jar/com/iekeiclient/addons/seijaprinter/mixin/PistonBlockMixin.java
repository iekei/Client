/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.mixin;

import com.iekeiclient.engine.utils.player.ChatUtils;
import net.minecraft.class_1750;
import net.minecraft.class_2561;
import net.minecraft.class_2665;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2665.class)
public class PistonBlockMixin {
    @Inject(method = "getPlacementState",at = @At("RETURN"))
    public void a(class_1750 ctx, CallbackInfoReturnable<class_2680> cir){
        ChatUtils.sendMsg(class_2561.method_30163(ctx.method_17698().toString()));
        ChatUtils.sendMsg(ctx.method_8036().method_5477());
        ChatUtils.sendMsg(class_2561.method_30163(""+ctx.method_8036().method_5705(1.0F)));
        ChatUtils.sendMsg(class_2561.method_30163(""+ctx.method_7715()));
    }
}
