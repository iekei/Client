/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.settings.impl;

import com.iekeiclient.engine.settings.IVisible;
import com.iekeiclient.engine.settings.Setting;
import java.util.*;
import java.util.function.Consumer;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class BlockReplaceSetting extends Setting<HashMap<List<class_2248>, List<class_2248>>> {


    private BlockReplaceSetting(String name, String description, HashMap<List<class_2248>, List<class_2248>> defaultValue, Consumer<HashMap<List<class_2248>, List<class_2248>>> onChanged, Consumer<Setting<HashMap<List<class_2248>, List<class_2248>>>> onModuleActivated, IVisible visible) {
        super(name, description, defaultValue, onChanged, onModuleActivated, visible);
    }

    @Override
    protected void resetImpl() {
        value = new LinkedHashMap<>(defaultValue);
    }

    @Override
    protected HashMap<List<class_2248>, List<class_2248>> parseImpl(String str) {
        return new LinkedHashMap<>(0);
    }

    @Override
    protected boolean isValueValid(HashMap<List<class_2248>, List<class_2248>> value) {
        return true;
    }


    @Override
    protected class_2487 save(class_2487 tag) {
        class_2499 valueTag = new class_2499();//总列表 存储键值对
        for (Map.Entry<List<class_2248>, List<class_2248>> blockEntry : get().entrySet()) {
            List<class_2248> keyBlocks = blockEntry.getKey();
            List<class_2248> valueBlocks = blockEntry.getValue();

            if (valueBlocks == null)
                continue;

            //单个
            class_2487 entryTag = new class_2487();//单个键值对标签

            class_2499 keyBlockList = new class_2499();
            for (class_2248 block : keyBlocks) {
                keyBlockList.add(class_2519.method_23256(class_7923.field_41175.method_10221(block).toString()));
            }//填写key
            entryTag.method_10566("keyBlocks", keyBlockList);

            class_2499 valueBlockList = new class_2499();
            for (class_2248 block : valueBlocks) {
                valueBlockList.add(class_2519.method_23256(class_7923.field_41175.method_10221(block).toString()));
            }//填valueBlock
            entryTag.method_10566("valBlocks", valueBlockList);

            valueTag.add(entryTag);

        }
        tag.method_10566("value", valueTag);


        return tag;
    }

    @Override
    protected HashMap<List<class_2248>, List<class_2248>> load(class_2487 tag) {
        get().clear();
        class_2499 entryListTag = tag.method_68569("value");

        for (int i = 0; i < entryListTag.size(); i++) {
            class_2487 entryTag = entryListTag.method_10602(i).orElse(null);
            if (entryTag==null)continue;
            class_2499 keyBlocksTag = entryTag.method_68569("keyBlocks");
            ArrayList<class_2248> keyList = new ArrayList<>();
            for (class_2520 tagI : keyBlocksTag) {
                class_2248 block = class_7923.field_41175.method_63535(class_2960.method_60654(tagI.method_68658().orElse("")));
                keyList.add(block);
            }
            class_2499 valBlocksTag = entryTag.method_68569("valBlocks");
            ArrayList<class_2248> valList = new ArrayList<>();
            for (class_2520 tagI : valBlocksTag) {
                class_2248 block = class_7923.field_41175.method_63535(class_2960.method_60654(tagI.method_68658().orElse("")));
                valList.add(block);
            }
            get().put(keyList, valList);
        }

        return get();
    }

    public static class Builder extends SettingBuilder<BlockReplaceSetting.Builder, HashMap<List<class_2248>, List<class_2248>>, BlockReplaceSetting> {
        public Builder() {
            super(new LinkedHashMap<>());
        }

        @Override
        public BlockReplaceSetting build() {
            return new BlockReplaceSetting(name, description, new LinkedHashMap<>(defaultValue), onChanged, onModuleActivated, visible);
        }


    }
}
