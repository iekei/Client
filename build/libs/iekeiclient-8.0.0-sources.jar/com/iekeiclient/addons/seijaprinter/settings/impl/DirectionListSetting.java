/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.settings.impl;

import com.iekeiclient.engine.settings.IVisible;
import com.iekeiclient.engine.settings.Setting;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

public class DirectionListSetting extends Setting<List<class_2350>> {
    public DirectionListSetting(String name, String description, List<class_2350> defaultValue, Consumer<List<class_2350>> onChanged, Consumer<Setting<List<class_2350>>> onModuleActivated, IVisible visible) {
        super(name, description, defaultValue, onChanged, onModuleActivated, visible);
    }

    @Override
    protected List<class_2350> parseImpl(String str) {
        String[] values = str.split(",");
        List<class_2350> dirs = new ArrayList<>(values.length);
        for (String s : values) {
            class_2350 dir = class_2350.method_10168(s);
            if (dir != null) dirs.add(dir);
        }
        return dirs;
    }

    @Override
    protected boolean isValueValid(List<class_2350> value) {
        return true;
    }

    @Override
    protected void resetImpl() {
        value = new ArrayList<>();
    }

    @Override
    public class_2487 save(class_2487 tag) {
        class_2499 valueTag = new class_2499();
        for (class_2350 dir : get()) {
            valueTag.add(class_2519.method_23256(dir.method_10151()));
        }
        tag.method_10566("value", valueTag);

        return tag;
    }

    @Override
    public List<class_2350> load(class_2487 tag) {
        get().clear();

        class_2499 valueTag = tag.method_68569("value");
        for (class_2520 tagI : valueTag) {
            class_2350 dir = class_2350.method_10168(tagI.method_68658().orElse(null));
            if (dir != null)
                get().add(dir);
        }

        return get();
    }

    public static class Builder extends SettingBuilder<Builder, List<class_2350>, DirectionListSetting> {

        public Builder() {
            super(new ArrayList<>(0));
        }

        @Override
        public Builder defaultValue(List<class_2350> map) {
            this.defaultValue = map;
            return this;
        }

        public DirectionListSetting.Builder defaultValue(class_2350... defaults) {
            return defaultValue(defaults != null ? Arrays.asList(defaults) : new ArrayList<>());
        }

        @Override
        public DirectionListSetting build() {
            return new DirectionListSetting(name, description, defaultValue, onChanged, onModuleActivated, visible);
        }
    }
}
