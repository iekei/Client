/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.settings.impl;

import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.WindowScreen;
import com.iekeiclient.engine.gui.renderer.GuiRenderer;
import com.iekeiclient.engine.gui.screens.settings.BlockListSettingScreen;
import com.iekeiclient.engine.gui.widgets.containers.WTable;
import com.iekeiclient.engine.gui.widgets.input.WTextBox;
import com.iekeiclient.engine.gui.widgets.pressable.WButton;
import com.iekeiclient.engine.gui.widgets.pressable.WPressable;
import com.iekeiclient.engine.settings.BlockListSetting;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2248;

import static com.iekeiclient.engine.IekeiClient.mc;

public class BlockReplaceSettingScreen extends WindowScreen {


    public BlockReplaceSettingScreen(GuiTheme theme, BlockReplaceSetting setting) {
        super(theme, "BlockReplace");
        this.setting = setting;
    }

    private final BlockReplaceSetting setting;
    WTable table = add(theme.table()).expandX().widget();

    private WTextBox filter;
    private String filterText = "";

    @Override
    public void initWidgets() {
//        table = add(theme.table()).expandX().widget();
        widgets();
    }

    public void widgets() {


//        if (table.rowI()!=setting.get().size()+1)
//            table.clear();

        for (Map.Entry<List<class_2248>, List<class_2248>> entry : setting.get().entrySet()) {
            if (entry.getValue() == null) {
                continue;
            }
            List<class_2248> keyBlocks = entry.getKey();
            WButton editKeys = table.add(theme.button(GuiRenderer.EDIT)).widget();
            int keyRenderCount = 0;//渲染的预览被替换方块数
            for (; keyRenderCount < keyBlocks.size() && keyRenderCount < 4; keyRenderCount++) {
                table.add(theme.item(keyBlocks.get(keyRenderCount).method_8389().method_7854()));
            }//方块预览
            int extraKeyBlockCount = keyBlocks.size() - 4;
            table.add(theme.tooltip(extraKeyBlockCount > 0 ? "+" + extraKeyBlockCount + "  ->  " : "  ->  "));
            //额外数量
            editKeys.action = () -> {
                BlockListSetting keySetting = new BlockListSetting.Builder()
                    .name("keyBlock").defaultValue(keyBlocks).build();
                //调用流星的方块选择要转换setting

                BlockListSettingScreen keyScreen = new BlockListSettingScreen(theme, keySetting);
                //创建流星的方块选择窗口
                keyScreen.onClosed(() -> {
                    keyBlocks.clear();
                    keyBlocks.addAll(keySetting.get());
                    table.clear();
                    widgets();
                });//关闭窗口时应用选择的配置
                mc.method_1507(keyScreen);
            };


//            setting.get().computeIfAbsent(keyBlocks, k -> new ArrayList<>());
            List<class_2248> valueBlocks = entry.getValue();
            WButton editValues = table.add(theme.button(GuiRenderer.EDIT)).widget();

            int valRenderCount = 0;//渲染的预览替换方块数
            for (; valRenderCount < valueBlocks.size() && valRenderCount <= 4; valRenderCount++) {
                table.add(theme.item(valueBlocks.get(valRenderCount).method_8389().method_7854()));
            }//方块预览
            int extraValBlockCount = valueBlocks.size() - 4;
            table.add(theme.tooltip(extraValBlockCount > 0 ? "+" + extraValBlockCount : ""));
            //额外数量

            editValues.action = () -> {
                BlockListSetting valueSetting = new BlockListSetting.Builder()
                    .name("valueBlock").defaultValue(valueBlocks).build();
                BlockListSettingScreen valueScreen = new BlockListSettingScreen(theme, valueSetting);
                valueScreen.onClosed(() -> {
                    valueBlocks.clear();
                    valueBlocks.addAll(valueSetting.get());
                    table.clear();
                    widgets();
                });
                mc.method_1507(valueScreen);
            };


            WPressable button = table.add(theme.minus()).expandCellX().right().widget();
            button.action = () -> {
                keyBlocks.clear();
                valueBlocks.clear();
                setting.get().put(keyBlocks, null);
                setting.get().remove(keyBlocks);
                table.clear();
                widgets();
            };
            table.row();
        }
//        for (List<Block> keyBlocks : setting.get().values()) {
//
//
//        }
        WButton add = table.add(theme.button("Add")).expandCellX().center().widget();
        add.action = () -> {
            setting.get().put(new ArrayList<>(), new ArrayList<>());
            table.clear();
            widgets();
        };
    }
}
