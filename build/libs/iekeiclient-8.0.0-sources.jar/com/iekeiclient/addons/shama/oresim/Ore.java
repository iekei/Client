package com.iekeiclient.addons.shama.oresim;

/*
 * Ore registry reader — ported to Yarn mappings from Iekei Rejects' Ore.java.
 *   Original (GPL-3.0): https://github.com/AntiCope/meteor-rejects
 *   Rejects ported it from Atomic: https://gitlab.com/0x151/atomic
 * This reads the REAL ore placement configs from the vanilla registry, so each
 * ore's index/step/count/height/rarity/size match actual generation. That's
 * what makes the sim accurate instead of an approximation.
 */

import com.iekeiclient.addons.shama.mixin.CountPlacementModifierAccessor;
import com.iekeiclient.addons.shama.mixin.HeightRangePlacementModifierAccessor;
import com.iekeiclient.addons.shama.mixin.RarityFilterPlacementModifierAccessor;

import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.world.Dimension;
import java.util.*;
import net.minecraft.class_1959;
import net.minecraft.class_3037;
import net.minecraft.class_310;
import net.minecraft.class_3124;
import net.minecraft.class_5321;
import net.minecraft.class_5539;
import net.minecraft.class_5868;
import net.minecraft.class_6016;
import net.minecraft.class_6017;
import net.minecraft.class_6122;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6816;
import net.minecraft.class_7225;
import net.minecraft.class_7510;
import net.minecraft.class_7887;
import net.minecraft.class_7924;

public class Ore {

    private static final Setting<Boolean> coal     = new BoolSetting.Builder().name("Coal").build();
    private static final Setting<Boolean> iron     = new BoolSetting.Builder().name("Iron").build();
    private static final Setting<Boolean> gold     = new BoolSetting.Builder().name("Gold").build();
    private static final Setting<Boolean> redstone = new BoolSetting.Builder().name("Redstone").build();
    private static final Setting<Boolean> diamond  = new BoolSetting.Builder().name("Diamond").build();
    private static final Setting<Boolean> lapis    = new BoolSetting.Builder().name("Lapis").build();
    private static final Setting<Boolean> copper   = new BoolSetting.Builder().name("Copper").build();
    private static final Setting<Boolean> emerald  = new BoolSetting.Builder().name("Emerald").build();
    private static final Setting<Boolean> quartz   = new BoolSetting.Builder().name("Quartz").build();
    private static final Setting<Boolean> debris   = new BoolSetting.Builder().name("Ancient Debris").build();
    public static final List<Setting<Boolean>> oreSettings = new ArrayList<>(Arrays.asList(
        coal, iron, gold, redstone, diamond, lapis, copper, emerald, quartz, debris));

    public static Map<class_5321<class_1959>, List<Ore>> getRegistry(Dimension dimension) {
        // Use the LIVE world registries. registry.get(key) returns the value
        // directly, sidestepping RegistryEntry.value() entirely.
        var world = class_310.method_1551().field_1687;
        if (world == null) return null;
        var drm = world.method_30349();
        // Servers (SMP/anarchy like DonutSMP) usually DON'T sync the worldgen
        // placed_feature registry to the client. If it's missing, return null so
        // the caller can fall back, instead of throwing inside the game-join
        // handler (which disconnects the client and locks it out of the server).
        net.minecraft.class_2378<class_6796> placedReg;
        net.minecraft.class_2378<class_1959> biomeReg;
        try {
            placedReg = drm.method_30530(class_7924.field_41245);
            biomeReg = drm.method_30530(class_7924.field_41236);
        } catch (Exception e) {
            return null;
        }

        // Biome VALUES (not entries) so the indexer function needs no .value().
        List<class_1959> biomeList = new ArrayList<>();
        for (class_1959 b : biomeReg) biomeList.add(b);
        return build(biomeList, b -> biomeReg.method_29113(b).orElse(null), key -> placedReg.method_29107(key), dimension);
    }

    // ---- Source B: rebuild vanilla worldgen locally on the client ----
    // Lets Current stay seed-exact even on servers that don't share the
    // placed_feature registry (DonutSMP etc.), like Nora/Rejects do. Wrapped so
    // any vanilla-API mismatch returns null (caller falls back) instead of crashing.
    private static class_7225.class_7874 VANILLA;

    /** Find the vanilla worldgen wrapper reflectively — the class name/location has
     *  moved between versions, so try the known ones and return null (caller falls
     *  back to the server registry / hardcoded path) if none are present. */
    private static class_7225.class_7874 loadVanilla() {
        // 1.21.11 (verified): BuiltinRegistries.createWrapperLookup() builds the full
        // builtin registry set (biomes + placed features) used for ore prediction.
        // Direct call so Loom remaps it; the server-registry path is the fallback if
        // this ever throws.
        try {
            return class_7887.method_46817();
        } catch (Throwable t) {
            return null;
        }
    }

    public static Map<class_5321<class_1959>, List<Ore>> getRegistryLocal(Dimension dimension) {
        try {
            if (VANILLA == null) VANILLA = loadVanilla();
            if (VANILLA == null) return null;
            class_7225.class_7226<class_1959> biomeW = VANILLA.method_46762(class_7924.field_41236);
            class_7225.class_7226<class_6796> placedW = VANILLA.method_46762(class_7924.field_41245);

            List<class_1959> biomeList = new ArrayList<>();
            Map<class_1959, class_5321<class_1959>> keyMap = new HashMap<>();
            biomeW.method_42017().forEach(ref -> {
                Object v = entryValue(ref, class_1959.class);
                if (v instanceof class_1959 b) { biomeList.add(b); keyMap.put(b, ref.method_40237()); }
            });
            if (biomeList.isEmpty()) return null;

            java.util.function.Function<class_5321<class_6796>, class_6796> placedGet = key -> {
                if (key == null) return null;
                try {
                    Object v = entryValue(placedW.method_46747(key), class_6796.class);
                    return (v instanceof class_6796 pf) ? pf : null;
                } catch (Exception e) { return null; }
            };
            return build(biomeList, keyMap::get, placedGet, dimension);
        } catch (Throwable t) {
            return null; // any vanilla-API mismatch -> caller falls back, never crash
        }
    }

    // ---- Version + source dispatch (called by OreSim) ----
    public static Map<class_5321<class_1959>, List<Ore>> getRegistry(Dimension dimension, OreVersion version, boolean useServerRegistry) {
        if (version == OreVersion.CURRENT) {
            Map<class_5321<class_1959>, List<Ore>> primary = useServerRegistry ? getRegistry(dimension) : getRegistryLocal(dimension);
            if (primary != null && !primary.isEmpty()) return primary;
            // chosen source failed -> try the other, then the bundled modern table.
            Map<class_5321<class_1959>, List<Ore>> secondary = useServerRegistry ? getRegistryLocal(dimension) : getRegistry(dimension);
            if (secondary != null && !secondary.isEmpty()) return secondary;
            return buildHardcoded(dimension, OreVersion.V1_20);
        }
        return buildHardcoded(dimension, version);
    }

    // ---- Shared builder: biomes + key/value lookups -> biome→ore map ----
    private static Map<class_5321<class_1959>, List<Ore>> build(
            List<class_1959> biomeList,
            java.util.function.Function<class_1959, class_5321<class_1959>> biomeKeyFn,
            java.util.function.Function<class_5321<class_6796>, class_6796> placedGet,
            Dimension dimension) {

        List<class_7510.class_6827> indexer = class_7510.method_44210(
            biomeList,
            biome -> biome.method_30970().method_30983(),
            true
        );

        Map<class_6796, Ore> featureToOre = new HashMap<>();
        reg(featureToOre, indexer, placedGet, class_6816.field_36070, 6, coal, new Color(47, 44, 54));
        reg(featureToOre, indexer, placedGet, class_6816.field_36069, 6, coal, new Color(47, 44, 54));
        reg(featureToOre, indexer, placedGet, class_6816.field_36072, 6, iron, new Color(236, 173, 119));
        reg(featureToOre, indexer, placedGet, class_6816.field_36073, 6, iron, new Color(236, 173, 119));
        reg(featureToOre, indexer, placedGet, class_6816.field_36071, 6, iron, new Color(236, 173, 119));
        reg(featureToOre, indexer, placedGet, class_6816.field_36075, 6, gold, new Color(247, 229, 30));
        reg(featureToOre, indexer, placedGet, class_6816.field_36076, 6, gold, new Color(247, 229, 30));
        reg(featureToOre, indexer, placedGet, class_6816.field_36074, 6, gold, new Color(247, 229, 30));
        reg(featureToOre, indexer, placedGet, class_6816.field_36056, 7, gold, new Color(247, 229, 30));
        reg(featureToOre, indexer, placedGet, class_6816.field_36054, 7, gold, new Color(247, 229, 30));
        reg(featureToOre, indexer, placedGet, class_6816.field_36077, 6, redstone, new Color(245, 7, 23));
        reg(featureToOre, indexer, placedGet, class_6816.field_36039, 6, redstone, new Color(245, 7, 23));
        reg(featureToOre, indexer, placedGet, class_6816.field_36040, 6, diamond, new Color(33, 244, 255));
        reg(featureToOre, indexer, placedGet, class_6816.field_36042, 6, diamond, new Color(33, 244, 255));
        reg(featureToOre, indexer, placedGet, class_6816.field_36041, 6, diamond, new Color(33, 244, 255));
        reg(featureToOre, indexer, placedGet, class_6816.field_45664, 6, diamond, new Color(33, 244, 255));
        reg(featureToOre, indexer, placedGet, class_6816.field_36043, 6, lapis, new Color(8, 26, 189));
        reg(featureToOre, indexer, placedGet, class_6816.field_36044, 6, lapis, new Color(8, 26, 189));
        reg(featureToOre, indexer, placedGet, class_6816.field_36049, 6, copper, new Color(239, 151, 0));
        reg(featureToOre, indexer, placedGet, class_6816.field_36050, 6, copper, new Color(239, 151, 0));
        reg(featureToOre, indexer, placedGet, class_6816.field_36046, 6, emerald, new Color(27, 209, 45));
        reg(featureToOre, indexer, placedGet, class_6816.field_36057, 7, quartz, new Color(205, 205, 205));
        reg(featureToOre, indexer, placedGet, class_6816.field_36055, 7, quartz, new Color(205, 205, 205));
        reg(featureToOre, indexer, placedGet, class_6816.field_36048, 7, debris, new Color(209, 27, 245));

        Map<class_5321<class_1959>, List<Ore>> biomeOreMap = new HashMap<>();
        for (class_1959 biome : biomeList) {
            class_5321<class_1959> key = biomeKeyFn.apply(biome);
            if (key == null) continue;
            List<Ore> list = new ArrayList<>();
            for (var stepFeatures : biome.method_30970().method_30983()) {
                for (var entry : stepFeatures) {
                    class_6796 pf = placedGet.apply(entry.method_40230().orElse(null));
                    if (pf != null && featureToOre.containsKey(pf)) list.add(featureToOre.get(pf));
                }
            }
            biomeOreMap.put(key, list);
        }
        return biomeOreMap;
    }

    private static void reg(
        Map<class_6796, Ore> map,
        List<class_7510.class_6827> indexer,
        java.util.function.Function<class_5321<class_6796>, class_6796> placedGet,
        class_5321<class_6796> oreKey,
        int genStep,
        Setting<Boolean> active,
        Color color
    ) {
        class_6796 orePlacement = placedGet.apply(oreKey);
        if (orePlacement == null) return;
        int index = indexOf(indexer.get(genStep), orePlacement);
        if (index < 0) return;
        map.put(orePlacement, new Ore(orePlacement, genStep, index, active, color));
    }

    // The value accessor on RegistryEntry is unnamed in this Yarn build (shows as an
    // intermediary comp_* name), so we can't call it directly. Match it by RESULT
    // instead of by name: invoke each no-arg method and keep the one that actually
    // returns the value type. Name-independent and erasure-proof, so it survives Loom
    // remapping (same philosophy as indexOf() below).
    private static Object entryValue(Object entry, Class<?> valueType) {
        if (entry == null) return null;
        for (java.lang.reflect.Method m : entry.getClass().getMethods()) {
            if (m.getParameterCount() != 0 || m.getReturnType() == void.class) continue;
            try {
                Object r = m.invoke(entry);
                if (valueType.isInstance(r)) return r;
            } catch (Exception ignored) {}
        }
        return null;
    }

    // The IndexedFeatures record's accessor names are remapped in this build, so
    // read its List<PlacedFeature> component by reflection and find the index.
    @SuppressWarnings("unchecked")
    private static int indexOf(class_7510.class_6827 indexed, class_6796 target) {
        try {
            for (java.lang.reflect.Field f : indexed.getClass().getDeclaredFields()) {
                if (java.util.List.class.isAssignableFrom(f.getType())) {
                    f.setAccessible(true);
                    List<class_6796> list = (List<class_6796>) f.get(indexed);
                    int i = list.indexOf(target);
                    if (i >= 0) return i;
                }
            }
        } catch (Exception ignored) {}
        return -1;
    }

    public int step;
    public int index;
    public Setting<Boolean> active;
    public class_6017 count = class_6016.method_34998(1);
    public class_6122 heightProvider;
    public class_5868 heightContext;
    public float rarity = 1;
    public float discardOnAirChance;
    public int size;
    public Color color;
    public boolean scattered;

    // --- Hardcoded (older-version) path ---
    public boolean hardcoded = false;   // true => use sampleY() instead of heightProvider
    public int hcMinY;
    public int hcMaxY;
    public boolean hcTrapezoid;          // true = triangle/trapezoid bias toward center, false = uniform

    /** Build an ore from explicit constants (older-version path). Height is sampled
     *  by sampleY() with plain math, so no Yarn HeightProvider/HeightContext is built. */
    public Ore(int step, int index, Setting<Boolean> active, Color color,
               int count, int minY, int maxY, boolean trapezoid,
               int size, float discardOnAir, float rarity, boolean scattered) {
        this.step = step;
        this.index = index;
        this.active = active;
        this.color = color;
        this.count = class_6016.method_34998(count);
        this.hcMinY = minY;
        this.hcMaxY = maxY;
        this.hcTrapezoid = trapezoid;
        this.size = size;
        this.discardOnAirChance = discardOnAir;
        this.rarity = rarity;
        this.scattered = scattered;
        this.hardcoded = true;
    }

    /** Sample a Y for the hardcoded path. Approximate (matches the old version's
     *  approach); the registry-accurate CURRENT path uses the real heightProvider. */
    public int sampleY(net.minecraft.class_2919 random) {
        int span = Math.max(0, hcMaxY - hcMinY);
        if (hcTrapezoid) {
            return hcMinY + (random.method_43048(span + 1) + random.method_43048(span + 1)) / 2;
        }
        return hcMinY + random.method_43048(span + 1);
    }

    private Ore(class_6796 feature, int step, int index, Setting<Boolean> active, Color color) {
        this.step = step;
        this.index = index;
        this.active = active;
        this.color = color;

        var world = class_310.method_1551().field_1687;
        int bottom = world.method_31607();
        int top = world.method_31600();
        class_5539 view = class_5539.method_39034(bottom, top - bottom + 1);
        // HeightContext only reads min/height from the view; generator can be null.
        this.heightContext = new class_5868(null, view);

        for (class_6797 modifier : feature.comp_335()) {
            if (modifier instanceof class_6793) {
                this.count = ((CountPlacementModifierAccessor) modifier).getCount();
            } else if (modifier instanceof class_6795) {
                this.heightProvider = ((HeightRangePlacementModifierAccessor) modifier).getHeight();
            } else if (modifier instanceof class_6799) {
                this.rarity = ((RarityFilterPlacementModifierAccessor) modifier).getChance();
            }
        }

        // Read the OreFeatureConfig via the decorated-feature stream (avoids the
        // renamed RegistryEntry.value()).
        var configured = feature.method_39643().findFirst().orElse(null);
        class_3037 featureConfig = configured == null ? null : configured.comp_333();
        if (featureConfig instanceof class_3124 ore) {
            this.discardOnAirChance = ore.field_29064;
            this.size = ore.field_13723;
        } else {
            throw new IllegalStateException("config for " + feature + " is not OreFeatureConfig");
        }
    }

    // ==================== Older-version (hardcoded) path ====================

    public static Map<class_5321<class_1959>, List<Ore>> getRegistry(Dimension dimension, OreVersion version) {
        return getRegistry(dimension, version, false);
    }

    private static Map<class_5321<class_1959>, List<Ore>> buildHardcoded(Dimension dim, OreVersion ver) {
        Map<class_5321<class_1959>, List<Ore>> map = new HashMap<>();

        // One real biome key as a single bucket. OreSim.getOresForBiome falls back
        // to this list for every biome, so these ores apply everywhere (approx).
        var world = class_310.method_1551().field_1687;
        if (world == null) return map;
        net.minecraft.class_2378<class_1959> biomeReg;
        try { biomeReg = world.method_30349().method_30530(class_7924.field_41236); }
        catch (Exception e) { return map; }
        class_5321<class_1959> bucket = null;
        for (class_1959 b : biomeReg) { bucket = biomeReg.method_29113(b).orElse(null); if (bucket != null) break; }
        if (bucket == null) return map;

        List<Ore> ores = new ArrayList<>();
        boolean nether = dim == Dimension.Nether;
        boolean end = dim == Dimension.End;
        if (end) { map.put(bucket, ores); return map; }

        int s = 6;   // UNDERGROUND_ORES step
        int[] i = {0}; // sequential index (approximate; not seed-exact for old versions)

        if (ver.era == OreVersion.Era.NEW) {
            if (nether) {
                ores.add(new Ore(s, i[0]++, gold,    new Color(247,229,30),  10, 10, 117, false, 9,  0f,   1f, false));
                ores.add(new Ore(s, i[0]++, quartz,  new Color(205,205,205), 16, 10, 117, false, 14, 0f,   1f, false));
                ores.add(new Ore(s, i[0]++, debris,  new Color(209,27,245),  1,  8,  24,  false, 3,  0f,   1f, true));
            } else {
                ores.add(new Ore(s, i[0]++, coal,     new Color(47,44,54),   20,  0,  192, true,  17, 0.7f, 1f, false));
                ores.add(new Ore(s, i[0]++, copper,   new Color(239,151,0),  16, -16, 112, true,  10, 0f,   1f, false));
                ores.add(new Ore(s, i[0]++, iron,     new Color(236,173,119),10, -24, 56,  true,  9,  0f,   1f, false));
                ores.add(new Ore(s, i[0]++, iron,     new Color(236,173,119),10, -64, 72,  false, 9,  0f,   1f, false));
                ores.add(new Ore(s, i[0]++, gold,     new Color(247,229,30),  4, -64, 32,  true,  9,  0.5f, 1f, false));
                ores.add(new Ore(s, i[0]++, redstone, new Color(245,7,23),    4, -64, 15,  false, 8,  0f,   1f, false));
                ores.add(new Ore(s, i[0]++, redstone, new Color(245,7,23),    4, -64, -32, true,  8,  0f,   1f, false));
                ores.add(new Ore(s, i[0]++, diamond,  new Color(33,244,255),  7, -64, 16,  false, 8,  0.7f, 1f, false));
                ores.add(new Ore(s, i[0]++, lapis,    new Color(8,26,189),    2, -32, 32,  true,  7,  0f,   1f, false));
                ores.add(new Ore(s, i[0]++, lapis,    new Color(8,26,189),    4, -64, 64,  false, 7,  0f,   1f, true));
                ores.add(new Ore(s, i[0]++, emerald,  new Color(27,209,45),   50, -16, 256, false, 3,  0f,   1f, true));
            }
        } else { // OLD distribution (<= 1.17)
            if (nether) {
                ores.add(new Ore(s, i[0]++, quartz,  new Color(205,205,205), 16, 10, 117, false, 14, 0f, 1f, false));
                ores.add(new Ore(s, i[0]++, gold,    new Color(247,229,30),  2,  10, 117, false, 9,  0f, 1f, false));
                ores.add(new Ore(s, i[0]++, debris,  new Color(209,27,245),  1,  8,  22,  false, 3,  0f, 1f, true));
            } else {
                ores.add(new Ore(s, i[0]++, coal,     new Color(47,44,54),   20, 0,  127, false, 17, 0f, 1f, false));
                ores.add(new Ore(s, i[0]++, iron,     new Color(236,173,119),20, 0,  63,  false, 9,  0f, 1f, false));
                ores.add(new Ore(s, i[0]++, gold,     new Color(247,229,30), 2,  0,  31,  false, 9,  0f, 1f, false));
                ores.add(new Ore(s, i[0]++, redstone, new Color(245,7,23),   8,  0,  15,  false, 8,  0f, 1f, false));
                ores.add(new Ore(s, i[0]++, diamond,  new Color(33,244,255), 1,  0,  15,  false, 8,  0f, 1f, false));
                ores.add(new Ore(s, i[0]++, lapis,    new Color(8,26,189),   1,  0,  30,  true,  7,  0f, 1f, false));
                ores.add(new Ore(s, i[0]++, emerald,  new Color(27,209,45),  11, 4,  31,  false, 1,  0f, 1f, true));
            }
        }

        map.put(bucket, ores);
        return map;
    }
}
