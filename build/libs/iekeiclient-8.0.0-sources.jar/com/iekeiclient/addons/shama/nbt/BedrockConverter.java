package com.iekeiclient.addons.shama.nbt;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2487;
import net.minecraft.class_2497;
import net.minecraft.class_2499;
import net.minecraft.class_2514;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

/**
 * Converts Bedrock NBT (already parsed by {@link LeNbt}) into Java-format NBT that
 * {@link NbtActions} can place/give.
 *
 * What it does well: geometry + block types of a .mcstructure, and id/count/damage/
 * enchantments of an item.
 * What's lossy (honest limits): block orientation/rotation and other complex block
 * states are only partially translated (unknown states are dropped, so the block
 * falls back to its default facing); waterlogging (Bedrock layer 1) is ignored;
 * block entities (chests' contents, sign text, etc.) and entities are not carried
 * over; items keep only id/count/damage/enchantments.
 *
 * Navigation uses raw get()+casts and stable number/string extraction so it doesn't
 * depend on the 1.20.5/1.21 typed-getter churn.
 */
public final class BedrockConverter {

    // ---- small, version-stable NBT accessors -------------------------------

    private static class_2520 get(class_2520 e, String key) {
        return (e instanceof class_2487 c) ? c.method_10580(key) : null;
    }

    private static int asInt(class_2520 e) {
        if (e instanceof class_2514 n) return n.method_10701();
        try { return Integer.parseInt(asStr(e)); } catch (Exception ignored) { return 0; }
    }

    private static String asStr(class_2520 e) {
        if (e == null) return "";
        if (e instanceof class_2519) {
            // NbtString#toString() is the SNBT form: a quoted, escaped string. Strip the
            // outer quotes and unescape. Remap-safe — no reflection, no version-specific
            // accessor whose mapped name changes across builds.
            String raw = e.toString();
            int n = raw.length();
            if (n >= 2) {
                char q = raw.charAt(0);
                if ((q == '"' || q == '\'') && raw.charAt(n - 1) == q) {
                    StringBuilder sb = new StringBuilder(n - 2);
                    for (int i = 1; i < n - 1; i++) {
                        char c = raw.charAt(i);
                        if (c == '\\' && i + 1 < n - 1) c = raw.charAt(++i);
                        sb.append(c);
                    }
                    return sb.toString();
                }
            }
            return raw;
        }
        return e.toString();
    }

    // =======================================================================
    //  STRUCTURE  (.mcstructure  ->  Java structure template NBT)
    // =======================================================================

    public static class_2487 structure(class_2487 bedrock) {
        class_2520 sizeEl = bedrock.method_10580("size");
        if (!(sizeEl instanceof class_2499 size) || size.size() < 3)
            throw new RuntimeException("no 'size' list — not a .mcstructure?");
        int sx = asInt(size.get(0)), sy = asInt(size.get(1)), sz = asInt(size.get(2));

        class_2520 structEl = bedrock.method_10580("structure");
        if (!(structEl instanceof class_2487 structure))
            throw new RuntimeException("no 'structure' compound — not a .mcstructure?");

        // block_indices: a list of layers; layer 0 = main blocks, layer 1 = waterlog (ignored).
        class_2520 biEl = structure.method_10580("block_indices");
        if (!(biEl instanceof class_2499 layers) || layers.isEmpty())
            throw new RuntimeException("no 'block_indices'");
        class_2520 layer0El = layers.get(0);
        if (!(layer0El instanceof class_2499 layer0))
            throw new RuntimeException("bad 'block_indices' layer 0");

        // palette.default.block_palette
        class_2520 paletteRoot = structure.method_10580("palette");
        class_2520 def = get(paletteRoot, "default");
        class_2520 bpEl = get(def, "block_palette");
        if (!(bpEl instanceof class_2499 bedrockPalette))
            throw new RuntimeException("no 'block_palette'");

        // Convert palette.
        class_2499 javaPalette = new class_2499();
        for (int i = 0; i < bedrockPalette.size(); i++) {
            class_2520 be = bedrockPalette.get(i);
            javaPalette.add(convertBlock(be instanceof class_2487 c ? c : new class_2487()));
        }

        // Convert blocks. Bedrock index order: x outer, y middle, z inner.
        class_2499 blocks = new class_2499();
        int total = sx * sy * sz;
        for (int i = 0; i < total && i < layer0.size(); i++) {
            int state = asInt(layer0.get(i));
            if (state < 0) continue; // -1 = no block
            int x = i / (sy * sz);
            int rem = i % (sy * sz);
            int y = rem / sz;
            int z = rem % sz;

            class_2487 block = new class_2487();
            class_2499 pos = new class_2499();
            pos.add(class_2497.method_23247(x));
            pos.add(class_2497.method_23247(y));
            pos.add(class_2497.method_23247(z));
            block.method_10566("pos", pos);
            block.method_10569("state", state);
            blocks.add(block);
        }

        class_2487 out = new class_2487();
        class_2499 javaSize = new class_2499();
        javaSize.add(class_2497.method_23247(sx));
        javaSize.add(class_2497.method_23247(sy));
        javaSize.add(class_2497.method_23247(sz));
        out.method_10566("size", javaSize);
        out.method_10566("palette", javaPalette);
        out.method_10566("blocks", blocks);
        out.method_10566("entities", new class_2499());
        return out;
    }

    /** Bedrock palette entry {name, states, version} -> Java {Name, Properties}. */
    private static class_2487 convertBlock(class_2487 bb) {
        class_2487 out = new class_2487();
        String name = asStr(bb.method_10580("name"));
        if (name.isEmpty()) name = "minecraft:air";
        out.method_10566("Name", class_2519.method_23256(mapBlockName(name)));

        class_2520 statesEl = bb.method_10580("states");
        if (statesEl instanceof class_2487 states) {
            class_2487 props = new class_2487();
            for (String key : states.method_10541()) {
                translateState(props, key, states.method_10580(key));
            }
            if (!props.method_33133()) out.method_10566("Properties", props);
        }
        return out;
    }

    private static final Map<String, String> BLOCK_OVERRIDES = new HashMap<>();
    static {
        // Most modern (1.18+) Bedrock block names already match Java, so default is
        // passthrough; these are the common ones that don't.
        BLOCK_OVERRIDES.put("minecraft:grass", "minecraft:grass_block");
        BLOCK_OVERRIDES.put("minecraft:flowing_water", "minecraft:water");
        BLOCK_OVERRIDES.put("minecraft:flowing_lava", "minecraft:lava");
        BLOCK_OVERRIDES.put("minecraft:powered_repeater", "minecraft:repeater");
        BLOCK_OVERRIDES.put("minecraft:unpowered_repeater", "minecraft:repeater");
        BLOCK_OVERRIDES.put("minecraft:powered_comparator", "minecraft:comparator");
        BLOCK_OVERRIDES.put("minecraft:unpowered_comparator", "minecraft:comparator");
        BLOCK_OVERRIDES.put("minecraft:lit_redstone_lamp", "minecraft:redstone_lamp");
        BLOCK_OVERRIDES.put("minecraft:lit_furnace", "minecraft:furnace");
        BLOCK_OVERRIDES.put("minecraft:wall_sign", "minecraft:oak_wall_sign");
        BLOCK_OVERRIDES.put("minecraft:standing_sign", "minecraft:oak_sign");
    }

    private static String mapBlockName(String name) {
        if (!name.contains(":")) name = "minecraft:" + name;
        return BLOCK_OVERRIDES.getOrDefault(name, name);
    }

    /** Translate a Bedrock block state into a Java palette Property (value as String).
     *  Unknown states are dropped, so the block keeps its default for that axis. */
    private static void translateState(class_2487 props, String key, class_2520 val) {
        switch (key) {
            case "pillar_axis" -> props.method_10566("axis", class_2519.method_23256(asStr(val)));
            case "upside_down_bit" -> props.method_10566("half", class_2519.method_23256(asInt(val) != 0 ? "top" : "bottom"));
            case "upper_block_bit" -> props.method_10566("half", class_2519.method_23256(asInt(val) != 0 ? "upper" : "lower"));
            case "open_bit" -> props.method_10566("open", class_2519.method_23256(bool(val)));
            case "door_hinge_bit" -> props.method_10566("hinge", class_2519.method_23256(asInt(val) != 0 ? "right" : "left"));
            case "facing_direction", "torch_facing_direction" -> props.method_10566("facing", class_2519.method_23256(face(asInt(val))));
            case "weirdo_direction" -> props.method_10566("facing", class_2519.method_23256(stairFace(asInt(val))));
            case "top_slot_bit" -> props.method_10566("type", class_2519.method_23256(asInt(val) != 0 ? "top" : "bottom"));
            case "minecraft:vertical_half" -> props.method_10566("half", class_2519.method_23256(asStr(val)));
            case "minecraft:cardinal_direction" -> props.method_10566("facing", class_2519.method_23256(asStr(val)));
            case "powered_bit" -> props.method_10566("powered", class_2519.method_23256(bool(val)));
            case "button_pressed_bit" -> props.method_10566("powered", class_2519.method_23256(bool(val)));
            case "age", "growth", "moisturized_amount" -> props.method_10566("age", class_2519.method_23256(String.valueOf(asInt(val))));
            default -> {
                // Pass through string-valued states whose key already looks like a
                // Java property (e.g. "axis"); skip the rest.
                if (val instanceof class_2519 && !key.contains("_bit"))
                    props.method_10566(key, class_2519.method_23256(asStr(val)));
            }
        }
    }

    private static String bool(class_2520 v) { return asInt(v) != 0 ? "true" : "false"; }

    // Bedrock facing_direction: 0 down,1 up,2 north,3 south,4 west,5 east.
    private static String face(int d) {
        return switch (d) {
            case 0 -> "down";
            case 1 -> "up";
            case 2 -> "north";
            case 3 -> "south";
            case 4 -> "west";
            default -> "east";
        };
    }

    // Bedrock stair weirdo_direction: 0 east,1 west,2 south,3 north.
    private static String stairFace(int d) {
        return switch (d) {
            case 0 -> "east";
            case 1 -> "west";
            case 2 -> "south";
            default -> "north";
        };
    }

    // =======================================================================
    //  ITEM  (Bedrock item  ->  Java component item)
    // =======================================================================

    public static class_2487 item(class_2487 bedrock) {
        // Some exporters wrap the item as {"Item":{...}}.
        if (bedrock.method_10580("Name") == null && bedrock.method_10580("Item") instanceof class_2487 inner) bedrock = inner;

        String id = asStr(bedrock.method_10580("Name"));
        if (id.isEmpty()) throw new RuntimeException("item has no 'Name'");
        id = mapItemName(id);

        int count = bedrock.method_10580("Count") != null ? asInt(bedrock.method_10580("Count")) : 1;
        if (count <= 0) count = 1;

        class_2487 out = new class_2487();
        out.method_10566("id", class_2519.method_23256(id));
        out.method_10569("count", count);

        class_2487 components = new class_2487();

        int damage = bedrock.method_10580("Damage") != null ? asInt(bedrock.method_10580("Damage")) : 0;
        if (damage > 0) components.method_10569("minecraft:damage", damage);

        class_2520 tag = bedrock.method_10580("tag");
        class_2487 t = tag instanceof class_2487 tc ? tc : null;

        // Container "kits" (shulker / chest with items): Bedrock stores the contents
        // as an Items list (under tag.Items, or sometimes top-level). Java 1.20.5+
        // uses the minecraft:container component: [{slot, item}, ...]. Recurse so
        // enchanted items and nested shulkers inside the kit convert too.
        class_2520 itemsEl = t != null ? t.method_10580("Items") : null;
        if (itemsEl == null) itemsEl = bedrock.method_10580("Items");
        if (itemsEl instanceof class_2499 itemList && !itemList.isEmpty()) {
            class_2499 container = new class_2499();
            for (int i = 0; i < itemList.size(); i++) {
                if (!(itemList.get(i) instanceof class_2487 ic) || ic.method_10580("Name") == null) continue;
                int slot = ic.method_10580("Slot") != null ? asInt(ic.method_10580("Slot")) : i;
                class_2487 entry = new class_2487();
                entry.method_10569("slot", slot);
                entry.method_10566("item", item(ic));
                container.add(entry);
            }
            if (!container.isEmpty()) components.method_10566("minecraft:container", container);
        }

        if (t != null) {
            // Enchantments: tag.ench = [{id, lvl}, ...]
            class_2520 ench = t.method_10580("ench");
            if (ench instanceof class_2499 el && !el.isEmpty()) {
                class_2487 levels = new class_2487();
                for (int i = 0; i < el.size(); i++) {
                    class_2520 e = el.get(i);
                    int eid = asInt(get(e, "id"));
                    int lvl = asInt(get(e, "lvl"));
                    String ench_name = ENCHANTS.get(eid);
                    if (ench_name != null && lvl > 0) levels.method_10569("minecraft:" + ench_name, lvl);
                }
                if (!levels.method_33133()) {
                    class_2487 enchComp = new class_2487();
                    enchComp.method_10566("levels", levels);
                    components.method_10566("minecraft:enchantments", enchComp);
                }
            }
            // Custom name: tag.display.Name (plain string on Bedrock).
            class_2520 display = t.method_10580("display");
            String customName = asStr(get(display, "Name"));
            if (!customName.isEmpty())
                components.method_10566("minecraft:custom_name", class_2519.method_23256("\"" + customName.replace("\"", "\\\"") + "\""));
        }

        if (!components.method_33133()) out.method_10566("components", components);
        return out;
    }

    private static final Map<String, String> ITEM_OVERRIDES = new HashMap<>();
    static {
        // Bedrock item ids that differ from Java (the common kit-relevant ones).
        ITEM_OVERRIDES.put("minecraft:undyed_shulker_box", "minecraft:shulker_box");
    }

    private static String mapItemName(String id) {
        if (!id.contains(":")) id = "minecraft:" + id;
        return ITEM_OVERRIDES.getOrDefault(id, id);
    }

    // Bedrock enchantment id -> Java enchantment name (covers the common set).
    private static final Map<Integer, String> ENCHANTS = new HashMap<>();
    static {
        ENCHANTS.put(0, "protection");
        ENCHANTS.put(1, "fire_protection");
        ENCHANTS.put(2, "feather_falling");
        ENCHANTS.put(3, "blast_protection");
        ENCHANTS.put(4, "projectile_protection");
        ENCHANTS.put(5, "thorns");
        ENCHANTS.put(6, "respiration");
        ENCHANTS.put(7, "depth_strider");
        ENCHANTS.put(8, "aqua_affinity");
        ENCHANTS.put(9, "sharpness");
        ENCHANTS.put(10, "smite");
        ENCHANTS.put(11, "bane_of_arthropods");
        ENCHANTS.put(12, "knockback");
        ENCHANTS.put(13, "fire_aspect");
        ENCHANTS.put(14, "looting");
        ENCHANTS.put(15, "efficiency");
        ENCHANTS.put(16, "silk_touch");
        ENCHANTS.put(17, "unbreaking");
        ENCHANTS.put(18, "fortune");
        ENCHANTS.put(19, "power");
        ENCHANTS.put(20, "punch");
        ENCHANTS.put(21, "flame");
        ENCHANTS.put(22, "infinity");
        ENCHANTS.put(23, "luck_of_the_sea");
        ENCHANTS.put(24, "lure");
        ENCHANTS.put(25, "frost_walker");
        ENCHANTS.put(26, "mending");
        ENCHANTS.put(27, "binding_curse");
        ENCHANTS.put(28, "vanishing_curse");
        ENCHANTS.put(29, "impaling");
        ENCHANTS.put(30, "riptide");
        ENCHANTS.put(31, "loyalty");
        ENCHANTS.put(32, "channeling");
        ENCHANTS.put(33, "multishot");
        ENCHANTS.put(34, "piercing");
        ENCHANTS.put(35, "quick_charge");
        ENCHANTS.put(36, "soul_speed");
        ENCHANTS.put(37, "swift_sneak");
    }
}
