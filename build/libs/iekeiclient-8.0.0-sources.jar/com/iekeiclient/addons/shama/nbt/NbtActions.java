package com.iekeiclient.addons.shama.nbt;

import com.iekeiclient.engine.utils.player.ChatUtils;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_7225;
import net.minecraft.class_7924;

/**
 * Shared actions for turning a Java-format NbtCompound into something in the world:
 * give an item (creative) or place a structure (singleplayer). Used by both the
 * .nbt command (Java SNBT) and the .bnbt command (converted Bedrock).
 */
public final class NbtActions {

    /** Route a Java NBT compound to the right action based on its shape. */
    public static void handle(class_2487 nbt) {
        class_310 mc = class_310.method_1551();
        if (nbt.method_10545("size") && nbt.method_10545("blocks")) {
            placeStructure(mc, nbt);
        } else if (nbt.method_10545("id")) {
            giveItem(mc, nbt);
        } else {
            ChatUtils.warning("Unrecognized NBT — need 'id' for an item or 'size'+'blocks' for a structure.");
        }
    }

    public static void giveItem(class_310 mc, class_2487 nbt) {
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1687 == null) return;
        if (!mc.field_1724.method_31549().field_7477) {
            ChatUtils.error("Items can only be spawned in creative.");
            return;
        }
        class_1799 stack = Snbt.itemFromNbt(nbt);
        if (stack.method_7960()) {
            ChatUtils.error("That NBT didn't parse into a valid item.");
            return;
        }
        int slot = 36 + mc.field_1724.method_31548().method_67532();
        mc.field_1761.method_2909(stack, slot);
        ChatUtils.info("Gave " + stack.method_7964().getString() + ".");
    }

    /** Reflective StructureTemplate use so the version-sensitive API can't block the
     *  build or crash — degrades to a message. Singleplayer only. */
    public static void placeStructure(class_310 mc, class_2487 nbt) {
        if (mc.method_1576() == null || mc.field_1724 == null) {
            ChatUtils.error("Structures can only be placed in singleplayer (the integrated server sets the blocks).");
            return;
        }
        try {
            class_3218 world = mc.method_1576().method_3847(mc.field_1724.method_73183().method_27983());
            if (world == null) world = mc.method_1576().method_30002();

            // 1.21.11 (verified): StructureTemplate#readNbt(RegistryEntryLookup<Block>, NbtCompound)
            // and #place(ServerWorldAccess, BlockPos pos, BlockPos pivot, StructurePlacementData,
            // Random, int flags). Direct calls so Loom remaps them into the built jar — name-based
            // reflection compiles but breaks after remapping.
            class_7225.class_7226<class_2248> blockLookup = world.method_30349().method_30530(class_7924.field_41254);

            class_3499 template = new class_3499();
            template.method_15183(blockLookup, nbt);

            class_3492 data = new class_3492();
            class_2338 pos = mc.field_1724.method_24515();
            template.method_15172(world, pos, pos, data, world.method_8409(), 3);
            ChatUtils.info("Placed structure at " + pos.method_23854() + ".");
        } catch (Exception e) {
            ChatUtils.error("Structure place failed: " + e.getMessage());
        }
    }
}
