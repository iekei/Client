package com.iekeiclient.addons.shama.nbt;

import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2522;
import net.minecraft.class_310;
import net.minecraft.class_6903;

/**
 * NBT helpers for 1.21.11. Two relevant API moves from earlier 1.21.x:
 *   - StringNbtReader.parse(String) was replaced by readCompound(String) at 1.21.7
 *   - ItemStack.fromNbt / ItemStack.encode were removed in favour of ItemStack.CODEC
 * Verified against Yarn 1.21.11. Direct calls (not reflection) so Loom remaps them
 * into the built jar — name-based reflection would compile but break after remap.
 */
public final class Snbt {

    /** Parse SNBT text into an NbtCompound (1.21.7+ readCompound). */
    public static class_2487 parse(String s) throws Exception {
        return class_2522.method_67315(s);
    }

    private static class_6903<class_2520> ops() {
        class_310 mc = class_310.method_1551();
        return class_6903.method_46632(class_2509.field_11560, mc.field_1687.method_30349());
    }

    /** Decode an item from a Java item NbtCompound ({id,count,components}). */
    public static class_1799 itemFromNbt(class_2487 nbt) {
        try {
            return class_1799.field_24671.parse(ops(), nbt).result().orElse(class_1799.field_8037);
        } catch (Exception e) {
            return class_1799.field_8037;
        }
    }

    /** Encode an item to its full Java NBT form (id/count/components). */
    public static class_2520 itemToNbt(class_1799 stack) {
        try {
            return class_1799.field_24671.encodeStart(ops(), stack).result().orElse(new class_2487());
        } catch (Exception e) {
            return new class_2487();
        }
    }
}
