package com.iekeiclient.addons.shama.util;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;

/**
 * Amethyst geode scanning, taken from the AmethystESP source Eyad supplied.
 *
 * The matcher and the flood fill are that code as written — they are what make this find whole
 * geodes rather than counting loose blocks, so they are kept intact rather than reimplemented.
 * Everything in the original that depended on unverified client APIs (the toast popups, the
 * BlockUpdateEvent hook, boxLines) is left out and handled by each module's own alert and render
 * path instead, so nothing here can fail to build.
 *
 * Used by every module that looks at amethyst, so they all agree on what a geode is.
 */
public final class AmethystScan {
    public static final int MIN_Y = -58;
    public static final int MAX_Y = 30;

    /** Straight from the supplied source. */
    private static final int[][] NEIGHBORS = new int[][]{
        {1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}
    };

    private AmethystScan() {}

    /** Straight from the supplied source. */
    public static boolean isAmethystLike(class_2680 state) {
        return state.method_27852(class_2246.field_27161)
            || state.method_27852(class_2246.field_27162)
            || state.method_27852(class_2246.field_27163)
            || state.method_27852(class_2246.field_27164)
            || state.method_27852(class_2246.field_27159)
            || state.method_27852(class_2246.field_27160);
    }

    /**
     * Every connected geode in this chunk that reaches the threshold.
     *
     * The gather pass and the flood fill are the supplied code, with the world lookup swapped for a
     * chunk-local one so it stays safe to run off the main thread, and the results returned instead
     * of written into fields.
     */
    public static List<Set<class_2338>> findGeodes(class_1937 world, class_2818 chunk, int threshold, int minY, int maxY) {
        class_1923 chunkPos = chunk.method_12004();
        int minX = chunkPos.method_8326();
        int minZ = chunkPos.method_8328();
        Set<class_2338> cluster = new HashSet<>();

        int lo = Math.max(minY, chunk.method_31607());
        int hi = Math.min(maxY, chunk.method_31600());

        for (int y = lo; y <= hi; ++y) {
            for (int x = minX; x < minX + 16; ++x) {
                for (int z = minZ; z < minZ + 16; ++z) {
                    class_2338 pos = new class_2338(x, y, z);
                    if (isAmethystLike(chunk.method_8320(pos))) {
                        cluster.add(pos);
                    }
                }
            }
        }

        List<Set<class_2338>> geodes = new ArrayList<>();
        if (cluster.isEmpty()) return geodes;

        Set<class_2338> visited = new HashSet<>();
        Iterator<class_2338> var19 = cluster.iterator();

        while (var19.hasNext()) {
            class_2338 seed = var19.next();
            if (visited.contains(seed)) continue;

            Set<class_2338> geode = new HashSet<>();
            Deque<class_2338> queue = new ArrayDeque<>();
            queue.add(seed);
            visited.add(seed);

            while (!queue.isEmpty()) {
                class_2338 current = queue.poll();
                geode.add(current);
                int[][] var13 = NEIGHBORS;
                int var14 = var13.length;

                for (int var15 = 0; var15 < var14; ++var15) {
                    int[] n = var13[var15];
                    class_2338 next = current.method_10069(n[0], n[1], n[2]);
                    if (cluster.contains(next) && !visited.contains(next)) {
                        visited.add(next);
                        queue.add(next);
                    }
                }
            }

            if (geode.size() >= threshold) {
                geodes.add(geode);
            }
        }
        return geodes;
    }

    /** Chunk key in the supplied source's encoding. */
    public static long encodeChunk(int x, int z) {
        return (long) x << 32 | (long) z & 4294967295L;
    }
}
