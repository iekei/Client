package com.iekeiclient.addons.shama.util;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1923;
import net.minecraft.class_2338;

/** Their ChunkStateCache helper — fingerprints scanned chunks so finders skip re-scanning unchanged ones. */
public final class ChunkStateCache {
    private final Set<Long> dirty = ConcurrentHashMap.newKeySet();
    private final Map<Long, Long> fingerprints = new ConcurrentHashMap<>();

    public void markDirty(class_2338 pos) { dirty.add(class_1923.method_8331(pos.method_10263() >> 4, pos.method_10260() >> 4)); }
    public void markDirty(class_1923 pos) { dirty.add(pos.method_8324()); }

    public boolean needsUpdate(class_1923 pos, long fingerprint) {
        Long fp = fingerprints.get(pos.method_8324());
        return dirty.contains(pos.method_8324()) || fp == null || fp != fingerprint;
    }

    public void remember(class_1923 pos, long fingerprint) { fingerprints.put(pos.method_8324(), fingerprint); dirty.remove(pos.method_8324()); }
    public void forget(class_1923 pos) { fingerprints.remove(pos.method_8324()); dirty.remove(pos.method_8324()); }
    public void clear() { dirty.clear(); fingerprints.clear(); }
}
