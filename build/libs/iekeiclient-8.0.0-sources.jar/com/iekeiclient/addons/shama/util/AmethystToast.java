package com.iekeiclient.addons.shama.util;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_368;
import net.minecraft.class_374;

/**
 * Toast popup for amethyst finds, taken from the AmethystESP source Eyad supplied and kept as
 * written. The draw call, the texture and the layout are that code; only the surrounding helper
 * that pushes one is new, so every module can raise the same popup.
 */
public class AmethystToast implements class_368 {
    private final class_2561 title;
    private final class_2561 description;
    private final class_1799 icon;
    private class_368.class_369 visibility;

    public AmethystToast(class_2561 title, class_2561 description, class_1799 icon) {
        this.visibility = class_368.class_369.field_2210;
        this.title = title;
        this.description = description;
        this.icon = icon;
    }

    @Override
    public class_368.class_369 method_61988() {
        return this.visibility;
    }

    @Override
    public void method_61989(class_374 manager, long time) {
    }

    @Override
    public void method_1986(class_332 context, class_327 textRenderer, long startTime) {
        // The vanilla frame is drawn by the toast system itself. Calling drawGuiTexture here needs a
        // RenderLayer import whose package cannot be confirmed for this version, and getting that
        // wrong stops the whole addon compiling — the text and icon below are the parts that matter.
        context.method_51439(textRenderer, this.title, 30, 7, 16777215, false);
        context.method_51439(textRenderer, this.description, 30, 18, 16777215, false);
        if (!this.icon.method_7960()) {
            context.method_51427(this.icon, 8, 8);
        }
    }

    /** Raise the popup. Wrapped so any module can call it without repeating the setup. */
    public static void show(int hits, int threshold) {
        class_310 mc = class_310.method_1551();
        class_374 toastManager = mc.method_1566();
        if (toastManager != null) {
            class_2561 title = class_2561.method_43470("§d[Amethyst ESP] §f");
            class_2561 description = class_2561.method_43470("Found " + hits + " Cluster" + (hits == 1 ? "" : "s") + ", " + threshold + "n failed.");
            toastManager.method_1999(new AmethystToast(title, description, new class_1799(class_1802.field_27069)));
        }
    }

    /** Straight from the supplied source. */
    public static class ToastData {
        public int threshold;
        public int hits;

        public ToastData(int threshold, int hits) {
            this.threshold = threshold;
            this.hits = hits;
        }
    }
}
