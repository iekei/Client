package com.iekeiclient.addons.shama.util;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import net.minecraft.class_1923;
import net.minecraft.class_238;

/** Their ChunkOverlayRenderer helper — shared chunk/box drawing used by the finders. */
public final class ChunkOverlayRenderer {
    public static void drawChunkBox(Render3DEvent event, class_1923 chunkPos, SettingColor color, double y1, double y2, ShapeMode mode) {
        double x1 = chunkPos.method_8326(), z1 = chunkPos.method_8328();
        Color side = new Color(color.r, color.g, color.b, color.a / 4);
        event.renderer.box(x1, y1, z1, x1 + 16.0D, y2, z1 + 16.0D, side, color, mode, 0);
    }

    public static void drawBox(Render3DEvent event, class_238 box, SettingColor color, ShapeMode mode) {
        Color side = new Color(color.r, color.g, color.b, color.a / 4);
        event.renderer.box(box, side, color, mode, 0);
    }
}
