package com.iekeiclient.addons.shama.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2248;
import net.minecraft.class_7923;

/**
 * Registry path lookups cached per block TYPE.
 *
 * Registries.BLOCK.getId(block).getPath() allocates an Identifier and a String every call. The
 * chunk scanners call it once per block — around 98,000 times per chunk — so on a busy world that
 * was a large slice of the stutter when chunks streamed in while moving. There are only a couple
 * of thousand block types, so caching the result makes it a single map lookup after the first hit.
 *
 * Thread-safe: the scanners run on background threads.
 */
public final class BlockPaths {
    private static final Map<class_2248, String> CACHE = new ConcurrentHashMap<>();

    private BlockPaths() {}

    public static String of(class_2248 block) {
        String p = CACHE.get(block);
        if (p == null) {
            p = class_7923.field_41175.method_10221(block).method_12832();
            CACHE.put(block, p);
        }
        return p;
    }
}
