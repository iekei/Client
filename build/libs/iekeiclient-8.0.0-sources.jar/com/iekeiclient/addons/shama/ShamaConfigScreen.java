package com.iekeiclient.addons.shama;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.iekeiclient.addons.shama.log.LogConfig;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Mod Menu config screen for the log filter. Lets you toggle the filter options
 * from the GUI instead of editing config/shama-log.json by hand.
 *
 * Note: the filter runs at launch (preLaunch), so changes here are saved to the
 * JSON and take effect on the NEXT launch, not the current session. The screen
 * says so, to avoid confusion.
 */
public class ShamaConfigScreen extends class_437 {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final class_437 parent;
    private LogConfig config;

    public ShamaConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Shama Addon — Log Filter"));
        this.parent = parent;
        this.config = load();
    }

    private Path configPath() {
        return net.fabricmc.loader.api.FabricLoader.getInstance()
            .getConfigDir().resolve("shama-log.json");
    }

    private LogConfig load() {
        try (Reader r = Files.newBufferedReader(configPath())) {
            LogConfig c = GSON.fromJson(r, LogConfig.class);
            if (c != null) return c;
        } catch (Exception ignored) {}
        return new LogConfig();
    }

    private void save() {
        try (Writer w = Files.newBufferedWriter(configPath())) {
            GSON.toJson(config, w);
        } catch (IOException ignored) {}
    }

    @Override
    protected void method_25426() {
        int cx = field_22789 / 2;
        int y = 50;

        method_37063(toggle(cx - 150, y, "Filter enabled", config.enabled,
            v -> config.enabled = v));
        y += 28;

        method_37063(class_4185.method_46430(
            class_2561.method_43470("Mode: " + config.mode),
            b -> {
                config.mode = config.mode.equalsIgnoreCase("DENYLIST") ? "ALLOWLIST" : "DENYLIST";
                b.method_25355(class_2561.method_43470("Mode: " + config.mode));
            }
        ).method_46434(cx - 150, y, 300, 20).method_46431());
        y += 28;

        method_37063(toggle(cx - 150, y, "Show crashes", config.showCrashes,
            v -> config.showCrashes = v));
        y += 28;

        method_37063(toggle(cx - 150, y, "Hide mod list", config.hideModList,
            v -> config.hideModList = v));
        y += 28;

        method_37063(toggle(cx - 150, y, "Hide render spam", config.hideRenderSpam,
            v -> config.hideRenderSpam = v));
        y += 28;

        method_37063(toggle(cx - 150, y, "Write clean log", config.writeCleanLog,
            v -> config.writeCleanLog = v));
        y += 40;

        method_37063(class_4185.method_46430(
            class_2561.method_43470("Save"),
            b -> { save(); if (field_22787 != null) field_22787.method_1507(parent); }
        ).method_46434(cx - 150, y, 145, 20).method_46431());

        method_37063(class_4185.method_46430(
            class_2561.method_43470("Cancel"),
            b -> { if (field_22787 != null) field_22787.method_1507(parent); }
        ).method_46434(cx + 5, y, 145, 20).method_46431());
    }

    private class_4185 toggle(int x, int y, String label, boolean initial, java.util.function.Consumer<Boolean> setter) {
        final boolean[] state = { initial };
        return class_4185.method_46430(
            class_2561.method_43470(label + ": " + (state[0] ? "ON" : "OFF")),
            b -> {
                state[0] = !state[0];
                setter.accept(state[0]);
                b.method_25355(class_2561.method_43470(label + ": " + (state[0] ? "ON" : "OFF")));
            }
        ).method_46434(x, y, 300, 20).method_46431();
    }

    @Override
    public void method_25394(net.minecraft.class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, field_22785, field_22789 / 2, 10, 0xFFFFFF);
        context.method_27534(field_22793,
            class_2561.method_43470("Changes apply on next launch.").method_27692(class_124.field_1080),
            field_22789 / 2, 28, 0xAAAAAA);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }
}
