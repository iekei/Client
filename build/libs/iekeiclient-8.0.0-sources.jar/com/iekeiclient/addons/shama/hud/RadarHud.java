package com.iekeiclient.addons.shama.hud;

import com.iekeiclient.engine.systems.hud.HudElement;
import com.iekeiclient.engine.systems.hud.HudElementInfo;
import com.iekeiclient.engine.systems.hud.HudRenderer;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import net.minecraft.class_1657;
import net.minecraft.class_310;

import static com.iekeiclient.engine.IekeiClient.mc;

/**
 * Radar HUD — a top-down mini radar drawn on the HUD (built with Iekei's HudElement
 * API, same as their region-map HUD). Plots nearby players as dots relative to you
 * (north-up), so you can see who's around without turning. Add it from the HUD tab.
 */
public class RadarHud extends HudElement {
    public static final HudElementInfo<RadarHud> INFO =
        new HudElementInfo<>(com.iekeiclient.addons.shama.ShamaAddon.HUD_GROUP, "shama-radar", "Top-down radar of nearby players.", RadarHud::new);

    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Integer> size = sg.add(new IntSetting.Builder().name("size").defaultValue(120).range(60, 300).sliderRange(60, 240).build());
    private final Setting<Double> range = sg.add(new DoubleSetting.Builder().name("range").description("Blocks mapped to the radar edge.").defaultValue(128).min(16).sliderRange(32, 512).build());
    private final Setting<SettingColor> bg = sg.add(new ColorSetting.Builder().name("background").defaultValue(new SettingColor(0, 0, 0, 120)).build());
    private final Setting<SettingColor> selfColor = sg.add(new ColorSetting.Builder().name("self-color").defaultValue(new SettingColor(0, 255, 0, 255)).build());
    private final Setting<SettingColor> playerColor = sg.add(new ColorSetting.Builder().name("player-color").defaultValue(new SettingColor(255, 0, 0, 255)).build());

    public RadarHud() { super(INFO); }

    @Override
    public void render(HudRenderer renderer) {
        int s = size.get();
        setSize(s, s);
        double x = this.x, y = this.y;

        renderer.quad(x, y, s, s, bg.get());

        double cx = x + s / 2.0, cy = y + s / 2.0;
        double scale = (s / 2.0) / range.get();

        // self dot in the centre
        renderer.quad(cx - 2, cy - 2, 4, 4, selfColor.get());

        class_310 m = mc;
        if (m.field_1687 == null || m.field_1724 == null) return;
        Color pc = playerColor.get();
        for (class_1657 p : m.field_1687.method_18456()) {
            if (p == m.field_1724) continue;
            double dx = (p.method_23317() - m.field_1724.method_23317()) * scale;
            double dz = (p.method_23321() - m.field_1724.method_23321()) * scale;
            if (Math.abs(dx) > s / 2.0 || Math.abs(dz) > s / 2.0) continue; // off radar
            renderer.quad(cx + dx - 1.5, cy + dz - 1.5, 3, 3, pc);
        }
    }
}
