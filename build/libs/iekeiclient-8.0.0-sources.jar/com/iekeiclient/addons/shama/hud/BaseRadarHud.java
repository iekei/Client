package com.iekeiclient.addons.shama.hud;

import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.hud.HudElement;
import com.iekeiclient.engine.systems.hud.HudElementInfo;
import com.iekeiclient.engine.systems.hud.HudRenderer;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1657;

import static com.iekeiclient.engine.IekeiClient.mc;

/** Base Radar HUD — top-down radar plotting nearby players (red) and mobs (yellow), north-up. Base-hunting aid. */
public class BaseRadarHud extends HudElement {
    public static final HudElementInfo<BaseRadarHud> INFO =
        new HudElementInfo<>(com.iekeiclient.addons.shama.ShamaAddon.HUD_GROUP, "shama-base-radar", "Radar of nearby players and mobs.", BaseRadarHud::new);

    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Integer> size = sg.add(new IntSetting.Builder().name("size").defaultValue(120).range(60, 300).sliderRange(60, 240).build());
    private final Setting<Double> range = sg.add(new DoubleSetting.Builder().name("range").defaultValue(96).min(16).sliderRange(32, 256).build());
    private final Setting<SettingColor> bg = sg.add(new ColorSetting.Builder().name("background").defaultValue(new SettingColor(0, 0, 0, 120)).build());
    private final Setting<SettingColor> playerColor = sg.add(new ColorSetting.Builder().name("player-color").defaultValue(new SettingColor(255, 0, 0, 255)).build());
    private final Setting<SettingColor> mobColor = sg.add(new ColorSetting.Builder().name("mob-color").defaultValue(new SettingColor(255, 210, 0, 255)).build());

    public BaseRadarHud() { super(INFO); }

    @Override
    public void render(HudRenderer renderer) {
        int s = size.get();
        setSize(s, s);
        double cx = x + s / 2.0, cy = y + s / 2.0, scale = (s / 2.0) / range.get();
        renderer.quad(x, y, s, s, bg.get());
        renderer.quad(cx - 2, cy - 2, 4, 4, new SettingColor(0, 255, 0, 255));
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e == mc.field_1724) continue;
            boolean pl = e instanceof class_1657, mob = e instanceof class_1308;
            if (!pl && !mob) continue;
            double dx = (e.method_23317() - mc.field_1724.method_23317()) * scale, dz = (e.method_23321() - mc.field_1724.method_23321()) * scale;
            if (Math.abs(dx) > s / 2.0 || Math.abs(dz) > s / 2.0) continue;
            renderer.quad(cx + dx - 1.5, cy + dz - 1.5, 3, 3, pl ? playerColor.get() : mobColor.get());
        }
    }
}
