package com.iekeiclient.addons.shama.mixin;

import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.iekeiclient.addons.shama.modules.SwingSpeed;

/** Overrides the local player's hand-swing duration from the SwingSpeed module (vanilla value read at RETURN). */
@Mixin(class_1309.class)
public class HandSwingDurationMixin {
    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true, require = 0)
    private void shama$swingSpeed(CallbackInfoReturnable<Integer> cir) {
        if ((Object) this != class_310.method_1551().field_1724) return;
        SwingSpeed m = Modules.get().get(SwingSpeed.class);
        if (m != null && m.isActive()) cir.setReturnValue(m.getSwingDuration(cir.getReturnValue()));
    }
}
