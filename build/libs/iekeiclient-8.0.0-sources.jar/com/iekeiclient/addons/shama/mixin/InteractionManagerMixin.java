package com.iekeiclient.addons.shama.mixin;

import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Exposes the private block-break cooldown so we can zero it (no break delay). */
@Mixin(class_636.class)
public interface InteractionManagerMixin {
    @Accessor("blockBreakingCooldown")
    void setBlockBreakingCooldown(int cooldown);

    @Accessor("blockBreakingCooldown")
    int getBlockBreakingCooldown();
}
