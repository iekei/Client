package com.iekeiclient.addons.shama.mixin;

import net.minecraft.class_6017;
import net.minecraft.class_6793;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Exposes the private vein-count provider on CountPlacementModifier. */
@Mixin(class_6793.class)
public interface CountPlacementModifierAccessor {
    @Accessor("count")
    class_6017 getCount();
}
