package com.iekeiclient.addons.shama.mixin;

import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes HandledScreen#focusedSlot (the slot under the cursor) so NbtAdder can
 * read it on a middle-click. This is an @Accessor, not a method @Inject: it just
 * generates a getter for an existing field, so there's no handler signature to
 * mismatch — it stays valid across the 1.21.11 mouseClicked(Click, boolean) refactor
 * that broke the old injection approach.
 */
@Mixin(class_465.class)
public interface HandledScreenAccessor {
    @Accessor("focusedSlot")
    class_1735 shama$focusedSlot();
}
