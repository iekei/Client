package com.iekeiclient.addons.shama.mixin;

import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.class_1796;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.iekeiclient.addons.shama.modules.NoCooldown;

/** Reports items as never cooling down when NoCooldown's item toggle is on. */
@Mixin(class_1796.class)
public class ItemCooldownMixin {
    @Inject(method = "isCoolingDown", at = @At("HEAD"), cancellable = true, require = 0)
    private void shamaNoItemCooldown(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
        NoCooldown m = Modules.get().get(NoCooldown.class);
        if (m != null && m.isActive() && m.items.get()) {
            cir.setReturnValue(false);
        }
    }
}
