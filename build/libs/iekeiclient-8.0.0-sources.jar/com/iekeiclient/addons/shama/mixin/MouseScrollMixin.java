package com.iekeiclient.addons.shama.mixin;

import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.iekeiclient.addons.shama.modules.Freecam;

/**
 * Routes the scroll wheel to Freecam's fly speed while it's active (like Iekei's freecam),
 * cancelling the hotbar scroll. Non-required so a mapping change just disables the feature.
 */
@Mixin(class_312.class)
public class MouseScrollMixin {
    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true, require = 0)
    private void shama$freecamScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        Freecam fc = Modules.get().get(Freecam.class);
        if (fc != null && fc.isActive() && fc.consumeScroll(vertical)) ci.cancel();
    }
}
