package com.iekeiclient.addons.shama.mixin;

import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.class_1657;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.iekeiclient.addons.shama.modules.InstantMine;

/** Scales block breaking speed by InstantMine's factor when active. */
@Mixin(class_1657.class)
public class BlockBreakingSpeedMixin {
    @Inject(method = "getBlockBreakingSpeed", at = @At("RETURN"), cancellable = true, require = 0)
    private void shamaScaleBreakSpeed(class_2680 block, CallbackInfoReturnable<Float> cir) {
        InstantMine m = Modules.get().get(InstantMine.class);
        if (m != null && m.isActive()) {
            float base = cir.getReturnValue();
            cir.setReturnValue((float) (base * m.factor()));
        }
    }
}
