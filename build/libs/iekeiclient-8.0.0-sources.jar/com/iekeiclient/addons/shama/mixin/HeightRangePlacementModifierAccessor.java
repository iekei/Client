package com.iekeiclient.addons.shama.mixin;

import net.minecraft.class_6122;
import net.minecraft.class_6795;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Exposes the private height provider on HeightRangePlacementModifier. */
@Mixin(class_6795.class)
public interface HeightRangePlacementModifierAccessor {
    @Accessor("height")
    class_6122 getHeight();
}
