package com.iekeiclient.addons.shama.mixin;

import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.iekeiclient.addons.shama.modules.Freecam;

/**
 * Detaches the camera to the Freecam position/rotation. Injects at the TAIL of
 * Camera#update with a no-argument handler so it doesn't depend on that method's
 * parameter list, which changed in 1.21.11 (first arg BlockView -> World). setPos and
 * setRotation are stable. Lives in the non-required config, so a mapping change just
 * disables Freecam rather than crashing.
 */
@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPos(class_243 pos);
    @Shadow protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "update", at = @At("TAIL"), require = 0)
    private void shama$freecam(CallbackInfo ci) {
        Freecam fc = Modules.get().get(Freecam.class);
        if (fc != null && fc.isActive() && fc.hasPos()) {
            // Interpolate the per-tick camera position by the current frame's tick progress
            // so motion is smooth at any FPS (rotation stays direct for responsive mouse-look).
            float td;
            try { td = net.minecraft.class_310.method_1551().method_61966().method_60637(true); }
            catch (Throwable t) { td = 1f; }
            this.setRotation(fc.getFreecamYaw(), fc.getFreecamPitch());
            this.setPos(fc.getRenderPos(td));
        }
    }
}
