package com.iekeiclient.addons.shama.mixin;

import net.minecraft.class_6799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Exposes the private rarity chance on RarityFilterPlacementModifier. */
@Mixin(class_6799.class)
public interface RarityFilterPlacementModifierAccessor {
    @Accessor("chance")
    int getChance();
}
