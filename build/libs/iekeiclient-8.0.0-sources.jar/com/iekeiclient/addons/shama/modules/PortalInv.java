package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3675;
import net.minecraft.class_490;
import org.lwjgl.glfw.GLFW;

/**
 * Portal Inv — lets you open and use your inventory during nether/end portal transit.
 * Normally the "Downloading terrain" screen locks you out while the destination loads;
 * with this on, pressing your inventory key during that screen opens the survival
 * inventory over it (the load keeps running in the background), or it opens automatically
 * if auto-open is enabled. Handy for re-gearing / totem swaps the instant you arrive.
 */
public class PortalInv extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> autoOpen = sg.add(new BoolSetting.Builder()
        .name("auto-open")
        .description("Open the inventory the moment portal transit starts, without pressing a key.")
        .defaultValue(false)
        .build()
    );

    public PortalInv() {
        super(com.iekeiclient.addons.shama.ShamaAddon.PLAYER, "portal-inv++", "Access your inventory during portal transit loading.");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null) return;
        boolean transit = mc.field_1755 != null && mc.field_1755.getClass().getSimpleName().contains("DownloadingTerrain"); // terrain-load lockout (name-checked so mapping changes can't break the build)
        boolean inPortal = mc.field_1755 == null && inNetherPortal();          // purple portal view, nothing open yet
        if (!transit && !inPortal) return;
        if (autoOpen.get() || invKeyDown()) {
            mc.method_1507(new class_490(mc.field_1724));
        }
    }

    /** True when the player is standing inside a nether portal block (the purple-view state). */
    private boolean inNetherPortal() {
        if (mc.field_1687 == null || mc.field_1724 == null) return false;
        if (mc.field_1687.method_8320(mc.field_1724.method_24515()).method_27852(class_2246.field_10316)) return true;
        class_2338 eye = class_2338.method_49638(mc.field_1724.method_33571());
        return mc.field_1687.method_8320(eye).method_27852(class_2246.field_10316);
    }

    private boolean invKeyDown() {
        try {
            int code = class_3675.method_15981(mc.field_1690.field_1822.method_1428()).method_1444();
            return GLFW.glfwGetKey(mc.method_22683().method_4490(), code) == GLFW.GLFW_PRESS;
        } catch (Exception e) {
            return false;
        }
    }
}
