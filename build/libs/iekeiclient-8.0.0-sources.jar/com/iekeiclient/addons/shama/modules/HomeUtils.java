package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Home Utils++ — merged from the several home-setter variants. Saves named coordinate
 * "homes" and can auto-walk toward the selected one. Homes persist for the session.
 */
public class HomeUtils extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<String> homeName = sg.add(new StringSetting.Builder()
        .name("name").description("Name for save/goto/remove.").defaultValue("base").build());

    private final Setting<Boolean> autoWalk = sg.add(new BoolSetting.Builder()
        .name("walk-to-home").description("Hold forward toward the current home until you arrive.").defaultValue(false).build());

    private final Map<String, class_2338> homes = new LinkedHashMap<>();
    private class_2338 target;

    public HomeUtils() {
        super(com.iekeiclient.addons.shama.ShamaAddon.PLAYER, "home-utils++", "Save/goto named coordinate homes; optional auto-walk.");
    }

    public void save() { if (mc.field_1724 != null) { homes.put(homeName.get(), mc.field_1724.method_24515()); com.iekeiclient.addons.shama.util.Chat.info("[Home] saved '%s' at %s", homeName.get(), mc.field_1724.method_24515().method_23854()); } }
    public void goHome() { class_2338 p = homes.get(homeName.get()); if (p == null) { com.iekeiclient.addons.shama.util.Chat.warning("[Home] no home '%s'", homeName.get()); return; } target = p; com.iekeiclient.addons.shama.util.Chat.info("[Home] walking to '%s' %s", homeName.get(), p.method_23854()); }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!autoWalk.get() || target == null || mc.field_1724 == null) { if (mc.field_1690 != null) mc.field_1690.field_1894.method_23481(false); return; }
        double dx = target.method_10263() + 0.5 - mc.field_1724.method_23317();
        double dz = target.method_10260() + 0.5 - mc.field_1724.method_23321();
        if (dx * dx + dz * dz < 4) { target = null; mc.field_1690.field_1894.method_23481(false); com.iekeiclient.addons.shama.util.Chat.info("[Home] arrived."); return; }
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        mc.field_1724.method_36456(yaw);
        mc.field_1690.field_1894.method_23481(true);
    }

    @Override public void onDeactivate() { if (mc.field_1690 != null) mc.field_1690.field_1894.method_23481(false); target = null; }
    @Override public String getInfoString() { return homes.size() + " homes"; }
}
