package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2620;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Break Indicators — draws a shrinking box on blocks being broken (yours and other players').
 * Reads the server's block-breaking-progress packets directly, so it needs no mixin into WorldRenderer
 * (whose internal field for this moved in 1.21.11).
 */
public class BreakIndicators extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<SettingColor> startColor = sg.add(new ColorSetting.Builder().name("color-at-start").description("Colour at the start (0% progress).").defaultValue(new SettingColor(255, 0, 0, 30)).build());
    private final Setting<SettingColor> endColor = sg.add(new ColorSetting.Builder().name("color-when-done").description("Colour at the end (100% progress).").defaultValue(new SettingColor(0, 255, 0, 60)).build());
    private final Setting<SettingColor> lineColor = sg.add(new ColorSetting.Builder().name("line-color").description("Colour of the box outline.").defaultValue(new SettingColor(255, 255, 255, 200)).build());
    private final Setting<ShapeMode> shapeMode = sg.add(new EnumSetting.Builder<ShapeMode>().name("shape-mode").description("How boxes are drawn: outline only, filled sides only, or both.").defaultValue(ShapeMode.Both).build());
    private final Setting<Integer> timeout = sg.add(new IntSetting.Builder().name("timeout-ticks").description("Forget a break if no update arrives for this many ticks (in case the finish/cancel packet is missed).").defaultValue(100).min(20).max(400).sliderRange(40, 200).build());

    // pos -> [stage 0..10, ticksSinceUpdate]
    private final Map<Long, int[]> breaking = new ConcurrentHashMap<>();

    public BreakIndicators() { super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "break-indicators++", "Boxes blocks being broken, shrinking with progress."); }

    @Override public void onDeactivate() { breaking.clear(); }

    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (!(event.packet instanceof class_2620 p)) return;
        int stage = p.method_11278();
        long key = p.method_11277().method_10063();
        if (stage < 0 || stage > 9) breaking.remove(key);        // finished or cancelled
        else breaking.put(key, new int[]{stage, 0});
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (breaking.isEmpty()) return;
        int limit = timeout.get();
        breaking.values().removeIf(v -> (v[1] += 1) > limit);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1687 == null || breaking.isEmpty()) return;
        Color start = startColor.get(), end = endColor.get(), line = lineColor.get();
        for (Map.Entry<Long, int[]> e : breaking.entrySet()) {
            class_2338 pos = class_2338.method_10092(e.getKey());
            float t = e.getValue()[0] / 9f;
            class_2680 state = mc.field_1687.method_8320(pos);
            class_265 shape = state.method_26218(mc.field_1687, pos);
            class_238 b = shape.method_1110() ? new class_238(0, 0, 0, 1, 1, 1) : shape.method_1107();
            double shrink = 0.5 * t * (b.field_1320 - b.field_1323);
            double x1 = pos.method_10263() + b.field_1323 + shrink, y1 = pos.method_10264() + b.field_1322 + shrink, z1 = pos.method_10260() + b.field_1321 + shrink;
            double x2 = pos.method_10263() + b.field_1320 - shrink, y2 = pos.method_10264() + b.field_1325 - shrink, z2 = pos.method_10260() + b.field_1324 - shrink;
            Color side = new Color(
                (int) (start.r + (end.r - start.r) * t), (int) (start.g + (end.g - start.g) * t),
                (int) (start.b + (end.b - start.b) * t), (int) (start.a + (end.a - start.a) * t));
            event.renderer.box(x1, y1, z1, x2, y2, z2, side, line, shapeMode.get(), 0);
        }
    }
}
