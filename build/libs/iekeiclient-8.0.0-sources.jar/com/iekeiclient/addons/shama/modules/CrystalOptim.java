package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;

/**
 * Crystal Optim++ — two supports, both toggleable:
 *   desync-fix   : client-side removes crystals you attack immediately (their CrystalOptim:
 *                  "client-side crystal removal for faster crystals"), so a ghost crystal
 *                  never blocks your next place/hit.
 *   show-placement: highlights the single best obsidian/bedrock base around the nearest
 *                  target (max target damage under your self-damage cap). Placement helper,
 *                  not an auto-hack — it only shows, you act.
 */
public class CrystalOptim extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> desyncFix = sg.add(new BoolSetting.Builder().name("desync-fix").description("Client-side remove crystals you attack (faster crystals).").defaultValue(true).build());
    private final Setting<Double> removeRange = sg.add(new DoubleSetting.Builder().name("remove-range").description("How close a crystal must be for the desync fix to remove it on your client (blocks).").defaultValue(6).min(1).sliderRange(2, 8).visible(desyncFix::get).build());
    private final Setting<Boolean> showPlacement = sg.add(new BoolSetting.Builder().name("show-placement").description("Highlight the optimal crystal base around the nearest target.").defaultValue(false).build());
    private final Setting<Double> targetRange = sg.add(new DoubleSetting.Builder().name("target-range").description("How far away a player can be and still be targeted (blocks).").defaultValue(8).min(1).sliderRange(2, 12).visible(showPlacement::get).build());
    private final Setting<Double> maxSelfDamage = sg.add(new DoubleSetting.Builder().name("max-self-damage").description("Never suggest a placement that would deal more than this much damage to you.").defaultValue(8).min(0).sliderRange(0, 20).visible(showPlacement::get).build());
    private final Setting<SettingColor> color = sg.add(new ColorSetting.Builder().name("color").description("Colour of the best-placement highlight.").defaultValue(new SettingColor(0, 255, 0, 90)).visible(showPlacement::get).build());

    private class_2338 best;

    public CrystalOptim() {
        super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "crystal-optim++", "Makes crystals you hit vanish on your client straight away so you can chain into the next one, and highlights the best spot to place.");
    }

    @Override public void onActivate() { best = null; }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (desyncFix.get() && mc.field_1690.field_1886.method_1434()) {
            double r = removeRange.get();
            for (class_1297 e : mc.field_1687.method_18112())
                if (e instanceof class_1511 && mc.field_1724.method_5739(e) <= r) e.method_31472();
        }

        best = null;
        if (showPlacement.get()) {
            class_1657 target = null; double bd = targetRange.get();
            for (class_1657 p : mc.field_1687.method_18456()) {
                if (p == mc.field_1724 || !p.method_5805()) continue;
                double d = mc.field_1724.method_5739(p);
                if (d < bd) { bd = d; target = p; }
            }
            if (target == null) return;
            double bestDmg = -1;
            class_2338 tb = target.method_24515();
            for (int dx = -3; dx <= 3; dx++) for (int dy = -2; dy <= 2; dy++) for (int dz = -3; dz <= 3; dz++) {
                class_2338 base = tb.method_10069(dx, dy, dz);
                var b = mc.field_1687.method_8320(base).method_26204();
                if (b != class_2246.field_10540 && b != class_2246.field_9987) continue;
                class_2338 on = base.method_10084();
                if (!mc.field_1687.method_8320(on).method_26215()) continue;
                class_243 c = new class_243(on.method_10263() + 0.5, on.method_10264() + 0.5, on.method_10260() + 0.5);
                if (dmg(mc.field_1724, c) > maxSelfDamage.get()) continue;
                double td = dmg(target, c);
                if (td > bestDmg) { bestDmg = td; best = on; }
            }
        }
    }

    private double dmg(class_1657 e, class_243 center) {
        double dist = Math.sqrt(e.method_5707(center));
        return Math.max(0, (1.0 - dist / 12.0) * 42.0);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (best == null) return;
        Color c = color.get();
        event.renderer.box(best.method_10263(), best.method_10264(), best.method_10260(), best.method_10263() + 1, best.method_10264() + 1, best.method_10260() + 1,
            c, new Color(c.r, c.g, c.b, 255), ShapeMode.Both, 0);
    }

    @Override public String getInfoString() { return best != null ? "spot" : (desyncFix.get() ? "desync" : "on"); }
}
