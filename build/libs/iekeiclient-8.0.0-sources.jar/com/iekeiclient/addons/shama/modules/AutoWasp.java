package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_243;

/**
 * AutoWasp++ — ported from their AutoWasp: auto-fly toward the nearest target and hold a
 * set offset above/around them (elytra "wasp" pursuit), with separate horizontal/vertical
 * speed and an option to avoid landing on the ground. Movement-assist for elytra combat.
 */
public class AutoWasp extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Double> targetRange = sg.add(new DoubleSetting.Builder().name("target-range").description("How far away a target can be (blocks).").defaultValue(64).min(4).sliderRange(8, 128).build());
    private final Setting<Double> horizontalSpeed = sg.add(new DoubleSetting.Builder().name("horizontal-speed").description("Horizontal speed (blocks/tick).").defaultValue(1.5).min(0).sliderRange(0.2, 4).build());
    private final Setting<Double> verticalSpeed = sg.add(new DoubleSetting.Builder().name("vertical-speed").description("Vertical speed (blocks/tick).").defaultValue(0.8).min(0).sliderRange(0, 3).build());
    private final Setting<Double> offsetY = sg.add(new DoubleSetting.Builder().name("offset-y").description("Height to hold above the target.").defaultValue(3).sliderRange(-5, 10).build());
    private final Setting<Boolean> avoidLanding = sg.add(new BoolSetting.Builder().name("avoid-landing").description("Don't dive into the ground.").defaultValue(true).build());

    public AutoWasp() {
        super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "auto-wasp++", "Auto-fly pursuit that holds an offset over the nearest target.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        class_1657 target = null; double best = targetRange.get();
        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724 || !p.method_5805()) continue;
            double d = mc.field_1724.method_5739(p);
            if (d < best) { best = d; target = p; }
        }
        if (target == null) return;

        class_243 goal = new net.minecraft.class_243(target.method_23317(), target.method_23318(), target.method_23321()).method_1031(0, offsetY.get(), 0);
        class_243 delta = goal.method_1020(new net.minecraft.class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()));
        class_243 horiz = new class_243(delta.field_1352, 0, delta.field_1350);
        class_243 dir = horiz.method_1027() > 0.01 ? horiz.method_1029() : class_243.field_1353;

        double vy = Math.max(-verticalSpeed.get(), Math.min(verticalSpeed.get(), delta.field_1351));
        if (avoidLanding.get() && mc.field_1724.method_23318() < target.method_23318() && mc.field_1724.method_24828()) vy = verticalSpeed.get();

        mc.field_1724.method_18800(dir.field_1352 * horizontalSpeed.get(), vy, dir.field_1350 * horizontalSpeed.get());
        mc.field_1724.field_64356 = true;
    }
}
