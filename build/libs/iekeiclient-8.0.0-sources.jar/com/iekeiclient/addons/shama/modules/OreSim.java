package com.iekeiclient.addons.shama.modules;

/*
 * OreSim++ — ore-from-seed simulator.
 * Ported to Yarn mappings from Iekei Rejects (GPL-3.0):
 *   https://github.com/AntiCope/meteor-rejects
 * which itself ported it from Atomic: https://gitlab.com/0x151/atomic
 * The "Mojang code" vein section is Minecraft's own OreFeature placement,
 * translated to Yarn. Block selection, rendering, and the registry-accurate
 * approach all follow the rejects/Nora Tweaks design.
 */

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.ChunkDataEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.PlayerUtils;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2826;
import net.minecraft.class_2902;
import net.minecraft.class_2919;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_638;
import net.minecraft.class_6677;
import com.iekeiclient.addons.shama.oresim.Ore;
import com.iekeiclient.addons.shama.oresim.OreVersion;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class OreSim extends Module {
    private final Map<Long, Map<Ore, Set<class_243>>> chunkRenderers = new ConcurrentHashMap<>();
    private Long worldSeed = null;
    private Map<class_5321<class_1959>, List<Ore>> oreConfig;

    public enum AirCheck { ON_LOAD, RECHECK, OFF }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<OreVersion> version = sgGeneral.add(new EnumSetting.Builder<OreVersion>()
        .name("mc-version")
        .description("Which Minecraft version's ore generation to simulate. Current = the running game (1.21.x), registry-accurate like Nora/Rejects. Older versions restore the cross-version pick; validate them in singleplayer.")
        .defaultValue(OreVersion.CURRENT)
        .build());

    private final Setting<Boolean> useServerRegistry = sgGeneral.add(new BoolSetting.Builder()
        .name("use-server-registry")
        .description("Off (default): rebuild vanilla ore generation locally on the client, so Current stays seed-exact even on servers that don't share worldgen data (DonutSMP etc.). On: read the server's synced registry instead (only useful on modded servers with custom ore placement).")
        .defaultValue(false)
        .visible(() -> version.get() == OreVersion.CURRENT)
        .build());

    private final Setting<Boolean> autoSeed = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-seed")
        .description("Use the current singleplayer world's seed automatically. Off = type a seed (for servers).")
        .defaultValue(true)
        .build());

    private final Setting<String> seedText = sgGeneral.add(new StringSetting.Builder()
        .name("seed")
        .description("World seed (numbers or text). Used when auto-seed is off.")
        .defaultValue("")
        .visible(() -> !autoSeed.get())
        .build());

    private final Setting<Integer> horizontalRadius = sgGeneral.add(new IntSetting.Builder()
        .name("chunk-range")
        .description("Range of chunks to render around you.")
        .defaultValue(5)
        .min(1)
        .sliderRange(1, 16)
        .build());

    private final Setting<AirCheck> airCheck = sgGeneral.add(new EnumSetting.Builder<AirCheck>()
        .name("air-check-mode")
        .description("Checks for air at simulated ore positions to drop exposed ones.")
        .defaultValue(AirCheck.RECHECK)
        .build());

    private final Setting<Integer> recheckInterval = sgGeneral.add(new IntSetting.Builder()
        .name("recheck-interval")
        .description("Ticks between line-of-sight rechecks. On these, a box on a block you can actually see (in your FOV, with an exposed face and no obstruction) that isn't ore gets removed. Mined ores clear every tick regardless. 20 ticks = 1s.")
        .defaultValue(200)
        .min(20)
        .sliderRange(20, 600)
        .visible(() -> airCheck.get() == AirCheck.RECHECK)
        .build());

    private final Setting<Boolean> baritone = sgGeneral.add(new BoolSetting.Builder()
        .name("baritone")
        .description("Expose the simulated ore positions as Baritone mining goals so #mine / Baritone can path to them. Requires Baritone (built into Iekei).")
        .defaultValue(false)
        .build());

    // ---- Render ----
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Boolean> colorByOre = sgRender.add(new BoolSetting.Builder()
        .name("color-by-ore")
        .description("Color-code each box by ore type (diamond cyan, gold yellow, redstone red, etc.). Off = use the single fill/line colors below for every ore.")
        .defaultValue(true)
        .build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("Draw outlines, filled sides, or both.")
        .defaultValue(ShapeMode.Lines)
        .build());

    private final Setting<Integer> fillOpacity = sgRender.add(new IntSetting.Builder()
        .name("fill-opacity")
        .description("Fill opacity used when color-by-ore is on (and shape-mode includes sides).")
        .defaultValue(40)
        .range(0, 255)
        .sliderRange(0, 255)
        .visible(colorByOre::get)
        .build());

    private final Setting<SettingColor> fillColor = sgRender.add(new ColorSetting.Builder()
        .name("fill-color")
        .description("Box fill color (used when color-by-ore is off).")
        .defaultValue(new SettingColor(255, 255, 255, 40))
        .visible(() -> !colorByOre.get())
        .build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("Box outline color (used when color-by-ore is off).")
        .defaultValue(new SettingColor(255, 255, 255, 200))
        .visible(() -> !colorByOre.get())
        .build());

        private final Setting<Integer> glow = sgGeneral.add(new IntSetting.Builder()
        .name("glow")
        .description("How strongly each find glows through terrain. 0 is off; higher makes the outline brighter and more solid so it stands out at distance.")
        .defaultValue(0).min(0).max(100).sliderRange(0, 100).build());

    // Sorted list of simulated ore positions, refreshed each tick when baritone
    // is on. Public so a MineProcess hook (or Baritone command) can consume it.
    public final List<class_2338> oreGoals = new ArrayList<>();

    // Counts ticks so the expensive line-of-sight pass runs only every recheck-interval.
    private int validateCounter = 0;

    public OreSim() {
        super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "ore-sim++", "Predicts where ores are from the world seed, accurate to vanilla generation. Enter a seed or let it detect one.");
        SettingGroup sgOres = settings.createGroup("Ores");
        Ore.oreSettings.forEach(sgOres::add);
    }

    private long resolveSeed() {
        if (autoSeed.get()) {
            if (mc.method_1576() != null && mc.method_1576().method_30002() != null)
                return mc.method_1576().method_30002().method_8412();
            return 0;
        }
        String s = seedText.get().trim();
        if (s.isEmpty()) return 0;
        try { return Long.parseLong(s); }
        catch (NumberFormatException e) { return s.hashCode(); }
    }

    public boolean baritone() {
        return isActive() && baritone.get() && com.iekeiclient.engine.pathing.BaritoneUtils.IS_AVAILABLE;
    }

    /** Snapshot of the current simulated ore goals, nearest first. Called by the
     *  Baritone MineProcess mixin to feed positions into auto-mining. */
    public List<class_2338> getBaritoneGoals() {
        return new ArrayList<>(oreGoals);
    }

    @EventHandler
    private void onTick(com.iekeiclient.engine.events.world.TickEvent.Pre event) {
        if (!baritone() || mc.field_1724 == null || oreConfig == null) return;

        // Rebuild the goal list from currently-simulated chunks, nearest first.
        oreGoals.clear();
        for (Map<Ore, Set<class_243>> chunk : chunkRenderers.values()) {
            for (Map.Entry<Ore, Set<class_243>> entry : chunk.entrySet()) {
                if (!entry.getKey().active.get()) continue;
                for (class_243 v : entry.getValue()) {
                    oreGoals.add(class_2338.method_49637(v.field_1352, v.field_1351, v.field_1350));
                }
            }
        }
        class_2338 p = mc.field_1724.method_24515();
        oreGoals.sort(Comparator.comparingDouble(b -> b.method_10262(p)));
    }

    @Override
    public void onActivate() {
        reload();
    }

    @Override
    public void onDeactivate() {
        chunkRenderers.clear();
        oreConfig = null;
        oreGoals.clear();
    }

    private void reload() {
        try {
            long seed = resolveSeed();
            if (seed == 0) {
                error("No seed. Turn on auto-seed in singleplayer, or type a seed.");
                toggle();
                return;
            }
            worldSeed = seed;
            oreConfig = Ore.getRegistry(PlayerUtils.getDimension(), version.get(), useServerRegistry.get());
            if (oreConfig == null || oreConfig.isEmpty()) {
                oreConfig = null;
                error("No ore data available here. Pick a specific mc-version (those work off the biome registry).");
                if (isActive()) toggle();
                return;
            }
            chunkRenderers.clear();
            if (mc.field_1687 != null) {
                for (class_2791 chunk : com.iekeiclient.engine.utils.Utils.chunks(false)) {
                    calculateChunk(chunk);
                }
            }
        } catch (Exception e) {
            // CRITICAL: onActivate() runs inside Iekei's game-join handler. An
            // uncaught exception here disconnects the client and locks it out of
            // the server. Swallow it, disable cleanly, and report instead.
            oreConfig = null;
            chunkRenderers.clear();
            error("OreSim couldn't load here; disabling. (" + e.getClass().getSimpleName() + ")");
            if (isActive()) toggle();
        }
    }

    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        calculateChunk(event.chunk());
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1724 == null || oreConfig == null) return;

        int chunkX = mc.field_1724.method_31476().field_9181;
        int chunkZ = mc.field_1724.method_31476().field_9180;
        int rangeVal = horizontalRadius.get();

        for (int range = 0; range <= rangeVal; range++) {
            for (int x = -range + chunkX; x <= range + chunkX; x++)
                renderChunk(x, chunkZ + range - rangeVal, event);
            for (int x = -range + 1 + chunkX; x < range + chunkX; x++)
                renderChunk(x, chunkZ - range + rangeVal + 1, event);
        }
    }

    private void renderChunk(int x, int z, Render3DEvent event) {
        long key = class_1923.method_8331(x, z);
        Map<Ore, Set<class_243>> chunk = chunkRenderers.get(key);
        if (chunk == null) return;
        ShapeMode mode = shapeMode.get();
        boolean perOre = colorByOre.get();
        for (Map.Entry<Ore, Set<class_243>> entry : chunk.entrySet()) {
            Ore ore = entry.getKey();
            if (!ore.active.get()) continue;
            Color side, line;
            if (perOre) {
                Color c = ore.color;
                line = new Color(c.r, c.g, c.b, 255);
                side = new Color(c.r, c.g, c.b, fillOpacity.get());
            } else {
                line = lineColor.get();
                side = fillColor.get();
            }
            for (class_243 pos : entry.getValue()) {
                if ((glow.get() > 0)) {
                    Color halo = new Color(line.r, line.g, line.b, 45);
                    event.renderer.box(pos.field_1352 - 0.15, pos.field_1351 - 0.15, pos.field_1350 - 0.15,
                        pos.field_1352 + 1.15, pos.field_1351 + 1.15, pos.field_1350 + 1.15,
                        halo, new Color(0, 0, 0, 0), ShapeMode.Sides, 0);
                }
                event.renderer.box(pos.field_1352, pos.field_1351, pos.field_1350, pos.field_1352 + 1, pos.field_1351 + 1, pos.field_1350 + 1, side, line, mode, 0);
            }
        }
    }

    /** Air removal runs every tick (mining clears a box instantly). The heavier
     *  line-of-sight removal — a box on a block you can actually see (in your FOV,
     *  exposed face, unobstructed) that isn't ore — runs only every recheck-interval
     *  ticks. Blocks still buried in stone are kept; predicting unseen ore is the point.
     *  RECHECK mode only (default). Only loaded chunks near you are checked. */
    @EventHandler
    private void onValidateTick(com.iekeiclient.engine.events.world.TickEvent.Post event) {
        if (airCheck.get() == AirCheck.OFF || mc.field_1687 == null || mc.field_1724 == null) return;
        class_638 w = mc.field_1687;
        int pcx = mc.field_1724.method_31476().field_9181;
        int pcz = mc.field_1724.method_31476().field_9180;
        int r = horizontalRadius.get() + 1;

        boolean doRay = airCheck.get() == AirCheck.RECHECK
            && (validateCounter++ % Math.max(1, recheckInterval.get()) == 0);
        class_243 eye = doRay ? mc.field_1724.method_33571() : null;
        class_243 look = doRay ? mc.field_1724.method_5828(1.0F) : null;

        for (Map.Entry<Long, Map<Ore, Set<class_243>>> chunkEntry : chunkRenderers.entrySet()) {
            class_1923 cp = new class_1923(chunkEntry.getKey());
            if (Math.abs(cp.field_9181 - pcx) > r || Math.abs(cp.field_9180 - pcz) > r) continue;   // far away
            if (w.method_8402(cp.field_9181, cp.field_9180, class_2806.field_12803, false) == null) continue; // not loaded
            for (Set<class_243> positions : chunkEntry.getValue().values()) {
                positions.removeIf(p -> {
                    class_2338 bp = class_2338.method_49637(p.field_1352, p.field_1351, p.field_1350);
                    net.minecraft.class_2680 bs = w.method_8320(bp);
                    if (bs.method_26215()) return true;            // mined/empty -> remove (every tick)
                    if (!doRay) return false;               // visibility only on ray ticks
                    if (isOreBlock(bs)) return false;       // confirmed ore -> keep
                    if (!exposed(w, bp)) return false;      // no open face -> can't be seen -> keep
                    if (!inFov(eye, look, bp)) return false;// not in view -> keep
                    return rayVisible(w, eye, bp);          // in view & unobstructed & not ore -> remove
                });
            }
        }
    }

    private boolean isOreBlock(net.minecraft.class_2680 bs) {
        String path = com.iekeiclient.addons.shama.util.BlockPaths.of(bs.method_26204());
        return path.endsWith("_ore") || path.equals("ancient_debris");
    }

    private boolean exposed(class_638 w, class_2338 p) {
        for (class_2350 d : class_2350.values())
            if (!w.method_8320(p.method_10093(d)).method_26216()) return true;
        return false;
    }

    /** Block center is within ~the view cone (in front of the camera). */
    private boolean inFov(class_243 eye, class_243 look, class_2338 p) {
        class_243 to = class_243.method_24953(p).method_1020(eye);
        if (to.method_1027() < 1.0E-4) return true;
        return to.method_1029().method_1026(look) > 0.4D;
    }

    /** A clear line of sight exists from the eye to the block (the first solid the
     *  ray hits is the block itself, not something in front of it). */
    private boolean rayVisible(class_638 w, class_243 eye, class_2338 p) {
        net.minecraft.class_3965 hit = w.method_17742(new net.minecraft.class_3959(
            eye, class_243.method_24953(p),
            net.minecraft.class_3959.class_3960.field_17558,
            net.minecraft.class_3959.class_242.field_1348,
            mc.field_1724));
        return hit.method_17783() == net.minecraft.class_239.class_240.field_1332 && hit.method_17777().equals(p);
    }

    private void calculateChunk(class_2791 chunk) {
        if (chunk == null || mc.field_1687 == null || oreConfig == null || worldSeed == null) return;

        class_1923 chunkPos = chunk.method_12004();
        long key = chunkPos.method_8324();
        if (chunkRenderers.containsKey(key)) return;

        class_638 world = mc.field_1687;

        Set<class_5321<class_1959>> biomeKeys = new HashSet<>();
        class_1923.method_19280(chunkPos, 1).forEach(pos -> {
            class_2791 c = world.method_8402(pos.field_9181, pos.field_9180, class_2806.field_12794, false);
            if (c == null) return;
            for (class_2826 section : c.method_12006())
                section.method_38294().method_39793(b -> b.method_40230().ifPresent(biomeKeys::add));
        });

        Set<Ore> ores = biomeKeys.stream()
            .flatMap(b -> getOresForBiome(b).stream())
            .collect(Collectors.toSet());

        int chunkX = chunkPos.field_9181 << 4;
        int chunkZ = chunkPos.field_9180 << 4;
        class_2919 random = new class_2919(new class_6677(0));
        long populationSeed = random.method_12661(worldSeed, chunkX, chunkZ);

        Map<Ore, Set<class_243>> orePositions = new HashMap<>();
        for (Ore ore : ores) {
            HashSet<class_243> positions = new HashSet<>();
            random.method_12664(populationSeed, ore.index, ore.step);
            int repeat = ore.count.method_35008(random);

            for (int i = 0; i < repeat; i++) {
                if (ore.rarity != 1.0F && random.method_43057() >= 1.0F / ore.rarity) continue;
                int x = random.method_43048(16) + chunkX;
                int z = random.method_43048(16) + chunkZ;
                int y = ore.hardcoded ? ore.sampleY(random) : ore.heightProvider.method_35391(random, ore.heightContext);
                class_2338 origin = new class_2338(x, y, z);

                class_5321<class_1959> biome = chunk.method_16359(x, y, z).method_40230().orElse(null);
                if (biome != null && !getOresForBiome(biome).contains(ore)) continue;

                if (ore.scattered) positions.addAll(generateHidden(world, random, origin, ore.size));
                else positions.addAll(generateNormal(world, random, origin, ore.size, ore.discardOnAirChance));
            }
            if (!positions.isEmpty()) orePositions.put(ore, positions);
        }
        if (!orePositions.isEmpty()) chunkRenderers.put(key, orePositions);
    }

    private List<Ore> getOresForBiome(class_5321<class_1959> biomeKey) {
        if (oreConfig == null) return Collections.emptyList();
        List<Ore> ores = oreConfig.get(biomeKey);
        if (ores != null) return ores;
        return oreConfig.values().stream().findAny().orElse(Collections.emptyList());
    }

    // ==================== Mojang code (Yarn-mapped) ====================

    private List<class_243> generateNormal(class_638 world, class_2919 random, class_2338 blockPos, int veinSize, float discardOnAir) {
        float angle = random.method_43057() * (float) Math.PI;
        float spread = (float) veinSize / 8.0F;
        int padding = class_3532.method_15386(((float) veinSize / 16.0F * 2.0F + 1.0F) / 2.0F);
        double startX = blockPos.method_10263() + Math.sin(angle) * spread;
        double endX = blockPos.method_10263() - Math.sin(angle) * spread;
        double startZ = blockPos.method_10260() + Math.cos(angle) * spread;
        double endZ = blockPos.method_10260() - Math.cos(angle) * spread;
        double startY = blockPos.method_10264() + random.method_43048(3) - 2;
        double endY = blockPos.method_10264() + random.method_43048(3) - 2;
        int minX = blockPos.method_10263() - class_3532.method_15386(spread) - padding;
        int minY = blockPos.method_10264() - 2 - padding;
        int minZ = blockPos.method_10260() - class_3532.method_15386(spread) - padding;
        int sizeXZ = 2 * (class_3532.method_15386(spread) + padding);
        int sizeY = 2 * (2 + padding);

        for (int x = minX; x <= minX + sizeXZ; x++) {
            for (int z = minZ; z <= minZ + sizeXZ; z++) {
                if (minY <= world.method_8624(class_2902.class_2903.field_13197, x, z)) {
                    return generateVein(world, random, veinSize, startX, endX, startZ, endZ, startY, endY, minX, minY, minZ, sizeXZ, sizeY, discardOnAir);
                }
            }
        }
        return new ArrayList<>();
    }

    private List<class_243> generateVein(class_638 world, class_2919 random, int veinSize, double startX, double endX, double startZ, double endZ, double startY, double endY, int minX, int minY, int minZ, int sizeXZ, int sizeY, float discardOnAir) {
        BitSet bitSet = new BitSet(sizeXZ * sizeY * sizeXZ);
        class_2338.class_2339 mutable = new class_2338.class_2339();
        double[] buf = new double[veinSize * 4];
        List<class_243> positions = new ArrayList<>();

        for (int i = 0; i < veinSize; i++) {
            float t = (float) i / (float) veinSize;
            double x = class_3532.method_16436(t, startX, endX);
            double y = class_3532.method_16436(t, startY, endY);
            double z = class_3532.method_16436(t, startZ, endZ);
            double scale = random.method_43058() * veinSize / 16.0D;
            double radius = ((class_3532.method_15374((float) Math.PI * t) + 1.0F) * scale + 1.0D) / 2.0D;
            buf[i * 4] = x; buf[i * 4 + 1] = y; buf[i * 4 + 2] = z; buf[i * 4 + 3] = radius;
        }

        for (int i = 0; i < veinSize - 1; i++) {
            if (buf[i * 4 + 3] <= 0.0D) continue;
            for (int j = i + 1; j < veinSize; j++) {
                if (buf[j * 4 + 3] <= 0.0D) continue;
                double dx = buf[i * 4] - buf[j * 4];
                double dy = buf[i * 4 + 1] - buf[j * 4 + 1];
                double dz = buf[i * 4 + 2] - buf[j * 4 + 2];
                double dr = buf[i * 4 + 3] - buf[j * 4 + 3];
                if (dr * dr > dx * dx + dy * dy + dz * dz) {
                    if (dr > 0.0D) buf[j * 4 + 3] = -1.0D; else buf[i * 4 + 3] = -1.0D;
                }
            }
        }

        for (int i = 0; i < veinSize; i++) {
            double radius = buf[i * 4 + 3];
            if (radius < 0.0D) continue;
            double cx = buf[i * 4], cy = buf[i * 4 + 1], cz = buf[i * 4 + 2];
            int x0 = Math.max(class_3532.method_15357(cx - radius), minX);
            int y0 = Math.max(class_3532.method_15357(cy - radius), minY);
            int z0 = Math.max(class_3532.method_15357(cz - radius), minZ);
            int x1 = Math.max(class_3532.method_15357(cx + radius), x0);
            int y1 = Math.max(class_3532.method_15357(cy + radius), y0);
            int z1 = Math.max(class_3532.method_15357(cz + radius), z0);

            for (int x = x0; x <= x1; x++) {
                double nx = ((double) x + 0.5D - cx) / radius;
                if (nx * nx >= 1.0D) continue;
                for (int y = y0; y <= y1; y++) {
                    double ny = ((double) y + 0.5D - cy) / radius;
                    if (nx * nx + ny * ny >= 1.0D) continue;
                    for (int z = z0; z <= z1; z++) {
                        double nz = ((double) z + 0.5D - cz) / radius;
                        if (nx * nx + ny * ny + nz * nz >= 1.0D) continue;
                        int idx = x - minX + (y - minY) * sizeXZ + (z - minZ) * sizeXZ * sizeY;
                        if (bitSet.get(idx)) continue;
                        bitSet.set(idx);
                        mutable.method_10103(x, y, z);
                        if (y < world.method_31607() || y > world.method_31607() + world.method_31605()) continue;
                        if (airCheck.get() != AirCheck.OFF && !world.method_8320(mutable).method_26216()) continue;
                        if (shouldPlace(world, mutable, discardOnAir, random)) positions.add(new class_243(x, y, z));
                    }
                }
            }
        }
        return positions;
    }

    private boolean shouldPlace(class_638 world, class_2338 pos, float discardOnAir, class_2919 random) {
        if (discardOnAir == 0 || (discardOnAir != 1.0F && random.method_43057() >= discardOnAir)) return true;
        for (class_2350 direction : class_2350.values()) {
            if (!world.method_8320(pos.method_10093(direction)).method_26216() && discardOnAir != 1.0F)
                return false;
        }
        return true;
    }

    private List<class_243> generateHidden(class_638 world, class_2919 random, class_2338 origin, int size) {
        List<class_243> positions = new ArrayList<>();
        int limit = random.method_43048(size + 1);
        for (int i = 0; i < limit; i++) {
            int range = Math.min(i, 7);
            int x = randomCoord(random, range) + origin.method_10263();
            int y = randomCoord(random, range) + origin.method_10264();
            int z = randomCoord(random, range) + origin.method_10260();
            class_2338 pos = new class_2338(x, y, z);
            if (airCheck.get() != AirCheck.OFF && !world.method_8320(pos).method_26216()) continue;
            if (shouldPlace(world, pos, 1.0F, random)) positions.add(new class_243(x, y, z));
        }
        return positions;
    }

    private int randomCoord(class_2919 random, int size) {
        return Math.round((random.method_43057() - random.method_43057()) * size);
    }

    @Override
    public String getInfoString() {
        int n = 0;
        for (var m : chunkRenderers.values()) for (var s : m.values()) n += s.size();
        return n + " ores";
    }
}
