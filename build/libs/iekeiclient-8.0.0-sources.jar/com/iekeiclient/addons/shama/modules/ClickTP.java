package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import net.minecraft.class_243;
import net.minecraft.class_2828;

/** ClickTP++ — teleport forward along your look by sending stepped position packets. Bind a key; press to blink. Server-validated, so distance is capped on strict servers. */
public class ClickTP extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Double> distance = sg.add(new DoubleSetting.Builder().name("distance").description("Maximum distance in blocks.").defaultValue(6).min(1).sliderRange(1, 20).build());
    private final Setting<Integer> steps = sg.add(new IntSetting.Builder().name("steps").description("Packets to split the jump into (more = smoother/safer).").defaultValue(4).range(1, 20).build());

    public ClickTP() { super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "click-tp++", "Blink forward along your look. Bind a key and tap it."); }

    @Override
    public void onActivate() {
        if (mc.field_1724 == null || mc.method_1562() == null) { toggle(); return; }
        class_243 look = mc.field_1724.method_5828(1f).method_18805(1, 0, 1).method_1029();
        double per = distance.get() / steps.get();
        double x = mc.field_1724.method_23317(), y = mc.field_1724.method_23318(), z = mc.field_1724.method_23321();
        for (int i = 0; i < steps.get(); i++) {
            x += look.field_1352 * per; z += look.field_1350 * per;
            mc.method_1562().method_52787(new class_2828.class_2829(x, y, z, false, mc.field_1724.field_5976));
        }
        mc.field_1724.method_5814(x, y, z);
        toggle(); // one-shot
    }
}
