package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.DoubleSetting;
import com.iekeiclient.engine.settings.EnumSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;

/**
 * Speed++ — scales your horizontal velocity up to a target speed in whatever
 * direction you're already moving. This is real movement (no fake AC bypass): the
 * server validates movement, so it works in singleplayer / lenient servers and
 * gets flagged by strict anti-cheats. Vanilla reference: walk ~0.13, sprint ~0.28
 * blocks/tick.
 */
public class Speed extends Module {
    public enum Mode {
        Simple,   // scale current velocity up to target (works on ground or air)
        Bhop,     // auto-jump while moving to chain sprint-jumps for ground speed
        Strafe,   // accelerate by aligning velocity to your input each tick
        Sprint,   // force-sprint + scale; mimics legit sprint movement
        YPort,    // hop a tiny amount each tick so ground-friction speed checks don't apply
        OnGround, // scale speed but report on-ground, to fool simple ground-speed checks
        Hop       // continuous micro-jumps that keep you technically airborne with speed
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("How speed is applied, each defeating different checks: Simple (scale velocity), Bhop (auto-jump), Strafe (steer to keys), Sprint (force-sprint + scale), YPort (tiny per-tick hop so ground-friction checks don't apply), OnGround (scale but report grounded), Hop (continuous micro-jumps). Which survives depends on the server's anticheat — try a few.")
        .defaultValue(Mode.Simple)
        .build()
    );

    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
        .name("speed")
        .description("Target horizontal speed in blocks/tick.")
        .defaultValue(0.4)
        .min(0.0)
        .sliderRange(0.15, 1.5)
        .build()
    );

    private final Setting<Boolean> groundOnly = sgGeneral.add(new BoolSetting.Builder()
        .name("ground-only")
        .description("Only boost while on the ground (less obvious, fewer anti-cheat flags than air-speed).")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> sprintOnly = sgGeneral.add(new BoolSetting.Builder()
        .name("sprint-only")
        .description("Only boost while you're sprinting.")
        .defaultValue(false)
        .build()
    );

    public Speed() {
        super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "speed++", "Move faster than normal. How much you can get away with depends on the server's anti-cheat.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null) return;
        if (groundOnly.get() && !mc.field_1724.method_24828()) return;
        if (sprintOnly.get() && !mc.field_1724.method_5624()) return;

        switch (mode.get()) {
            case Simple -> applyScale();
            case Bhop -> {
                // Auto-hop: the instant you're grounded and moving, jump again, so
                // you chain sprint-jumps. Then scale the horizontal like Simple.
                if (mc.field_1724.method_24828() && isMoving()) {
                    class_243 v = mc.field_1724.method_18798();
                    mc.field_1724.method_18800(v.field_1352, 0.42, v.field_1350); // vanilla jump impulse
                }
                applyScale();
            }
            case Strafe -> {
                // Steer velocity toward where you're trying to go and push it up to
                // the target speed — gains speed in the air like classic strafing.
                double mx = 0, mz = 0;
                boolean f = mc.field_1690.field_1894.method_1434();
                boolean b = mc.field_1690.field_1881.method_1434();
                boolean l = mc.field_1690.field_1913.method_1434();
                boolean r = mc.field_1690.field_1849.method_1434();
                if (!(f || b || l || r)) return;
                float yaw = (float) Math.toRadians(mc.field_1724.method_36454());
                double sin = Math.sin(yaw), cos = Math.cos(yaw);
                double forward = (f ? 1 : 0) - (b ? 1 : 0);
                double strafe = (r ? 1 : 0) - (l ? 1 : 0);
                mx = forward * -sin + strafe * cos;
                mz = forward * cos + strafe * sin;
                double len = Math.sqrt(mx * mx + mz * mz);
                if (len == 0) return;
                class_243 v = mc.field_1724.method_18798();
                mc.field_1724.method_18800(mx / len * speed.get(), v.field_1351, mz / len * speed.get());
            }
            case Sprint -> {
                // Force the sprint flag on (so the server sees legit sprint state)
                // and scale to target. Reads more like real movement than a raw
                // velocity multiply with no sprint.
                if (isMoving()) mc.field_1724.method_5728(true);
                applyScale();
            }
            case YPort -> {
                // Bob a hair up/down each tick. While the server thinks you're
                // airborne it often doesn't apply the on-ground friction speed cap,
                // so the horizontal boost passes checks that only gate ground speed.
                if (isMoving()) {
                    class_243 v = mc.field_1724.method_18798();
                    double y = mc.field_1724.method_24828() ? 0.07 : v.field_1351; // little hop off the floor
                    mc.field_1724.method_18800(v.field_1352, y, v.field_1350);
                }
                applyScale();
            }
            case OnGround -> {
                // Scale, then report grounded. Fools simple checks that only measure
                // speed while you're flagged as in the air.
                applyScale();
                mc.field_1724.method_24830(true);
            }
            case Hop -> {
                // Continuous low hops: smaller than Bhop so you skim along, staying
                // briefly airborne each cycle while keeping the horizontal boost.
                if (mc.field_1724.method_24828() && isMoving()) {
                    class_243 v = mc.field_1724.method_18798();
                    mc.field_1724.method_18800(v.field_1352, 0.30, v.field_1350);
                }
                applyScale();
            }
        }
    }

    /** Scale current horizontal momentum up to the target speed (never down). */
    private void applyScale() {
        class_243 v = mc.field_1724.method_18798();
        double h = Math.sqrt(v.field_1352 * v.field_1352 + v.field_1350 * v.field_1350);
        if (h < 0.06) return;                 // basically standing still
        double scale = speed.get() / h;
        if (scale <= 1.0) return;             // never slow you down
        mc.field_1724.method_18800(v.field_1352 * scale, v.field_1351, v.field_1350 * scale);
    }

    private boolean isMoving() {
        return mc.field_1690.field_1894.method_1434() || mc.field_1690.field_1881.method_1434()
            || mc.field_1690.field_1913.method_1434() || mc.field_1690.field_1849.method_1434();
    }

    @Override
    public String getInfoString() {
        return mode.get().name().toLowerCase() + " " + String.format("%.2f", speed.get());
    }
}
