package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import com.iekeiclient.addons.shama.util.Humanize;

/**
 * Crystal Aura++ — auto end-crystal combat, ported from their crystal-macro method with
 * the Horion-style extras you asked for:
 *   spam         : place + break as fast as the delays allow (no strict 1-per-cycle).
 *   multi-crystal: place on several valid bases around the target in one tick.
 *   walk-through : place/break without needing line of sight (ignores raycast occlusion).
 *
 * Flow (their method): pick nearest player target -> find obsidian/bedrock bases next to
 * them with air above -> place crystal -> attack any crystal in range to detonate. Damage
 * gates keep you from blowing yourself up.
 */
public class CrystalAura extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Double> targetRange = sg.add(new DoubleSetting.Builder().name("target-range").description("How far away a target can be (blocks).").defaultValue(8).min(1).sliderRange(2, 12).build());
    private final Setting<Double> placeRange = sg.add(new DoubleSetting.Builder().name("place-range").description("How far away you can place (blocks).").defaultValue(5).min(1).sliderRange(2, 8).build());
    private final Setting<Double> breakRange = sg.add(new DoubleSetting.Builder().name("break-range").description("How far away you can break (blocks).").defaultValue(5).min(1).sliderRange(2, 8).build());
    // ===== crystal-optim helpers, kept here as redundancy so the aura works standalone =====
    private final SettingGroup sgOptim = settings.createGroup("Helpers");
    private final Setting<Boolean> desyncFix = sgOptim.add(new BoolSetting.Builder()
        .name("desync-fix").description("Remove crystals you attack on your client straight away, so you can hit the next one without waiting for the server. Also available as the standalone crystal-optim++ module; running both is harmless.").defaultValue(true).build());
    private final Setting<Double> removeRange = sgOptim.add(new DoubleSetting.Builder()
        .name("remove-range").description("Range to client-side remove crystals within (blocks).").defaultValue(6).min(1).sliderRange(2, 8).visible(desyncFix::get).build());
    private final Setting<Boolean> showPlacement = sgOptim.add(new BoolSetting.Builder()
        .name("show-placement").description("Highlight the single best obsidian/bedrock base to place a crystal on against the nearest target.").defaultValue(false).build());
    private final Setting<SettingColor> optimColor = sgOptim.add(new ColorSetting.Builder()
        .name("placement-color").description("Colour of the best-placement highlight.").defaultValue(new SettingColor(0, 255, 120, 200)).visible(showPlacement::get).build());

    private net.minecraft.class_2338 bestSpot;

    private final SettingGroup sgBypass = settings.createGroup("Bypass");
    private final Setting<Integer> missChance = sgBypass.add(new IntSetting.Builder()
        .name("miss-chance").description("Chance (%) to skip an attack this tick, like a human misclicking. 0 = never miss (fastest but most robotic).").defaultValue(0).min(0).max(100).sliderRange(0, 50).build());
    private final Setting<Integer> timingJitter = sgBypass.add(new IntSetting.Builder()
        .name("timing-jitter").description("Randomly vary the delays by +/- this % so they aren't a perfect fixed rhythm.").defaultValue(0).min(0).max(100).sliderRange(0, 60).build());

    private final Setting<Boolean> spam = sg.add(new BoolSetting.Builder().name("max-speed").description("Place and break as fast as the delays allow.").defaultValue(true).build());
    private final Setting<Boolean> multi = sg.add(new BoolSetting.Builder().name("multi-crystal").description("Place on several bases around the target each tick.").defaultValue(false).build());
    private final Setting<Integer> multiMax = sg.add(new IntSetting.Builder().name("multi-max").description("Most crystals to place at once.").defaultValue(3).range(1, 10).sliderRange(1, 6).visible(multi::get).build());
    private final Setting<Boolean> walkThrough = sg.add(new BoolSetting.Builder().name("walk-through").description("Place/break without line of sight.").defaultValue(true).build());
    private final Setting<Boolean> autoPlace = sg.add(new BoolSetting.Builder().name("place").description("Place crystals automatically.").defaultValue(true).build());
    private final Setting<Boolean> autoBreak = sg.add(new BoolSetting.Builder().name("break").description("Break crystals automatically.").defaultValue(true).build());
    private final Setting<Integer> placeDelay = sg.add(new IntSetting.Builder().name("place-delay").description("Ticks between placements.").defaultValue(0).range(0, 20).sliderRange(0, 10).build());
    private final Setting<Integer> breakDelay = sg.add(new IntSetting.Builder().name("break-delay").description("Ticks between breaks.").defaultValue(0).range(0, 20).sliderRange(0, 10).visible(autoBreak::get).build());
    private final Setting<Double> maxSelfDamage = sg.add(new DoubleSetting.Builder().name("max-self-damage").description("Don't act if it would deal more than this much damage to you.").defaultValue(8).min(0).sliderRange(0, 20).build());

    private int placeTimer, breakTimer;

    public CrystalAura() {
        super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "crystal-aura++", "Places and blows end crystals for you. Also carries the helpers: crystals you hit vanish on your client straight away so you can chain into the next one, and the best spot to place is highlighted. Turn place and break off to use it as helpers only.");
    }

    @Override public void onActivate() { placeTimer = 0; breakTimer = 0; }

    @EventHandler
    private void onOptimTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (desyncFix.get() && mc.field_1690.field_1886.method_1434()) {
            double r = removeRange.get();
            for (net.minecraft.class_1297 e : mc.field_1687.method_18112())
                if (e instanceof class_1511 && mc.field_1724.method_5739(e) <= r) e.method_31472();
        }
        bestSpot = null;
        if (!showPlacement.get()) return;
        net.minecraft.class_1657 target = null;
        double bd = targetRange.get();
        for (net.minecraft.class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724 || !p.method_5805()) continue;
            double d = mc.field_1724.method_5739(p);
            if (d < bd) { bd = d; target = p; }
        }
        if (target == null) return;
        double bestDmg = -1;
        net.minecraft.class_2338 tb = target.method_24515();
        for (int dx = -3; dx <= 3; dx++) for (int dy = -2; dy <= 2; dy++) for (int dz = -3; dz <= 3; dz++) {
            net.minecraft.class_2338 base = tb.method_10069(dx, dy, dz);
            var b = mc.field_1687.method_8320(base).method_26204();
            if (b != net.minecraft.class_2246.field_10540 && b != net.minecraft.class_2246.field_9987) continue;
            net.minecraft.class_2338 on = base.method_10084();
            if (!mc.field_1687.method_8320(on).method_26215()) continue;
            net.minecraft.class_243 c = new net.minecraft.class_243(on.method_10263() + 0.5, on.method_10264() + 0.5, on.method_10260() + 0.5);
            if (optimDmg(mc.field_1724, c) > maxSelfDamage.get()) continue;
            double td = optimDmg(target, c);
            if (td > bestDmg) { bestDmg = td; bestSpot = on; }
        }
    }

    private double optimDmg(net.minecraft.class_1657 e, net.minecraft.class_243 centre) {
        double dist = Math.sqrt(e.method_5707(centre));
        return Math.max(0, (1.0 - dist / 12.0) * 42.0);
    }

    @EventHandler
    private void onOptimRender(com.iekeiclient.engine.events.render.Render3DEvent event) {
        if (bestSpot == null || !showPlacement.get()) return;
        var c = optimColor.get();
        event.renderer.box(bestSpot.method_10263(), bestSpot.method_10264(), bestSpot.method_10260(),
            bestSpot.method_10263() + 1, bestSpot.method_10264() + 1, bestSpot.method_10260() + 1,
            c, new Color(c.r, c.g, c.b, 255), com.iekeiclient.engine.renderer.ShapeMode.Both, 0);
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        if (placeTimer > 0) placeTimer--;
        if (breakTimer > 0) breakTimer--;

        // 1) break existing crystals in range (detonate)
        if (autoBreak.get() && breakTimer == 0) {
            for (class_1297 e : mc.field_1687.method_18112()) {
                if (!(e instanceof class_1511)) continue;
                if (mc.field_1724.method_5739(e) > breakRange.get()) continue;
                if (Humanize.shouldMiss(missChance.get())) { breakTimer = Humanize.jitter(breakDelay.get(), timingJitter.get()); break; }
                mc.field_1761.method_2918(mc.field_1724, e);
                mc.field_1724.method_6104(class_1268.field_5808);
                breakTimer = Humanize.jitter(breakDelay.get(), timingJitter.get());
                if (!spam.get()) break;
            }
        }

        // 2) find target
        class_1657 target = null; double best = targetRange.get();
        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724 || !p.method_5805()) continue;
            double d = mc.field_1724.method_5739(p);
            if (d < best) { best = d; target = p; }
        }
        if (target == null) return;

        // 3) place crystal(s) on valid bases around target
        if (autoPlace.get() && placeTimer == 0) {
            int slot = com.iekeiclient.engine.utils.player.InvUtils.findInHotbar(class_1802.field_8301).slot();
            if (slot < 0) return;
            int placed = 0, want = multi.get() ? multiMax.get() : 1;
            class_2338 tb = target.method_24515();
            for (int dx = -2; dx <= 2 && placed < want; dx++)
                for (int dz = -2; dz <= 2 && placed < want; dz++) {
                    class_2338 base = tb.method_10069(dx, -1, dz);
                    if (!isBase(base)) continue;
                    class_2338 on = base.method_10084();
                    if (!mc.field_1687.method_8320(on).method_26215()) continue;
                    if (mc.field_1724.method_33571().method_1022(class_243.method_24953(base)) > placeRange.get()) continue;
                    if (crystalDamage(mc.field_1724, class_243.method_24953(on)) > maxSelfDamage.get()) continue;
                    if (!walkThrough.get() && !hasLineOfSight(base)) continue;   // walk-through OFF = must actually see the spot
                    com.iekeiclient.engine.utils.player.InvUtils.swap(slot, true);
                    class_3965 hit = new class_3965(class_243.method_24953(base), class_2350.field_11036, base, false);
                    mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
                    mc.field_1724.method_6104(class_1268.field_5808);
                    placed++;
                    if (!spam.get() && !multi.get()) break;
                }
            if (placed > 0) placeTimer = Humanize.jitter(placeDelay.get(), timingJitter.get());
        }
    }

    /** True if nothing solid is between your eyes and this block. Only consulted when walk-through is off. */
    private boolean hasLineOfSight(class_2338 pos) {
        if (mc.field_1724 == null || mc.field_1687 == null) return false;
        class_243 eye = mc.field_1724.method_33571();
        class_239 res = mc.field_1687.method_17742(new class_3959(eye, class_243.method_24953(pos),
            class_3959.class_3960.field_17558, class_3959.class_242.field_1348, mc.field_1724));
        if (res == null || res.method_17783() == class_239.class_240.field_1333) return true;
        return res instanceof class_3965 bhr && bhr.method_17777().equals(pos);
    }

    private boolean isBase(class_2338 p) {
        var b = mc.field_1687.method_8320(p).method_26204();
        return b == class_2246.field_10540 || b == class_2246.field_9987;
    }

    private double crystalDamage(class_1657 e, class_243 center) {
        double dist = e.method_33571().method_1022(center);
        return Math.max(0, (1.0 - dist / 12.0) * 42.0); // end crystal ~6 power falloff approximation
    }

    @Override public String getInfoString() { return spam.get() ? "spam" : multi.get() ? "multi" : "on"; }
}
