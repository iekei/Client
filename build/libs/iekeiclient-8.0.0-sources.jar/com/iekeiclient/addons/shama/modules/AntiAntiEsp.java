package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2622;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2675;
import net.minecraft.class_2767;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Anti Anti ESP — recovers what the server is hiding by reading the messages it cannot fake.
 *
 * The protection works on the bulk chunk packet. Everything below your cutoff gets replaced with
 * deepslate while you are above it, and things like amethyst and dripstone are stripped out unless
 * you are down there with them and looking. So the chunk you receive is a lie.
 *
 * It cannot lie on the other channels. A block change, a block entity, a particle, a sound — those
 * describe live events the client has to render correctly, so they carry true positions. A chest
 * announces itself; amethyst gives off particles; a farm makes noise. This listens to all of it and
 * keeps a picture built only from things the server told the truth about, which survives whatever
 * the chunk data claims.
 */
public class AntiAntiEsp extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Integer> range = sg.add(new IntSetting.Builder()
        .name("range").description("How far out to keep what has been recovered, in blocks.")
        .defaultValue(160).min(16).max(512).sliderRange(48, 320).build());

    private final Setting<Boolean> forgetOnUpdate = sg.add(new BoolSetting.Builder()
        .name("forget-on-update")
        .description("Keep a recovered position until the server actually says that block changed, instead of dropping it after a timer. Hiding a block from chunk data is easy, but when somebody breaks it the server has to send a block update or your world would be wrong — so no update means it is still there. Works on anything, not just amethyst, and it sends nothing.")
        .defaultValue(true).build());

    private final Setting<Integer> keepSeconds = sg.add(new IntSetting.Builder()
        .name("remember-for")
        .description("How long a recovered position stays on screen, in seconds. Only used when forget-on-update is off — with that on, a position is kept until the server says it changed, which needs no timer.")
        .defaultValue(600).min(10).max(7200).sliderRange(60, 1800).visible(() -> !forgetOnUpdate.get()).build());

    private final Setting<Boolean> chat = sg.add(new BoolSetting.Builder()
        .name("chat").description("Report each recovery in chat.").defaultValue(false).build());

    // ---------------------------------------------------------------- channels
    private final SettingGroup sgSources = settings.createGroup("Channels");

    private final Setting<Boolean> fromBlockUpdates = sgSources.add(new BoolSetting.Builder()
        .name("block-changes")
        .description("Read single block changes. Something being placed inside ground the server told you was solid is that ground exposed as a lie. Blocks being broken are ignored — that is activity, not a hidden find, and deep-activity++ is the module for it.")
        .defaultValue(true).build());

    private final Setting<Boolean> fromBulkUpdates = sgSources.add(new BoolSetting.Builder()
        .name("bulk-changes")
        .description("Read bulk section updates as well. Mining and explosions arrive this way rather than one block at a time, so leaving this off misses most of what people are doing.")
        .defaultValue(true).build());

    private final Setting<Boolean> fromBlockEntities = sgSources.add(new BoolSetting.Builder()
        .name("block-entities")
        .description("Read block entities. Chests, hoppers, spawners and signs travel in their own packet with a real position attached, and the protection does not touch it — this is the most reliable channel there is.")
        .defaultValue(true).build());

    private final Setting<Boolean> fromParticles = sgSources.add(new BoolSetting.Builder()
        .name("particles")
        .description("Read particles. Amethyst, dripstone drips, portals and lava all give themselves away this way, and it works even when the block itself has been stripped out of the chunk you were sent.")
        .defaultValue(true).build());

    private final Setting<Boolean> fromSounds = sgSources.add(new BoolSetting.Builder()
        .name("sounds")
        .description("Read sounds. Amethyst chimes, water drips and machinery all carry a position, so a place that is silent in your chunk data can still be noisy on this channel.")
        .defaultValue(true).build());

    // ---------------------------------------------------------------- filter
    private final SettingGroup sgFilter = settings.createGroup("Filter");

    private final Setting<Boolean> beyondSendRange = sgFilter.add(new BoolSetting.Builder()
        .name("beyond-send-range")
        .description("Trust anything reported from further away than the server says it sends chunks. It announces that distance itself, so a position past it cannot have come from chunk data at all — it can only have arrived on one of the honest channels. That makes it certain rather than probable, and it needs no guessing about what your client is drawing.")
        .defaultValue(true).build());

    private final Setting<Boolean> onlyHidden = sgFilter.add(new BoolSetting.Builder()
        .name("only-hidden")
        .description("Only keep positions where your client currently shows deepslate, stone or air. That mismatch is the protection caught in the act — the server described something real in a place it told you was solid rock.")
        .defaultValue(true).build());

    private final Setting<Boolean> belowYOnly = sgFilter.add(new BoolSetting.Builder()
        .name("below-y-only")
        .description("Only keep what is under the height below, which is where the ground gets replaced.")
        .defaultValue(true).build());

    private final Setting<Integer> belowY = sgFilter.add(new IntSetting.Builder()
        .name("below-y").description("The height that limit uses.")
        .defaultValue(0).min(-64).max(320).sliderRange(-64, 64)
        .visible(belowYOnly::get).build());

    private final Setting<List<net.minecraft.class_1792>> watch = sgFilter.add(new ItemListSetting.Builder()
        .name("blocks")
        .description("Which blocks are worth recovering. Anything not here is ignored even when the server slips up and mentions it. It is an item picker, matched against the block's item form.")
        .defaultValue(List.of(
            net.minecraft.class_1802.field_8106, net.minecraft.class_1802.field_8247,
            net.minecraft.class_1802.field_16307, net.minecraft.class_1802.field_8466,
            net.minecraft.class_1802.field_8545, net.minecraft.class_1802.field_8239,
            net.minecraft.class_1802.field_8732, net.minecraft.class_1802.field_16306,
            net.minecraft.class_1802.field_16309, net.minecraft.class_1802.field_8740,
            net.minecraft.class_1802.field_8849, net.minecraft.class_1802.field_8668,
            net.minecraft.class_1802.field_8140, net.minecraft.class_1802.field_8657,
            net.minecraft.class_1802.field_8782, net.minecraft.class_1802.field_27069,
            net.minecraft.class_1802.field_27065, net.minecraft.class_1802.field_27064,
            net.minecraft.class_1802.field_28042, net.minecraft.class_1802.field_22019,
            net.minecraft.class_1802.field_8787, net.minecraft.class_1802.field_29022,
            net.minecraft.class_1802.field_8281, net.minecraft.class_1802.field_22421))
        .build());

    // ---------------------------------------------------------------- render
    // ---------------------------------------------------------------- forcing the server's hand
    private final SettingGroup sgForce = settings.createGroup("Force Data");

    private final Setting<Boolean> forceData = sgForce.add(new BoolSetting.Builder()
        .name("force-data")
        .description("Try to make the server send the real thing rather than only listening for slips. It decides what to hide from two things it cannot verify: where you say you are, and where you say you are looking. Everything under this claims one of those is different from the truth, so all of it carries some risk — the options only appear once this is on.")
        .defaultValue(false).build());

    private final Setting<Boolean> lookDown = sgForce.add(new BoolSetting.Builder()
        .name("look-down (risky)")
        .description("Report your view as pointing straight down while your actual view stays put. If the rule is that you only get amethyst and dripstone you are looking at, then as far as the server is concerned you are always looking at the ground. Your aim on screen does not move, but rotation you never made is the classic thing anti-cheats watch for.")
        .defaultValue(false).visible(forceData::get).build());

    private final Setting<Boolean> lookSweep = sgForce.add(new BoolSetting.Builder()
        .name("look-sweep (risky)")
        .description("Turn the reported view right around between updates so every direction counts as looked at, not just downward. Covers far more ground than looking down alone, and looks correspondingly worse — a player does not spin like this.")
        .defaultValue(false).visible(forceData::get).build());

    private final Setting<Boolean> claimBelow = sgForce.add(new BoolSetting.Builder()
        .name("claim-below-y (risky)")
        .description("Report a height under the cutoff so the server stops swapping the ground for deepslate, then correct back the same tick. This is the one that gets you data from above ground, and it is also the most obvious — you are claiming to be somewhere you are not.")
        .defaultValue(false).visible(forceData::get).build());

    private final Setting<Integer> claimY = sgForce.add(new IntSetting.Builder()
        .name("claim-y")
        .description("The height to report. It needs to sit under the cutoff to be worth anything.")
        .defaultValue(-8).min(-64).max(320).sliderRange(-64, 32)
        .visible(() -> forceData.get() && claimBelow.get()).build());

    private final Setting<Integer> forceRate = sgForce.add(new IntSetting.Builder()
        .name("force-rate")
        .description("Ticks between attempts. Slower is quieter and less likely to be noticed.")
        .defaultValue(10).min(1).max(200).sliderRange(2, 40)
        .visible(forceData::get).build());

    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<SettingColor> blockColor = sgRender.add(new ColorSetting.Builder()
        .name("block-color").description("Colour for blocks recovered from change or block-entity packets.")
        .defaultValue(new SettingColor(0, 255, 140, 220)).build());
    private final Setting<SettingColor> hintColor = sgRender.add(new ColorSetting.Builder()
        .name("hint-color").description("Colour for positions recovered from particles or sounds, where the exact block is unknown.")
        .defaultValue(new SettingColor(255, 190, 0, 180)).build());
    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").description("Outline only, filled sides only, or both.")
        .defaultValue(ShapeMode.Both).build());
    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
        .name("tracers").description("Draw a line from you to each recovery.").defaultValue(false).build());

    /** position -> {when it was seen, 0 = a known block / 1 = a particle or sound hint} */
    private final Map<Long, long[]> found = new ConcurrentHashMap<>();
    private final java.util.Set<Long> announced = ConcurrentHashMap.newKeySet();
    /** How far the server says it sends real chunks; -1 until it tells us. */
    private int serverDistance = -1;

    public AntiAntiEsp() {
        super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "anti-anti-esp++",
            "Recovers blocks the server left out of your chunk data. It listens to the messages that carry a real position — block entities, particles, sounds, live block changes — and keeps only the ones landing where your client shows plain stone, which is the server contradicting itself.");
    }

    @Override
    public void onActivate() { found.clear(); announced.clear(); }

    @Override
    public void onDeactivate() { found.clear(); announced.clear(); }

    /** Amethyst always counts, matched with the supplied AmethystESP check. */
    private boolean isAmethyst(class_2338 pos) {
        if (mc.field_1687 == null) return false;
        try { return com.iekeiclient.addons.shama.util.AmethystScan.isAmethystLike(mc.field_1687.method_8320(pos)); }
        catch (Throwable t) { return false; }
    }

    private boolean wanted(class_2338 pos, class_2248 block) {
        if (mc.field_1724 == null) return false;
        // A block turning to air is somebody breaking it, which is activity, not a hidden find.
        // deep-activity++ is the module for that; recording it here just fills the list with holes.
        if (block == class_2246.field_10124 || block == class_2246.field_10543 || block == class_2246.field_10243) return false;
        if (belowYOnly.get() && pos.method_10264() > belowY.get()) return false;
        if (mc.field_1724.method_24515().method_10262(pos) > (double) range.get() * range.get()) return false;
        if (isAmethyst(pos)) return true;                     // amethyst is always worth keeping
        if (block == null) return true;                       // position-only channels
        var it = block.method_8389();
        return it != net.minecraft.class_1802.field_8162 && watch.get().contains(it);
    }

    /** True when this position is further out than the server admits to sending chunks. */
    private boolean pastSendRange(class_2338 pos) {
        if (!beyondSendRange.get() || serverDistance <= 0 || mc.field_1724 == null) return false;
        int dx = Math.abs((pos.method_10263() >> 4) - mc.field_1724.method_31476().field_9181);
        int dz = Math.abs((pos.method_10260() >> 4) - mc.field_1724.method_31476().field_9180);
        return Math.max(dx, dz) > serverDistance;
    }

    /** True when the client currently shows filler here — proof the chunk data was a lie. */
    private boolean looksHidden(class_2338 pos) {
        if (pastSendRange(pos)) return true;        // certain: chunk data never reached this far
        if (!onlyHidden.get()) return true;
        if (mc.field_1687 == null) return true;
        class_2248 b = mc.field_1687.method_8320(pos).method_26204();
        return b == class_2246.field_28888 || b == class_2246.field_10340 || b == class_2246.field_10124
            || b == class_2246.field_27165 || b == class_2246.field_10515 || b == class_2246.field_10471;
    }

    private void record(class_2338 pos, class_2248 block, boolean hint, String what) {
        if (!wanted(pos, block)) return;

        // A recovery only means something when the server described something real in a place your
        // client currently shows as filler. If your client already draws it, nothing was hidden and
        // there is nothing to recover.
        if (!looksHidden(pos)) return;
        long key = pos.method_10063();
        found.put(key, new long[]{System.currentTimeMillis(), hint ? 1 : 0});
        if (chat.get() && announced.add(key))
            com.iekeiclient.addons.shama.util.Chat.info("[AntiAntiEsp] %s at %d, %d, %d — the chunk data hid this",
                what, pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        if (fromBlockUpdates.get() && event.packet instanceof class_2626 p) {
            class_2338 bp = p.method_11309().method_10062();
            // The one thing that removes a find: the server telling us this block is now something
            // we do not care about. A rescan coming back empty never removes anything.
            if (forgetOnUpdate.get() && found.containsKey(bp.method_10063()) && !wanted(bp, p.method_11308().method_26204()))
                found.remove(bp.method_10063());
            record(bp, p.method_11308().method_26204(), false, "block change");
        }
        else if (fromBulkUpdates.get() && event.packet instanceof class_2637 bulk) {
            bulk.method_30621((bp, state) -> record(bp.method_10062(), state.method_26204(), false, "block change"));
        }
        else if (fromBlockEntities.get() && event.packet instanceof class_2622 be) {
            // the block itself is not named here, so accept it on position alone
            record(be.method_11293().method_10062(), null, false, "block entity");
        }
        else if (fromParticles.get() && event.packet instanceof class_2675 p) {
            class_2338 at = class_2338.method_49637(p.method_11544(), p.method_11547(), p.method_11546());
            record(at, null, true, "particles");
        }
        else if (fromSounds.get() && event.packet instanceof class_2767 p) {
            class_2338 at = class_2338.method_49637(p.method_11890(), p.method_11889(), p.method_11893());
            record(at, null, true, "sound");
        }
    }

    /**
     * The server announces how far it will send real chunks. Knowing it means anything reported
     * beyond that distance came from a channel the chunk data never covered, which is worth saying.
     */
    @EventHandler
    private void onServerDistance(PacketEvent.Receive event) {
        // matched by name, since this packet has been renamed between versions and naming the class
        // directly would stop the addon compiling if it moves again
        String n = event.packet.getClass().getSimpleName();
        if (!n.contains("ChunkLoadDistance") && !n.contains("SetChunkCacheRadius")) return;
        try {
            for (var m : event.packet.getClass().getMethods()) {
                if (m.getParameterCount() != 0 || m.getReturnType() != int.class) continue;
                int v = (int) m.invoke(event.packet);
                if (v > 1 && v <= 64) { serverDistance = v; break; }
            }
        } catch (Throwable ignored) {}
    }

    private int forceTick, sweepStep;

    /**
     * Claim a position or a view the server cannot check, then correct straight back inside the same
     * tick so nothing you see moves and the server never has cause to drag you back.
     */
    private void tryForce() {
        if (!forceData.get() || mc.field_1724 == null || mc.method_1562() == null) return;
        if (++forceTick < forceRate.get()) return;
        forceTick = 0;

        var net = mc.method_1562();
        double px = mc.field_1724.method_23317(), py = mc.field_1724.method_23318(), pz = mc.field_1724.method_23321();
        float realYaw = mc.field_1724.method_36454(), realPitch = mc.field_1724.method_36455();
        boolean ground = mc.field_1724.method_24828();

        float yaw = realYaw, pitch = realPitch;
        if (lookSweep.get()) {
            yaw = (360f / 8) * sweepStep - 180f;
            sweepStep = (sweepStep + 1) % 8;
            pitch = 60f;                                   // angled down as it sweeps
        } else if (lookDown.get()) {
            pitch = 90f;                                   // straight at the ground
        }

        double y = claimBelow.get() ? Math.min(py, claimY.get()) : py;

        if (lookDown.get() || lookSweep.get() || claimBelow.get()) {
            net.method_52787(new net.minecraft.class_2828.class_2830(
                px, y, pz, yaw, pitch, ground, false));
            // put the truth back immediately; without this the server corrects you and you rubber-band
            net.method_52787(new net.minecraft.class_2828.class_2830(
                px, py, pz, realYaw, realPitch, ground, false));
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        tryForce();
        if (found.isEmpty() || forgetOnUpdate.get()) return;      // updates handle removal instead
        long cutoff = System.currentTimeMillis() - keepSeconds.get() * 1000L;
        found.entrySet().removeIf(e -> e.getValue()[0] < cutoff);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (found.isEmpty() || mc.field_1724 == null) return;
        SettingColor bc = blockColor.get(), hc = hintColor.get();
        var cam = com.iekeiclient.engine.utils.render.RenderUtils.center;

        for (Map.Entry<Long, long[]> e : found.entrySet()) {
            class_2338 p = class_2338.method_10092(e.getKey());
            boolean hint = e.getValue()[1] == 1;
            SettingColor c = hint ? hc : bc;
            Color line = new Color(c.r, c.g, c.b, c.a);
            Color fill = new Color(c.r, c.g, c.b, Math.min(120, c.a / 3));
            event.renderer.box(p.method_10263(), p.method_10264(), p.method_10260(), p.method_10263() + 1, p.method_10264() + 1, p.method_10260() + 1,
                fill, line, shapeMode.get(), 0);
            if (tracers.get())
                event.renderer.line(cam.field_1352, cam.field_1351, cam.field_1350, p.method_10263() + 0.5, p.method_10264() + 0.5, p.method_10260() + 0.5, line);
        }
    }

    @Override
    public String getInfoString() {
        if (found.isEmpty()) return null;
        return serverDistance > 0 ? found.size() + " (server " + serverDistance + ")" : Integer.toString(found.size());
    }
}
