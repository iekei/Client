package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.RenderUtils;
import com.iekeiclient.engine.utils.render.WireframeEntityRenderer;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_238;
import net.minecraft.class_243;
import java.util.ArrayList;
import java.util.List;

public class HostileEsp extends Module {
    public enum HealthColor {
        Off,
        Outline,
        Fill,
        Both
    }

    public enum Mode {
        Box,
        Wireframe
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");
    private final SettingGroup sgTracer = settings.createGroup("Tracers");

    // General — keep the concrete type so add()'s generic inference resolves cleanly.
    private final EntityTypeListSetting entities = sgGeneral.add(new EntityTypeListSetting.Builder()
        .name("entities")
        .description("Which hostile mobs to show. Empty = all hostile mobs.")
        .build()
    );

    private final Setting<Boolean> infiniteRange = sgGeneral.add(new BoolSetting.Builder()
        .name("infinite-range")
        .description("Ignore the range limit and show every loaded hostile mob. Note: the client only knows about entities the server has sent, so this reaches as far as your entity render distance, not literally infinite.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range")
        .description("Only show mobs within this distance.")
        .defaultValue(128)
        .min(0)
        .sliderMax(256)
        .visible(() -> !infiniteRange.get())
        .build()
    );

    // Render
    private final Setting<Mode> mode = sgRender.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("How the mobs are rendered.")
        .defaultValue(Mode.Box)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How the shapes are rendered.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("fill-color")
        .description("The fill/side color.")
        .defaultValue(new SettingColor(255, 0, 0, 30))
        .visible(() -> mode.get() == Mode.Box)
        .build()
    );

    private final Setting<HealthColor> healthColor = sgRender.add(new EnumSetting.Builder<HealthColor>()
        .name("health-color")
        .description("Tint by health (green at full, fading to red). Choose whether it colors the Outline, the Fill, or Both. Off uses the fixed colors below.")
        .defaultValue(HealthColor.Off)
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("The outline color (when health-color isn't tinting the outline).")
        .defaultValue(new SettingColor(255, 0, 0, 255))
        .build()
    );

    // Tracers
    private final Setting<Boolean> tracers = sgTracer.add(new BoolSetting.Builder()
        .name("tracers")
        .description("Draw a line from your camera to each hostile mob.")
        .defaultValue(true)
        .build()
    );

    private final Setting<SettingColor> tracerColor = sgTracer.add(new ColorSetting.Builder()
        .name("tracer-color")
        .description("Color of the tracer lines.")
        .defaultValue(new SettingColor(255, 0, 0, 200))
        .visible(tracers::get)
        .build()
    );

    private final List<class_1297> targets = new ArrayList<>();

    public HostileEsp() {
        super(com.iekeiclient.addons.shama.ShamaAddon.MISC, "hostile-esp++", "ESP for hostile mobs with an optional tracer.");
    }

    @Override
    public String getInfoString() {
        return Integer.toString(targets.size());
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        targets.clear();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        boolean noLimit = infiniteRange.get();
        double rangeSq = range.get() * range.get();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1569)) continue;
            if (entity == mc.field_1724) continue;
            if (!entity.method_5805()) continue;

            if (!entities.get().isEmpty() && !entities.get().contains(entity.method_5864())) continue;

            if (!noLimit && mc.field_1724.method_5858(entity) > rangeSq) continue;

            targets.add(entity);
        }
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (targets.isEmpty()) return;

        for (class_1297 entity : targets) {
            SettingColor line = lineFor(entity);
            SettingColor side = sideFor(entity);

            // Boxes / wireframe
            if (mode.get() == Mode.Box) {
                class_238 box = entity.method_5829();
                event.renderer.box(box, side, line, shapeMode.get(), 0);
            } else {
                WireframeEntityRenderer.render(event, entity, 1, side, line, shapeMode.get());
            }

            // Tracers — use the health tint when it's applied to the outline.
            if (tracers.get()) {
                class_243 pos = entity.method_30950(event.tickDelta).method_1031(0, entity.method_17682() / 2, 0);
                boolean tintTracer = healthColor.get() == HealthColor.Outline || healthColor.get() == HealthColor.Both;
                event.renderer.line(
                    RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350,
                    pos.field_1352, pos.field_1351, pos.field_1350,
                    tintTracer ? line : tracerColor.get()
                );
            }
        }
    }

    // Outline color: health gradient if health-color tints the outline, else fixed.
    private SettingColor lineFor(class_1297 entity) {
        if ((healthColor.get() == HealthColor.Outline || healthColor.get() == HealthColor.Both)
            && entity instanceof class_1309 living) {
            return healthGradient(living, 255);
        }
        return lineColor.get();
    }

    // Fill color: health gradient if health-color tints the fill, else fixed.
    private SettingColor sideFor(class_1297 entity) {
        if ((healthColor.get() == HealthColor.Fill || healthColor.get() == HealthColor.Both)
            && entity instanceof class_1309 living) {
            return healthGradient(living, sideColor.get().a);
        }
        return sideColor.get();
    }

    // green (full) -> yellow -> red (empty), at the given alpha.
    private SettingColor healthGradient(class_1309 living, int alpha) {
        float max = living.method_6063();
        float frac = max <= 0 ? 1f : Math.max(0f, Math.min(1f, living.method_6032() / max));
        int r = (int) ((1f - frac) * 255);
        int g = (int) (frac * 255);
        return new SettingColor(r, g, 0, alpha);
    }
}
