package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import java.util.List;
import java.util.Random;

/**
 * RTP Finder — runs the server's random-teleport command over and over looking for rare loot.
 *
 * The loop: send /rtp, wait for the chunks around you to finish loading, then look for anything on
 * your rare list (dropped, in item frames, or in nearby storage). Nothing found means it waits a
 * random gap and rtps again. Something found means it marks the spot with a beacon, shouts at you,
 * optionally saves a home and/or logs you out, and switches itself off.
 *
 * It also switches itself off whenever you reconnect, so it can never quietly keep running after a
 * relog.
 */
public class RtpFinder extends Module {
    private final Random rng = new Random();

    // ---------------------------------------------------------------- commands
    private final SettingGroup sgCmd = settings.createGroup("Command");

    private final Setting<String> rtpCommand = sgCmd.add(new StringSetting.Builder()
        .name("rtp-command")
        .description("The command to send, without the slash. Usually just rtp.")
        .defaultValue("rtp").build());

    private final Setting<List<String>> extraVariants = sgCmd.add(new StringListSetting.Builder()
        .name("extra-variants")
        .description("Optional extra versions to mix in at random, e.g. \"rtp east\" and \"rtp west\". Leave empty to always send the plain command above.")
        .defaultValue(List.of()).build());

    private final Setting<Integer> minWait = sgCmd.add(new IntSetting.Builder()
        .name("min-wait-seconds")
        .description("Shortest gap between attempts. The real gap is picked at random between this and the maximum, so the timing never looks mechanical.")
        .defaultValue(20).min(1).max(600).sliderRange(5, 120).build());

    private final Setting<Integer> maxWait = sgCmd.add(new IntSetting.Builder()
        .name("max-wait-seconds")
        .description("Longest gap between attempts.")
        .defaultValue(45).min(1).max(1200).sliderRange(10, 300).build());

    private final Setting<Integer> loadTimeout = sgCmd.add(new IntSetting.Builder()
        .name("load-timeout-seconds")
        .description("Give up waiting for chunks to finish loading after this long and search anyway.")
        .defaultValue(20).min(3).max(120).sliderRange(5, 60).build());

    // ---------------------------------------------------------------- what counts as a find
    private final SettingGroup sgFind = settings.createGroup("What To Look For");

    private final Setting<List<class_1792>> rareItems = sgFind.add(new ItemListSetting.Builder()
        .name("rare-items")
        .description("The loot worth stopping for. Anything here counts as a find whether it's lying on the ground, hanging in an item frame, or sitting in a nearby container.")
        .defaultValue(List.of(
            class_1802.field_8833, class_1802.field_8398, class_1802.field_8470, class_1802.field_8681, class_1802.field_8575, class_1802.field_41304, class_1802.field_22020, class_1802.field_22018, class_1802.field_22021,
            class_1802.field_22027, class_1802.field_22028, class_1802.field_22029, class_1802.field_22030,
            class_1802.field_22022, class_1802.field_22024, class_1802.field_22025,
            class_1802.field_22023, class_1802.field_22026,
            class_1802.field_22019, class_1802.field_8840, class_1802.field_8712, class_1802.field_8668,
            class_1802.field_8137, class_1802.field_8367, class_1802.field_8547, class_1802.field_8207,
            class_1802.field_8791, class_1802.field_8545, class_1802.field_8288,
            class_1802.field_23984, class_1802.field_8535, class_1802.field_8554))
        .build());

    private final Setting<Boolean> checkDropped = sgFind.add(new BoolSetting.Builder()
        .name("check-dropped").description("Count rare items lying on the ground.").defaultValue(true).build());
    private final Setting<Boolean> checkPlaced = sgFind.add(new BoolSetting.Builder()
        .name("check-placed").description("Count rare blocks that have been placed in the world — a built beacon, a sponge wall, heads on display. These never drop as items, so without this a base full of them looks empty.")
        .defaultValue(true).build());
    private final Setting<Boolean> checkFrames = sgFind.add(new BoolSetting.Builder()
        .name("check-item-frames").description("Look inside item frames too — people display their best gear.").defaultValue(true).build());

    private final Setting<Boolean> storageCluster = sgFind.add(new BoolSetting.Builder()
        .name("storage-cluster")
        .description("Stop when a lot of containers sit close together. This counts containers rather than reading what's inside them, because a server won't tell you a chest's contents until you open it — a dense pile is a stash regardless.")
        .defaultValue(false).build());
    private final Setting<Integer> minStorage = sgFind.add(new IntSetting.Builder()
        .name("min-storage").description("How many containers must be nearby to count as a stash.")
        .defaultValue(12).min(2).max(200).sliderRange(4, 60).visible(storageCluster::get).build());

    private final Setting<Boolean> susCluster = sgFind.add(new BoolSetting.Builder()
        .name("frames-and-stands")
        .description("Also stop on clusters of the little things players leave behind — item frames, armour stands and similar.")
        .defaultValue(false).build());
    private final Setting<Integer> minSus = sgFind.add(new IntSetting.Builder()
        .name("min-frames-stands").description("How many of those must be nearby to count.")
        .defaultValue(6).min(2).max(100).sliderRange(3, 30).visible(susCluster::get).build());

    private final Setting<Integer> searchRadius = sgFind.add(new IntSetting.Builder()
        .name("search-radius").description("How far around you to search after each teleport, in blocks.")
        .defaultValue(96).min(16).max(256).sliderRange(32, 160).build());

    // ---------------------------------------------------------------- after a find
    private final SettingGroup sgAfter = settings.createGroup("After A Find");

    private final Setting<Boolean> doHome = sgAfter.add(new BoolSetting.Builder()
        .name("set-home")
        .description("Save a home at the spot so you can come back. Off by default because it overwrites whichever home slot you pick.")
        .defaultValue(false).build());
    private final Setting<Integer> homeNumber = sgAfter.add(new IntSetting.Builder()
        .name("home-number").description("Which home slot to overwrite. It runs delhome on this slot first, then sethome.")
        .defaultValue(1).min(1).max(50).sliderRange(1, 10).visible(doHome::get).build());
    private final Setting<Boolean> doLogout = sgAfter.add(new BoolSetting.Builder()
        .name("log-out")
        .description("Disconnect afterwards. With set-home on it waits out one more random gap after saving; with set-home off it just waits that gap and then leaves.")
        .defaultValue(false).build());

    // ---------------------------------------------------------------- pacing
    private final SettingGroup sgPace = settings.createGroup("Pacing");

    private final Setting<Boolean> tpsBackoff = sgPace.add(new BoolSetting.Builder()
        .name("wait-longer-on-lag")
        .description("When the region you land in is lagging, add extra time before the next teleport rather than hammering a struggling server.")
        .defaultValue(true).build());
    private final Setting<Integer> tpsExtraSeconds = sgPace.add(new IntSetting.Builder()
        .name("extra-wait-seconds").description("How much time to add when that happens.")
        .defaultValue(15).min(1).max(120).sliderRange(5, 60).visible(tpsBackoff::get).build());
    private final Setting<Double> tpsThreshold = sgPace.add(new DoubleSetting.Builder()
        .name("low-tps-below").description("What counts as lagging.")
        .defaultValue(15.0).min(1).max(20).sliderRange(5, 20).decimalPlaces(1).visible(tpsBackoff::get).build());

    // ---------------------------------------------------------------- alerts
    private final SettingGroup sgAlert = settings.createGroup("Alerts");

    private final Setting<Boolean> popup = sgAlert.add(new BoolSetting.Builder()
        .name("popup").description("Throw a title across the screen on a find.").defaultValue(true).build());
    private final Setting<Boolean> sound = sgAlert.add(new BoolSetting.Builder()
        .name("sound").description("Play a loud alert on a find, so you hear it from across the room.").defaultValue(true).build());
    private final Setting<Double> volume = sgAlert.add(new DoubleSetting.Builder()
        .name("volume").description("How loud that alert is.").defaultValue(5.0).min(0.1).max(10).sliderRange(1, 10).decimalPlaces(1).visible(sound::get).build());
    private final Setting<Boolean> chat = sgAlert.add(new BoolSetting.Builder()
        .name("chat").description("Log what happened in chat: each teleport, each wait, and the find itself.").defaultValue(true).build());

    private final Setting<Boolean> beacon = sgAlert.add(new BoolSetting.Builder()
        .name("beacon").description("Shoot a beam up from the find so you can walk back to it.").defaultValue(true).build());
    private final Setting<SettingColor> beaconColor = sgAlert.add(new ColorSetting.Builder()
        .name("beacon-color").description("Colour of that beam.").defaultValue(new SettingColor(255, 215, 0, 200)).visible(beacon::get).build());

    // ---------------------------------------------------------------- state
    private enum Phase { IDLE, WAITING, LOADING, SEARCHING, FOLLOW_UP, DONE }

    private Phase phase = Phase.IDLE;
    private long phaseUntil;              // wall-clock deadline for the current phase
    private long loadDeadline;
    private class_2338 foundAt;
    private String foundWhat = "";
    private int attempts;
    private int followStep;
    private boolean sawWorld;             // used to notice a relog

    public RtpFinder() {
        super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "rtp-finder++",
            "Teleports around with /rtp hunting for rare loot, marks anything it finds with a beacon, and stops itself once it does.");
    }

    @Override
    public void onActivate() {
        phase = Phase.WAITING;
        phaseUntil = System.currentTimeMillis();     // first attempt goes out immediately
        foundAt = null; foundWhat = ""; attempts = 0; followStep = 0;
        sawWorld = mc.field_1687 != null;
        if (chat.get()) com.iekeiclient.addons.shama.util.Chat.info("[RtpFinder] started — searching with /%s", rtpCommand.get());
    }

    @Override
    public void onDeactivate() {
        phase = Phase.IDLE;
        foundAt = null;
    }

    private long randomGap() {
        int lo = Math.min(minWait.get(), maxWait.get());
        int hi = Math.max(minWait.get(), maxWait.get());
        return (lo + (hi > lo ? rng.nextInt(hi - lo + 1) : 0)) * 1000L;
    }

    private void send(String command) {
        if (mc.method_1562() != null) mc.method_1562().method_45730(command);
    }

    private String pickCommand() {
        List<String> variants = extraVariants.get();
        if (variants.isEmpty() || rng.nextBoolean()) return rtpCommand.get();
        return variants.get(rng.nextInt(variants.size()));
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || mc.field_1687 == null) {
            // dropped out of the world: this is the relog case, so stop rather than resume blindly
            if (sawWorld && phase != Phase.IDLE) {
                phase = Phase.IDLE;
                toggle();
            }
            return;
        }
        sawWorld = true;
        long now = System.currentTimeMillis();

        switch (phase) {
            case WAITING -> {
                if (now < phaseUntil) return;
                attempts++;
                String cmd = pickCommand();
                if (chat.get()) com.iekeiclient.addons.shama.util.Chat.info("[RtpFinder] attempt %d — /%s", attempts, cmd);
                send(cmd);
                phase = Phase.LOADING;
                loadDeadline = now + loadTimeout.get() * 1000L;
            }
            case LOADING -> {
                if (chunksReady() || now >= loadDeadline) {
                    phase = Phase.SEARCHING;
                }
            }
            case SEARCHING -> {
                String hit = search();
                if (hit != null) {
                    foundWhat = hit;
                    foundAt = mc.field_1724.method_24515();
                    announce();
                    phase = Phase.FOLLOW_UP;
                    followStep = 0;
                    phaseUntil = now + randomGap();
                } else {
                    long gap = randomGap();
                    if (tpsBackoff.get() && regionLagging()) {
                        gap += tpsExtraSeconds.get() * 1000L;
                        if (chat.get()) com.iekeiclient.addons.shama.util.Chat.warning("[RtpFinder] region is lagging — waiting %ds longer.", tpsExtraSeconds.get());
                    }
                    if (chat.get()) com.iekeiclient.addons.shama.util.Chat.info("[RtpFinder] nothing here, next try in %ds", gap / 1000);
                    phase = Phase.WAITING;
                    phaseUntil = now + gap;
                }
            }
            case FOLLOW_UP -> {
                if (now < phaseUntil) return;
                if (followStep == 0 && doHome.get()) {
                    send("delhome " + homeNumber.get());
                    send("sethome " + homeNumber.get());
                    if (chat.get()) com.iekeiclient.addons.shama.util.Chat.info("[RtpFinder] saved home %d here.", homeNumber.get());
                    followStep = 1;
                    phaseUntil = now + randomGap();
                    return;
                }
                if (doLogout.get()) {
                    if (chat.get()) com.iekeiclient.addons.shama.util.Chat.info("[RtpFinder] logging out.");
                    if (mc.method_1562() != null)
                        mc.method_1562().method_48296().method_10747(class_2561.method_43470("[RtpFinder] found something"));
                }
                phase = Phase.DONE;
                toggle();     // job done — switch off so it can't wander away from the find
            }
            default -> { }
        }
    }

    /** True once the chunks in a small ring around you have arrived. */
    private boolean chunksReady() {
        if (mc.field_1687 == null || mc.field_1724 == null) return false;
        int cx = mc.field_1724.method_31477() >> 4, cz = mc.field_1724.method_31479() >> 4;
        for (int dx = -2; dx <= 2; dx++)
            for (int dz = -2; dz <= 2; dz++)
                if (!mc.field_1687.method_2935().method_12123(cx + dx, cz + dz)) return false;
        return true;
    }

    private boolean regionLagging() {
        LagDetector m = com.iekeiclient.engine.systems.modules.Modules.get().get(LagDetector.class);
        if (m == null || !m.isActive()) return false;
        double t = m.currentTps();
        return t > 0 && t < tpsThreshold.get();
    }

    /** Returns a short description of what was found, or null for nothing. */
    private String search() {
        if (mc.field_1687 == null || mc.field_1724 == null) return null;
        double r = searchRadius.get(), r2 = r * r;
        List<class_1792> wanted = rareItems.get();
        int storage = 0, sus = 0;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e.method_5858(mc.field_1724) > r2) continue;
            if (checkDropped.get() && e instanceof class_1542 ie && wanted.contains(ie.method_6983().method_7909()))
                return ie.method_6983().method_7964().getString() + " on the ground";
            if (e instanceof class_1533 fr) {
                class_1799 held = fr.method_6940();
                if (checkFrames.get() && !held.method_7960() && wanted.contains(held.method_7909()))
                    return held.method_7964().getString() + " in an item frame";
                sus++;
            } else if (e.method_5864() == net.minecraft.class_1299.field_6131) sus++;
        }

        // walk the loaded chunks around you using the same access pattern the other scanners use
        int pcx = mc.field_1724.method_31477() >> 4, pcz = mc.field_1724.method_31479() >> 4;
        int cr = Math.max(1, (int) Math.ceil(r / 16.0));
        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                net.minecraft.class_2791 ch = mc.field_1687.method_8402(pcx + dx, pcz + dz,
                    net.minecraft.class_2806.field_12803, false);
                if (!(ch instanceof class_2818 wc)) continue;
                for (java.util.Map.Entry<class_2338, class_2586> en : wc.method_12214().entrySet()) {
                    if (en.getKey().method_10262(mc.field_1724.method_24515()) > r2) continue;
                    // Count only. A server almost never sends you what's inside a chest until you
                    // open it, so counting the containers is the honest signal — a pile of them is
                    // a stash whether or not we can see the contents.
                    if (en.getValue() instanceof class_1263) storage++;
                }
                // placed rare blocks in this chunk
                if (checkPlaced.get()) {
                    int bx2 = wc.method_12004().method_8326(), bz2 = wc.method_12004().method_8328();
                    class_2338 me = mc.field_1724.method_24515();
                    int bot = Math.max(wc.method_31607(), me.method_10264() - (int) r), top2 = Math.min(wc.method_31600(), me.method_10264() + (int) r);
                    class_2338.class_2339 m2 = new class_2338.class_2339();
                    for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) for (int y = bot; y <= top2; y++) {
                        var st = wc.method_8320(m2.method_10103(bx2 + x, y, bz2 + z));
                        if (st.method_26215()) continue;
                        var it = st.method_26204().method_8389();
                        if (it != class_1802.field_8162 && wanted.contains(it)) return it.method_63680().getString() + " placed";
                    }
                }
            }
        }

        if (storageCluster.get() && storage >= minStorage.get()) return storage + " containers together";
        if (susCluster.get() && sus >= minSus.get()) return sus + " frames/stands together";
        return null;
    }

    private void announce() {
        if (chat.get())
            com.iekeiclient.addons.shama.util.Chat.info("[RtpFinder] FOUND %s at %d, %d, %d (after %d tries)",
                foundWhat, foundAt.method_10263(), foundAt.method_10264(), foundAt.method_10260(), attempts);
        if (popup.get() && mc.field_1705 != null) {
            mc.field_1705.method_34001(2, 60, 10);
            mc.field_1705.method_34004(class_2561.method_43470("RTP FIND").method_27692(class_124.field_1065));
            mc.field_1705.method_34002(class_2561.method_43470(foundWhat).method_27692(class_124.field_1054));
        }
        if (sound.get() && mc.field_1687 != null && mc.field_1724 != null) {
            float v = volume.get().floatValue();
            // played a few times so it carries even if you're away from the keyboard
            for (int i = 0; i < 3; i++)
                mc.field_1687.method_60511(mc.field_1724, mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(),
                    net.minecraft.class_3417.field_14622,
                    net.minecraft.class_3419.field_15248, v, 1.6f);
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!beacon.get() || foundAt == null) return;
        SettingColor c = beaconColor.get();
        Color line = new Color(c.r, c.g, c.b, 255);
        Color fill = new Color(c.r, c.g, c.b, 60);
        event.renderer.box(foundAt.method_10263(), foundAt.method_10264(), foundAt.method_10260(),
            foundAt.method_10263() + 1, foundAt.method_10264() + 320, foundAt.method_10260() + 1, fill, line, ShapeMode.Both, 0);
    }

    @Override
    public String getInfoString() {
        return switch (phase) {
            case WAITING -> "waiting";
            case LOADING -> "loading";
            case SEARCHING -> "searching";
            case FOLLOW_UP -> "wrapping up";
            case DONE -> "found";
            default -> null;
        };
    }
}
