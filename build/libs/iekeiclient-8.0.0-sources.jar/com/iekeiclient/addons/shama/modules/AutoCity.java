package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import com.iekeiclient.addons.shama.util.Humanize;

/**
 * AutoCity++ — "cities" a target: finds the nearest player sitting in a hole and breaks
 * the block on the side of their feet facing you, opening them up for a crystal/attack.
 * Ported from their AutoCity (target-range + break-range, packet break).
 */
public class AutoCity extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Double> targetRange = sg.add(new DoubleSetting.Builder().name("target-range").description("How far away a target can be (blocks).").defaultValue(5).min(1).sliderRange(2, 8).build());
    private final Setting<Integer> timingJitter = sg.add(new IntSetting.Builder().name("timing-jitter").description("Randomly space out the block-break so it isn't a perfect fixed rhythm (%).").defaultValue(0).min(0).max(100).sliderRange(0,60).build());
    private final Setting<Double> breakRange = sg.add(new DoubleSetting.Builder().name("break-range").description("How far away you can break (blocks).").defaultValue(5).min(1).sliderRange(2, 8).build());

    private int cityCooldown;

    public AutoCity() {
        super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "auto-city++", "Breaks the block beside a target in a hole to expose them.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null || mc.method_1562() == null) return;
        if (cityCooldown > 0) { cityCooldown--; return; }
        class_1657 target = null; double best = targetRange.get();
        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724 || !p.method_5805()) continue;
            double d = mc.field_1724.method_5739(p);
            if (d < best) { best = d; target = p; }
        }
        if (target == null) return;

        class_2338 feet = target.method_24515();
        // pick the surrounding foot-block closest to us that's breakable
        class_2338 bestPos = null; double bd = breakRange.get();
        for (class_2350 dir : class_2350.class_2353.field_11062) {
            class_2338 p = feet.method_10093(dir);
            if (mc.field_1687.method_8320(p).method_26215()) continue;
            double d = mc.field_1724.method_33571().method_1022(p.method_46558());
            if (d < bd) { bd = d; bestPos = p; }
        }
        if (bestPos == null) return;

        class_2350 side = class_2350.field_11036;
        mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12968, bestPos, side, 0));
        mc.method_1562().method_52787(new class_2846(class_2846.class_2847.field_12973, bestPos, side, 0));
        mc.field_1724.method_6104(class_1268.field_5808);
        cityCooldown = Humanize.jitter(1, timingJitter.get());
    }
}
