package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import com.iekeiclient.addons.shama.util.Humanize;

/**
 * Anchor Aura++ — auto respawn-anchor combat, ported from their AnchorAura/DoubleAnchor/
 * BedAura flow (merged): pick the best nearby player target, find a placement next to
 * them, then run the place -> charge -> detonate cycle with a per-step delay. Includes
 * the bed variant as a tickbox (place+break beds in Nether/End for the same effect).
 *
 * Their exact step order is preserved: swap+place anchor, swap+charge with glowstone,
 * then break to explode; a delay counter gates each action. Server-validated, so it
 * lands on lenient servers / where anchors are allowed.
 */
public class AnchorAura extends Module {
    public enum Mode { Anchor, Bed }

    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Mode> mode = sg.add(new EnumSetting.Builder<Mode>().name("mode").description("Anchor (any dim) or Bed (Nether/End).").defaultValue(Mode.Anchor).build());
    private final Setting<Double> targetRange = sg.add(new DoubleSetting.Builder().name("target-range").description("How far away a target can be (blocks).").defaultValue(5).min(1).sliderRange(2, 8).build());
    private final Setting<Double> placeRange = sg.add(new DoubleSetting.Builder().name("place-range").description("How far away you can place (blocks).").defaultValue(5).min(1).sliderRange(2, 8).build());
    private final Setting<Integer> stepDelay = sg.add(new IntSetting.Builder().name("step-delay").description("Ticks between place/charge/detonate.").defaultValue(2).range(0, 20).sliderRange(0, 10).build());
    private final Setting<Double> minDamage = sg.add(new DoubleSetting.Builder().name("min-damage").description("Only detonate if it would deal at least this to the target.").defaultValue(6).min(0).sliderRange(0, 20).build());
    private final Setting<Double> maxSelfDamage = sg.add(new DoubleSetting.Builder().name("max-self-damage").description("Never detonate if it would deal more than this to you.").defaultValue(8).min(0).sliderRange(0, 20).build());
    private final SettingGroup sgBypass = settings.createGroup("Bypass");
    private final Setting<Integer> missChance = sgBypass.add(new IntSetting.Builder().name("miss-chance").description("Chance (%) to skip a step this cycle, like a human hesitating. 0 = never (fastest but most robotic).").defaultValue(0).min(0).max(100).sliderRange(0, 40).build());
    private final Setting<Integer> timingJitter = sgBypass.add(new IntSetting.Builder().name("timing-jitter").description("Randomly vary the step delay by +/- this % so it isn't a perfect fixed rhythm.").defaultValue(0).min(0).max(100).sliderRange(0, 60).build());

    private int delayCounter;
    private int phase; // 0 place, 1 charge, 2 detonate
    private class_2338 placePos;
    private class_1657 target;

    public AnchorAura() {
        super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "bombaura++", "Auto anchor/bed aura (place, charge, detonate on nearby enemies).");
    }

    @Override public void onActivate() { delayCounter = 0; phase = 0; placePos = null; target = null; }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;

        // pick / validate target (their TargetUtils.getPlayerTarget)
        if (target == null || !target.method_5805() || mc.field_1724.method_5739(target) > targetRange.get()) {
            target = null;
            double best = targetRange.get();
            for (class_1657 p : mc.field_1687.method_18456()) {
                if (p == mc.field_1724 || !p.method_5805()) continue;
                double d = mc.field_1724.method_5739(p);
                if (d < best) { best = d; target = p; }
            }
            if (target == null) return;
        }

        if (delayCounter < Humanize.jitter(stepDelay.get(), timingJitter.get())) { delayCounter++; return; }
        delayCounter = 0;
        if (Humanize.shouldMiss(missChance.get())) return;   // human hesitation: skip this step, try next tick

        if (placePos == null) placePos = findPlace(target);
        if (placePos == null) return;

        boolean bed = mode.get() == Mode.Bed;
        // self/target damage gate (their DamageUtils.anchorDamage / bedDamage)
        double dmgTarget = explosionDamage(target, class_243.method_24953(placePos));
        double dmgSelf = explosionDamage(mc.field_1724, class_243.method_24953(placePos));
        if (dmgTarget < minDamage.get() || dmgSelf > maxSelfDamage.get()) { placePos = null; phase = 0; return; }

        switch (phase) {
            case 0 -> { // place anchor/bed
                if (swapTo(bed ? class_1802.field_8789 : class_1802.field_23141)) {
                    place(placePos);
                    phase = bed ? 2 : 1; // beds explode on the follow-up interact; anchors need charge
                }
            }
            case 1 -> { // charge anchor with glowstone
                if (swapTo(class_1802.field_8801)) { interact(placePos); phase = 2; }
            }
            case 2 -> { // detonate: interact anchor (empty hand) / interact bed
                interact(placePos);
                placePos = null; phase = 0;
            }
        }
    }

    private class_2338 findPlace(class_1657 t) {
        // scan around the target for an air spot within place-range (their findPlace)
        class_2338 base = t.method_24515();
        for (int dy = 0; dy <= 2; dy++) {
            for (class_2350 d : class_2350.class_2353.field_11062) {
                class_2338 p = base.method_10086(dy).method_10093(d);
                if (mc.field_1687.method_8320(p).method_26215() && mc.field_1724.method_33571().method_1022(class_243.method_24953(p)) <= placeRange.get())
                    return p;
            }
        }
        return null;
    }

    private boolean swapTo(net.minecraft.class_1792 item) {
        int slot = InvUtils.findInHotbar(item).slot();
        if (slot < 0) return false;
        InvUtils.swap(slot, false);
        return true;
    }

    private void place(class_2338 pos) {
        class_2350 side = class_2350.field_11036;
        class_3965 hit = new class_3965(class_243.method_24953(pos), side, pos, false);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void interact(class_2338 pos) {
        class_3965 hit = new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    /** Rough explosion damage falloff by distance (stand-in for their DamageUtils). */
    private double explosionDamage(class_1657 e, class_243 center) {
        double dist = e.method_33571().method_1022(center);
        double power = mode.get() == Mode.Bed ? 5.0 : 5.0; // both ~5 power
        double raw = Math.max(0, (1.0 - dist / (power * 2)) * (power * 7));
        return raw;
    }

    @Override public String getInfoString() { return target != null ? "target" : "idle"; }
}
