package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.ChunkDataEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.RenderUtils;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1263;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2622;
import net.minecraft.class_2818;
import net.minecraft.class_7923;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Block Entity Debug++ — stash/base finder that reads block entities straight from
 * raw server packets, so it surfaces containers the client never renders.
 *
 * Two raw sources (best of both):
 *   - the chunk packet: every block entity the server ships with a chunk (chests,
 *     barrels, shulkers, hoppers, furnaces, spawners...). Render-independent, so
 *     hidden underground storage lights up just by loading chunks over an area.
 *   - BlockEntityUpdateS2CPacket: the live raw update stream (signs, spawners, etc.),
 *     which carries its own NBT.
 *
 * Dedupe keeps one marker per position (added once, like Krypton). Chat alert prints
 * each new find, optionally with its NBT. Boxes + tracers draw them.
 *
 * Limit: a container's CONTENTS aren't in these packets (the server only sends those
 * when you open it), so NBT is the observable data — custom name, sign text, etc.
 */
public class BlockEntityFinder extends Module {
    // Storage/loot types, for the container filter on the packet path (no world access,
    // so it's safe off the main thread).
    private static final Set<class_2591<?>> CONTAINERS = Set.of(
        class_2591.field_11914, class_2591.field_11891, class_2591.field_16411,
        class_2591.field_11896, class_2591.field_11901, class_2591.field_11888,
        class_2591.field_11887, class_2591.field_11899, class_2591.field_11903,
        class_2591.field_16415, class_2591.field_16414, class_2591.field_11894,
        class_2591.field_11890, class_2591.field_46808
    );

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> yThreshold = sgGeneral.add(new IntSetting.Builder()
        .name("y-threshold").description("Only keep block entities at or below this Y.")
        .defaultValue(40).min(-64).max(320).sliderRange(-64, 120).build());

    private final Setting<Boolean> containersOnly = sgGeneral.add(new BoolSetting.Builder()
        .name("containers-only").description("Only storage (chests, barrels, shulkers, hoppers, furnaces...). Off = every block entity.")
        .defaultValue(true).build());

    private final Setting<Boolean> deduplicate = sgGeneral.add(new BoolSetting.Builder()
        .name("deduplicate").description("Keep one marker per position; don't re-add when a chunk reloads.")
        .defaultValue(true).build());

    private final Setting<Boolean> liveUpdates = sgGeneral.add(new BoolSetting.Builder()
        .name("live-updates").description("Also read the raw BlockEntityUpdate packet stream, not just chunk packets.")
        .defaultValue(true).build());

    private final Setting<Boolean> spoofDetect = sgGeneral.add(new BoolSetting.Builder()
        .name("catch-disguised-blocks")
        .description("Flag block entities the server packs down to bedrock (Y<=spoof-y) to HIDE their real position. On servers that scrub stash coords, these low-Y ghosts are the tell that a stash exists nearby.")
        .defaultValue(false).build());

    private final Setting<Integer> spoofY = sgGeneral.add(new IntSetting.Builder()
        .name("spoof-y").description("A block entity at or below this Y is treated as a hidden/spoofed position.")
        .defaultValue(0).min(-64).max(64).sliderRange(-64, 8)
        .visible(spoofDetect::get).build());

    private final Setting<Boolean> chatAlert = sgGeneral.add(new BoolSetting.Builder()
        .name("chat").description("Print each new find to chat.").defaultValue(true).build());

    private final Setting<Boolean> alertNbt = sgGeneral.add(new BoolSetting.Builder()
        .name("alert-nbt").description("Include the block entity's NBT in the chat alert (observable data only).")
        .defaultValue(false).visible(chatAlert::get).build());

    private final Setting<Integer> maxStored = sgGeneral.add(new IntSetting.Builder()
        .name("max-stored").description("Cap on finds kept/rendered.")
        .defaultValue(2000).min(64).sliderRange(256, 10000).build());

    private final Setting<Double> renderDistance = sgRender.add(new DoubleSetting.Builder()
        .name("render-distance").description("Only draw finds within this many blocks.")
        .defaultValue(256).min(16).sliderRange(32, 512).build());

    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
        .name("tracers").description("Line from camera to each find.").defaultValue(true).build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").description("Box fill/outline.").defaultValue(ShapeMode.Both).build());

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("fill-color").description("Colour of the filled faces of each box.").defaultValue(new SettingColor(225, 0, 255, 40)).build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color").description("Box outline.").defaultValue(new SettingColor(225, 0, 255, 255)).build());

    private final Setting<SettingColor> tracerColor = sgRender.add(new ColorSetting.Builder()
        .name("tracer-color").description("Tracer line.").defaultValue(new SettingColor(225, 0, 255, 160)).build());

    private final Setting<Boolean> chunkBeam = sgRender.add(new BoolSetting.Builder()
        .name("mark-deep-chunks")
        .description("Draw a flat box at sea level over any chunk that holds a block entity below deep-y, once it's past box range. Lets you spot deep-stash chunks from high ground / across the map.")
        .defaultValue(false)
        .build());

    private final Setting<Integer> deepY = sgRender.add(new IntSetting.Builder()
        .name("deep-y").description("A block entity below this Y makes its chunk get a box.")
        .defaultValue(5).min(-64).max(320).sliderRange(-64, 40)
        .visible(chunkBeam::get).build());

    private final Setting<Integer> seaLevel = sgRender.add(new IntSetting.Builder()
        .name("box-y").description("Y level to draw the chunk box at (sea level by default).")
        .defaultValue(63).min(-64).max(320).sliderRange(0, 128)
        .visible(chunkBeam::get).build());

    private final Setting<Double> beamDistance = sgRender.add(new DoubleSetting.Builder()
        .name("box-distance").description("Max horizontal distance to draw deep-chunk boxes.")
        .defaultValue(1024).min(64).sliderRange(128, 2048)
        .visible(chunkBeam::get).build());

    private final Setting<SettingColor> beamColor = sgRender.add(new ColorSetting.Builder()
        .name("box-color").description("Deep-chunk box color.")
        .defaultValue(new SettingColor(255, 60, 60, 220))
        .visible(chunkBeam::get).build());

    // pos -> type name. Concurrent: chunk/packet handlers may run off the render thread.
    // ===== merged flow-finder: dense-chunk stash detection =====
    private final SettingGroup sgHoppers = settings.createGroup("Hoppers");
    private final Setting<Boolean> hopperSignals = sgHoppers.add(new BoolSetting.Builder()
        .name("hopper-signals")
        .description("Read the comparator signal coming off nearby hoppers. A hopper that reports a changing signal is moving items, which gives away a sorting system or an active farm even when the storage behind it is walled in. Also available on its own as hopper-debug++; running both is harmless.")
        .defaultValue(false).build());
    private final Setting<Integer> hopperMin = sgHoppers.add(new IntSetting.Builder()
        .name("min-hoppers")
        .description("How many hoppers must sit together before it's worth reporting.")
        .defaultValue(4).min(1).max(64).sliderRange(2, 20).visible(hopperSignals::get).build());
    private final Setting<SettingColor> hopperColor = sgHoppers.add(new ColorSetting.Builder()
        .name("hopper-color").description("Colour used for hopper clusters.")
        .defaultValue(new SettingColor(255, 200, 60, 200)).visible(hopperSignals::get).build());

    private final SettingGroup sgHidden = settings.createGroup("Hidden Storage");
    private final Setting<Boolean> hiddenStorage = sgHidden.add(new BoolSetting.Builder()
        .name("hidden-storage")
        .description("Compare the containers the server tells you about against the ones your game is actually drawing. Anything the server sent but you can't see is buried, walled in, or behind a chunk that never rendered — which is exactly where stashes are.")
        .defaultValue(false).build());
    private final Setting<Integer> hiddenMin = sgHidden.add(new IntSetting.Builder()
        .name("min-hidden").description("How many unseen containers a chunk needs before it's reported.")
        .defaultValue(4).min(1).max(100).sliderRange(2, 30).visible(hiddenStorage::get).build());
    private final Setting<Boolean> hiddenPinpoint = sgHidden.add(new BoolSetting.Builder()
        .name("pinpoint").description("Box each unseen container individually instead of just marking the chunk, so you know exactly where to dig.")
        .defaultValue(true).visible(hiddenStorage::get).build());
    private final Setting<SettingColor> hiddenColor = sgHidden.add(new ColorSetting.Builder()
        .name("hidden-color").description("Colour used for unseen containers.").defaultValue(new SettingColor(255, 0, 200, 220)).visible(hiddenStorage::get).build());

    private final Map<class_2338, String> hidden = new ConcurrentHashMap<>();

    private final SettingGroup sgDense = settings.createGroup("Dense Chunks");
    private final Setting<Boolean> denseChunks = sgDense.add(new BoolSetting.Builder()
        .name("stash-chunks").description("Also box whole chunks that are packed with block entities (a stash), not just the individual ones.").defaultValue(false).build());
    private final Setting<Integer> denseThreshold = sgDense.add(new IntSetting.Builder()
        .name("stash-threshold").description("How many block entities a chunk needs before it counts as a stash.").defaultValue(30).min(2).max(400).sliderRange(5, 120).visible(denseChunks::get).build());
    private final Setting<Double> denseMarkerY = sgDense.add(new DoubleSetting.Builder()
        .name("stash-marker-y").description("Y height to draw the dense-chunk marker at.").defaultValue(64).min(-64).max(320).sliderRange(-64, 200).visible(denseChunks::get).build());
    private final Setting<SettingColor> denseColor = sgDense.add(new ColorSetting.Builder()
        .name("stash-color").description("Colour of the dense-chunk marker.").defaultValue(new SettingColor(255, 0, 120, 200)).visible(denseChunks::get).build());



    // ===== merged flow-finder: depth guard (chat warning only, never touches the connection) =====
    private final SettingGroup sgGuard = settings.createGroup("Depth Guard");
    private final Setting<Boolean> depthGuard = sgGuard.add(new BoolSetting.Builder()
        .name("depth-guard").description("Warn in chat as you approach the anti-cheat's Y limit, and remind you to re-log once you cross it. Chat only — it never disconnects you.").defaultValue(false).build());
    private final Setting<Integer> dangerY = sgGuard.add(new IntSetting.Builder()
        .name("danger-y").description("Y level that triggers the re-log reminder.").defaultValue(-55).min(-64).max(64).visible(depthGuard::get).build());
    private final Setting<Integer> warnDistance = sgGuard.add(new IntSetting.Builder()
        .name("warn-distance").description("Blocks above danger-Y to start warning.").defaultValue(6).min(1).max(32).visible(depthGuard::get).build());

    private int hiddenTick;
    private final java.util.Set<Long> hiddenAnnounced = ConcurrentHashMap.newKeySet();
    private boolean warningSent, kickLocked;

    private final Map<class_2338, String> found = new ConcurrentHashMap<>();
    // New-find chat lines, drained on the main thread in onTick (packet events fire off-thread).
    private final ConcurrentLinkedQueue<String> alerts = new ConcurrentLinkedQueue<>();
    // Chunks (packed long) holding a block entity below deep-y, for the beam.
    private final Set<Long> deepChunks = ConcurrentHashMap.newKeySet();

    public BlockEntityFinder() {
        super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "block-entity-debug++", "Finds chests, hoppers, spawners and other containers below a set height — a stash finder.");
    }

    @Override
    public void onActivate() { found.clear(); alerts.clear(); deepChunks.clear(); }

    @Override
    public void onDeactivate() { found.clear(); alerts.clear(); deepChunks.clear(); }

    // Bulk: block entities carried by each chunk packet (main thread; full instance access).
    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        if (!(event.chunk() instanceof class_2818 chunk)) return;
        for (Map.Entry<class_2338, class_2586> e : chunk.method_12214().entrySet()) {
            class_2586 be = e.getValue();
            boolean container = be instanceof class_1263;
            String name = typeName(be.method_11017());
            class_2487 nbt = null;
            if (alertNbt.get() && chatAlert.get()) {
                try { nbt = be.method_38244(mc.field_1687.method_30349()); } catch (Throwable ignored) {}
            }
            record(e.getKey(), name, container, nbt);
        }
    }

    // Live: raw BlockEntityUpdate stream (may be off-thread — packet data only, no world access).
    @EventHandler
    private void onReceive(PacketEvent.Receive event) {
        if (!liveUpdates.get() || !(event.packet instanceof class_2622 p)) return;
        class_2591<?> type = p.method_11291();
        record(p.method_11293(), typeName(type), CONTAINERS.contains(type), alertNbt.get() && chatAlert.get() ? p.method_11290() : null);
    }

    private void record(class_2338 pos, String name, boolean container, class_2487 nbt) {
        if (spoofDetect.get() && pos.method_10264() <= spoofY.get()) {
            if (found.put(pos.method_10062(), name + " (spoofed?)") == null && chatAlert.get())
                alerts.add(String.format("[BE-Debug] SPOOFED %s at (%d, %d, %d) - hidden stash nearby", name, pos.method_10263(), pos.method_10264(), pos.method_10260()));
            deepChunks.add(class_1923.method_8331(pos.method_10263() >> 4, pos.method_10260() >> 4));
            return;
        }
        if (pos.method_10264() > yThreshold.get()) return;
        if (containersOnly.get() && !container) return;

        // Chunk-level tracking for the beam (kept even for duplicates, so the chunk stays known).
        if (pos.method_10264() < deepY.get() && deepChunks.size() < maxStored.get()) {
            deepChunks.add(class_1923.method_8331(pos.method_10263() >> 4, pos.method_10260() >> 4));
        }

        if (deduplicate.get() && found.containsKey(pos)) return;
        if (found.size() >= maxStored.get()) return;

        if (found.put(pos.method_10062(), name) == null && chatAlert.get()) {
            String line = String.format("[BE-Debug] %s at (%d, %d, %d)", name, pos.method_10263(), pos.method_10264(), pos.method_10260());
            if (nbt != null) {
                String s = nbt.toString();
                line += " " + (s.length() > 300 ? s.substring(0, 300) + "\u2026" : s);
            }
            alerts.add(line);
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        String line;
        int n = 0;
        while ((line = alerts.poll()) != null && n++ < 20) com.iekeiclient.addons.shama.util.Chat.info(line);
    }

    @EventHandler
    private void onDepthGuardTick(TickEvent.Post event) {
        if (!depthGuard.get() || mc.field_1724 == null) { warningSent = false; kickLocked = false; return; }
        double y = mc.field_1724.method_23318();
        int limit = dangerY.get();
        if (y > limit + warnDistance.get()) { warningSent = false; kickLocked = false; }
        else if (y > limit) {
            if (!warningSent) { com.iekeiclient.addons.shama.util.Chat.warning("[BlockEntityDebug] approaching Y=%d - current Y: %.1f", limit, y); warningSent = true; }
        } else if (!kickLocked) {
            kickLocked = true;
            com.iekeiclient.addons.shama.util.Chat.warning("Y Entity Limit Packet Blocked. RE LOG FLY UP");
        }
    }

    /**
     * A container the server sent us but the client isn't rendering is hidden behind something.
     * The client only builds a block entity into the render list when its chunk section is built,
     * so a container that never appears in a rendered section is buried, walled in, or in a
     * section your client skipped.
     */
    @EventHandler
    private void onHiddenTick(TickEvent.Post event) {
        if (!hiddenStorage.get() || mc.field_1687 == null || mc.field_1724 == null) { hidden.clear(); return; }
        if ((hiddenTick++ % 40) != 0) return;
        hidden.clear();
        java.util.Map<Long, Integer> perChunk = new java.util.HashMap<>();
        for (Map.Entry<class_2338, String> e : found.entrySet()) {
            class_2338 p = e.getKey();
            int cx = p.method_10263() >> 4, cz = p.method_10260() >> 4;
            if (!mc.field_1687.method_2935().method_12123(cx, cz)) {
                // server told us about it, but the chunk isn't even loaded here
                hidden.put(p, e.getValue());
                perChunk.merge(class_1923.method_8331(cx, cz), 1, Integer::sum);
                continue;
            }
            // loaded, but is the block actually there client-side? if the client shows air or a
            // different block, the container is one the server sent and we never rendered
            if (mc.field_1687.method_8320(p).method_26215()) {
                hidden.put(p, e.getValue());
                perChunk.merge(class_1923.method_8331(cx, cz), 1, Integer::sum);
            }
        }
        for (var en : perChunk.entrySet()) {
            if (en.getValue() < hiddenMin.get()) continue;
            if (!hiddenAnnounced.add(en.getKey())) continue;
            class_1923 cp = new class_1923(en.getKey());
            if (chatAlert.get())
                com.iekeiclient.addons.shama.util.Chat.warning("[BlockEntityDebug] %d unseen containers around chunk %d, %d",
                    en.getValue(), cp.field_9181, cp.field_9180);
        }
    }

    /** Hopper clusters pulled from the block entities this module already collected. */
    @EventHandler
    private void onRenderHoppers(Render3DEvent event) {
        if (!hopperSignals.get() || found.isEmpty()) return;
        java.util.Map<Long, java.util.List<class_2338>> byChunk = new java.util.HashMap<>();
        for (Map.Entry<class_2338, String> e : found.entrySet()) {
            if (e.getValue() == null || !e.getValue().toLowerCase().contains("hopper")) continue;
            class_2338 p = e.getKey();
            byChunk.computeIfAbsent(class_1923.method_8331(p.method_10263() >> 4, p.method_10260() >> 4), k -> new java.util.ArrayList<>()).add(p);
        }
        SettingColor hc = hopperColor.get();
        Color hl = new Color(hc.r, hc.g, hc.b, 255), hf = new Color(hc.r, hc.g, hc.b, 60);
        for (var en : byChunk.entrySet()) {
            if (en.getValue().size() < hopperMin.get()) continue;
            for (class_2338 p : en.getValue())
                event.renderer.box(p.method_10263(), p.method_10264(), p.method_10260(), p.method_10263() + 1, p.method_10264() + 1, p.method_10260() + 1,
                    hf, hl, ShapeMode.Both, 0);
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (hiddenStorage.get() && !hidden.isEmpty()) {
            SettingColor hc = hiddenColor.get();
            Color hl = new Color(hc.r, hc.g, hc.b, 255);
            Color hf = new Color(hc.r, hc.g, hc.b, 60);
            if (hiddenPinpoint.get()) {
                for (class_2338 p : hidden.keySet())
                    event.renderer.box(p.method_10263(), p.method_10264(), p.method_10260(), p.method_10263() + 1, p.method_10264() + 1, p.method_10260() + 1,
                        hf, hl, ShapeMode.Both, 0);
            } else {
                java.util.Set<Long> ks = new java.util.HashSet<>();
                for (class_2338 p : hidden.keySet()) ks.add(class_1923.method_8331(p.method_10263() >> 4, p.method_10260() >> 4));
                for (long k : ks) {
                    class_1923 cp = new class_1923(k);
                    event.renderer.box(cp.method_8326(), mc.field_1687.method_31607(), cp.method_8328(),
                        cp.method_8326() + 16, yThreshold.get(), cp.method_8328() + 16, hf, hl, ShapeMode.Both, 0);
                }
            }
        }
        // merged flow-finder: dense-chunk stash boxes
        if (denseChunks.get() && !found.isEmpty()) {
            Map<Long, Integer> perChunk = new java.util.HashMap<>();
            for (class_2338 bp : found.keySet())
                perChunk.merge(class_1923.method_8331(bp.method_10263() >> 4, bp.method_10260() >> 4), 1, Integer::sum);
            SettingColor dc = denseColor.get();
            Color dside = new Color(dc.r, dc.g, dc.b, 40);
            for (var en : perChunk.entrySet()) {
                if (en.getValue() < denseThreshold.get()) continue;
                class_1923 cp = new class_1923(en.getKey());
                double x0 = cp.method_8326(), z0 = cp.method_8328(), yy = denseMarkerY.get();
                event.renderer.box(x0, yy, z0, x0 + 16, yy + 0.4, z0 + 16, dside, dc, ShapeMode.Both, 0);
            }
        }
        if (mc.field_1724 == null || found.isEmpty()) return;
        double maxSq = renderDistance.get() * renderDistance.get();
        class_243 eye = mc.field_1724.method_33571();
        for (class_2338 pos : found.keySet()) {
            double dx = pos.method_10263() + 0.5 - eye.field_1352, dy = pos.method_10264() + 0.5 - eye.field_1351, dz = pos.method_10260() + 0.5 - eye.field_1350;
            if (dx * dx + dy * dy + dz * dz > maxSq) continue;
            event.renderer.box(pos.method_10263(), pos.method_10264(), pos.method_10260(), pos.method_10263() + 1, pos.method_10264() + 1, pos.method_10260() + 1,
                sideColor.get(), lineColor.get(), shapeMode.get(), 0);
            if (tracers.get()) {
                event.renderer.line(RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, tracerColor.get());
            }
        }

        // Deep-chunk boxes: a flat box at sea level over chunks that hold a block entity
        // below deep-y, shown once the chunk is past box range — spot deep stashes from afar.
        if (chunkBeam.get() && !deepChunks.isEmpty()) {
            double beamSq = beamDistance.get() * beamDistance.get();
            double boxHorizSq = renderDistance.get() * renderDistance.get();
            double y = seaLevel.get();
            SettingColor line = beamColor.get();
            Color fill = new Color(line.r, line.g, line.b, 35);
            for (long key : deepChunks) {
                class_1923 cp = new class_1923(key);
                double x0 = cp.field_9181 * 16, z0 = cp.field_9180 * 16;
                double hdx = x0 + 8 - eye.field_1352, hdz = z0 + 8 - eye.field_1350;
                double horizSq = hdx * hdx + hdz * hdz;
                if (horizSq > beamSq || horizSq <= boxHorizSq) continue;
                event.renderer.box(x0, y, z0, x0 + 16, y + 1, z0 + 16, fill, line, ShapeMode.Both, 0);
            }
        }
    }

    private static String typeName(class_2591<?> type) {
        var id = class_7923.field_41181.method_10221(type);
        return id != null ? id.method_12832() : "block_entity";
    }

    @Override
    public String getInfoString() { return String.valueOf(found.size()); }
}
