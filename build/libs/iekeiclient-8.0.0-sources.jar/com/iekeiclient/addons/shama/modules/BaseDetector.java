package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_2675;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Base Detector++ — flags chunks emitting lots of particles. Active farms, redstone,
 * brewing, campfires and portals all spew particle packets the server sends you even
 * when far off; a chunk that keeps producing them is almost always a working base.
 * Ported from their BaseDetector (particle-info per chunk). Counts decay over time.
 */
public class BaseDetector extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> weighted = sg.add(new BoolSetting.Builder().name("score-by-type").description("Score particles by how base-like they are (witch 4, flame/enchant 3, smoke/portal/campfire 2, redstone/note 1) instead of counting each one as 1.").defaultValue(true).build());
    private final Setting<Boolean> blockScoring = sg.add(new BoolSetting.Builder().name("block-scoring").description("Also score chunks by player-placed blocks (workstations/storage/farming/lighting), on top of particle activity.").defaultValue(false).build());
    private final Setting<Integer> blockScoreEvery = sg.add(new IntSetting.Builder().name("block-scan-interval").description("Ticks between block-scoring passes.").defaultValue(40).min(10).max(200).sliderRange(20,120).visible(blockScoring::get).build());
    private int blockTick;
    private final Setting<Integer> threshold = sg.add(new IntSetting.Builder().name("threshold").description("Particle packets in the window to flag a chunk.").defaultValue(25).range(3, 200).sliderRange(5, 100).build());
    private final Setting<Integer> windowTicks = sg.add(new IntSetting.Builder().name("window-ticks").description("Length of the counting window, in ticks.").defaultValue(60).range(20, 400).sliderRange(20, 200).build());
    private final Setting<Double> boxY = sg.add(new DoubleSetting.Builder().name("box-y").description("The Y height to draw the box/marker at.").defaultValue(64).min(-64).max(320).sliderRange(-64, 320).build());
    private final Setting<SettingColor> lineColor = sg.add(new ColorSetting.Builder().name("line-color").description("Colour of the box outline.").defaultValue(new SettingColor(255, 90, 255, 220)).build());

    private final Map<Long, Integer> counts = new ConcurrentHashMap<>();
    private int tick;

    public BaseDetector() { super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "base-detector++", "Flags chunks emitting heavy particle activity (working bases)."); }

    @Override public void onActivate() { counts.clear(); }

    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        if (!(event.packet instanceof class_2675 p)) return;
        long key = new class_1923((int) Math.floor(p.method_11544()) >> 4, (int) Math.floor(p.method_11546()) >> 4).method_8324();
        int weight = 1;
        if (weighted.get()) {
            String type = net.minecraft.class_7923.field_41180.method_10221(p.method_11551().method_10295()).method_12832();
            // their exact INTERESTING_PARTICLES weights
            if (type.contains("witch")) weight = 4;
            else if (type.contains("flame") || type.contains("enchant") || type.contains("spit")) weight = 3;
            else if (type.contains("smoke") || type.contains("portal") || type.contains("happy_villager") || type.contains("heart") || type.contains("campfire") || type.contains("squid_ink") || type.contains("fishing")) weight = 2;
            else if (type.contains("composter") || type.contains("redstone") || type.contains("note")) weight = 1;
        }
        counts.merge(key, weight, Integer::sum);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (blockScoring.get() && mc.field_1687 != null && mc.field_1724 != null && ++blockTick % blockScoreEvery.get() == 0) blockScorePass();
        if (++tick % Math.max(1, windowTicks.get()) == 0) counts.replaceAll((k, v) -> v / 2); // decay
        counts.entrySet().removeIf(e -> e.getValue() <= 0);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (counts.isEmpty()) return;
        Color l = lineColor.get(), f = new Color(l.r, l.g, l.b, 40);
        double y = boxY.get();
        for (Map.Entry<Long, Integer> e : counts.entrySet()) {
            if (e.getValue() < threshold.get()) continue;
            class_1923 cp = new class_1923(e.getKey());
            double x0 = cp.field_9181 * 16, z0 = cp.field_9180 * 16;
            event.renderer.box(x0, y, z0, x0 + 16, y + 1, z0 + 16, f, l, ShapeMode.Both, 0);
        }
    }

    private void blockScorePass() {
        int r = mc.field_1690.method_42503().method_41753();
        var center = mc.field_1724.method_31476();
        for (int cx = center.field_9181 - r; cx <= center.field_9181 + r; cx++) for (int cz = center.field_9180 - r; cz <= center.field_9180 + r; cz++) {
            var ch = mc.field_1687.method_8402(cx, cz, net.minecraft.class_2806.field_12803, false);
            if (!(ch instanceof net.minecraft.class_2818 wc)) continue;
            int score = 0;
            for (var sec : wc.method_12006()) {
                if (sec == null || sec.method_38292()) continue;
                for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
                    var st = sec.method_12254(x, y, z); if (st.method_26215()) continue;
                    String pth = com.iekeiclient.addons.shama.util.BlockPaths.of(st.method_26204());
                    if (pth.equals("crafting_table") || pth.endsWith("furnace") || pth.equals("smoker") || pth.equals("anvil") || pth.equals("enchanting_table") || pth.equals("brewing_stand") || pth.equals("smithing_table") || pth.equals("grindstone") || pth.equals("loom") || pth.equals("cartography_table") || pth.equals("stonecutter")) score += 5;
                    else if (pth.equals("chest") || pth.equals("trapped_chest") || pth.equals("barrel") || pth.endsWith("shulker_box") || pth.equals("hopper") || pth.equals("ender_chest") || pth.equals("dispenser") || pth.equals("dropper")) score += 4;
                    else if (pth.equals("farmland") || pth.equals("composter") || pth.equals("beehive") || pth.equals("bee_nest") || pth.equals("hay_block")) score += 3;
                    else if (pth.equals("torch") || pth.equals("wall_torch") || pth.equals("lantern") || pth.equals("glowstone") || pth.equals("sea_lantern") || pth.equals("shroomlight")) score += 2;
                }
            }
            if (score > 0) counts.merge(net.minecraft.class_1923.method_8331(cx, cz), score, Integer::sum);
        }
    }

    @Override public String getInfoString() {
        int n = 0; for (int v : counts.values()) if (v >= threshold.get()) n++;
        return n + " bases";
    }
}
