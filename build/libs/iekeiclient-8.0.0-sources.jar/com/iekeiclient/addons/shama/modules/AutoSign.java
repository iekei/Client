package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.packets.PacketEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2877;
import java.lang.reflect.Field;

/**
 * AutoSign — ported from their AutoSign: learns the text from the first sign you write
 * (captured off your outgoing sign packet), then auto-fills every sign edit screen after
 * that with the same four lines and closes it. Write one sign, the rest copy it.
 */
public class AutoSign extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> front = sg.add(new BoolSetting.Builder().name("front").description("Write on the front side of the sign.").defaultValue(true).build());
    private String[] text;

    public AutoSign() { super(com.iekeiclient.addons.shama.ShamaAddon.PLAYER, "auto-sign++", "Copies your first sign's text onto every sign after."); }

    @Override public void onDeactivate() { text = null; }

    @EventHandler
    private void onSend(PacketEvent.Send event) {
        if (event.packet instanceof class_2877 u) text = u.method_12508(); // learn from your manual sign
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || mc.method_1562() == null || text == null || mc.field_1755 == null) return;
        if (!mc.field_1755.getClass().getName().toLowerCase().contains("sign")) return;
        class_2338 pos = findSignPos(mc.field_1755);
        if (pos == null) return;
        String l0 = text.length > 0 ? text[0] : "", l1 = text.length > 1 ? text[1] : "",
               l2 = text.length > 2 ? text[2] : "", l3 = text.length > 3 ? text[3] : "";
        mc.method_1562().method_52787(new class_2877(pos, front.get(), l0, l1, l2, l3));
        mc.method_1507(null);
    }

    private class_2338 findSignPos(Object screen) {
        try {
            for (Field f : screen.getClass().getDeclaredFields()) {
                f.setAccessible(true);
                Object v = f.get(screen);
                if (v instanceof class_2586 be) return be.method_11016();
                if (v instanceof class_2338 bp) return bp;
            }
        } catch (Throwable ignored) {}
        return null;
    }

    @Override public String getInfoString() { return text != null ? "ready" : "learning"; }
}
