package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Reach++ — extended-range attacking with selectable targeting and rotation.
 *
 * Reality check: the SERVER validates attack range. Beyond ~3 blocks, vanilla and
 * anti-cheats reject the hit; this can't change that. Singleplayer / lenient servers
 * get the extended reach; strict servers cap you at vanilla range.
 *
 * target-priority: Crosshair = only what you're looking at (most legit-looking);
 * the others auto-pick within range like a killaura. Silent rotation sends look
 * packets so the server sees your aim without your camera moving.
 */
public class ReachPlus extends Module {
    public enum Target { Crosshair, Nearest, LowestHealth, LowestArmor, Random }
    public enum Rotation { None, Client, Silent }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Target> target = sgGeneral.add(new EnumSetting.Builder<Target>()
        .name("target-priority")
        .description("Crosshair = only what you aim at; others auto-select within range.")
        .defaultValue(Target.Crosshair)
        .build()
    );

    private final Setting<Rotation> rotation = sgGeneral.add(new EnumSetting.Builder<Rotation>()
        .name("rotation")
        .description("None = don't aim; Client = turn your view; Silent = send look packets only (server sees the aim, camera stays put).")
        .defaultValue(Rotation.None)
        .visible(() -> target.get() != Target.Crosshair)
        .build()
    );

    private final Setting<Double> range = sgGeneral.add(new DoubleSetting.Builder()
        .name("range").description("Attack range in blocks (vanilla is ~3).").defaultValue(5.0).min(1.0).sliderRange(3.0, 10.0).build());

    private final Setting<Boolean> autoAttack = sgGeneral.add(new BoolSetting.Builder()
        .name("auto-attack").description("Automatically attack the selected target within range.").defaultValue(false).build());

    private final Setting<Boolean> hardCap = sgGeneral.add(new BoolSetting.Builder()
        .name("hard-cap")
        .description("Also raise the vanilla attack-range attribute directly (in addition to the extended-range targeting above), for servers that read that attribute instead of just validating hit distance.")
        .defaultValue(false).build());

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("attack-delay").description("Ticks between auto-attacks (lower = faster).").defaultValue(10).range(1, 40).sliderRange(1, 20).visible(autoAttack::get).build());

    private final Setting<Boolean> playersOnly = sgGeneral.add(new BoolSetting.Builder()
        .name("players-only").description("Only target players.").defaultValue(false).build());

    private int timer;

    public ReachPlus() {
        super(com.iekeiclient.addons.shama.ShamaAddon.PLAYER, "reach++", "Extends attack range with selectable targeting. Rejected by strict server anti-cheats.");
    }

    private static final class_2960 REACH_MOD_ID = class_2960.method_60655("shama", "reach_plus_hardcap");

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        applyHardCap();
        if (!autoAttack.get()) return;
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;

        if (timer++ < delay.get()) return;
        timer = 0;

        class_1297 t = target.get() == Target.Crosshair ? raycastEntity(range.get()) : selectTarget(range.get());
        if (t == null) return;

        if (target.get() != Target.Crosshair && rotation.get() != Rotation.None) aim(t);

        mc.field_1761.method_2918(mc.field_1724, t);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    /** Entity the player is looking at, up to maxRange. */
    private class_1297 raycastEntity(double maxRange) {
        class_243 eyes = mc.field_1724.method_33571();
        class_243 look = mc.field_1724.method_5828(1.0f);
        class_243 end = eyes.method_1019(look.method_1021(maxRange));
        class_1297 best = null;
        double bestDist = maxRange * maxRange;

        class_238 search = mc.field_1724.method_5829().method_18804(look.method_1021(maxRange)).method_1014(1.0);
        for (class_1297 e : mc.field_1687.method_8335(mc.field_1724, search)) {
            if (!(e instanceof class_1309) || !e.method_5805()) continue;
            if (playersOnly.get() && !(e instanceof class_1657)) continue;
            class_238 box = e.method_5829().method_1014(e.method_5871());
            var hit = box.method_992(eyes, end);
            if (hit.isPresent()) {
                double d = eyes.method_1025(hit.get());
                if (d < bestDist) { bestDist = d; best = e; }
            }
        }
        return best;
    }

    /** Auto-pick a target within range by the chosen priority. */
    private class_1297 selectTarget(double maxRange) {
        double maxSq = maxRange * maxRange;
        class_1297 best = null;
        double bestScore = Double.MAX_VALUE;
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (e == mc.field_1724 || !(e instanceof class_1309 le) || !e.method_5805()) continue;
            if (playersOnly.get() && !(e instanceof class_1657)) continue;
            double distSq = mc.field_1724.method_5858(e);
            if (distSq > maxSq) continue;
            double score = switch (target.get()) {
                case Nearest -> distSq;
                case LowestHealth -> le.method_6032();
                case LowestArmor -> le.method_6096();
                case Random -> ThreadLocalRandom.current().nextDouble();
                case Crosshair -> distSq; // unreachable here
            };
            if (score < bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    private void aim(class_1297 e) {
        double dx = e.method_23317() - mc.field_1724.method_23317();
        double dy = (e.method_23318() + e.method_5751()) - mc.field_1724.method_23320();
        double dz = e.method_23321() - mc.field_1724.method_23321();
        double dist = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
        if (rotation.get() == Rotation.Client) {
            mc.field_1724.method_36456(yaw);
            mc.field_1724.method_36457(pitch);
        } else if (mc.method_1562() != null) {
            mc.method_1562().method_52787(new class_2828.class_2831(
                yaw, pitch, mc.field_1724.method_24828(), mc.field_1724.field_5976));
        }
    }

    private void applyHardCap() {
        if (mc.field_1724 == null) return;
        class_1324 attr = mc.field_1724.method_5996(class_5134.field_47759);
        if (attr == null) return;
        attr.method_6200(REACH_MOD_ID);
        if (hardCap.get()) {
            attr.method_26835(new class_1322(REACH_MOD_ID, range.get() - attr.method_6201(), class_1322.class_1323.field_6328));
        }
    }

    @Override
    public void onDeactivate() {
        if (mc.field_1724 == null) return;
        class_1324 attr = mc.field_1724.method_5996(class_5134.field_47759);
        if (attr != null) attr.method_6200(REACH_MOD_ID);
    }

    @Override
    public String getInfoString() {
        return target.get().name().toLowerCase();
    }
}
