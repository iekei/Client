package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;

/**
 * Self Defense++ — merged SelfWeb / SelfAnvil / SelfTrap. Tickboxes:
 *   web  : place a cobweb on yourself (and your upper hitbox with double-place).
 *   trap : surround yourself with obsidian (hole-trap).
 *   anvil: place an anvil two blocks above you (blocks players dropping into your hole).
 */
public class SelfDefense extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> web = sg.add(new BoolSetting.Builder().name("web").description("Trap attackers in cobwebs.").defaultValue(false).build());
    private final Setting<Boolean> doublePlace = sg.add(new BoolSetting.Builder().name("web-double").description("Also web your upper hitbox.").defaultValue(false).visible(web::get).build());
    private final Setting<Boolean> trap = sg.add(new BoolSetting.Builder().name("trap").description("Obsidian around you.").defaultValue(false).build());
    private final Setting<Boolean> anvil = sg.add(new BoolSetting.Builder().name("anvil").description("Anvil two blocks above you.").defaultValue(false).build());

    public SelfDefense() {
        super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "self-defense++", "Self web / trap / anvil in one module.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;
        class_2338 feet = mc.field_1724.method_24515();

        if (web.get()) {
            placeAt(feet, class_1802.field_8786);
            if (doublePlace.get()) placeAt(feet.method_10084(), class_1802.field_8786);
        }
        if (trap.get()) {
            for (class_2350 d : class_2350.class_2353.field_11062) placeAt(feet.method_10093(d), class_1802.field_8281);
            placeAt(feet.method_10086(2), class_1802.field_8281);
        }
        if (anvil.get()) placeAt(feet.method_10086(2), class_1802.field_8782);
    }

    private void placeAt(class_2338 pos, net.minecraft.class_1792 item) {
        if (!mc.field_1687.method_8320(pos).method_45474()) return;
        int slot = InvUtils.findInHotbar(item).slot();
        if (slot < 0) return;
        int prev = mc.field_1724.method_31548().method_67532();
        InvUtils.swap(slot, true);
        class_3965 hit = new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        mc.field_1724.method_6104(class_1268.field_5808);
        InvUtils.swap(prev, true);
    }
}
