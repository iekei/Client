package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** HopperDebug — their module: queue-scans chunks for hoppers below max-y (optionally under deepslate), flags dense chunks. */
public class HopperDebug extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");
    private final Setting<Integer> scanRadius = sgGeneral.add(new IntSetting.Builder().name("scan-radius").description("Chunk scan radius.").defaultValue(6).min(1).max(16).build());
    private final Setting<Integer> maxY = sgGeneral.add(new IntSetting.Builder().name("max-y").description("Maximum Y level to scan.").defaultValue(0).min(-64).max(64).build());
    private final Setting<Integer> minHoppers = sgGeneral.add(new IntSetting.Builder().name("min-hoppers").description("Minimum hoppers to flag a chunk.").defaultValue(1).min(1).max(32).build());
    private final Setting<Integer> chunksPerTick = sgGeneral.add(new IntSetting.Builder().name("chunks-per-tick").description("Chunks scanned per tick.").defaultValue(3).min(1).max(12).build());
    private final Setting<Boolean> requireDeepslate = sgGeneral.add(new BoolSetting.Builder().name("under-deepslate").description("Only count hoppers with deepslate above.").defaultValue(false).build());
    private final Setting<Integer> minDeepslate = sgGeneral.add(new IntSetting.Builder().name("min-deepslate").description("Minimum deepslate blocks above.").defaultValue(2).min(1).max(10).visible(requireDeepslate::get).build());
    private final Setting<Double> chunkMarkY = sgRender.add(new DoubleSetting.Builder().name("chunk-y-level").description("Y level for chunk mark.").defaultValue(55.0).min(-64).max(320).build());
    private final Setting<Boolean> signalDetect = sgGeneral.add(new BoolSetting.Builder().name("signal-detect").description("Also watch hopper comparator signals and flag ones that CHANGE (active item flow = a running farm).").defaultValue(false).build());
    private final Setting<Integer> signalDelta = sgGeneral.add(new IntSetting.Builder().name("signal-delta").description("How much a hopper's signal must change to flag it.").defaultValue(1).min(1).max(15).visible(signalDetect::get).build());
    private final Setting<SettingColor> color = sgRender.add(new ColorSetting.Builder().name("color").description("Highlight colour.").defaultValue(new SettingColor(255, 140, 0, 120)).build());

    private final Map<Long, Set<class_2338>> hoppersByChunk = new ConcurrentHashMap<>();
    private final Set<Long> notifiedChunks = ConcurrentHashMap.newKeySet();
    private final Queue<Long> scanQueue = new ArrayDeque<>();
    private int tickCounter;
    private final Map<Long, Integer> lastSignal = new ConcurrentHashMap<>();
    private final Map<Long, Long> signalFlagged = new ConcurrentHashMap<>();

    public HopperDebug() { super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "hopper-debug++", "Finds hoppers and reads the signal strength around them, which gives away sorting systems and hidden storage."); }

    @Override public void onActivate() { hoppersByChunk.clear(); notifiedChunks.clear(); scanQueue.clear(); lastSignal.clear(); signalFlagged.clear(); }
    @Override public void onDeactivate() { hoppersByChunk.clear(); notifiedChunks.clear(); scanQueue.clear(); lastSignal.clear(); signalFlagged.clear(); }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        if (++tickCounter % 20 == 0) { // periodically refill the scan queue around the player
            class_1923 center = mc.field_1724.method_31476();
            int r = scanRadius.get();
            for (int cx = center.field_9181 - r; cx <= center.field_9181 + r; cx++) for (int cz = center.field_9180 - r; cz <= center.field_9180 + r; cz++) {
                long k = class_1923.method_8331(cx, cz);
                if (!scanQueue.contains(k)) scanQueue.add(k);
            }
        }
        for (int i = 0; i < chunksPerTick.get() && !scanQueue.isEmpty(); i++) {
            long k = scanQueue.poll();
            var ch = mc.field_1687.method_8402(class_1923.method_8325(k), class_1923.method_8332(k), net.minecraft.class_2806.field_12803, false);
            if (ch instanceof class_2818 wc) scanChunk(wc, k);
        }
        if (signalDetect.get()) signalPass();
    }

    private void signalPass() {
        class_1923 center = mc.field_1724.method_31476(); int r = scanRadius.get();
        for (int cx = center.field_9181 - r; cx <= center.field_9181 + r; cx++) for (int cz = center.field_9180 - r; cz <= center.field_9180 + r; cz++) {
            var ch = mc.field_1687.method_8402(cx, cz, net.minecraft.class_2806.field_12803, false);
            if (!(ch instanceof class_2818 wc)) continue;
            for (var en : wc.method_12214().entrySet()) {
                if (!(en.getValue() instanceof net.minecraft.class_2614 hop)) continue;
                if (en.getKey().method_10264() > maxY.get()) continue;
                long key = en.getKey().method_10063();
                int sig = net.minecraft.class_1703.method_7618((net.minecraft.class_1263) hop);
                Integer prev = lastSignal.put(key, sig);
                if (prev != null && Math.abs(sig - prev) >= signalDelta.get()) {
                    signalFlagged.put(key, System.currentTimeMillis());
                    com.iekeiclient.addons.shama.util.Chat.info("[HopperDebug] hopper signal change at %d, %d, %d (%d)", en.getKey().method_10263(), en.getKey().method_10264(), en.getKey().method_10260(), sig);
                }
            }
        }
        long now = System.currentTimeMillis();
        signalFlagged.entrySet().removeIf(e -> now - e.getValue() > 5000L);
    }

    private void scanChunk(class_2818 chunk, long key) {
        Set<class_2338> found = new HashSet<>();
        int bx = chunk.method_12004().method_8326(), bz = chunk.method_12004().method_8328();
        class_2338.class_2339 m = new class_2338.class_2339();
        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) for (int y = chunk.method_31607(); y <= maxY.get(); y++) {
            if (!chunk.method_8320(m.method_10103(bx + x, y, bz + z)).method_27852(class_2246.field_10312)) continue;
            if (requireDeepslate.get()) {
                int ds = 0;
                for (int dy = 1; dy <= minDeepslate.get() + 2 && ds < minDeepslate.get(); dy++)
                    if (chunk.method_8320(m.method_10103(bx + x, y + dy, bz + z)).method_27852(class_2246.field_28888)) ds++;
                if (ds < minDeepslate.get()) continue;
            }
            found.add(new class_2338(bx + x, y, bz + z));
        }
        if (found.size() >= minHoppers.get()) {
            hoppersByChunk.put(key, found);
            if (notifiedChunks.add(key)) com.iekeiclient.addons.shama.util.Chat.info("[HopperDebug] %d hoppers in chunk (%d, %d)", found.size(), chunk.method_12004().field_9181, chunk.method_12004().field_9180);
        } else hoppersByChunk.remove(key);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!signalFlagged.isEmpty()) {
            var sc = color.get();
            for (long k : signalFlagged.keySet()) {
                var bp = net.minecraft.class_2338.method_10092(k);
                event.renderer.box(bp.method_10263(), bp.method_10264(), bp.method_10260(), bp.method_10263()+1, bp.method_10264()+1, bp.method_10260()+1, new com.iekeiclient.engine.utils.render.color.Color(sc.r, sc.g, sc.b, 60), sc, ShapeMode.Both, 0);
            }
        }
        if (hoppersByChunk.isEmpty()) return;
        var c = color.get();
        var side = new com.iekeiclient.engine.utils.render.color.Color(c.r, c.g, c.b, 40);
        for (long key : hoppersByChunk.keySet()) {
            class_1923 cp = new class_1923(key);
            double x0 = cp.method_8326(), z0 = cp.method_8328(), y = chunkMarkY.get();
            event.renderer.box(x0, y, z0, x0 + 16, y + 1, z0 + 16, side, c, ShapeMode.Both, 0);
        }
    }
}
