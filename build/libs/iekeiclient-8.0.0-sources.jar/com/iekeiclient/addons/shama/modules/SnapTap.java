package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_304;

/**
 * Snap Tap — when you hold two opposite movement keys, the one you pressed most recently wins
 * instead of the two cancelling each other out. Makes counter-strafing instant.
 */
public class SnapTap extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> leftRight = sg.add(new BoolSetting.Builder()
        .name("left-right")
        .description("Apply it to strafing (A / D).")
        .defaultValue(true).build());

    private final Setting<Boolean> forwardBack = sg.add(new BoolSetting.Builder()
        .name("forward-back")
        .description("Apply it to forward / back (W / S).")
        .defaultValue(true).build());

    private final Setting<Boolean> releaseRestores = sg.add(new BoolSetting.Builder()
        .name("release-restores")
        .description("When you let go of the newer key while still holding the older one, snap straight back to the older direction instead of stopping.")
        .defaultValue(true).build());

    // which side was pressed most recently: 1 = first key, 2 = second key, 0 = neither
    private int lrNewest, fbNewest;
    private boolean lastLeft, lastRight, lastFwd, lastBack;

    public SnapTap() {
        super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "snap-tap++",
            "When you hold two opposite movement keys at once, the most recently pressed one wins instead of both cancelling out.");
    }

    @Override
    public void onDeactivate() {
        lrNewest = fbNewest = 0;
        lastLeft = lastRight = lastFwd = lastBack = false;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1690 == null) return;

        if (leftRight.get()) {
            class_304 l = mc.field_1690.field_1913, r = mc.field_1690.field_1849;
            boolean lp = l.method_1434(), rp = r.method_1434();
            if (lp && !lastLeft) lrNewest = 1;          // just pressed left  -> left is newest
            if (rp && !lastRight) lrNewest = 2;         // just pressed right -> right is newest
            if (!lp && !rp) lrNewest = 0;
            else if (!lp && lrNewest == 1) lrNewest = releaseRestores.get() ? 2 : 0;
            else if (!rp && lrNewest == 2) lrNewest = releaseRestores.get() ? 1 : 0;
            lastLeft = lp; lastRight = rp;
            if (lp && rp) {                              // both held: suppress the older one
                l.method_23481(lrNewest == 1);
                r.method_23481(lrNewest == 2);
            }
        }

        if (forwardBack.get()) {
            class_304 f = mc.field_1690.field_1894, b = mc.field_1690.field_1881;
            boolean fp = f.method_1434(), bp = b.method_1434();
            if (fp && !lastFwd) fbNewest = 1;
            if (bp && !lastBack) fbNewest = 2;
            if (!fp && !bp) fbNewest = 0;
            else if (!fp && fbNewest == 1) fbNewest = releaseRestores.get() ? 2 : 0;
            else if (!bp && fbNewest == 2) fbNewest = releaseRestores.get() ? 1 : 0;
            lastFwd = fp; lastBack = bp;
            if (fp && bp) {
                f.method_23481(fbNewest == 1);
                b.method_23481(fbNewest == 2);
            }
        }
    }
}
