package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.DoubleSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.RenderUtils;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import com.iekeiclient.engine.settings.ColorSetting;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1577;
import net.minecraft.class_238;
import net.minecraft.class_243;
import java.util.HashSet;
import java.util.Set;

/**
 * Ocean Monument Finder++ — their actual method: guardians only exist near ocean
 * monuments, so any guardian entity in range reveals a nearby monument even before
 * you've seen its prismarine structure. Tracers to each detected guardian.
 */
public class OceanMonumentFinder extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Double> scanRadius = sg.add(new DoubleSetting.Builder()
        .name("scan-radius").description("How far out to scan, in chunks.").defaultValue(128).min(16).sliderRange(32, 256).build());

    private final Setting<SettingColor> color = sg.add(new ColorSetting.Builder()
        .name("color").description("Highlight colour.").defaultValue(new SettingColor(0, 180, 255, 200)).build());

    private final Set<Integer> found = new HashSet<>();

    public OceanMonumentFinder() {
        super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "ocean-monument-finder++", "Detects nearby ocean monuments by spotting guardian entities (their only habitat).");
    }

    @Override
    public void onActivate() { found.clear(); }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        double r = scanRadius.get();
        class_238 box = mc.field_1724.method_5829().method_1014(r);
        for (class_1297 e : mc.field_1687.method_8335(mc.field_1724, box)) {
            if (e instanceof class_1577) found.add(e.method_5628());
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null || found.isEmpty()) return;
        class_243 cam = RenderUtils.center;
        for (Integer id : found) {
            class_1297 e = mc.field_1687.method_8469(id);
            if (e == null) continue;
            event.renderer.line(cam.field_1352, cam.field_1351, cam.field_1350, e.method_23317(), e.method_23318() + e.method_17682() / 2, e.method_23321(), color.get());
        }
    }

    @Override
    public String getInfoString() { return found.size() + " guardians"; }
}
