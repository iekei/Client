package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1429;
import net.minecraft.class_1472;
import net.minecraft.class_1496;
import net.minecraft.class_1536;
import net.minecraft.class_1708;
import net.minecraft.class_1713;
import net.minecraft.class_1720;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

/**
 * Autoer++ — merged automation with per-feature tickboxes. Consolidates the various
 * auto-* helpers into one module.
 *
 *   auto-tool  : swap to the fastest applicable tool for whatever you're breaking.
 *   auto-mount : right-click the nearest rideable (horse/camel/etc.) to mount it.
 *
 * (More auto-farm features fold in here as additional tickboxes.)
 */
public class Autoer extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> autoTool = sg.add(new BoolSetting.Builder().name("auto-tool").description("Swap to the best tool for the block you're mining.").defaultValue(true).build());
    private final Setting<Boolean> autoMount = sg.add(new BoolSetting.Builder().name("auto-mount").description("Mount the nearest rideable animal you look at.").defaultValue(false).build());
    private final Setting<Boolean> autoWeapon = sg.add(new BoolSetting.Builder().name("auto-weapon").description("Swap to your best sword/axe when attacking a mob.").defaultValue(false).build());
    private final Setting<Boolean> autoShear = sg.add(new BoolSetting.Builder().name("auto-shear").description("Shear nearby wooly sheep (needs shears in hand).").defaultValue(false).build());
    private final Setting<Boolean> autoBreed = sg.add(new BoolSetting.Builder().name("auto-breed").description("Feed nearby breedable animals with the food you're holding.").defaultValue(false).build());
    private final Setting<Boolean> autoFish = sg.add(new BoolSetting.Builder().name("auto-fish").description("Auto-reel and recast when a fish bites.").defaultValue(false).build());
    private final Setting<Boolean> mountBypass = sg.add(new BoolSetting.Builder().name("mount-bypass").description("Force-mount the animal you look at even if you have a vehicle already / server quirks.").defaultValue(false).build());
    private final Setting<Boolean> autoSmelter = sg.add(new BoolSetting.Builder().name("auto-smelter").description("With a furnace open: auto-collect finished output and top up coal fuel.").defaultValue(false).build());
    private final Setting<Boolean> autoBrewer = sg.add(new BoolSetting.Builder().name("auto-brewer").description("With a brewing stand open: auto-collect finished potions and top up blaze powder fuel.").defaultValue(false).build());
    private final Setting<Boolean> autoNametag = sg.add(new BoolSetting.Builder().name("auto-nametag").description("Name-tag nearby un-named animals (needs a name tag in hotbar).").defaultValue(false).build());
    private final Setting<Boolean> autoArmor = sg.add(new BoolSetting.Builder().name("auto-armor").description("Equip the best armor from your inventory into empty armor slots.").defaultValue(false).build());

    private int armorTick;

    public Autoer() {
        super(com.iekeiclient.addons.shama.ShamaAddon.PLAYER, "autoer++", "Auto-tool + auto-mount (and more) in one module.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;

        if (autoArmor.get() && armorTick++ % 8 == 0) equipArmor();

        if (autoTool.get() && mc.field_1690.field_1886.method_1434()
            && mc.field_1765 instanceof class_3965 hit && hit.method_17783() == class_239.class_240.field_1332) {
            class_2680 state = mc.field_1687.method_8320(hit.method_17777());
            int best = mc.field_1724.method_31548().method_67532();
            double bestSpeed = mc.field_1724.method_31548().method_5438(best).method_7924(state);
            for (int i = 0; i < 9; i++) {
                class_1799 s = mc.field_1724.method_31548().method_5438(i);
                double sp = s.method_7924(state);
                if (sp > bestSpeed) { bestSpeed = sp; best = i; }
            }
            if (best != mc.field_1724.method_31548().method_67532()) InvUtils.swap(best, false);
        }

        if ((autoMount.get() || mountBypass.get()) && mc.field_1765 instanceof net.minecraft.class_3966 eh
            && eh.method_17782() instanceof class_1496 && (mountBypass.get() || !mc.field_1724.method_5765())) {
            mc.field_1761.method_2905(mc.field_1724, eh.method_17782(), class_1268.field_5808);
        }

        if (autoWeapon.get() && mc.field_1690.field_1886.method_1434()
            && mc.field_1765 instanceof net.minecraft.class_3966) {
            int best = -1, bestScore = -1;
            for (int i = 0; i < 9; i++) {
                var it = mc.field_1724.method_31548().method_5438(i).method_7909();
                String id = net.minecraft.class_7923.field_41178.method_10221(it).method_12832();
                int sc = id.endsWith("_sword") ? 2 : id.endsWith("_axe") ? 1 : 0;
                if (sc > bestScore) { bestScore = sc; best = i; }
            }
            if (best >= 0 && bestScore > 0 && best != mc.field_1724.method_31548().method_67532()) InvUtils.swap(best, false);
        }

        class_238 near = mc.field_1724.method_5829().method_1014(4);
        if (autoNametag.get()) {
            int nt = InvUtils.findInHotbar(class_1802.field_8448).slot();
            if (nt >= 0) for (class_1297 e : mc.field_1687.method_8335(mc.field_1724, near))
                if (e instanceof class_1429 an && !an.method_16914()) {
                    int sel = mc.field_1724.method_31548().method_67532();
                    InvUtils.swap(nt, false);
                    mc.field_1761.method_2905(mc.field_1724, e, class_1268.field_5808);
                    InvUtils.swap(sel, false);
                    break;
                }
        }
        if (autoShear.get() && (mc.field_1724.method_6047().method_31574(class_1802.field_8868) || mc.field_1724.method_6079().method_31574(class_1802.field_8868))) {
            for (class_1297 e : mc.field_1687.method_8335(mc.field_1724, near))
                if (e instanceof class_1472 sh && !sh.method_6629() && !sh.method_6109()) {
                    mc.field_1761.method_2905(mc.field_1724, e, mc.field_1724.method_6047().method_31574(class_1802.field_8868) ? class_1268.field_5808 : class_1268.field_5810);
                    break;
                }
        }
        if (autoBreed.get() && !mc.field_1724.method_6047().method_7960()) {
            for (class_1297 e : mc.field_1687.method_8335(mc.field_1724, near))
                if (e instanceof class_1429 an && an.method_6481(mc.field_1724.method_6047()) && an.method_5618() == 0) {
                    mc.field_1761.method_2905(mc.field_1724, e, class_1268.field_5808);
                    break;
                }
        }
        if (autoSmelter.get() && mc.field_1724.field_7512 instanceof class_1720 fh && mc.field_1761 != null) {
            int sync = fh.field_7763;
            // collect output (slot 2)
            if (!fh.method_7611(2).method_7677().method_7960())
                mc.field_1761.method_2906(sync, 2, 0, class_1713.field_7794, mc.field_1724);
            // top up fuel (slot 1) with coal from inventory
            if (fh.method_7611(1).method_7677().method_7960()) {
                for (int i = 3; i < fh.field_7761.size(); i++) {
                    if (fh.method_7611(i).method_7677().method_31574(class_1802.field_8713) || fh.method_7611(i).method_7677().method_31574(class_1802.field_8665)) {
                        mc.field_1761.method_2906(sync, i, 0, class_1713.field_7794, mc.field_1724);
                        break;
                    }
                }
            }
        }
        if (autoBrewer.get() && mc.field_1724.field_7512 instanceof class_1708 bh && mc.field_1761 != null) {
            int sync = bh.field_7763;
            // top up blaze powder fuel (slot 4)
            if (bh.method_7611(4).method_7677().method_7960()) {
                for (int i = 5; i < bh.field_7761.size(); i++)
                    if (bh.method_7611(i).method_7677().method_31574(class_1802.field_8183)) { mc.field_1761.method_2906(sync, i, 0, net.minecraft.class_1713.field_7794, mc.field_1724); break; }
            }
        }
        if (autoFish.get() && (mc.field_1724.method_6047().method_31574(class_1802.field_8378) || mc.field_1724.method_6079().method_31574(class_1802.field_8378))) {
            class_1536 bobber = mc.field_1724.field_7513;
            if (bobber != null && bobber.method_24828() == false && bobber.method_18798().field_1351 < -0.05 && bobber.method_5799()) {
                class_1268 h = mc.field_1724.method_6047().method_31574(class_1802.field_8378) ? class_1268.field_5808 : class_1268.field_5810;
                mc.field_1761.method_2919(mc.field_1724, h); // reel in
                mc.field_1761.method_2919(mc.field_1724, h); // recast
            }
        }
    }

    private void equipArmor() {
        class_1304[] slots = {class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
        String[] kinds = {"helmet", "chestplate", "leggings", "boots"};
        for (int si = 0; si < 4; si++) {
            if (!mc.field_1724.method_6118(slots[si]).method_7960()) continue;   // slot already filled
            int bestSlot = -1, bestTier = -1;
            for (int i = 0; i < 36; i++) {
                class_1799 st = mc.field_1724.method_31548().method_5438(i);
                if (st.method_7960()) continue;
                String pth = net.minecraft.class_7923.field_41178.method_10221(st.method_7909()).method_12832();
                boolean match = pth.endsWith(kinds[si]) || (si == 0 && pth.equals("turtle_helmet"));
                if (!match) continue;
                int tier = armorTier(pth);
                if (tier > bestTier) { bestTier = tier; bestSlot = i; }
            }
            if (bestSlot >= 0) {
                int screen = bestSlot < 9 ? bestSlot + 36 : bestSlot; // inv index -> player screen slot
                mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, screen, 0, class_1713.field_7794, mc.field_1724);
            }
        }
    }

    private int armorTier(String p) {
        if (p.contains("netherite")) return 5;
        if (p.contains("diamond")) return 4;
        if (p.contains("iron")) return 3;
        if (p.contains("chainmail")) return 2;
        if (p.contains("golden")) return 1;
        return 0; // leather / turtle
    }

    @Override
    public String getInfoString() {
        return autoTool.get() ? "tool" : autoMount.get() ? "mount" : "off";
    }
}
