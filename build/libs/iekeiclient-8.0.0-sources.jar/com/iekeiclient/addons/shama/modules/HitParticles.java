package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2398;
import net.minecraft.class_3966;

/** Hit Particles — spawns a burst of particles on the entity you attack. */
public class HitParticles extends Module {
    public enum Particle { Crit, Damage, Flame, Heart, Explosion }

    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Particle> particle = sg.add(new EnumSetting.Builder<Particle>().name("particle").description("Which particle to use.").defaultValue(Particle.Crit).build());
    private final Setting<Integer> count = sg.add(new IntSetting.Builder().name("count").description("How many particles to spawn.").defaultValue(12).min(1).max(60).sliderRange(4, 30).build());

    private boolean wasAttacking;

    public HitParticles() { super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "hit-particles++", "Spawns particles on the entity you attack."); }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1690 == null) return;
        boolean attacking = mc.field_1690.field_1886.method_1434();
        boolean edge = attacking && !wasAttacking;   // rising edge = a fresh click
        wasAttacking = attacking;
        if (!edge) return;
        if (!(mc.field_1765 instanceof class_3966 hit)) return;

        var e = hit.method_17782();
        var type = switch (particle.get()) {
            case Crit -> class_2398.field_11205;
            case Damage -> class_2398.field_11209;
            case Flame -> class_2398.field_11240;
            case Heart -> class_2398.field_11201;
            case Explosion -> class_2398.field_11236;
        };
        for (int i = 0; i < count.get(); i++) {
            double ox = (mc.field_1687.field_9229.method_43058() - 0.5) * e.method_17681();
            double oy = mc.field_1687.field_9229.method_43058() * e.method_17682();
            double oz = (mc.field_1687.field_9229.method_43058() - 0.5) * e.method_17681();
            mc.field_1687.method_8406(type, e.method_23317() + ox, e.method_23318() + oy, e.method_23321() + oz,
                (mc.field_1687.field_9229.method_43058() - 0.5) * 0.4, mc.field_1687.field_9229.method_43058() * 0.3, (mc.field_1687.field_9229.method_43058() - 0.5) * 0.4);
        }
    }
}
