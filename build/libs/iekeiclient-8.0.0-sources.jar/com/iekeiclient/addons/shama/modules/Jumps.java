package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;

/**
 * Jumps++ — merged jump modules with tickboxes:
 *   high-jump : jump higher than vanilla.
 *   long-jump : launch forward with your movement direction when you jump.
 *   air-jump  : allow one extra jump while airborne.
 *   auto-jump : auto-jump whenever you're holding forward on the ground.
 */
public class Jumps extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> highJump = sg.add(new BoolSetting.Builder().name("high-jump").description("Jump higher than normal.").defaultValue(false).build());
    private final Setting<Double> jumpHeight = sg.add(new DoubleSetting.Builder().name("jump-power").description("How high the high-jump goes.").defaultValue(0.7).min(0.42).sliderRange(0.42, 2).visible(highJump::get).build());
    private final Setting<Boolean> longJump = sg.add(new BoolSetting.Builder().name("long-jump").description("Jump further forward.").defaultValue(false).build());
    private final Setting<Double> longPower = sg.add(new DoubleSetting.Builder().name("long-power").description("How far the long-jump goes.").defaultValue(1.2).min(0.3).sliderRange(0.3, 3).visible(longJump::get).build());
    private final Setting<Boolean> airJump = sg.add(new BoolSetting.Builder().name("air-jump").description("Allow jumping again in mid-air.").defaultValue(false).build());
    private final Setting<Boolean> autoJump = sg.add(new BoolSetting.Builder().name("auto-jump").description("Jump automatically whenever possible.").defaultValue(false).build());

    private boolean prevJump, usedAir, prevOnGround;

    public Jumps() {
        super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "jumps++", "High / long / air / auto jump in one module.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null) return;
        boolean onGround = mc.field_1724.method_24828();
        boolean jumpPressed = mc.field_1690.field_1903.method_1434();
        if (onGround) usedAir = false;

        if (autoJump.get() && onGround && mc.field_1690.field_1894.method_1434()) jumpPressed = true;

        // rising edge of jump
        boolean edge = jumpPressed && !prevJump;

        if (edge && onGround) {
            class_243 v = mc.field_1724.method_18798();
            double vy = highJump.get() ? jumpHeight.get() : v.field_1351;
            double vx = v.field_1352, vz = v.field_1350;
            if (longJump.get()) {
                double rad = Math.toRadians(mc.field_1724.method_36454());
                vx = -Math.sin(rad) * longPower.get();
                vz = Math.cos(rad) * longPower.get();
                if (!highJump.get()) vy = 0.42;
            }
            if (highJump.get() || longJump.get()) mc.field_1724.method_18800(vx, vy, vz);
        } else if (edge && !onGround && airJump.get() && !usedAir) {
            usedAir = true;
            class_243 v = mc.field_1724.method_18798();
            mc.field_1724.method_18800(v.field_1352, highJump.get() ? jumpHeight.get() : 0.42, v.field_1350);
        }
        if (autoJump.get() && onGround && mc.field_1690.field_1894.method_1434()) mc.field_1690.field_1903.method_23481(true);
        prevJump = jumpPressed;
        prevOnGround = onGround;
    }

    @Override public String getInfoString() {
        StringBuilder b = new StringBuilder();
        if (highJump.get()) b.append("high ");
        if (longJump.get()) b.append("long ");
        if (airJump.get()) b.append("air ");
        if (autoJump.get()) b.append("auto");
        return b.length() == 0 ? "off" : b.toString().trim();
    }
}
