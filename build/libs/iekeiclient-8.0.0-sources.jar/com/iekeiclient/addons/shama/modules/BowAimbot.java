package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import com.iekeiclient.addons.shama.util.Humanize;

/** BowAimbot++ — while you're drawing a bow/crossbow, auto-aims your view at the nearest target (with a small arc for drop). Ported from their BowAimbot. */
public class BowAimbot extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Double> range = sg.add(new DoubleSetting.Builder().name("range").description("How far out (in blocks) this reaches.").defaultValue(40).min(4).sliderRange(8, 80).build());
    private final Setting<Double> aimNoise = sg.add(new DoubleSetting.Builder().name("aim-noise").description("Add a tiny random wobble (degrees) to the auto-aim so it doesn't lock on with robotic precision.").defaultValue(0.0).min(0).max(5).sliderRange(0,3).build());

    public BowAimbot() { super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "bow-aimbot++", "Auto-aims your bow at the nearest target while drawing."); }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        boolean drawing = mc.field_1724.method_6115() && (mc.field_1724.method_6030().method_31574(class_1802.field_8102) || mc.field_1724.method_6030().method_31574(class_1802.field_8399));
        if (!drawing) return;

        class_1657 target = null; double best = range.get();
        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724 || !p.method_5805()) continue;
            double d = mc.field_1724.method_5739(p);
            if (d < best) { best = d; target = p; }
        }
        if (target == null) return;

        class_243 eye = mc.field_1724.method_33571();
        double tx = target.method_23317() - eye.field_1352;
        double ty = (target.method_23318() + target.method_5751() * 0.9) - eye.field_1351;
        double tz = target.method_23321() - eye.field_1350;
        double dist = Math.sqrt(tx * tx + tz * tz);
        // simple projectile arc compensation
        double arc = dist * 0.05;
        float yaw = (float) (class_3532.method_15349(tz, tx) * (180 / Math.PI)) - 90f;
        float pitch = (float) -(class_3532.method_15349(ty + arc, dist) * (180 / Math.PI));
        float n = (float) (double) aimNoise.get();
        mc.field_1724.method_36456(yaw + Humanize.rotationNoise(n));
        mc.field_1724.method_36457(class_3532.method_15363(pitch + Humanize.rotationNoise(n), -90f, 90f));
    }
}
