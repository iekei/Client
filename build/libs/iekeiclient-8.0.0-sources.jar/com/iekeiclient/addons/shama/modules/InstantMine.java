package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.EnumSetting;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2846;
import net.minecraft.class_3965;

/**
 * Instant Mine++ — several distinct ways to break faster.
 *
 *   Multiplier - scale client break speed via BlockBreakingSpeedMixin (uses the
 *                speed slider). SP / lenient servers.
 *   Packet     - raw START+STOP destroy packets on the crosshair block (sequence 0).
 *   Abort      - raw START+ABORT instead (some servers finalize on abort).
 *   Vanilla    - no speed change; only removes the delay between breaks.
 *   Sequenced  - break the crosshair block through the client's OWN sequenced
 *                breakBlock() pipeline, i.e. with correct sequence numbers and
 *                block prediction — different from Packet's raw sequence-0 spam, so
 *                servers that validate the sequence field accept it where Packet is
 *                dropped. Reverts on strict servers if the block is genuinely too hard.
 *   Nuker      - AREA break: every solid block within radius AND reach, each tick,
 *                not just the one under your crosshair. Completely different shape of
 *                attack. High radius = lots of packets; a server may kick for spam.
 *
 * Honest scope: full effect in singleplayer; on servers the server re-validates, so
 * instant/area work only on lenient ones. Strict anti-cheats cap break rate regardless.
 */
public class InstantMine extends Module {
    public enum Mode { Multiplier, Packet, Abort, Vanilla, Sequenced, Nuker, SpeedMine }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    public final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("Multiplier scales break speed. Packet/Abort fire raw destroy packets. Vanilla only removes break delay. Sequenced uses the game's own sequenced break (accepted where raw packets are dropped). Nuker breaks everything in radius+reach at once. SpeedMine ramps break speed up the longer you hold attack on the same block (merged module).")
        .defaultValue(Mode.Multiplier)
        .build()
    );

    public final Setting<Integer> speedPercent = sgGeneral.add(new IntSetting.Builder()
        .name("speed-percent")
        .description("100 = instant (default), 0 = normal speed, -500 = 5x slower.")
        .defaultValue(100)
        .range(-500, 100)
        .sliderRange(-500, 100)
        .visible(() -> mode.get() == Mode.Multiplier)
        .build()
    );

    public final Setting<Integer> nukerRadius = sgGeneral.add(new IntSetting.Builder()
        .name("nuker-radius")
        .description("Nuker: block radius around you to break each tick. Kept within reach. Higher = far more packets (kick risk).")
        .defaultValue(2)
        .range(1, 5)
        .sliderRange(1, 5)
        .visible(() -> mode.get() == Mode.Nuker)
        .build()
    );

    public final Setting<Boolean> noBreakDelay = sgGeneral.add(new BoolSetting.Builder()
        .name("no-break-delay")
        .description("Remove the cooldown between block breaks so mining is continuous. Works in singleplayer and on servers.")
        .defaultValue(true)
        .build()
    );

    private net.minecraft.class_2338 speedMineTarget;
    private int speedMineHoldTicks;

    public InstantMine() {
        super(com.iekeiclient.addons.shama.ShamaAddon.PLAYER, "instant-mine++", "Break blocks far faster, with several methods to choose from (speed multiplier, packets, abort, sequenced, or an area nuker). Strength depends on the server.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mode.get() == Mode.SpeedMine) {
            boolean looking = mc.field_1765 instanceof class_3965 bh && bh.method_17783() == class_239.class_240.field_1332;
            net.minecraft.class_2338 cur = looking ? ((class_3965) mc.field_1765).method_17777() : null;
            if (cur != null && cur.equals(speedMineTarget) && mc.field_1690.field_1886.method_1434()) speedMineHoldTicks++;
            else { speedMineHoldTicks = 0; speedMineTarget = cur; }
        }
        if (noBreakDelay.get() && mc.field_1761 != null) {
            NoBreakDelay.zeroCooldown(mc.field_1761);
        }
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null || mc.field_1761 == null) return;

        Mode m = mode.get();
        boolean attacking = mc.field_1690.field_1886.method_1434();
        boolean lookingAtBlock = mc.field_1765 instanceof class_3965 hit && hit.method_17783() == class_239.class_240.field_1332;

        if ((m == Mode.Packet || m == Mode.Abort) && attacking && lookingAtBlock) {
            class_3965 hit = (class_3965) mc.field_1765;
            sendBreak(hit.method_17777(), hit.method_17780(), m == Mode.Abort);
        } else if (m == Mode.Sequenced && attacking && lookingAtBlock) {
            // Game's own sequenced instant break (correct sequence + prediction).
            class_3965 hit = (class_3965) mc.field_1765;
            mc.field_1761.method_2899(hit.method_17777());
            mc.field_1724.method_6104(class_1268.field_5808);
        } else if (m == Mode.Nuker) {
            nuke();
        }
    }

    /** Raw start + stop/abort destroy packets for one block (sequence 0). */
    private void sendBreak(class_2338 pos, class_2350 side, boolean abort) {
        var nh = mc.method_1562();
        nh.method_52787(new class_2846(class_2846.class_2847.field_12968, pos, side, 0));
        nh.method_52787(new class_2846(
            abort ? class_2846.class_2847.field_12971 : class_2846.class_2847.field_12973,
            pos, side, 0));
    }

    /** Break every solid block within radius and reach this tick. */
    private void nuke() {
        int r = nukerRadius.get();
        double reachSq = 5.0 * 5.0;
        class_243 eye = mc.field_1724.method_33571();
        class_2338 center = mc.field_1724.method_24515();
        boolean swung = false;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    if (eye.method_1025(class_243.method_24953(pos)) > reachSq) continue;
                    if (mc.field_1687.method_8320(pos).method_26215()) continue;
                    sendBreak(pos, class_2350.field_11036, false);
                    if (!swung) { mc.field_1724.method_6104(class_1268.field_5808); swung = true; }
                }
            }
        }
    }

    /**
     * Multiplier applied to vanilla block-breaking speed (Multiplier mode only).
     *   p = 100 -> instant; 0 < p < 100 -> 1/(1 - p/100); p = 0 -> 1.0; p < 0 -> slower.
     */
    public double factor() {
        if (mode.get() == Mode.SpeedMine) return 1.0 + Math.min(speedMineHoldTicks, 100) * 0.15; // ramps up the longer you hold
        if (mode.get() != Mode.Multiplier) return 1.0;
        int p = speedPercent.get();
        if (p >= 100) return 100000.0;
        if (p > 0)   return 1.0 / (1.0 - p / 100.0);
        if (p == 0)  return 1.0;
        return 1.0 / (1.0 + (-p) / 125.0);
    }

    @Override
    public String getInfoString() {
        return mode.get().name().toLowerCase();
    }
}
