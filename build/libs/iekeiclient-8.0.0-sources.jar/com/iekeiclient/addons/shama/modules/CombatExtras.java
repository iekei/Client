package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;

/**
 * Combat Extras++ — merged BowSpam / AutoEXP / AutoDTap tickboxes.
 *   bow-spam : instantly release + redraw a bow for rapid fire.
 *   auto-exp : throw XP bottles while held for fast mending repair.
 *   d-tap    : right-click with a sword auto-places an obsidian, then swaps back (hole defense).
 */
public class CombatExtras extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> bowSpam = sg.add(new BoolSetting.Builder().name("bow-spam").description("Rapidly fire the bow.").defaultValue(false).build());
    private final Setting<Boolean> autoExp = sg.add(new BoolSetting.Builder().name("auto-exp").description("Automatically throw XP bottles.").defaultValue(false).build());
    private final Setting<Boolean> dTap = sg.add(new BoolSetting.Builder().name("d-tap").description("Double-tap to trigger.").defaultValue(false).build());

    public CombatExtras() { super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "combat-extras++", "Bow-spam / auto-exp / d-tap."); }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1761 == null) return;

        if (bowSpam.get() && mc.field_1724.method_6047().method_31574(class_1802.field_8102) && mc.field_1690.field_1904.method_1434()) {
            mc.field_1761.method_2897(mc.field_1724);          // release
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808); // redraw
        }
        if (autoExp.get()) {
            int s = InvUtils.findInHotbar(class_1802.field_8287).slot();
            if (s >= 0) { int sel = mc.field_1724.method_31548().method_67532(); InvUtils.swap(s, false); mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808); InvUtils.swap(sel, false); }
        }
        if (dTap.get() && mc.field_1724.method_6047().method_7909().toString().contains("sword") && mc.field_1690.field_1904.method_1434()) {
            int s = InvUtils.findInHotbar(class_1802.field_8281).slot();
            if (s >= 0 && mc.field_1765 instanceof net.minecraft.class_3965 hit) {
                int sel = mc.field_1724.method_31548().method_67532();
                InvUtils.swap(s, false);
                mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
                InvUtils.swap(sel, false);
            }
        }
    }
}
