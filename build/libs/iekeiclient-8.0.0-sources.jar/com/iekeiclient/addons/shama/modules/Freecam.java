package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.DoubleSetting;
import com.iekeiclient.engine.settings.EnumSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import net.minecraft.class_5498;

/**
 * Freecam++ — detached free-flying camera. Position is stepped once per tick and the
 * camera mixin interpolates it by tick-delta every frame, so motion is smooth at any FPS
 * (the old version set the camera straight to the per-tick position, which is what made it
 * jitter). The mouse steers the camera; your body stays put unless you enable rotate.
 */
public class Freecam extends Module {
    public enum Click {
        /** Do nothing at all — clicking while the camera is out is almost always a misfire. */
        Ignore,
        /** Mine and use where your real body is looking, not where the camera points. */
        RealBody
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgExtra = settings.createGroup("Extras");

    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
        .name("speed").description("Camera fly speed (blocks per tick).").defaultValue(0.5).min(0.05).sliderRange(0.1, 5.0).build());

    private final Setting<Double> verticalSpeed = sgGeneral.add(new DoubleSetting.Builder()
        .name("vertical-speed")
        .description("Multiplies how fast you rise and fall against your normal speed. Under 1 makes it easier to hold a height while you look around; over 1 gets you up and down a shaft quickly.")
        .defaultValue(1.2).min(0.5).max(4).sliderRange(0.5, 4).decimalPlaces(2).build());

    private final Setting<Boolean> verticalKeys = sgGeneral.add(new BoolSetting.Builder()
        .name("vertical-affects-keys")
        .description("Apply the multiplier to jump and sneak, so tapping up or down moves you at the boosted rate.")
        .defaultValue(true).build());

    private final Setting<Boolean> verticalLook = sgGeneral.add(new BoolSetting.Builder()
        .name("vertical-affects-look")
        .description("Apply it to the up-and-down part of flying where you look, too. Leave this off if you want flying forward to feel exactly as before and only the jump and sneak keys to be quicker.")
        .defaultValue(false).build());

    private final Setting<Boolean> scrollRemembers = sgGeneral.add(new BoolSetting.Builder()
        .name("scroll-remembers")
        .description("Keep whatever you scrolled to for next time instead of snapping back to the slider value when you close the camera. Off means the scroll only lasts for that session.")
        .defaultValue(true).build());

    private final Setting<Click> clickAction = sgGeneral.add(new EnumSetting.Builder<Click>()
        .name("click-action")
        .description("What a mouse click does while the camera is out. Your body is not where the camera is, so a click used to swing at whatever happened to be in front of the camera, which is usually thin air. Ignore drops the click entirely; Real Body mines and uses where your actual character is looking, which is what you would get with the camera closed.")
        .defaultValue(Click.RealBody).build());

    private final Setting<Boolean> holdToMine = sgGeneral.add(new BoolSetting.Builder()
        .name("hold-to-mine")
        .description("Hold left click to mine from your real character's crosshair, and stop the moment you let go. Off ignores left click entirely while the camera is out.")
        .defaultValue(true).visible(() -> clickAction.get() == Click.RealBody).build());

    private final Setting<Boolean> holdToUse = sgGeneral.add(new BoolSetting.Builder()
        .name("hold-to-use")
        .description("Hold right click to use whatever you are holding, from your real character rather than the camera. This is what lets you keep firing rockets while you fly the camera around, or eat, or draw a bow, without closing the camera first.")
        .defaultValue(true).visible(() -> clickAction.get() == Click.RealBody).build());
    private final Setting<Double> smoothing = sgGeneral.add(new DoubleSetting.Builder()
        .name("smoothing").description("How much the camera eases into a start and out of a stop. A little takes the jerkiness off without making it feel like it is floating; 0 is instant, the way Iekei moves.").defaultValue(0.05).min(0).max(0.9).sliderRange(0, 0.5).decimalPlaces(2).build());
    private final Setting<Boolean> lookFly = sgGeneral.add(new BoolSetting.Builder()
        .name("fly-toward-crosshair")
        .description("Move along the direction you're actually looking, so looking down and holding forward takes you down. Off = stay level and only rise/fall with jump and sneak.")
        .defaultValue(true).build());
    private final Setting<Double> sensitivity = sgGeneral.add(new DoubleSetting.Builder()
        .name("look-sensitivity").description("Mouse sensitivity for steering the camera.").defaultValue(0.15).min(0.01).sliderRange(0.05, 0.5).build());

    private final Setting<Boolean> scrollSpeed = sgGeneral.add(new BoolSetting.Builder()
        .name("scroll-speed").description("Scroll the mouse wheel to change fly speed live (like Iekei's freecam).").defaultValue(true).build());
    private final Setting<Double> scrollStep = sgGeneral.add(new DoubleSetting.Builder()
        .name("scroll-step").description("How much each scroll notch multiplies the speed.").defaultValue(1.1).min(1.01).sliderRange(1.05, 1.5).decimalPlaces(2).visible(scrollSpeed::get).build());

    private final Setting<Boolean> keepInputs = sgGeneral.add(new BoolSetting.Builder()
        .name("keep-inputs").description("Lock the attack/use you held on entry so you keep mining/using at your character's view.").defaultValue(false).build());
    private final Setting<Boolean> mineAtCharacter = sgGeneral.add(new BoolSetting.Builder()
        .name("mine-at-character").description("A mouse press in freecam mines/interacts where your CHARACTER looks, not the camera.").defaultValue(true).build());

    // Requested extras
    private final Setting<Boolean> reloadChunks = sgExtra.add(new BoolSetting.Builder()
        .name("reload-chunks").description("Reload all chunks when freecam toggles (fixes render gaps).").defaultValue(false).build());
    private final Setting<Boolean> showHands = sgExtra.add(new BoolSetting.Builder()
        .name("show-hands").description("Stay in first person so your hands/held item render at the camera. Off forces third person so you see your body.").defaultValue(true).build());
    private final Setting<Boolean> rotate = sgExtra.add(new BoolSetting.Builder()
        .name("rotate").description("Rotate your character's body to follow the camera direction.").defaultValue(false).build());
    private final Setting<Boolean> keepSneaking = sgExtra.add(new BoolSetting.Builder()
        .name("keep-sneaking").description("Hold the player sneaking the whole time so it can't walk off an edge.").defaultValue(false).build());
    private final Setting<Boolean> allowPathing = sgExtra.add(new BoolSetting.Builder()
        .name("allow-pathing").description("Don't lock movement keys, so Baritone / the player can still path while the camera flies free.").defaultValue(false).build());

    // Camera state (read by CameraMixin each frame).
    private class_243 pos, prevPos;
    private float yaw, pitch;
    private boolean hasPos;
    private double scrollMult = 1.0;
    private class_243 vel = class_243.field_1353;

    // Entry input snapshot.
    private boolean needInit;
    private boolean sForward, sBack, sLeft, sRight, sJump, sSneak, sSprint, sAttack, sUse;
    private class_5498 prevPerspective;

    public Freecam() {
        super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "freecam++", "Smooth free-flying detached camera with pathing / rotate / sneak options.");
    }

    @Override
    public void onActivate() {
        hasPos = false;
        needInit = true;
        if (!scrollRemembers.get()) scrollMult = 1.0;   // otherwise carry it over
        vel = class_243.field_1353;
        prevPerspective = mc.field_1690 != null ? mc.field_1690.method_31044() : null;
        if (mc.field_1690 != null && !showHands.get()) mc.field_1690.method_31043(class_5498.field_26665);
        if (reloadChunks.get() && mc.field_1769 != null) mc.field_1769.method_3279();
    }

    @Override
    public void onDeactivate() {
        if (mc.field_1690 != null) {
            for (class_304 k : new class_304[]{mc.field_1690.field_1894, mc.field_1690.field_1881, mc.field_1690.field_1913,
                mc.field_1690.field_1849, mc.field_1690.field_1903, mc.field_1690.field_1832, mc.field_1690.field_1886, mc.field_1690.field_1904}) {
                k.method_23481(false);
            }
            if (prevPerspective != null) mc.field_1690.method_31043(prevPerspective);
        }
        if (mc.field_1724 != null) mc.field_1724.method_5728(false);
        if (reloadChunks.get() && mc.field_1769 != null) mc.field_1769.method_3279();
        hasPos = false;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1690 == null) return;

        if (needInit) {
            pos = prevPos = mc.field_1724.method_33571();
            yaw = mc.field_1724.method_36454();
            pitch = mc.field_1724.method_36455();
            sForward = mc.field_1690.field_1894.method_1434();
            sBack = mc.field_1690.field_1881.method_1434();
            sLeft = mc.field_1690.field_1913.method_1434();
            sRight = mc.field_1690.field_1849.method_1434();
            sJump = mc.field_1690.field_1903.method_1434();
            sSneak = mc.field_1690.field_1832.method_1434();
            sSprint = mc.field_1724.method_5624();
            sAttack = mc.field_1690.field_1886.method_1434();
            sUse = mc.field_1690.field_1904.method_1434();
            hasPos = true;
            needInit = false;
        }

        prevPos = pos;            // snapshot for per-frame interpolation
        moveCamera();
        lockBody();
        if (rotate.get()) { mc.field_1724.method_36456(yaw); mc.field_1724.method_36457(pitch); }
        handleActions();
    }


    private void moveCamera() {
        // Typing in chat or sitting in a GUI shouldn't drift the camera — raw key reads don't
        // know a screen is open, which made movement feel like it had a mind of its own.
        if (mc.field_1755 != null) { vel = class_243.field_1353; return; }
        double s = speed.get() * scrollMult;
        // Built with Vec3d.fromPolar, the same way Iekei does it. Hand-rolled sin/cos vectors are
        // where the sideways movement went wrong — the strafe axis came out mirrored.
        class_243 forward = lookFly.get()
            ? class_243.method_1030(pitch, yaw)          // follow the crosshair, pitch included
            : class_243.method_1030(0, yaw);             // stay level
        class_243 right = class_243.method_1030(0, yaw + 90);
        // Build this tick's target velocity from the keys held right now.
        class_243 target = class_243.field_1353;
        if (phys(mc.field_1690.field_1894)) target = target.method_1019(forward);
        if (phys(mc.field_1690.field_1881)) target = target.method_1020(forward);
        if (phys(mc.field_1690.field_1849)) target = target.method_1019(right);
        if (phys(mc.field_1690.field_1913)) target = target.method_1020(right);
        boolean keyUp = phys(mc.field_1690.field_1903), keyDown = phys(mc.field_1690.field_1832);
        if (keyUp) target = target.method_1031(0, 1, 0);
        if (keyDown) target = target.method_1023(0, 1, 0);
        if (target.method_1027() > 0) target = target.method_1029();
        target = target.method_1021(s);

        // The multiplier is applied after the direction is settled, so it changes how fast you rise
        // and fall without bending the direction you are actually heading.
        double vm = verticalSpeed.get();
        if (vm != 1.0) {
            boolean fromKeys = keyUp || keyDown;
            if ((fromKeys && verticalKeys.get()) || (!fromKeys && verticalLook.get()))
                target = new class_243(target.field_1352, target.field_1351 * vm, target.field_1350);
        }
        // Tiny acceleration ramp: ease velocity toward target (smoothing 0 = instant snap).
        double k = 1.0 - smoothing.get();
        vel = vel.method_1019(target.method_1020(vel).method_1021(k));
        if (vel.method_1027() < 1.0e-6) vel = class_243.field_1353;
        pos = pos.method_1019(vel);
    }

    private void lockBody() {
        if (allowPathing.get()) {
            // let Baritone / the player move freely; only enforce sneak if asked
            if (keepSneaking.get()) mc.field_1690.field_1832.method_23481(true);
            return;
        }
        mc.field_1690.field_1894.method_23481(sForward);
        mc.field_1690.field_1881.method_23481(sBack);
        mc.field_1690.field_1913.method_23481(sLeft);
        mc.field_1690.field_1849.method_23481(sRight);
        mc.field_1690.field_1903.method_23481(sJump);
        mc.field_1690.field_1832.method_23481(keepSneaking.get() || sSneak);
        mc.field_1724.method_5728(sSprint);
        mc.field_1690.field_1886.method_23481(false);
        mc.field_1690.field_1904.method_23481(false);
    }

    private int useCooldown;

    /**
     * What your character does while the camera is out.
     *
     * Everything here aims from your real body, not the camera, so a click never swings at whatever
     * happens to be in front of the camera. Each button follows the physical key, so holding is
     * holding and letting go stops. Right click uses whatever you are holding when nothing is in
     * reach, which is what lets rockets keep firing while you fly the camera around.
     */
    private void handleActions() {
        if (mc.field_1761 == null || mc.field_1724 == null || mc.field_1755 != null) return;
        if (useCooldown > 0) useCooldown--;

        boolean real = mineAtCharacter.get() && clickAction.get() == Click.RealBody;
        boolean mine = (keepInputs.get() && sAttack) || (real && holdToMine.get() && phys(mc.field_1690.field_1886));
        boolean use  = (keepInputs.get() && sUse)    || (real && holdToUse.get()  && phys(mc.field_1690.field_1904));
        if (!mine && !use) return;

        class_239 hr = mc.field_1724.method_5745(4.5, 1.0f, false);
        class_3965 bhr = (hr != null && hr.method_17783() == class_239.class_240.field_1332 && hr instanceof class_3965 b) ? b : null;

        if (mine && bhr != null) {
            mc.field_1761.method_2902(bhr.method_17777(), bhr.method_17780());
            mc.field_1724.method_6104(class_1268.field_5808);
        }
        if (use && useCooldown == 0) {
            if (bhr != null) mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, bhr);
            else mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            mc.field_1724.method_6104(class_1268.field_5808);
            useCooldown = 4;                       // vanilla repeats a held right click every four ticks
        }
    }

    private boolean phys(class_304 kb) {
        try {
            int code = class_3675.method_15981(kb.method_1428()).method_1444();
            return org.lwjgl.glfw.GLFW.glfwGetKey(mc.method_22683().method_4490(), code) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
        } catch (Exception e) {
            return kb.method_1434();
        }
    }

    /** Wheel adjusts live fly speed (Iekei parity). Returns true if handled (so the hotbar scroll is cancelled). */
    public boolean consumeScroll(double amount) {
        if (!scrollSpeed.get() || amount == 0) return false;
        if (amount > 0) scrollMult *= scrollStep.get();
        else scrollMult /= scrollStep.get();
        scrollMult = class_3532.method_15350(scrollMult, 0.1, 10.0);
        return true;
    }

    public void applyLook(double dx, double dy) {
        yaw += (float) (dx * sensitivity.get());
        pitch += (float) (dy * sensitivity.get());
        pitch = class_3532.method_15363(pitch, -90f, 90f);
    }

    public boolean hasPos() { return hasPos; }
    /** Interpolated camera position for smooth per-frame rendering. */
    public class_243 getRenderPos(float tickDelta) { return prevPos == null ? pos : prevPos.method_35590(pos, tickDelta); }
    public float getFreecamYaw() { return yaw; }
    public float getFreecamPitch() { return pitch; }
}
