package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_2561;

/** AutoLog — disconnects you when your health drops below a threshold (or a stranger comes close). */
public class AutoLog extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Double> healthLog = sg.add(new DoubleSetting.Builder().name("health").description("Disconnect at/below this health (0 = off).").defaultValue(6).min(0).max(20).sliderRange(0, 20).build());
    private final Setting<Boolean> onPlayer = sg.add(new BoolSetting.Builder().name("on-player").description("Also disconnect when a player comes within range.").defaultValue(false).build());
    private final Setting<Double> playerRange = sg.add(new DoubleSetting.Builder().name("player-range").description("How close a player must be to react (blocks).").defaultValue(32).min(4).sliderRange(8, 128).visible(onPlayer::get).build());

    public AutoLog() { super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "auto-log++", "Auto-disconnect at low health or when a player approaches."); }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || mc.method_1562() == null) return;
        boolean logout = healthLog.get() > 0 && mc.field_1724.method_6032() <= healthLog.get();
        if (!logout && onPlayer.get() && mc.field_1687 != null) {
            for (class_1657 p : mc.field_1687.method_18456())
                if (p != mc.field_1724 && mc.field_1724.method_5739(p) <= playerRange.get()) { logout = true; break; }
        }
        if (logout) {
            mc.method_1562().method_48296().method_10747(class_2561.method_43470("[AutoLog] safety disconnect"));
            toggle();
        }
    }
}
