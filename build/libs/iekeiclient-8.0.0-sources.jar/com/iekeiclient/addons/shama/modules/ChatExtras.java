package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;

/**
 * Chat Extras++ — merged Spam / MessageAura. spam repeats a message on an interval;
 * message-aura sends a line when a player comes within range (cooldown-gated).
 */
public class ChatExtras extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> spam = sg.add(new BoolSetting.Builder().name("repeat-message").description("Repeat a chat message automatically.").defaultValue(false).build());
    private final Setting<String> spamMsg = sg.add(new StringSetting.Builder().name("spam-message").description("The message to repeat.").defaultValue("shama on top").visible(spam::get).build());
    private final Setting<Integer> spamDelay = sg.add(new IntSetting.Builder().name("spam-delay").description("Ticks between spam messages.").defaultValue(200).min(20).sliderRange(20, 600).visible(spam::get).build());
    private final Setting<Boolean> aura = sg.add(new BoolSetting.Builder().name("message-aura").description("Send a message when a player comes near.").defaultValue(false).build());
    private final Setting<String> auraMsg = sg.add(new StringSetting.Builder().name("aura-message").description("The message the aura sends.").defaultValue("caught in 4k").visible(aura::get).build());
    private final Setting<Double> auraRange = sg.add(new DoubleSetting.Builder().name("aura-range").description("How far the message-aura reaches (blocks).").defaultValue(6).min(1).sliderRange(2, 16).visible(aura::get).build());

    private int timer, auraCd;

    public ChatExtras() { super(com.iekeiclient.addons.shama.ShamaAddon.MISC, "chat-extras++", "Chat spam + proximity message-aura."); }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || mc.method_1562() == null) return;
        if (spam.get() && ++timer >= spamDelay.get()) { timer = 0; mc.method_1562().method_45729(spamMsg.get()); }
        if (auraCd > 0) auraCd--;
        if (aura.get() && auraCd == 0 && mc.field_1687 != null) {
            for (class_1657 p : mc.field_1687.method_18456())
                if (p != mc.field_1724 && mc.field_1724.method_5739(p) <= auraRange.get()) {
                    mc.method_1562().method_45729(auraMsg.get()); auraCd = 100; break;
                }
        }
    }
}
