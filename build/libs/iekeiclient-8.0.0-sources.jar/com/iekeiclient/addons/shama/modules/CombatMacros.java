package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import com.iekeiclient.engine.events.world.TickEvent;

/**
 * Combat Macros++ — merged AnchorMacro + WindPearlMacro, fired on a keybind (one action
 * per activation). Anchor: place -> charge -> break a respawn anchor at your crosshair.
 * WindPearl: throw an ender pearl then a wind charge to launch after it.
 */
public class CombatMacros extends Module {
    public enum Which { Anchor, WindPearl }
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Which> which = sg.add(new EnumSetting.Builder<Which>().name("macro").description("The command/text the macro runs.").defaultValue(Which.Anchor).build());
    private int step;

    public CombatMacros() { super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "combat-macros++", "Anchor / wind-pearl combo macros on a keybind."); }

    @Override public void onActivate() { step = 0; }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (which.get() == Which.WindPearl) {
            // throw pearl, then wind charge
            if (use(class_1802.field_8634)) { /* next tick wind charge */ }
            use(class_1802.field_49098);
            toggle();
            return;
        }
        // Anchor macro at crosshair
        if (!(mc.field_1765 instanceof class_3965 hit) || hit.method_17783() != class_239.class_240.field_1332) { toggle(); return; }
        switch (step) {
            case 0 -> { if (swap(class_1802.field_23141)) { mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit); step = 1; } else toggle(); }
            case 1 -> { if (swap(class_1802.field_8801)) { mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit); step = 2; } }
            default -> { mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit); toggle(); }
        }
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private boolean swap(net.minecraft.class_1792 item) {
        int s = InvUtils.findInHotbar(item).slot();
        if (s < 0) return false;
        InvUtils.swap(s, false);
        return true;
    }
    private boolean use(net.minecraft.class_1792 item) {
        if (!swap(item)) return false;
        mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        return true;
    }
}
