package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render2DEvent;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.utils.render.NametagUtils;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.events.world.ChunkDataEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.RenderUtils;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2818;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Spawner Finder++ — ESPs mob spawners and 1.21 trial spawners as chunks load, at any Y
 * (dungeons, XP/loot farms, trial chambers). Consolidates the assorted spawner-detect /
 * spawner-notifier finders into one module. Reads spawners straight from chunk data, so
 * it catches ones the client isn't rendering.
 */
public class SpawnerFinder extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Boolean> mobSpawners = sgGeneral.add(new BoolSetting.Builder()
        .name("mob-spawners").description("Classic mob spawners (dungeons, XP farms).").defaultValue(true).build());

    private final Setting<Boolean> trialSpawners = sgGeneral.add(new BoolSetting.Builder()
        .name("trial-spawners").description("1.21 trial spawners (trial chambers).").defaultValue(true).build());

    private final Setting<Boolean> belowYOnly = sgGeneral.add(new BoolSetting.Builder()
        .name("below-y-only")
        .description("Only report spawners under the height below. Handy when you're hunting stashes and don't care about surface dungeons.")
        .defaultValue(false).build());
    private final Setting<Integer> belowY = sgGeneral.add(new IntSetting.Builder()
        .name("below-y")
        .description("The height that cut-off uses.")
        .defaultValue(0).min(-64).max(320).sliderRange(-64, 64).visible(belowYOnly::get).build());

    private final Setting<Boolean> sound = sgRender.add(new BoolSetting.Builder().name("sound").description("Play a ping when a new spawner is found.").defaultValue(false).build());
    private final Setting<Boolean> chatAlert = sgGeneral.add(new BoolSetting.Builder()
        .name("chat").description("Print each new spawner to chat.").defaultValue(true).build());

    private final Setting<Double> renderDistance = sgRender.add(new DoubleSetting.Builder()
        .name("render-distance").description("How far away (in blocks) things are still drawn.").defaultValue(256).min(16).sliderRange(32, 512).build());

    private final Setting<Boolean> beam = sgRender.add(new BoolSetting.Builder()
        .name("beam").description("Draw a tall vertical beam above each spawner.").defaultValue(false).build());
    private final Setting<Boolean> nametags = sgRender.add(new BoolSetting.Builder()
        .name("nametags").description("Distance label over each spawner.").defaultValue(false).build());
    private final Setting<Boolean> chunkOutline = sgRender.add(new BoolSetting.Builder()
        .name("chunk-outline").description("Outline the chunk each spawner is in.").defaultValue(false).build());
    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
        .name("tracers").description("Draw a line from you to each highlighted thing.").defaultValue(true).build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").description("How boxes are drawn: outline only, filled sides only, or both.").defaultValue(ShapeMode.Both).build());

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("fill-color").description("Colour of the filled part of the box.").defaultValue(new SettingColor(255, 130, 0, 45)).build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color").description("Colour of the box outline.").defaultValue(new SettingColor(255, 130, 0, 255)).build());

    private final Setting<SettingColor> tracerColor = sgRender.add(new ColorSetting.Builder()
        .name("tracer-color").description("Colour of the tracer lines.").defaultValue(new SettingColor(255, 130, 0, 160)).visible(tracers::get).build());

    private final Map<class_2338, String> found = new ConcurrentHashMap<>();
    private final ConcurrentLinkedQueue<String> alerts = new ConcurrentLinkedQueue<>();

    public SpawnerFinder() {
        super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "spawner-finder++", "Highlights mob and trial spawners through terrain, at any height.");
    }

    @Override
    public void onActivate() { found.clear(); alerts.clear(); }

    @Override
    public void onDeactivate() { found.clear(); alerts.clear(); }

    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        if (!(event.chunk() instanceof class_2818 chunk)) return;
        for (Map.Entry<class_2338, class_2586> e : chunk.method_12214().entrySet()) {
            class_2591<?> type = e.getValue().method_11017();
            String label = null;
            if (mobSpawners.get() && type == class_2591.field_11889) label = "spawner";
            else if (trialSpawners.get() && type == class_2591.field_47352) label = "trial spawner";
            if (label == null) continue;
            class_2338 pos = e.getKey().method_10062();
            if (belowYOnly.get() && pos.method_10264() > belowY.get()) continue;   // stash hunting: ignore surface spawners
            if (found.put(pos, label) == null) {
                playPing();
                if (chatAlert.get())
                    alerts.add(String.format("[SpawnerFinder] %s at (%d, %d, %d)", label, pos.method_10263(), pos.method_10264(), pos.method_10260()));
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        String line; int n = 0;
        while ((line = alerts.poll()) != null && n++ < 20) com.iekeiclient.addons.shama.util.Chat.info(line);
    }

    private void playPing() {
        if (sound.get() && mc.field_1687 != null && mc.field_1724 != null)
            mc.field_1687.method_43128(mc.field_1724, mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(),
                net.minecraft.class_3417.field_14627, net.minecraft.class_3419.field_15248, 1.0f, 1.2f);
    }

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if (!nametags.get() || mc.field_1724 == null) return;
        var text = com.iekeiclient.engine.renderer.text.TextRenderer.get();
        for (class_2338 pos : found.keySet()) {
            org.joml.Vector3d p = new org.joml.Vector3d(pos.method_10263() + 0.5, pos.method_10264() + 1.2, pos.method_10260() + 0.5);
            double dist = Math.sqrt(mc.field_1724.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5));
            if (NametagUtils.to2D(p, 1.0)) {
                String label = String.format("Spawner %.0fm", dist);
                double w = text.getWidth(label);
                NametagUtils.begin(p);
                text.beginBig();
                text.render(label, -w / 2, 0, new Color(255, 0, 255, 255));
                text.end();
                NametagUtils.end();
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1724 == null || found.isEmpty()) return;
        double maxSq = renderDistance.get() * renderDistance.get();
        class_243 eye = mc.field_1724.method_33571();
        Color fill = sideColor.get(), line = lineColor.get(), tc = tracerColor.get();
        for (class_2338 pos : found.keySet()) {
            double dx = pos.method_10263() + 0.5 - eye.field_1352, dy = pos.method_10264() + 0.5 - eye.field_1351, dz = pos.method_10260() + 0.5 - eye.field_1350;
            if (dx * dx + dy * dy + dz * dz > maxSq) continue;
            event.renderer.box(pos.method_10263(), pos.method_10264(), pos.method_10260(), pos.method_10263() + 1, pos.method_10264() + 1, pos.method_10260() + 1, fill, line, shapeMode.get(), 0);
            if (tracers.get())
                event.renderer.line(RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, tc);
            if (beam.get())
                event.renderer.line(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5, pos.method_10263() + 0.5, pos.method_10264() + 32, pos.method_10260() + 0.5, line);
            if (chunkOutline.get() && mc.field_1687 != null) {
                double cx0 = (pos.method_10263() >> 4) * 16, cz0 = (pos.method_10260() >> 4) * 16;
                event.renderer.box(cx0, pos.method_10264() - 0.5, cz0, cx0 + 16, pos.method_10264() + 0.5, cz0 + 16, fill, line, shapeMode.get(), 0);
            }
        }
    }

    @Override
    public String getInfoString() { return String.valueOf(found.size()); }
}
