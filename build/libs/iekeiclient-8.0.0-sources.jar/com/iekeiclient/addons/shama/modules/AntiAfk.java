package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;

/** Anti-AFK — performs periodic actions (jump / swing / sneak / strafe / spin) to avoid AFK kicks. */
public class AntiAfk extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> jump = sg.add(new BoolSetting.Builder().name("jump").description("Jump periodically.").defaultValue(true).build());
    private final Setting<Boolean> swing = sg.add(new BoolSetting.Builder().name("swing").description("Swing your hand.").defaultValue(false).build());
    private final Setting<Boolean> sneak = sg.add(new BoolSetting.Builder().name("sneak").description("Sneak/unsneak quickly.").defaultValue(false).build());
    private final Setting<Boolean> strafe = sg.add(new BoolSetting.Builder().name("strafe").description("Alternate left/right steps.").defaultValue(false).build());
    private final Setting<Boolean> spin = sg.add(new BoolSetting.Builder().name("spin").description("Continuously rotate your view.").defaultValue(false).build());
    private final Setting<Integer> spinSpeed = sg.add(new IntSetting.Builder().name("spin-speed").description("How fast to spin while AFK.").defaultValue(10).min(1).max(45).sliderRange(1, 30).visible(spin::get).build());
    private final Setting<Integer> delay = sg.add(new IntSetting.Builder().name("delay").description("Ticks between actions.").defaultValue(20).min(1).max(200).sliderRange(1, 100).build());

    private int tick;
    private boolean strafeSide;

    public AntiAfk() { super(com.iekeiclient.addons.shama.ShamaAddon.MISC, "anti-afk++", "Periodic actions to prevent AFK kicks."); }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1690 == null) return;

        if (spin.get()) mc.field_1724.method_36456(mc.field_1724.method_36454() + spinSpeed.get());

        if (tick++ % Math.max(1, delay.get()) != 0) return;

        if (jump.get() && mc.field_1724.method_24828()) mc.field_1690.field_1903.method_23481(true);
        else mc.field_1690.field_1903.method_23481(false);

        if (swing.get()) mc.field_1724.method_6104(class_1268.field_5808);

        if (sneak.get()) mc.field_1690.field_1832.method_23481(!mc.field_1690.field_1832.method_1434());

        if (strafe.get()) {
            strafeSide = !strafeSide;
            mc.field_1690.field_1913.method_23481(strafeSide);
            mc.field_1690.field_1849.method_23481(!strafeSide);
        }
    }

    @Override
    public void onDeactivate() {
        if (mc.field_1690 != null) {
            mc.field_1690.field_1903.method_23481(false);
            mc.field_1690.field_1832.method_23481(false);
            mc.field_1690.field_1913.method_23481(false);
            mc.field_1690.field_1849.method_23481(false);
        }
    }
}
