package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Player Detector — alerts the moment another player is rendered near you (the server sends
 * their entity, which is what "someone is loading you" looks like client-side). Fires a title
 * popup, a sound, and a chat line, and re-alerts if they leave your range and come back. A
 * name whitelist keeps friends from tripping it. Note: a truly vanished player that the server
 * hides from your client entirely can't be seen by anything — this catches everyone the server
 * actually renders to you, spectators included where the server sends them.
 */
public class PlayerDetector extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

        private final Setting<Integer> alertCooldown = sg.add(new IntSetting.Builder()
        .name("alert-cooldown")
        .description("Don't alert on the same player again for this many seconds. Without it, somebody walking in and out of range — or an entity flickering as you cross a chunk boundary — sets off a fresh alert every time.")
        .defaultValue(30).min(0).max(600).sliderRange(0, 120).build());
    private final Setting<Boolean> realPlayersOnly = sg.add(new BoolSetting.Builder()
        .name("real-players-only")
        .description("Only count entities that also appear in the server's player list. NPCs, shop holograms and other fake players look identical to real ones in the world, and they are the usual reason this module cries wolf.")
        .defaultValue(true).build());

private final Setting<Double> range = sg.add(new DoubleSetting.Builder()
        .name("range").description("Alert when a player is within this many blocks.").defaultValue(128).min(4).sliderRange(16, 256).build());
    private final Setting<List<String>> whitelist = sg.add(new StringListSetting.Builder()
        .name("whitelist").description("Player names to ignore (case-insensitive).").defaultValue(List.of()).build());

    private final Setting<Boolean> popup = sg.add(new BoolSetting.Builder().name("popup").description("Show an on-screen title popup.").defaultValue(true).build());
    private final Setting<Boolean> chat = sg.add(new BoolSetting.Builder().name("chat").description("Send a chat message.").defaultValue(true).build());
    private final Setting<Double> soundVolume = sg.add(new DoubleSetting.Builder().name("volume").description("How loud the alert sound is (0.1 = quiet, 1.0 = full).").defaultValue(1.0).min(0.1).max(1.0).sliderRange(0.1,1.0).build());
    private final Setting<Boolean> highlightChunks = sg.add(new BoolSetting.Builder().name("highlight-chunks").description("Box the chunk each nearby player is standing in.").defaultValue(false).build());
    private final Setting<Boolean> fillChunk = sg.add(new BoolSetting.Builder().name("fill-chunk").description("Fill the player's chunk box instead of just outlining it.").defaultValue(true).visible(highlightChunks::get).build());
    private final Setting<SettingColor> chunkColor = sg.add(new ColorSetting.Builder().name("chunk-color").description("Colour of the player's chunk box.").defaultValue(new SettingColor(255, 60, 60, 180)).visible(highlightChunks::get).build());
    private final Setting<Boolean> sound = sg.add(new BoolSetting.Builder().name("sound").description("Play an alert sound.").defaultValue(true).build());

    private final Set<UUID> seen = new HashSet<>();

    public PlayerDetector() { super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "player-detector++", "Popup / sound / chat when another player renders near you."); }

    @Override public void onActivate() { seen.clear(); }
    @Override public void onDeactivate() { seen.clear(); lastAlert.clear(); }

    private final java.util.Map<UUID, Long> lastAlert = new java.util.HashMap<>();

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        Set<UUID> current = new HashSet<>();
        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724 || !p.method_5805()) continue;
            double dist = mc.field_1724.method_5739(p);
            if (dist > range.get()) continue;
            String name = p.method_5477().getString();
            if (isWhitelisted(name)) continue;
            // Fake players (NPCs, holograms) are in the world but never in the server's player list
            if (realPlayersOnly.get() && mc.method_1562() != null
                && mc.method_1562().method_2871(p.method_5667()) == null) continue;
            current.add(p.method_5667());
            if (!seen.contains(p.method_5667())) {
                long now = System.currentTimeMillis();
                Long last = lastAlert.get(p.method_5667());
                if (last == null || now - last >= alertCooldown.get() * 1000L) {
                    lastAlert.put(p.method_5667(), now);
                    alert(name, dist);
                }
            }
        }
        seen.clear();
        seen.addAll(current);
    }

    private boolean isWhitelisted(String name) {
        for (String w : whitelist.get()) if (w.equalsIgnoreCase(name)) return true;
        return false;
    }

    private void alert(String name, double dist) {
        if (chat.get()) com.iekeiclient.addons.shama.util.Chat.warning("[PlayerDetector] %s within %.0f blocks", name, dist);
        if (popup.get() && mc.field_1705 != null) {
            mc.field_1705.method_34001(2, 30, 8);
            mc.field_1705.method_34004(class_2561.method_43470("Player Nearby").method_27692(class_124.field_1061));
            mc.field_1705.method_34002(class_2561.method_43470(name + " (" + (int) dist + "m)").method_27692(class_124.field_1054));
        }
        if (sound.get() && mc.method_1483() != null) {
            try {
                if (mc.field_1724 != null) mc.field_1687.method_60511(mc.field_1724, mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(),
                    net.minecraft.class_3417.field_14622, net.minecraft.class_3419.field_15248, soundVolume.get().floatValue(), 1.2f);
            } catch (Throwable ignored) {}
        }
    }

    @Override public String getInfoString() { return seen.isEmpty() ? null : seen.size() + " near"; }

    @EventHandler
    private void onRenderChunks(Render3DEvent event) {
        if (!highlightChunks.get() || mc.field_1687 == null || mc.field_1724 == null) return;
        var col = chunkColor.get();
        double bY = mc.field_1687.method_31607(), tY = mc.field_1687.method_31600() + 1;
        for (var pl : mc.field_1687.method_18456()) {
            if (pl == mc.field_1724) continue;
            if (pl.method_5739(mc.field_1724) > range.get()) continue;
            var cp = pl.method_31476();
            double x0 = cp.method_8326(), z0 = cp.method_8328();
            event.renderer.box(x0, bY, z0, x0 + 16, tY, z0 + 16,
                new Color(col.r, col.g, col.b, fillChunk.get() ? 40 : 0), col, ShapeMode.Both, 0);
        }
    }
}
