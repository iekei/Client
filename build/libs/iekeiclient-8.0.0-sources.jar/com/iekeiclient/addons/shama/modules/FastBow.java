package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.EnumSetting;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_3222;
import com.iekeiclient.addons.shama.mixin.LivingEntityAccessor;

/**
 * Fast Bow++ — charge bows/crossbows fast and spam shots.
 *
 * Honesty up front: a bow's power is decided by the SERVER from how many ticks it
 * counted you drawing. A client can't forge that count, so a truly-instant full-power
 * shot is only possible where we control the server:
 *
 *   Full    - auto-release the instant the draw is genuinely full. Legit timing, so it
 *             works on every server and always fires full power. (Default.)
 *   Instant - singleplayer/LAN-host: force the integrated server's player to full draw
 *             and release => a real instant full-power shot. On a remote server there's
 *             no server player to touch, so it just releases early: fast, but weak on
 *             anything that validates draw time (vanilla and all anticheats do).
 *   Rapid   - fire as fast as the use-key lets you re-draw; each arrow is whatever charge
 *             it reached. Good for volume, not power.
 *   Desync  - send a RELEASE_USE_ITEM packet WITHOUT ending the client draw, so you can
 *             emit repeated shots from one draw. A genuine desync trick that some lenient
 *             servers mishandle; strict anticheat will flag or ignore it. Experimental.
 */
public class FastBow extends Module {
    public enum Mode { Full, Instant, Rapid, Desync }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("Release strategy. Full = server-safe full power; Instant = fastest release where the server allows it; Rapid = max fire rate; Desync = experimental server trick.")
        .defaultValue(Mode.Full)
        .build()
    );

    private final Setting<Boolean> bows = sgGeneral.add(new BoolSetting.Builder()
        .name("bows").description("Affect bows (including modded).").defaultValue(true).build());

    private final Setting<Boolean> crossbows = sgGeneral.add(new BoolSetting.Builder()
        .name("crossbows").description("Affect crossbows.").defaultValue(true).build());

    private final Setting<Integer> chargeTime = sgGeneral.add(new IntSetting.Builder()
        .name("charge-time")
        .description("Instant mode on a REMOTE server: ticks to draw before releasing (0 = weakest/instant, 20 = full vanilla). Ignored where you control the server.")
        .defaultValue(0).min(0).sliderRange(0, 40)
        .visible(() -> mode.get() == Mode.Instant)
        .build()
    );

    private final Setting<Boolean> spam = sgGeneral.add(new BoolSetting.Builder()
        .name("hold-to-repeat").description("Auto re-draw and fire again while you hold the use key.").defaultValue(false).build());

    private final Setting<Integer> spamDelay = sgGeneral.add(new IntSetting.Builder()
        .name("spam-delay").description("Ticks between shots for Rapid/Desync/spam.").defaultValue(1).min(0).sliderRange(0, 20).build());

    private int useTicks;
    private int cooldown;

    public FastBow() {
        super(com.iekeiclient.addons.shama.ShamaAddon.COMBAT, "fast-bow++", "Draw bows and crossbows much faster than normal.");
    }

    @Override
    public void onActivate() {
        useTicks = 0;
        cooldown = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (cooldown > 0) cooldown--;

        if (mc.field_1724.method_6115()) {
            class_1799 active = mc.field_1724.method_6030();
            if (!applies(active)) { useTicks = 0; return; }
            useTicks++;

            switch (mode.get()) {
                case Full -> {
                    if (useTicks >= fullDraw(active)) release();
                }
                case Instant -> {
                    if (mc.method_1576() != null) {      // singleplayer / LAN host: genuine instant full power
                        forceServerFull(active);
                        release();
                    } else if (useTicks >= Math.max(0, chargeTime.get())) {
                        release();                      // remote server: early release (weak unless server is lenient)
                    }
                }
                case Rapid -> {
                    if (cooldown <= 0) release();
                }
                case Desync -> {
                    if (cooldown <= 0) {                // fire without ending the client draw
                        sendRawRelease();
                        cooldown = Math.max(1, spamDelay.get());
                    }
                }
            }
        } else {
            useTicks = 0;
            if (spam.get() && cooldown <= 0 && mc.field_1690.field_1904.method_1434()) {
                class_1268 hand = rangedHand();
                if (hand != null) {
                    mc.field_1761.method_2919(mc.field_1724, hand);
                    cooldown = Math.max(1, spamDelay.get());
                }
            }
        }
    }

    /** Release the draw normally (real RELEASE_USE_ITEM via the interaction manager). */
    private void release() {
        mc.field_1761.method_2897(mc.field_1724);
        useTicks = 0;
        cooldown = spamDelay.get();
    }

    /** Send a raw release packet without clearing the client-side draw (Desync). */
    private void sendRawRelease() {
        if (mc.method_1562() == null) return;
        mc.method_1562().method_52787(new class_2846(
            class_2846.class_2847.field_12974, class_2338.field_10980, class_2350.field_11033, 0));
    }

    /**
     * Where you control the server (own worlds / lenient servers): jump the server player's draw
     * counter to full so a full-power arrow is computed on release. No-op and null-safe otherwise.
     */
    private void forceServerFull(class_1799 stack) {
        if (mc.method_1576() == null) return;
        class_3222 sp = mc.method_1576().method_3760().method_14602(mc.field_1724.method_5667());
        if (sp == null || !sp.method_6115()) return;
        LivingEntityAccessor acc = (LivingEntityAccessor) sp;
        int cur = acc.shama$getItemUseTimeLeft();
        acc.shama$setItemUseTimeLeft(Math.max(1, cur - fullDraw(stack)));
    }

    private int fullDraw(class_1799 stack) {
        return stack.method_7909() instanceof class_1764 ? 25 : 20; // vanilla full load / draw
    }

    private boolean applies(class_1799 stack) {
        if (stack == null) return false;
        if (stack.method_7909() instanceof class_1764) return crossbows.get();
        if (stack.method_7909() instanceof class_1811) return bows.get();
        return false;
    }

    private class_1268 rangedHand() {
        if (mc.field_1724.method_6047().method_7909() instanceof class_1811) return class_1268.field_5808;
        if (mc.field_1724.method_6079().method_7909() instanceof class_1811) return class_1268.field_5810;
        return null;
    }

    @Override
    public String getInfoString() {
        return mode.get().name().toLowerCase() + (mc.method_1576() == null && mode.get() == Mode.Instant ? " (remote)" : "");
    }
}
