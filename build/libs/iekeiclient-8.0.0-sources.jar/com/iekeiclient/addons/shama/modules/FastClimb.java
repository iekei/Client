package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;

/** FastClimb++ — climb ladders/vines/scaffolding much faster than vanilla. */
public class FastClimb extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Double> speed = sg.add(new DoubleSetting.Builder().name("speed").description("How fast (higher = faster).").defaultValue(0.5).min(0.1).sliderRange(0.2, 1.5).build());

    public FastClimb() { super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "fast-climb++", "Climb ladders/vines faster."); }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || !mc.field_1724.method_6101()) return;
        class_243 v = mc.field_1724.method_18798();
        double vy = 0;
        if (mc.field_1690.field_1894.method_1434() || mc.field_1690.field_1903.method_1434()) vy = speed.get();
        else if (mc.field_1690.field_1832.method_1434()) vy = -speed.get();
        mc.field_1724.method_18800(v.field_1352, vy, v.field_1350);
    }
}
