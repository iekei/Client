package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.ChunkDataEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2818;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tunnel Finder++ — scans each chunk for long straight air corridors along the 4
 * horizontal directions: a run of air at the same height and axis over 'min-length'
 * with solid floor beneath is a dug tunnel, not a cave, because caves are irregular.
 *
 * The shape ticks decide what counts. A crawl tunnel, a walking tunnel, a two-wide
 * corridor and a three-wide highway all read very differently about who dug them and
 * why, so each is its own option rather than one catch-all.
 */
public class TunnelFinder extends Module {
    private static final class_2350[] DIRS = {class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039};

    private final SettingGroup sg = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Boolean> size1x1 = sg.add(new BoolSetting.Builder()
        .name("1x1")
        .description("Crawl tunnels, one block wide and one high. The cheapest way to cover distance underground, so people digging long-haul routes use them and they are easy to miss.")
        .defaultValue(true).build());
    private final Setting<Boolean> size1x2 = sg.add(new BoolSetting.Builder()
        .name("1x2")
        .description("The ordinary walking tunnel, one wide and two high. By far the most common thing you will find.")
        .defaultValue(true).build());
    private final Setting<Boolean> size2x2 = sg.add(new BoolSetting.Builder()
        .name("2x2")
        .description("Two wide and two high — a main corridor rather than a branch, so it usually leads somewhere worth following.")
        .defaultValue(true).build());
    private final Setting<Boolean> size3x3 = sg.add(new BoolSetting.Builder()
        .name("3x3")
        .description("Three by three. Nobody digs this by hand for fun, so it means a highway, a nether route or something built to move a lot of material.")
        .defaultValue(true).build());

    private final Setting<Integer> minLength = sg.add(new IntSetting.Builder()
        .name("min-length").description("Minimum straight air-corridor length to flag as a tunnel.")
        .defaultValue(8).range(4, 30).sliderRange(5, 20).build());

    private final Setting<Integer> maxY = sg.add(new IntSetting.Builder()
        .name("max-y").description("Only scan below this Y (surface has too many false positives).")
        .defaultValue(40).min(-64).max(320).sliderRange(-64, 64).build());

    private final Setting<Double> renderDistance = sgRender.add(new DoubleSetting.Builder()
        .name("render-distance").description("How far away (in blocks) things are still drawn.").defaultValue(256).min(16).sliderRange(32, 512).build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color").description("Colour of the box outline.").defaultValue(new SettingColor(0, 200, 255, 220)).build());

    // chunkKey -> list of [x1,y1,z1,x2,y2,z2] segments
    private final java.util.Map<Long, List<int[]>> segments = new ConcurrentHashMap<>();

    public TunnelFinder() {
        super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "tunnel-finder++", "Finds long straight tunnels players have dug, including ones far underground you'd never stumble across.");
    }

    @Override
    public void onActivate() { segments.clear(); }

    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        if (!(event.chunk() instanceof class_2818 chunk)) return;
        int bottom = chunk.method_31607();
        int top = Math.min(maxY.get(), chunk.method_31600());
        int cx = chunk.method_12004().method_8326(), cz = chunk.method_12004().method_8328();
        List<int[]> found = new ArrayList<>();
        class_2338.class_2339 m = new class_2338.class_2339();

        for (int y = bottom + 1; y <= top; y++) {
            // scan rows along X and Z within this chunk
            for (int line = 0; line < 16; line++) {
                scanRun(chunk, cx, cz, y, line, true, found, m);
                scanRun(chunk, cx, cz, y, line, false, found, m);
            }
        }
        if (!found.isEmpty()) segments.put(chunk.method_12004().method_8324(), found);
    }

    private void scanRun(class_2818 chunk, int cx, int cz, int y, int line, boolean alongX, List<int[]> found, class_2338.class_2339 m) {
        int run = 0, startPos = 0;
        for (int i = 0; i <= 16; i++) {
            boolean air = false, floor = false;
            if (i < 16) {
                int x = alongX ? cx + i : cx + line;
                int z = alongX ? cz + line : cz + i;
                // width runs across the tunnel, height runs up it
                int side = alongX ? 0 : 1;
                boolean a1 = chunk.method_8320(m.method_10103(x, y, z)).method_26215();
                boolean a2 = chunk.method_8320(m.method_10103(x, y + 1, z)).method_26215();
                boolean roof = !chunk.method_8320(m.method_10103(x, y + 2, z)).method_26215();

                // one and two blocks to the side, for the wider shapes
                int wx = side == 0 ? x : x + 1, wz = side == 0 ? z + 1 : z;
                boolean w1 = chunk.method_8320(m.method_10103(wx, y, wz)).method_26215();
                boolean w2 = chunk.method_8320(m.method_10103(wx, y + 1, wz)).method_26215();
                int w2x = side == 0 ? x : x + 2, w2z = side == 0 ? z + 2 : z;
                boolean t1 = chunk.method_8320(m.method_10103(w2x, y, w2z)).method_26215();
                boolean t3 = chunk.method_8320(m.method_10103(x, y + 2, z)).method_26215();

                boolean is1x1 = size1x1.get() && a1 && !a2;                 // one high, capped
                boolean is1x2 = size1x2.get() && a1 && a2 && roof;          // two high, capped
                boolean is2x2 = size2x2.get() && a1 && a2 && w1 && w2;      // two wide, two high
                boolean is3x3 = size3x3.get() && a1 && a2 && t3 && w1 && t1;

                air = is1x1 || is1x2 || is2x2 || is3x3;
                floor = !chunk.method_8320(m.method_10103(x, y - 1, z)).method_26215();
            }
            if (air && floor) { if (run == 0) startPos = i; run++; }
            else {
                if (run >= minLength.get()) {
                    int x1 = alongX ? cx + startPos : cx + line, z1 = alongX ? cz + line : cz + startPos;
                    int x2 = alongX ? cx + startPos + run - 1 : cx + line, z2 = alongX ? cz + line : cz + startPos + run - 1;
                    found.add(new int[]{x1, y, z1, x2, y, z2});
                }
                run = 0;
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1724 == null || segments.isEmpty()) return;
        double maxSq = renderDistance.get() * renderDistance.get();
        class_243 eye = mc.field_1724.method_33571();
        SettingColor c = lineColor.get();
        for (List<int[]> list : segments.values()) {
            for (int[] s : list) {
                double mx = (s[0] + s[3]) / 2.0, mz = (s[2] + s[5]) / 2.0;
                double dx = mx - eye.field_1352, dz = mz - eye.field_1350;
                if (dx * dx + dz * dz > maxSq) continue;
                event.renderer.line(s[0] + 0.5, s[1] + 0.5, s[2] + 0.5, s[3] + 0.5, s[4] + 0.5, s[5] + 0.5, c);
            }
        }
    }

    @Override
    public String getInfoString() { return segments.size() + " chunks"; }
}
