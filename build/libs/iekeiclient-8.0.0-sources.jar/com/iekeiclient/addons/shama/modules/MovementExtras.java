package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_3675;

/**
 * Movement Extras++ — merged minor movement tweaks with tickboxes:
 *   gui-move       : keep walking with WASD while a screen (chest/inventory) is open.
 *   entity-control : steer the entity you're riding (pig/boat/horse) with WASD + look.
 *   slippy         : reduce ground friction so you slide like on ice.
 *   reverse-step    : step DOWN small ledges smoothly instead of walking off and falling.
 */
public class MovementExtras extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> guiMove = sg.add(new BoolSetting.Builder().name("gui-move").description("Keep moving while a screen is open.").defaultValue(false).build());
    private final Setting<Boolean> entityControl = sg.add(new BoolSetting.Builder().name("entity-control").description("Steer the entity you're riding.").defaultValue(false).build());
    private final Setting<Boolean> slippy = sg.add(new BoolSetting.Builder().name("slippy").description("Make movement slippery like ice.").defaultValue(false).build());
    private final Setting<Double> slipAmount = sg.add(new DoubleSetting.Builder().name("slip-amount").description("How slippery movement is.").defaultValue(1.5).min(1).sliderRange(1, 4).visible(slippy::get).build());
    private final Setting<Boolean> reverseStep = sg.add(new BoolSetting.Builder().name("reverse-step").description("Step down off edges smoothly instead of falling.").defaultValue(false).build());

    public MovementExtras() {
        super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "movement-extras++", "GUI-move / entity-control / slippy / reverse-step in one module.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null) return;

        // gui-move: force the movement keybinds from physical key state while a screen is open
        if (guiMove.get() && mc.field_1755 != null) {
            force(mc.field_1690.field_1894);
            force(mc.field_1690.field_1881);
            force(mc.field_1690.field_1913);
            force(mc.field_1690.field_1849);
            force(mc.field_1690.field_1903);
            force(mc.field_1690.field_1832);
        }

        // entity-control: drive the ridden entity toward your look with WASD
        if (entityControl.get() && mc.field_1724.method_5765()) {
            class_1297 v = mc.field_1724.method_5854();
            double mx = 0, mz = 0, rad = Math.toRadians(mc.field_1724.method_36454());
            class_243 f = new class_243(-Math.sin(rad), 0, Math.cos(rad));
            class_243 r = new class_243(Math.cos(rad), 0, Math.sin(rad));
            if (mc.field_1690.field_1894.method_1434()) { mx += f.field_1352; mz += f.field_1350; }
            if (mc.field_1690.field_1881.method_1434()) { mx -= f.field_1352; mz -= f.field_1350; }
            if (mc.field_1690.field_1849.method_1434()) { mx += r.field_1352; mz += r.field_1350; }
            if (mc.field_1690.field_1913.method_1434()) { mx -= r.field_1352; mz -= r.field_1350; }
            double vy = mc.field_1690.field_1903.method_1434() ? 0.42 : v.method_18798().field_1351;
            if (mx != 0 || mz != 0) v.method_18800(mx * 0.4, vy, mz * 0.4);
            v.method_36456(mc.field_1724.method_36454());
        }

        // slippy: amplify horizontal velocity on ground
        if (slippy.get() && mc.field_1724.method_24828()) {
            class_243 vel = mc.field_1724.method_18798();
            mc.field_1724.method_18800(vel.field_1352 * slipAmount.get(), vel.field_1351, vel.field_1350 * slipAmount.get());
        }

        // reverse-step: if walking off a 1-block ledge, drop straight down instead of arcing
        if (reverseStep.get() && mc.field_1724.method_24828() && !mc.field_1724.method_5715()) {
            class_243 vel = mc.field_1724.method_18798();
            if ((vel.field_1352 != 0 || vel.field_1350 != 0)) {
                var below = mc.field_1724.method_24515().method_10074();
                if (mc.field_1687 != null && mc.field_1687.method_8320(below).method_26220(mc.field_1687, below).method_1110()) {
                    // small assisted descend
                    mc.field_1724.method_18800(vel.field_1352, -0.3, vel.field_1350);
                }
            }
        }
    }

    private void force(class_304 kb) {
        try {
            int code = class_3675.method_15981(kb.method_1428()).method_1444();
            kb.method_23481(org.lwjgl.glfw.GLFW.glfwGetKey(mc.method_22683().method_4490(), code) == org.lwjgl.glfw.GLFW.GLFW_PRESS);
        } catch (Exception ignored) {}
    }

    @Override
    public void onDeactivate() {
        if (mc.field_1690 == null) return;
        for (class_304 k : new class_304[]{mc.field_1690.field_1894, mc.field_1690.field_1881, mc.field_1690.field_1913, mc.field_1690.field_1849, mc.field_1690.field_1903, mc.field_1690.field_1832})
            k.method_23481(false);
    }

    @Override public String getInfoString() {
        StringBuilder b = new StringBuilder();
        if (guiMove.get()) b.append("gui ");
        if (entityControl.get()) b.append("control ");
        if (slippy.get()) b.append("slip ");
        if (reverseStep.get()) b.append("rstep");
        return b.length() == 0 ? "off" : b.toString().trim();
    }
}
