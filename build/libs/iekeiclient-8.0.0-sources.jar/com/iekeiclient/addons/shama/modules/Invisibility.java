package com.iekeiclient.addons.shama.modules;

import com.mojang.datafixers.util.Pair;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2744;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.List;

/**
 * Invisibility++ — honest about each side:
 *
 *  - Singleplayer / your own LAN world: REAL invisibility. We apply the effect to
 *    the server-side you AND force the invisible flag, so mobs lose you and any
 *    other players in your world can't see your body. With hide-equipment on, we
 *    also blank your armor/held items to those players, so there's nothing left to
 *    see (vanilla invis still shows gear; this removes it).
 *  - Real servers: client-side self-invis only — you render invisible to yourself.
 *    Other players still see you; the server controls what they render and nothing
 *    purely client-side changes that.
 */
public class Invisibility extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> clientSelf = sgGeneral.add(new BoolSetting.Builder()
        .name("client-self")
        .description("Render yourself invisible on your own screen (cosmetic; doesn't affect what others see).")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> serverSp = sgGeneral.add(new BoolSetting.Builder()
        .name("true-invisible")
        .description("In your own world, apply real invisibility server-side so mobs and other players in your world can't see you. No effect on real servers.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> hideEquipment = sgGeneral.add(new BoolSetting.Builder()
        .name("hide-equipment")
        .description("Also hide your armor and held items from other players, so invisibility doesn't give you away by showing floating gear. How well this holds up depends on the server.")
        .defaultValue(true)
        .build()
    );

    public Invisibility() {
        super(com.iekeiclient.addons.shama.ShamaAddon.PLAYER, "invisibility++", "Turns you invisible to other players and mobs. How complete the invisibility is depends on the server.");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null) return;

        // Client-side self view.
        if (clientSelf.get())
            mc.field_1724.method_6092(new class_1293(class_1294.field_5905, 40, 0, false, false));

        // Singleplayer / LAN: real, broadcast to everyone tracking you.
        if (serverSp.get() && mc.method_1576() != null) {
            class_3222 sp = mc.method_1576().method_3760().method_14602(mc.field_1724.method_5667());
            if (sp != null) {
                sp.method_6092(new class_1293(class_1294.field_5905, 60, 0, false, false));
                sp.method_5648(true);
                if (hideEquipment.get()) sendEquipment(sp, true);
            }
        }
    }

    @Override
    public void onDeactivate() {
        if (mc.field_1724 != null) mc.field_1724.method_6016(class_1294.field_5905);
        if (mc.method_1576() != null && mc.field_1724 != null) {
            class_3222 sp = mc.method_1576().method_3760().method_14602(mc.field_1724.method_5667());
            if (sp != null) {
                sp.method_6016(class_1294.field_5905);
                sp.method_5648(false);
                sendEquipment(sp, false); // restore real gear to other players
            }
        }
    }

    /** Push an equipment update for sp to every OTHER player in the world — empty
     *  stacks to hide, real stacks to restore. SP/LAN only; wrapped so any API
     *  drift can't crash the module. */
    private void sendEquipment(class_3222 sp, boolean blank) {
        try {
            List<Pair<class_1304, class_1799>> list = new ArrayList<>();
            for (class_1304 slot : class_1304.values())
                list.add(Pair.of(slot, blank ? class_1799.field_8037 : sp.method_6118(slot)));
            class_2744 packet = new class_2744(sp.method_5628(), list);
            for (class_3222 other : mc.method_1576().method_3760().method_14571()) {
                if (other != sp && other.field_13987 != null) other.field_13987.method_14364(packet);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public String getInfoString() {
        return mc.method_1576() != null ? "real" : "client";
    }
}
