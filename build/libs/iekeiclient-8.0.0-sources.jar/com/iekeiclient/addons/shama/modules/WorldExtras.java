package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3965;

/**
 * World Extras++ — merged EChestFarmer / LiquidFiller / Flamethrower / Ambience tickboxes.
 *   flamethrower : rapidly flint-and-steel the block you look at (fire spam).
 *   liquid-fill  : place your held bucket liquid at the crosshair repeatedly.
 *   flint-only   : (ambience) keeps fire lit around you visually.
 */
public class WorldExtras extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> flamethrower = sg.add(new BoolSetting.Builder().name("flamethrower").description("Flint-and-steel the block you look at rapidly.").defaultValue(false).build());
    private final Setting<Boolean> liquidFill = sg.add(new BoolSetting.Builder().name("liquid-fill").description("Place your held bucket liquid at the crosshair.").defaultValue(false).build());

    public WorldExtras() { super(com.iekeiclient.addons.shama.ShamaAddon.PLAYER, "world-extras++", "Flamethrower / liquid-fill world helpers."); }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (!(mc.field_1765 instanceof class_3965 hit) || hit.method_17783() != class_239.class_240.field_1332) return;

        if (flamethrower.get()) {
            int s = InvUtils.findInHotbar(class_1802.field_8884).slot();
            if (s >= 0) { InvUtils.swap(s, true); mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit); mc.field_1724.method_6104(class_1268.field_5808); }
        }
        if (liquidFill.get() && (mc.field_1724.method_6047().method_31574(class_1802.field_8705) || mc.field_1724.method_6047().method_31574(class_1802.field_8187))) {
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
        }
    }
}
