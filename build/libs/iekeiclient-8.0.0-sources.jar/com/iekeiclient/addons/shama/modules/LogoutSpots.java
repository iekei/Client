package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import java.util.HashMap;
import java.util.Map;

/**
 * Logout Spots++ — remembers where other players vanish. A player entity that was near
 * you last tick and is gone this tick (without you leaving render range) logged out
 * there — a prime spot to dig for a stash/base. Boxes each logout position.
 */
public class LogoutSpots extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> chatAlert = sg.add(new BoolSetting.Builder().name("chat").description("Print a chat message on a new find.").defaultValue(true).build());
    private final Setting<SettingColor> color = sg.add(new ColorSetting.Builder().name("color").description("Highlight colour.").defaultValue(new SettingColor(255, 0, 255, 90)).build());

    private final Map<Integer, class_243> lastSeen = new HashMap<>();
    private final Map<String, class_243> logouts = new HashMap<>();

    public LogoutSpots() { super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "logout-spots++", "Marks where other players log out."); }

    @Override public void onActivate() { lastSeen.clear(); logouts.clear(); }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        Map<Integer, class_243> current = new HashMap<>();
        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == mc.field_1724) continue;
            current.put(p.method_5628(), new net.minecraft.class_243(p.method_23317(), p.method_23318(), p.method_23321()));
        }
        // any id seen last tick, missing now, and within ~a chunk of where it was => logout
        for (Map.Entry<Integer, class_243> e : lastSeen.entrySet()) {
            if (!current.containsKey(e.getKey())) {
                class_243 pos = e.getValue();
                if (new net.minecraft.class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()).method_1022(pos) < 160) {
                    String key = (int) pos.field_1352 + "," + (int) pos.field_1351 + "," + (int) pos.field_1350;
                    if (logouts.put(key, pos) == null && chatAlert.get())
                        com.iekeiclient.addons.shama.util.Chat.info("[LogoutSpots] player logged out at (%d, %d, %d)", (int) pos.field_1352, (int) pos.field_1351, (int) pos.field_1350);
                }
            }
        }
        lastSeen.clear();
        lastSeen.putAll(current);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        Color c = color.get(); Color line = new Color(c.r, c.g, c.b, 255);
        for (class_243 p : logouts.values())
            event.renderer.box(p.field_1352 - 0.5, p.field_1351, p.field_1350 - 0.5, p.field_1352 + 0.5, p.field_1351 + 2, p.field_1350 + 0.5, c, line, ShapeMode.Both, 0);
    }

    @Override public String getInfoString() { return logouts.size() + " spots"; }
}
