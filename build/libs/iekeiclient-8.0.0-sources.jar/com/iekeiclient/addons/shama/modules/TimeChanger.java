package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;

/** Time Changer — sets a custom client-side world time. */
public class TimeChanger extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Integer> time = sg.add(new IntSetting.Builder().name("time").description("Time of day to force (0 = dawn, 6000 = noon, 18000 = midnight).").defaultValue(6000).min(0).max(24000).sliderRange(0, 24000).build());

    public TimeChanger() { super(com.iekeiclient.addons.shama.ShamaAddon.MISC, "time-changer++", "Force a custom client-side time of day."); }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1687 == null) return;
        if (mc.field_1687.method_28104() instanceof net.minecraft.class_638.class_5271 props)
            props.method_165(time.get().longValue());
    }
}
