package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2846;
import net.minecraft.class_3965;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/**
 * Miner++ — merged mining tools with per-method tickboxes (VeinMiner / PacketMine /
 * Excavator). Enable one; while you hold attack on a block it applies that method.
 * Full effect in singleplayer / on lenient servers; strict anti-cheats cap break rate.
 */
public class Miner extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> vein = sg.add(new BoolSetting.Builder().name("vein-miner").description("Break all connected same-type blocks around the target.").defaultValue(true).build());
    private final Setting<Boolean> packet = sg.add(new BoolSetting.Builder().name("packet-mine").description("Fire raw start+stop destroy packets (instant on lenient servers).").defaultValue(false).build());
    private final Setting<Boolean> excavate = sg.add(new BoolSetting.Builder().name("excavator").description("Break every block in a radius around the target (nuker-style area).").defaultValue(false).build());
    private final Setting<Boolean> infinity = sg.add(new BoolSetting.Builder().name("infinity-miner").description("Auto-hold mine on whatever block you look at (no need to hold click).").defaultValue(false).build());
    private final Setting<Integer> radius = sg.add(new IntSetting.Builder().name("radius").description("Vein/excavator search radius.").defaultValue(3).range(1, 6).sliderRange(1, 6).build());
    private final Setting<Integer> perTick = sg.add(new IntSetting.Builder().name("blocks-per-tick").description("Max blocks to send per tick (kick safety).").defaultValue(16).range(1, 128).sliderRange(4, 64).build());

    public Miner() {
        super(com.iekeiclient.addons.shama.ShamaAddon.PLAYER, "miner++", "Mines for you — vein mining, fast packet mining, or a wide excavator, all in one module.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null || mc.method_1562() == null) return;
        boolean mining = mc.field_1690.field_1886.method_1434();
        if (infinity.get() && mc.field_1765 instanceof class_3965 ih && ih.method_17783() == class_239.class_240.field_1332) {
            mc.field_1761.method_2902(ih.method_17777(), ih.method_17780());
            mc.field_1724.method_6104(class_1268.field_5808);
            mining = true;
        }
        if (!mining) return;
        if (!(mc.field_1765 instanceof class_3965 hit) || hit.method_17783() != class_239.class_240.field_1332) return;

        class_2338 origin = hit.method_17777();
        class_2350 side = hit.method_17780();
        int budget = perTick.get();

        if (excavate.get()) {
            int r = radius.get();
            for (int dx = -r; dx <= r && budget > 0; dx++)
                for (int dy = -r; dy <= r && budget > 0; dy++)
                    for (int dz = -r; dz <= r && budget > 0; dz++) {
                        class_2338 p = origin.method_10069(dx, dy, dz);
                        if (mc.field_1687.method_8320(p).method_26215()) continue;
                        breakBlock(p, side); budget--;
                    }
            return;
        }

        if (vein.get()) {
            class_2248 target = mc.field_1687.method_8320(origin).method_26204();
            if (target == null) return;
            int r = radius.get();
            Set<class_2338> seen = new HashSet<>();
            ArrayDeque<class_2338> q = new ArrayDeque<>();
            q.add(origin); seen.add(origin);
            while (!q.isEmpty() && budget > 0) {
                class_2338 p = q.poll();
                if (mc.field_1687.method_8320(p).method_26204() != target) continue;
                breakBlock(p, side); budget--;
                for (class_2350 d : class_2350.values()) {
                    class_2338 n = p.method_10093(d);
                    if (seen.add(n) && n.method_19771(origin, r + 0.5)) q.add(n);
                }
            }
            return;
        }

        if (packet.get()) breakBlock(origin, side);
    }

    private void breakBlock(class_2338 pos, class_2350 side) {
        var nh = mc.method_1562();
        nh.method_52787(new class_2846(class_2846.class_2847.field_12968, pos, side, 0));
        nh.method_52787(new class_2846(class_2846.class_2847.field_12973, pos, side, 0));
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    @Override
    public String getInfoString() {
        return excavate.get() ? "excavate" : vein.get() ? "vein" : packet.get() ? "packet" : "off";
    }
}
