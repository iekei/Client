package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_243;

/** Reverse Step — drop down small ledges quickly instead of the slow vanilla fall arc. */
public class ReverseStep extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Double> fallSpeed = sg.add(new DoubleSetting.Builder().name("fall-speed").description("Downward speed applied when dropping (blocks/tick).").defaultValue(3.0).min(0.1).sliderRange(0.5, 6).build());
    private final Setting<Double> fallDistance = sg.add(new DoubleSetting.Builder().name("fall-distance").description("Only trigger when ground is within this many blocks below.").defaultValue(3.0).min(0.5).sliderRange(1, 8).build());
    private final Setting<Boolean> vehicles = sg.add(new BoolSetting.Builder().name("vehicles").description("Also affect vehicles you're riding.").defaultValue(false).build());

    public ReverseStep() { super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "reverse-step++", "Fall down small ledges instantly."); }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1724.method_5765() && !vehicles.get()) return;
        if (mc.field_1724.method_24828()) return;
        class_243 v = mc.field_1724.method_18798();
        if (v.field_1351 > 0.0) return; // only while descending

        double x = mc.field_1724.method_23317(), y = mc.field_1724.method_23318(), z = mc.field_1724.method_23321();
        boolean groundBelow = false;
        for (double d = 0.5; d <= fallDistance.get() + 1; d += 0.5) {
            if (!mc.field_1687.method_8320(class_2338.method_49637(x, y - d, z)).method_26215()) { groundBelow = true; break; }
        }
        if (groundBelow) mc.field_1724.method_18800(v.field_1352, -fallSpeed.get(), v.field_1350);
    }
}
