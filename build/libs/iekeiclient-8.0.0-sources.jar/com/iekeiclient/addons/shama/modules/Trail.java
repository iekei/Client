package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import java.util.ArrayDeque;
import java.util.Deque;

/** Trail — draws a fading line trail behind you as you move. */
public class Trail extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Integer> length = sg.add(new IntSetting.Builder().name("length").description("How many points to keep.").defaultValue(80).min(2).max(400).sliderRange(10, 200).build());
    private final Setting<SettingColor> color = sg.add(new ColorSetting.Builder().name("color").description("Highlight colour.").defaultValue(new SettingColor(120, 200, 255, 200)).build());
    private final Setting<Boolean> fade = sg.add(new BoolSetting.Builder().name("fade").description("Fade the tail out.").defaultValue(true).build());

    private final Deque<class_243> points = new ArrayDeque<>();

    public Trail() { super(com.iekeiclient.addons.shama.ShamaAddon.MISC, "trail++", "A fading trail behind you."); }

    @Override public void onActivate() { points.clear(); }
    @Override public void onDeactivate() { points.clear(); }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null) return;
        points.addLast(new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()));
        while (points.size() > length.get()) points.removeFirst();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (points.size() < 2) return;
        Color base = color.get();
        class_243 prev = null;
        int i = 0, n = points.size();
        for (class_243 p : points) {
            if (prev != null) {
                int a = fade.get() ? (int) (base.a * (i / (double) n)) : base.a;
                Color c = new Color(base.r, base.g, base.b, a);
                event.renderer.line(prev.field_1352, prev.field_1351 + 0.1, prev.field_1350, p.field_1352, p.field_1351 + 0.1, p.field_1350, c);
            }
            prev = p; i++;
        }
    }
}
