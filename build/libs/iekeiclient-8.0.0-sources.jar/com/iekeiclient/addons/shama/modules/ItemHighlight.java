package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_238;

/** Item Highlight — boxes dropped items on the ground so they're easy to spot. */
public class ItemHighlight extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> colorByRarity = sg.add(new BoolSetting.Builder()
        .name("color-by-rarity")
        .description("Colour each item by how rare it is instead of using one flat colour: white common, yellow uncommon, pink rare, purple epic. Enchanted items get the rare colour too.")
        .defaultValue(true).build());
    private final Setting<SettingColor> line = sg.add(new ColorSetting.Builder().name("line-color").description("Colour of the box outline when rarity colouring is off.").defaultValue(new SettingColor(255, 255, 0, 220)).visible(() -> !colorByRarity.get()).build());
    private final Setting<SettingColor> side = sg.add(new ColorSetting.Builder().name("fill-color").description("Colour of the box sides when rarity colouring is off.").defaultValue(new SettingColor(255, 255, 0, 40)).visible(() -> !colorByRarity.get()).build());
    private final Setting<SettingColor> commonColor = sg.add(new ColorSetting.Builder().name("common-color").description("Colour for ordinary items.").defaultValue(new SettingColor(220, 220, 220, 220)).visible(colorByRarity::get).build());
    private final Setting<SettingColor> uncommonColor = sg.add(new ColorSetting.Builder().name("uncommon-color").description("Colour for uncommon items.").defaultValue(new SettingColor(255, 255, 85, 220)).visible(colorByRarity::get).build());
    private final Setting<SettingColor> rareColor = sg.add(new ColorSetting.Builder().name("rare-color").description("Colour for rare and enchanted items.").defaultValue(new SettingColor(255, 105, 180, 220)).visible(colorByRarity::get).build());
    private final Setting<SettingColor> epicColor = sg.add(new ColorSetting.Builder().name("epic-color").description("Colour for epic items.").defaultValue(new SettingColor(180, 80, 255, 220)).visible(colorByRarity::get).build());
    private final Setting<Integer> fillAlpha = sg.add(new IntSetting.Builder().name("fill-alpha").description("How solid the filled sides are when colouring by rarity.").defaultValue(40).min(0).max(255).sliderRange(0, 120).visible(colorByRarity::get).build());

    private final Setting<Boolean> tracers = sg.add(new BoolSetting.Builder().name("tracers").description("Draw a line from you to each highlighted thing.").defaultValue(false).build());
    private final Setting<ShapeMode> shapeMode = sg.add(new EnumSetting.Builder<ShapeMode>().name("shape-mode").description("How boxes are drawn: outline only, filled sides only, or both.").defaultValue(ShapeMode.Both).build());

    public ItemHighlight() { super(com.iekeiclient.addons.shama.ShamaAddon.MISC, "item-highlight++", "Highlights dropped items on the ground."); }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1687 == null) return;
        Color l = line.get(), s = side.get();
        var cam = com.iekeiclient.engine.utils.render.RenderUtils.center;
        for (var e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1542 item)) continue;
            Color il = l, is = s;
            if (colorByRarity.get()) {
                il = rarityColor(item.method_6983());
                is = new Color(il.r, il.g, il.b, fillAlpha.get());
            }
            class_238 b = item.method_5829();
            event.renderer.box(b.field_1323, b.field_1322, b.field_1321, b.field_1320, b.field_1325, b.field_1324, is, il, shapeMode.get(), 0);
            if (tracers.get()) event.renderer.line(cam.field_1352, cam.field_1351, cam.field_1350, item.method_23317(), item.method_23318(), item.method_23321(), il);
        }
    }

    /** Enchanted counts as rare even when the base item is common. */
    private Color rarityColor(class_1799 stack) {
        try {
            if (stack.method_7942()) return rareColor.get();
            class_1814 r = stack.method_7932();
            if (r == class_1814.field_8904) return epicColor.get();
            if (r == class_1814.field_8903) return rareColor.get();
            if (r == class_1814.field_8907) return uncommonColor.get();
        } catch (Throwable ignored) {}
        return commonColor.get();
    }
}
