package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.ChunkDataEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_243;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Signal Scanner++ — flags chunks packed with redstone/automation blocks (hoppers, comparators, observers, pistons, droppers, dispensers) = contraptions/farms. */
public class SignalScanner extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");
    private final Setting<Integer> threshold = sg.add(new IntSetting.Builder().name("threshold").description("Redstone components per chunk to flag.").defaultValue(8).range(1, 60).sliderRange(2, 40).build());
    private final Setting<Boolean> hopperEsp = sg.add(new BoolSetting.Builder().name("hopper-esp").description("Also box individual hoppers/droppers/dispensers (merged from HopperESP).").defaultValue(false).build());
    private final Setting<Boolean> lightAnomalies = sg.add(new BoolSetting.Builder().name("light-anomalies").description("Also add score for light-emitting blocks below Y0 (hidden underground lighting = base).").defaultValue(true).build());
    private final Setting<Double> boxY = sgRender.add(new DoubleSetting.Builder().name("box-y").description("The Y height to draw the box/marker at.").defaultValue(70).min(-64).max(320).sliderRange(-64, 320).build());
    private final Setting<Double> renderDistance = sgRender.add(new DoubleSetting.Builder().name("render-distance").description("How far away (in blocks) things are still drawn.").defaultValue(512).min(32).sliderRange(64, 1024).build());
    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder().name("line-color").description("Colour of the box outline.").defaultValue(new SettingColor(255, 0, 0, 230)).build());

    private final SettingGroup sgConnected = settings.createGroup("Connected Scan");
    private final Setting<Boolean> connectedScan = sgConnected.add(new BoolSetting.Builder().name("connected-scan").description("Live-scan the blocks below a Y line for clusters of connected redstone/rails/hoppers (contraptions you haven\'t rendered the chunk-data for yet).").defaultValue(false).build());
    private final Setting<Integer> connScanRadius = sgConnected.add(new IntSetting.Builder().name("conn-scan-radius").description("Chunk radius for the live connected-scan.").defaultValue(6).min(1).max(16).visible(connectedScan::get).build());
    private final Setting<Integer> connMaxY = sgConnected.add(new IntSetting.Builder().name("conn-max-y").description("Only scan blocks at or below this Y.").defaultValue(0).min(-64).max(64).visible(connectedScan::get).build());
    private final Setting<Integer> connMin = sgConnected.add(new IntSetting.Builder().name("conn-min-connected").description("Connected blocks a chunk needs to flag.").defaultValue(2).min(1).max(64).visible(connectedScan::get).build());
    private final Setting<Boolean> connRails = sgConnected.add(new BoolSetting.Builder().name("conn-rails").description("Count rails.").defaultValue(true).visible(connectedScan::get).build());
    private final Setting<Boolean> connRedstone = sgConnected.add(new BoolSetting.Builder().name("conn-redstone").description("Count redstone components (wire/repeaters/pistons…).").defaultValue(true).visible(connectedScan::get).build());
    private final Setting<Boolean> connHoppers = sgConnected.add(new BoolSetting.Builder().name("conn-hoppers").description("Count hoppers.").defaultValue(true).visible(connectedScan::get).build());
    private final Setting<SettingColor> connColor = sgConnected.add(new ColorSetting.Builder().name("connected-scan-color").description("Colour for connected-scan chunks.").defaultValue(new SettingColor(0, 200, 255, 200)).visible(connectedScan::get).build());

    private final Map<Long, Integer> scores = new ConcurrentHashMap<>();
    private final java.util.Set<net.minecraft.class_2338> hoppers = ConcurrentHashMap.newKeySet();
    private final java.util.Set<Long> connectedChunks = ConcurrentHashMap.newKeySet();
    private int connTick;

    public SignalScanner() { super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "signal-scanner++", "Hunts for the redstone and wiring signatures that give away hidden bases and farms."); }

    @Override public void onActivate() { scores.clear(); hoppers.clear(); connectedChunks.clear(); }

    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        if (!(event.chunk() instanceof class_2818 chunk)) return;
        int n = 0;
        net.minecraft.class_2826[] secs = chunk.method_12006();
        for (int si = 0; si < secs.length; si++) {
            class_2826 s = secs[si];
            if (s == null || s.method_38292()) continue;
            int baseY = chunk.method_31607() + (si << 4);
            for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
                var st = s.method_12254(x, y, z);
                String p = com.iekeiclient.addons.shama.util.BlockPaths.of(st.method_26204());
                if (p.equals("hopper") || p.equals("comparator") || p.equals("repeater") || p.equals("observer")
                    || p.equals("dropper") || p.equals("dispenser") || p.endsWith("piston") || p.equals("redstone_wire")
                    || p.equals("redstone_torch") || p.equals("target")) n++;
                else if (lightAnomalies.get() && baseY + y < 0 && st.method_26213() > 0) n++; // underground light source
            }
        }
        if (hopperEsp.get())
            for (java.util.Map.Entry<net.minecraft.class_2338, net.minecraft.class_2586> e : chunk.method_12214().entrySet())
                if (e.getValue() instanceof net.minecraft.class_2614 || e.getValue() instanceof net.minecraft.class_2601)
                    hoppers.add(e.getKey().method_10062());
        if (n > 0) scores.put(chunk.method_12004().method_8324(), n); else scores.remove(chunk.method_12004().method_8324());
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (mc.field_1724 == null || scores.isEmpty()) return;
        double maxSq = renderDistance.get() * renderDistance.get();
        class_243 eye = mc.field_1724.method_33571();
        double y = boxY.get();
        Color line = lineColor.get(), fill = new Color(line.r, line.g, line.b, 45);
        for (Map.Entry<Long, Integer> e : scores.entrySet()) {
            if (e.getValue() < threshold.get()) continue;
            class_1923 cp = new class_1923(e.getKey());
            double x0 = cp.field_9181 * 16, z0 = cp.field_9180 * 16;
            double dx = x0 + 8 - eye.field_1352, dz = z0 + 8 - eye.field_1350;
            if (dx * dx + dz * dz > maxSq) continue;
            event.renderer.box(x0, y, z0, x0 + 16, y + 1, z0 + 16, fill, line, ShapeMode.Both, 0);
        }
        if (hopperEsp.get()) {
            Color hf = new Color(180, 180, 180, 40), hl = new Color(180, 180, 180, 220);
            for (net.minecraft.class_2338 hp : hoppers) {
                double dx = hp.method_10263() + 0.5 - eye.field_1352, dz = hp.method_10260() + 0.5 - eye.field_1350;
                if (dx * dx + dz * dz > maxSq) continue;
                event.renderer.box(hp.method_10263(), hp.method_10264(), hp.method_10260(), hp.method_10263() + 1, hp.method_10264() + 1, hp.method_10260() + 1, hf, hl, ShapeMode.Both, 0);
            }
        }
    }

    private boolean isConnTarget(net.minecraft.class_2248 b) {
        String p = com.iekeiclient.addons.shama.util.BlockPaths.of(b);
        if (connHoppers.get() && p.equals("hopper")) return true;
        if (connRails.get() && p.endsWith("rail")) return true;
        if (connRedstone.get() && (p.equals("redstone_wire") || p.equals("repeater") || p.equals("comparator")
            || p.equals("redstone_torch") || p.equals("redstone_wall_torch") || p.equals("observer")
            || p.endsWith("piston") || p.equals("dropper") || p.equals("dispenser"))) return true;
        return false;
    }

    @EventHandler
    private void onConnTick(com.iekeiclient.engine.events.world.TickEvent.Post event) {
        if (!connectedScan.get() || mc.field_1687 == null || mc.field_1724 == null) return;
        if (++connTick % 20 != 0) return;
        class_1923 center = mc.field_1724.method_31476(); int r = connScanRadius.get();
        net.minecraft.class_2338.class_2339 m = new net.minecraft.class_2338.class_2339();
        for (int cx = center.field_9181 - r; cx <= center.field_9181 + r; cx++) for (int cz = center.field_9180 - r; cz <= center.field_9180 + r; cz++) {
            var ch = mc.field_1687.method_8402(cx, cz, net.minecraft.class_2806.field_12803, false);
            if (!(ch instanceof class_2818 wc)) continue;
            int bx = wc.method_12004().method_8326(), bz = wc.method_12004().method_8328(), found = 0;
            for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) for (int y = wc.method_31607(); y <= connMaxY.get(); y++) {
                var st = wc.method_8320(m.method_10103(bx + x, y, bz + z));
                if (!st.method_26215() && isConnTarget(st.method_26204())) found++;
            }
            long k = class_1923.method_8331(cx, cz);
            if (found >= connMin.get()) connectedChunks.add(k); else connectedChunks.remove(k);
        }
    }

    @EventHandler
    private void onConnRender(Render3DEvent event) {
        if (!connectedScan.get() || connectedChunks.isEmpty() || mc.field_1687 == null) return;
        var c = connColor.get(); var side = new Color(c.r, c.g, c.b, 40);
        double y = boxY.get();
        for (long k : connectedChunks) {
            class_1923 cp = new class_1923(k); double x0 = cp.method_8326(), z0 = cp.method_8328();
            event.renderer.box(x0, y, z0, x0 + 16, y + 1, z0 + 16, side, c, ShapeMode.Both, 0);
        }
    }

    @Override public String getInfoString() { return scores.size() + " chunks"; }
}
