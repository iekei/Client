package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import java.util.ArrayList;
import java.util.List;

/**
 * Rare Finder — highlights valuable items lying on the ground or displayed in item frames,
 * with an optional beam so you can spot them from a distance.
 */
public class RareFinder extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> findDropped = sg.add(new BoolSetting.Builder()
        .name("find-dropped").description("Highlight rare items lying on the ground.").defaultValue(true).build());
    private final Setting<Boolean> findPlaced = sg.add(new BoolSetting.Builder()
        .name("find-placed")
        .description("Also find rare blocks that have been placed in the world — a beacon someone built, a sponge wall, heads on display, gilded blackstone. These never appear as dropped items, so without this they're invisible.")
        .defaultValue(true).build());
    private final Setting<Integer> placedRange = sg.add(new IntSetting.Builder()
        .name("placed-range")
        .description("How far out to look for placed rare blocks, in blocks.")
        .defaultValue(64).min(8).max(256).sliderRange(16, 128).visible(findPlaced::get).build());
    private final Setting<SettingColor> placedColor = sg.add(new ColorSetting.Builder()
        .name("placed-color").description("Colour used for placed rare blocks.")
        .defaultValue(new SettingColor(255, 160, 0, 255)).visible(findPlaced::get).build());

    private final Setting<Boolean> findFramed = sg.add(new BoolSetting.Builder()
        .name("find-framed").description("Highlight rare items displayed in item frames — people put their best gear on show.").defaultValue(true).build());
    private final Setting<Integer> scanTicks = sg.add(new IntSetting.Builder()
        .name("scan-ticks").description("Ticks between sweeps for dropped and framed items.")
        .defaultValue(20).min(1).max(200).sliderRange(5, 60).build());

    private final Setting<List<class_1792>> items = sg.add(new ItemListSetting.Builder()
        .name("items")
        .description("Everything worth flagging — one list for the lot. Anything here is reported whether it is lying on the ground, hanging in an item frame, or placed as a block in the world. Ores are not here on purpose: ore-spotter++ handles those.")
        .defaultValue(List.of(
            class_1802.field_8840, class_1802.field_8712, class_1802.field_8791, class_1802.field_8575,
            class_1802.field_8398, class_1802.field_8470, class_1802.field_8681, class_1802.field_41304,
            class_1802.field_8833, class_1802.field_8137, class_1802.field_8207, class_1802.field_8668, class_1802.field_8140,
            class_1802.field_8367, class_1802.field_8547, class_1802.field_22020, class_1802.field_22021,
            class_1802.field_22018, class_1802.field_22027, class_1802.field_22028, class_1802.field_22029,
            class_1802.field_22030, class_1802.field_22022, class_1802.field_22024, class_1802.field_22025,
            class_1802.field_22023, class_1802.field_22026, class_1802.field_23984, class_1802.field_38974,
            class_1802.field_23847, class_1802.field_8305, class_1802.field_8535, class_1802.field_8554, class_1802.field_22019,
            class_1802.field_8657, class_1802.field_8545,
            class_1802.field_8106, class_1802.field_8247, class_1802.field_16307, class_1802.field_8466, class_1802.field_8239,
            class_1802.field_8732, class_1802.field_16306, class_1802.field_16309, class_1802.field_8740, class_1802.field_8782))
        .build());


    private final SettingGroup sgAlert = settings.createGroup("Alerts");
    private final Setting<Boolean> chat = sgAlert.add(new BoolSetting.Builder()
        .name("chat").description("Log each new rare item in chat.").defaultValue(true).build());
    private final Setting<Boolean> popup = sgAlert.add(new BoolSetting.Builder()
        .name("popup").description("Throw a title on screen when one turns up.").defaultValue(false).build());
    private final Setting<Boolean> sound = sgAlert.add(new BoolSetting.Builder()
        .name("sound").description("Play a sound when one turns up.").defaultValue(false).build());
    private final Setting<Double> volume = sgAlert.add(new DoubleSetting.Builder()
        .name("volume").description("How loud that sound is.").defaultValue(2.0).min(0.1).max(10)
        .sliderRange(0.5, 6).decimalPlaces(1).visible(sound::get).build());

    private final SettingGroup sgRender = settings.createGroup("Render");
    private final Setting<Boolean> beacon = sgRender.add(new BoolSetting.Builder()
        .name("beacon").description("Shoot a beam up from each rare item. Two within five blocks share one beam placed between them, so a pile doesn't become a wall of beams.")
        .defaultValue(false).build());
    private final Setting<SettingColor> beaconColor = sgRender.add(new ColorSetting.Builder()
        .name("beacon-color").description("Colour of those beams.").defaultValue(new SettingColor(255, 215, 0, 180))
        .visible(beacon::get).build());
    private final Setting<SettingColor> itemColor = sgRender.add(new ColorSetting.Builder()
        .name("item-color").description("Colour used for items on the ground.").defaultValue(new SettingColor(0, 255, 170, 255))
        .visible(findDropped::get).build());
    private final Setting<SettingColor> frameColor = sgRender.add(new ColorSetting.Builder()
        .name("frame-color").description("Colour used for items in frames.").defaultValue(new SettingColor(200, 90, 255, 255))
        .visible(findFramed::get).build());
    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").description("Outline only, filled sides only, or both.").defaultValue(ShapeMode.Both).build());
    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
        .name("tracers").description("Draw a line from you to each find.").defaultValue(false).build());

    /** {x, y, z, 0 = on the ground / 1 = in a frame} */
    private final List<double[]> found = new ArrayList<>();
    private final java.util.Set<Integer> announced = new java.util.HashSet<>();
    private int tick;

    public RareFinder() {
        super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "rare-finder++",
            "Highlights valuable items on the ground or in item frames, and can beam them so you spot them from far off.");
    }

    @Override
    public void onDeactivate() { found.clear(); announced.clear(); }

    private void alert(String what, double x, double y, double z) {
        if (chat.get())
            com.iekeiclient.addons.shama.util.Chat.info("[RareFinder] %s at (%.0f, %.0f, %.0f)", what, x, y, z);
        if (popup.get() && mc.field_1705 != null) {
            mc.field_1705.method_34001(2, 30, 8);
            mc.field_1705.method_34004(net.minecraft.class_2561.method_43470("Rare item")
                .method_27692(net.minecraft.class_124.field_1065));
            mc.field_1705.method_34002(net.minecraft.class_2561.method_43470(what)
                .method_27692(net.minecraft.class_124.field_1054));
        }
        if (sound.get() && mc.field_1687 != null && mc.field_1724 != null)
            mc.field_1687.method_60511(mc.field_1724, mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(),
                net.minecraft.class_3417.field_14622,
                net.minecraft.class_3419.field_15248, volume.get().floatValue(), 1.8f);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1687 == null || (!findDropped.get() && !findFramed.get())) { found.clear(); return; }
        if (tick++ % Math.max(1, scanTicks.get()) != 0) return;

        found.clear();

        // placed rare blocks: walk the loaded chunks around you and match the block against the
        // same item list, so a placed beacon or a sponge wall counts even though nothing dropped
        if (findPlaced.get() && mc.field_1724 != null) {
            int r = placedRange.get(), r2 = r * r;
            int pcx = mc.field_1724.method_31477() >> 4, pcz = mc.field_1724.method_31479() >> 4;
            int cr = Math.max(1, (int) Math.ceil(r / 16.0));
            net.minecraft.class_2338 me = mc.field_1724.method_24515();
            for (int dx = -cr; dx <= cr; dx++) for (int dz = -cr; dz <= cr; dz++) {
                net.minecraft.class_2791 ch = mc.field_1687.method_8402(pcx + dx, pcz + dz,
                    net.minecraft.class_2806.field_12803, false);
                if (!(ch instanceof net.minecraft.class_2818 wc)) continue;
                int bx = wc.method_12004().method_8326(), bz = wc.method_12004().method_8328();
                int bot = Math.max(wc.method_31607(), me.method_10264() - r), top = Math.min(wc.method_31600(), me.method_10264() + r);
                net.minecraft.class_2338.class_2339 m = new net.minecraft.class_2338.class_2339();
                for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) for (int y = bot; y <= top; y++) {
                    var st = wc.method_8320(m.method_10103(bx + x, y, bz + z));
                    if (st.method_26215()) continue;
                    // one list drives everything: a placed block is matched by the item it drops,
                    // so you only ever maintain a single picker
                    var it = st.method_26204().method_8389();
                    if (it == net.minecraft.class_1802.field_8162 || !items.get().contains(it)) continue;
                    if (me.method_40081(bx + x, y, bz + z) > r2) continue;
                    found.add(new double[]{bx + x + 0.5, y, bz + z + 0.5, 2});
                }
            }
        }

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (findDropped.get() && e instanceof class_1542 ie) {
                if (!items.get().contains(ie.method_6983().method_7909())) continue;
                found.add(new double[]{e.method_23317(), e.method_23318(), e.method_23321(), 0});
                if (announced.add(e.method_5628()))
                    alert(ie.method_6983().method_7964().getString(), e.method_23317(), e.method_23318(), e.method_23321());
            } else if (findFramed.get() && e instanceof class_1533 fr) {
                // item frames keep what they're displaying in getHeldItemStack
                var held = fr.method_6940();
                if (held.method_7960() || !items.get().contains(held.method_7909())) continue;
                found.add(new double[]{e.method_23317(), e.method_23318(), e.method_23321(), 1});
                if (announced.add(e.method_5628()))
                    alert(held.method_7964().getString() + " (framed)", e.method_23317(), e.method_23318(), e.method_23321());
            }
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (found.isEmpty()) return;
        var cam = com.iekeiclient.engine.utils.render.RenderUtils.center;

        if (beacon.get()) {
            SettingColor bc = beaconColor.get();
            Color bl = new Color(bc.r, bc.g, bc.b, 255);
            Color bf = new Color(bc.r, bc.g, bc.b, 50);
            boolean[] used = new boolean[found.size()];
            for (int i = 0; i < found.size(); i++) {
                if (used[i]) continue;
                double[] a = found.get(i);
                double bx = a[0], by = a[1], bz = a[2];
                int merged = 1;
                for (int j = i + 1; j < found.size(); j++) {
                    if (used[j]) continue;
                    double[] b = found.get(j);
                    if (Math.abs(a[0] - b[0]) <= 5 && Math.abs(a[1] - b[1]) <= 5 && Math.abs(a[2] - b[2]) <= 5) {
                        bx += b[0]; by += b[1]; bz += b[2]; merged++; used[j] = true;
                    }
                }
                bx /= merged; by /= merged; bz /= merged;
                event.renderer.box(bx - 0.15, by, bz - 0.15, bx + 0.15, by + 320, bz + 0.15, bf, bl, ShapeMode.Both, 0);
            }
        }

        for (double[] d : found) {
            SettingColor c = d[3] == 0 ? itemColor.get() : (d[3] == 1 ? frameColor.get() : placedColor.get());
            Color line = new Color(c.r, c.g, c.b, c.a);
            Color fill = new Color(c.r, c.g, c.b, 60);
            event.renderer.box(d[0] - 0.25, d[1] - 0.25, d[2] - 0.25, d[0] + 0.25, d[1] + 0.25, d[2] + 0.25,
                fill, line, shapeMode.get(), 0);
            if (tracers.get()) event.renderer.line(cam.field_1352, cam.field_1351, cam.field_1350, d[0], d[1], d[2], line);
        }
    }

    @Override
    public String getInfoString() { return found.isEmpty() ? null : Integer.toString(found.size()); }
}
