package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1802;
import net.minecraft.class_243;

/** TridentBoost++ — launch in your look direction with a riptide trident, without needing water/rain. Hold a trident and press use. */
public class TridentBoost extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Double> power = sg.add(new DoubleSetting.Builder().name("power").description("Strength of the effect.").defaultValue(2.5).min(0.5).sliderRange(1, 5).build());
    private int cooldown;

    public TridentBoost() { super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "trident-boost++", "Riptide-launch in any conditions with a trident."); }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (cooldown > 0) cooldown--;
        if (mc.field_1724 == null) return;
        boolean holdingTrident = mc.field_1724.method_6047().method_31574(class_1802.field_8547) || mc.field_1724.method_6079().method_31574(class_1802.field_8547);
        if (holdingTrident && mc.field_1690.field_1904.method_1434() && cooldown == 0) {
            class_243 look = mc.field_1724.method_5828(1f);
            mc.field_1724.method_18799(look.method_1021(power.get()));
            mc.field_1724.field_64356 = true;
            cooldown = 20;
        }
    }
}
