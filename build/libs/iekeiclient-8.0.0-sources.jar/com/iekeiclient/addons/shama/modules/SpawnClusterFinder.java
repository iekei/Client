package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.render.Render3DEvent;
import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.renderer.ShapeMode;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1588;
import net.minecraft.class_1923;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Spawn Cluster Finder++ — periodically counts live hostile mobs per chunk and boxes
 * any chunk with at least min-spawns present at once, revealing unusually dense mob
 * activity (grinder / farm / spawner) even when the spawner block isn't visible.
 * Ported from a mob-tracking scanner (renamed from its original troll branding).
 */
public class SpawnClusterFinder extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Integer> minSpawns = sg.add(new IntSetting.Builder()
        .name("min-spawns").description("Minimum hostile mobs in a chunk at once to flag it.")
        .defaultValue(3).range(2, 50).sliderRange(2, 30).build());

    private final Setting<Integer> rescanTicks = sg.add(new IntSetting.Builder()
        .name("rescan-ticks").description("Ticks between full rescans.").defaultValue(40).range(5, 100).sliderRange(5, 60).build());

    private final Setting<SettingColor> color = sg.add(new ColorSetting.Builder()
        .name("color").description("Highlight colour.").defaultValue(new SettingColor(255, 0, 0, 90)).build());

    private final Map<Long, Integer> counts = new ConcurrentHashMap<>();
    private int tick;

    public SpawnClusterFinder() {
        super(com.iekeiclient.addons.shama.ShamaAddon.HUNT, "spawn-cluster-finder++", "Boxes chunks with unusually dense live hostile-mob counts.");
    }

    @Override
    public void onActivate() { counts.clear(); tick = 0; }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1687 == null) return;
        if (tick++ % Math.max(1, rescanTicks.get()) != 0) return;

        Map<Long, Integer> next = new ConcurrentHashMap<>();
        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1588) || !e.method_5805()) continue;
            long key = new class_1923(e.method_24515()).method_8324();
            next.merge(key, 1, Integer::sum);
        }
        counts.clear();
        counts.putAll(next);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (counts.isEmpty()) return;
        Color c = color.get();
        Color line = new Color(c.r, c.g, c.b, 255);
        for (Map.Entry<Long, Integer> e : counts.entrySet()) {
            if (e.getValue() < minSpawns.get()) continue;
            class_1923 cp = new class_1923(e.getKey());
            double x0 = cp.field_9181 * 16, z0 = cp.field_9180 * 16;
            event.renderer.box(x0, 60, z0, x0 + 16, 61, z0 + 16, c, line, ShapeMode.Both, 0);
        }
    }

    @Override
    public String getInfoString() { return counts.size() + " chunks"; }
}
