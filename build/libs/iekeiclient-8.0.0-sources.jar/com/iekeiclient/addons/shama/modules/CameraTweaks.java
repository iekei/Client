package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;

/**
 * Camera Tweaks — safe camera/view overrides applied through the game options (no fragile
 * render-pipeline mixins): a custom FOV and toggles to kill view-bobbing.
 */
public class CameraTweaks extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();
    private final Setting<Boolean> customFov = sg.add(new BoolSetting.Builder().name("custom-fov").description("Force a specific FOV while active.").defaultValue(true).build());
    private final Setting<Integer> fov = sg.add(new IntSetting.Builder().name("fov").description("The field-of-view value to force.").defaultValue(90).min(30).max(160).sliderRange(30, 140).visible(customFov::get).build());
    private final Setting<Boolean> noBob = sg.add(new BoolSetting.Builder().name("no-view-bob").description("Disable view bobbing.").defaultValue(false).build());

    private int savedFov;
    private boolean savedBob;
    private boolean saved;

    public CameraTweaks() { super(com.iekeiclient.addons.shama.ShamaAddon.MISC, "camera-tweaks++", "Custom FOV and view-bob overrides."); }

    @Override
    public void onActivate() {
        if (mc.field_1690 == null) return;
        savedFov = mc.field_1690.method_41808().method_41753();
        savedBob = mc.field_1690.method_42448().method_41753();
        saved = true;
    }

    @Override
    public void onDeactivate() {
        if (mc.field_1690 != null && saved) {
            mc.field_1690.method_41808().method_41748(savedFov);
            mc.field_1690.method_42448().method_41748(savedBob);
        }
        saved = false;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1690 == null) return;
        if (customFov.get()) mc.field_1690.method_41808().method_41748(fov.get());
        if (noBob.get()) mc.field_1690.method_42448().method_41748(false);
    }
}
