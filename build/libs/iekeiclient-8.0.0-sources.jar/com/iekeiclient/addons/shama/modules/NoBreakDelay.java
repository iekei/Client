package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_636;
import com.iekeiclient.addons.shama.mixin.InteractionManagerMixin;

/**
 * No Break Delay — removes the ~5-tick cooldown vanilla adds after you break or
 * punch a block, so you can mine blocks back-to-back with no stutter. Same idea
 * as the No Break Delay / No Mining Cooldown / KeepOnMining mods.
 *
 * This is the standalone version; the same toggle also lives inside Instant Mine++.
 * The cooldown is a client-side gate, so this works in both singleplayer and on
 * servers (servers don't track this particular cooldown).
 */
public class NoBreakDelay extends Module {
    public NoBreakDelay() {
        super(com.iekeiclient.addons.shama.ShamaAddon.PLAYER, "no-break-delay++", "Removes the cooldown between breaking blocks. Mine continuously with no pause.");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1761 == null) return;
        zeroCooldown(mc.field_1761);
    }

    /** Shared helper so Instant Mine++ can call the exact same logic. */
    public static void zeroCooldown(class_636 im) {
        ((InteractionManagerMixin) im).setBlockBreakingCooldown(0);
    }
}
