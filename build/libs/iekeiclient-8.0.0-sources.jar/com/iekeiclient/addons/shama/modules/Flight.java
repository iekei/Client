package com.iekeiclient.addons.shama.modules;

import com.iekeiclient.engine.events.world.TickEvent;
import com.iekeiclient.engine.settings.BoolSetting;
import com.iekeiclient.engine.settings.DoubleSetting;
import com.iekeiclient.engine.settings.EnumSetting;
import com.iekeiclient.engine.settings.IntSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;

/**
 * Flight with several modes, each using a different mechanic so they get past
 * different checks. None of these are magic on a strict anti-cheat — they're
 * different trade-offs between smoothness and how obvious they are.
 *
 *  - Creative   : flips the vanilla creative-flight ability. Smoothest. A server
 *                 that tracks the flight ability sees it directly.
 *  - Velocity   : never touches the ability flag; zeroes gravity and sets your
 *                 velocity each tick from input. Looks like normal movement with
 *                 no fall.
 *  - Motion     : like Velocity but only nudges Y to cancel gravity (small
 *                 upward motion each tick) instead of forcing it to zero, so the
 *                 vertical movement reads more like vanilla jitter.
 *  - Glide      : no upward force at all — you slowly sink unless you hold jump.
 *                 The gentlest profile; good for staying near the ground without
 *                 ever triggering a "flying" state.
 */
public class Flight extends Module {
    public enum Mode {
        Creative,
        Velocity,
        Motion,
        Glide,
        Jetpack,
        Bounce,
        Smooth,
        Static,
        Packet,
        Vanilla
    }

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
        .name("mode")
        .description("Flight method, each bypassing differently. Creative flips the ability flag; Velocity/Motion/Glide drive velocity; Bounce adds a hover wobble; Smooth eases momentum; Static is a dead-stop hover; Packet reports on-ground; Jetpack thrusts where you look.")
        .defaultValue(Mode.Creative)
        .build()
    );

    private final Setting<Boolean> antiKick = sgGeneral.add(new BoolSetting.Builder()
        .name("anti-kick")
        .description("Periodically send a fake on-ground packet so servers that kick on prolonged airtime (rather than checking velocity) don't flag you. Independent of mode.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> antiKickInterval = sgGeneral.add(new IntSetting.Builder()
        .name("anti-kick-interval")
        .description("Ticks between the fake on-ground reports.")
        .defaultValue(60).min(10).sliderRange(10, 200)
        .visible(antiKick::get)
        .build()
    );

    private int antiKickTimer;

    private final Setting<Double> speed = sgGeneral.add(new DoubleSetting.Builder()
        .name("speed")
        .description("Horizontal flight speed (blocks/tick) for the non-creative modes.")
        .defaultValue(0.5)
        .min(0.0)
        .sliderRange(0.1, 3.0)
        .build()
    );

    private final Setting<Double> vertical = sgGeneral.add(new DoubleSetting.Builder()
        .name("vertical-speed")
        .description("Up/down speed for jump/sneak (non-creative modes).")
        .defaultValue(0.5)
        .min(0.0)
        .sliderRange(0.1, 3.0)
        .build()
    );

    private final Setting<Double> flySpeed = sgGeneral.add(new DoubleSetting.Builder()
        .name("creative-fly-speed")
        .description("Fly speed for Creative mode (1.0 = vanilla default).")
        .defaultValue(1.0)
        .min(0.0)
        .sliderRange(0.1, 5.0)
        .build()
    );

    private final Setting<Integer> pulldownInterval = sgGeneral.add(new IntSetting.Builder()
        .name("vanilla-pulldown-interval")
        .description("Vanilla mode: every N ticks, drop briefly so the server's \"time in air\" counter resets. This is the NCP-style trick that gets past anticheats that kick for being airborne too long. Lower = safer but jerkier.")
        .defaultValue(8)
        .min(2)
        .sliderRange(2, 40)
        .visible(() -> mode.get() == Mode.Vanilla)
        .build()
    );

    private boolean prevAllowFlying;
    private boolean prevFlying;
    private int animTick;
    private class_243 smoothVel = class_243.field_1353;

    public Flight() {
        super(com.iekeiclient.addons.shama.ShamaAddon.MOVEMENT, "flight++", "Fly freely. How well it holds up depends on the server's anti-cheat.");
    }

    @Override
    public void onActivate() {
        if (mc.field_1724 == null) return;
        prevAllowFlying = mc.field_1724.method_31549().field_7478;
        prevFlying = mc.field_1724.method_31549().field_7479;
        smoothVel = mc.field_1724.method_18798();

        if (mode.get() == Mode.Creative) {
            mc.field_1724.method_31549().field_7478 = true;
        }
    }

    @Override
    public void onDeactivate() {
        if (mc.field_1724 == null) return;
        if (!prevAllowFlying) {
            mc.field_1724.method_31549().field_7478 = false;
            mc.field_1724.method_31549().field_7479 = false;
        } else {
            mc.field_1724.method_31549().field_7478 = prevAllowFlying;
            mc.field_1724.method_31549().field_7479 = prevFlying;
        }
        mc.field_1724.method_31549().method_7248(0.05f);
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null) return;

        if (antiKick.get() && mc.method_1562() != null) {
            if (++antiKickTimer >= antiKickInterval.get()) {
                antiKickTimer = 0;
                mc.method_1562().method_52787(new net.minecraft.class_2828.class_5911(true, mc.field_1724.field_5976));
            }
        }

        if (mode.get() == Mode.Creative) {
            // Let vanilla's double-tap-jump start/stop it; just permit + set speed.
            mc.field_1724.method_31549().field_7478 = true;
            mc.field_1724.method_31549().method_7248((float) (0.05 * flySpeed.get()));
            return;
        }

        // --- Shared input-driven horizontal movement for the other modes ---
        double mx = 0, mz = 0;
        boolean f = mc.field_1690.field_1894.method_1434();
        boolean b = mc.field_1690.field_1881.method_1434();
        boolean l = mc.field_1690.field_1913.method_1434();
        boolean r = mc.field_1690.field_1849.method_1434();

        if (f || b || l || r) {
            float yaw = (float) Math.toRadians(mc.field_1724.method_36454());
            double sin = Math.sin(yaw);
            double cos = Math.cos(yaw);
            double forward = (f ? 1 : 0) - (b ? 1 : 0);
            double strafe = (r ? 1 : 0) - (l ? 1 : 0);
            mx = (forward * -sin + strafe * cos);
            mz = (forward * cos + strafe * sin);
            double len = Math.sqrt(mx * mx + mz * mz);
            if (len > 0) {
                mx = mx / len * speed.get();
                mz = mz / len * speed.get();
            }
        }

        boolean jump = mc.field_1690.field_1903.method_1434();
        boolean sneak = mc.field_1690.field_1832.method_1434();
        animTick++;

        switch (mode.get()) {
            case Velocity -> {
                // Hard zero gravity, full manual control.
                mc.field_1724.method_5875(true);
                double up = (jump ? vertical.get() : 0) - (sneak ? vertical.get() : 0);
                mc.field_1724.method_18800(mx, up, mz);
                mc.field_1724.method_24830(false);
            }
            case Motion -> {
                // Don't force noGravity; instead counter gravity with a small
                // per-tick upward nudge so vertical reads less robotic.
                mc.field_1724.method_5875(false);
                double up;
                if (jump) up = vertical.get();
                else if (sneak) up = -vertical.get();
                else up = 0.08; // ~cancels one tick of gravity (0.08/tick)
                mc.field_1724.method_18800(mx, up, mz);
                mc.field_1724.field_6017 = 0;
            }
            case Glide -> {
                // No upward force unless you hold jump; otherwise gentle sink.
                mc.field_1724.method_5875(false);
                double up;
                if (jump) up = vertical.get();
                else if (sneak) up = -vertical.get();
                else up = -0.04; // slow descent
                mc.field_1724.method_18800(mx, up, mz);
                mc.field_1724.field_6017 = 0;
            }
            case Jetpack -> {
                // Horion-style: thrust straight toward where you're looking
                // (pitch included, so look up to climb, look down to dive).
                // Meant to be bound as hold-to-fly: release the bind to stop.
                mc.field_1724.method_5875(true);
                class_243 look = mc.field_1724.method_5720(); // normalized look dir
                double s = speed.get();
                mc.field_1724.method_18800(look.field_1352 * s, look.field_1351 * s, look.field_1350 * s);
                mc.field_1724.method_24830(false);
                mc.field_1724.field_6017 = 0;
            }
            case Bounce -> {
                // Like Velocity but the resting vertical isn't a flat line — it
                // rides a small sine wave so checks that flag "perfectly constant
                // Y while airborne" have less to grab onto.
                mc.field_1724.method_5875(true);
                double up;
                if (jump) up = vertical.get();
                else if (sneak) up = -vertical.get();
                else up = 0.045 * Math.sin(animTick * 0.5); // gentle hover wobble
                mc.field_1724.method_18800(mx, up, mz);
                mc.field_1724.method_24830(false);
                mc.field_1724.field_6017 = 0;
            }
            case Smooth -> {
                // Eases velocity toward the target instead of snapping, so starts
                // and stops aren't instant (reads more like real momentum).
                mc.field_1724.method_5875(true);
                double up = (jump ? vertical.get() : 0) - (sneak ? vertical.get() : 0);
                class_243 target = new class_243(mx, up, mz);
                smoothVel = smoothVel.method_1019(target.method_1020(smoothVel).method_1021(0.25)); // lerp 25%/tick
                mc.field_1724.method_18799(smoothVel);
                mc.field_1724.method_24830(false);
                mc.field_1724.field_6017 = 0;
            }
            case Static -> {
                // Dead hover: no drift at all. Only moves while you hold a key,
                // otherwise pinned exactly in place. Good for AFK / building.
                mc.field_1724.method_5875(true);
                double up = (jump ? vertical.get() : 0) - (sneak ? vertical.get() : 0);
                mc.field_1724.method_18800(mx, up, mz);
                if (mx == 0 && mz == 0 && up == 0) mc.field_1724.method_18800(0, 0, 0);
                mc.field_1724.method_24830(false);
                mc.field_1724.field_6017 = 0;
            }
            case Packet -> {
                // Manual flight like Velocity, but reports onGround=true. Simple
                // "are you airborne and moving up" checks see a grounded player;
                // strict anti-cheats that reconcile position won't be fooled.
                mc.field_1724.method_5875(true);
                double up = (jump ? vertical.get() : 0) - (sneak ? vertical.get() : 0);
                mc.field_1724.method_18800(mx, up, mz);
                mc.field_1724.method_24830(true);
                mc.field_1724.field_6017 = 0;
            }
            case Vanilla -> {
                // The classic NCP-style bypass: fly at a near-vanilla speed and,
                // every pulldown-interval ticks, briefly drop so the server's
                // "ticks airborne" counter resets and never trips the "flying too
                // long" kick. The mode most likely to survive on NCP-based servers
                // (like 2b2t) — but speed has to stay low or it still flags.
                mc.field_1724.method_5875(true);
                double up;
                if (jump) up = vertical.get();
                else if (sneak) up = -vertical.get();
                else if (animTick % Math.max(2, pulldownInterval.get()) == 0) up = -0.062; // reset air-ticks
                else up = 0.0;
                // Cap horizontal near vanilla sprint-fly so it doesn't trip speed checks.
                double cap = Math.min(speed.get(), 0.34);
                double len = Math.sqrt(mx * mx + mz * mz);
                if (len > cap && len > 0) { mx = mx / len * cap; mz = mz / len * cap; }
                mc.field_1724.method_18800(mx, up, mz);
                mc.field_1724.field_6017 = 0;
            }
            default -> {}
        }
    }

    @Override
    public String getInfoString() {
        return mode.get().name().toLowerCase();
    }
}
