package com.iekeiclient.addons.shama.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.iekeiclient.engine.commands.Command;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.addons.shama.nbt.BedrockConverter;
import com.iekeiclient.addons.shama.nbt.LeNbt;
import com.iekeiclient.addons.shama.nbt.NbtActions;

import java.util.Base64;
import net.minecraft.class_2172;
import net.minecraft.class_2487;
import net.minecraft.class_310;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

/**
 * .bnbt [data] — convert a Bedrock structure/item/kit to Java, then place/give it.
 *
 * Accepts either:
 *   - pasted Bedrock NBT TEXT (SNBT/JSON), e.g. a Horion or Toolbox kit string that
 *     starts with '{', or
 *   - base64 of a raw binary Bedrock file (.mcstructure), which is little-endian.
 * Leave blank to use your clipboard.
 *
 * Shulker/chest kits: the Bedrock container's items (tag.Items) become Java's
 * minecraft:container component, so you get the shulker/chest already filled with
 * the kit (creative). Coverage is best-effort — see BedrockConverter for limits.
 */
public class BnbtCommand extends Command {
    public BnbtCommand() {
        super("bnbt", "Convert a Bedrock structure/item/kit (Horion/Toolbox text or base64) to Java and place/give it.");
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(ctx -> {
            run(null);
            return SINGLE_SUCCESS;
        });
        builder.then(argument("data", StringArgumentType.greedyString()).executes(ctx -> {
            run(StringArgumentType.getString(ctx, "data"));
            return SINGLE_SUCCESS;
        }));
    }

    private void run(String input) {
        class_310 mc = class_310.method_1551();
        if (input == null || input.isBlank()) input = mc.field_1774.method_1460();
        if (input == null || input.isBlank()) {
            ChatUtils.error("Nothing to convert. Paste a Horion/Toolbox NBT string, or base64 of a .mcstructure.");
            return;
        }
        input = input.trim();

        class_2487 bedrock;
        try {
            if (input.startsWith("{")) {
                // Horion / Toolbox export: textual Bedrock SNBT.
                bedrock = com.iekeiclient.addons.shama.nbt.Snbt.parse(input);
            } else {
                // Binary .mcstructure encoded as base64.
                byte[] bytes = Base64.getDecoder().decode(input.replaceAll("\\s", ""));
                bedrock = LeNbt.parse(bytes);
            }
        } catch (Exception e) {
            ChatUtils.error("Couldn't read that as Bedrock NBT (text or base64): " + e.getMessage());
            return;
        }

        class_2487 java;
        try {
            if (bedrock.method_10545("structure") || (bedrock.method_10545("size") && bedrock.method_10545("format_version"))) {
                java = BedrockConverter.structure(bedrock);
                ChatUtils.info("Converted Bedrock structure -> Java. Placing...");
            } else if (bedrock.method_10545("Name") || bedrock.method_10545("Item")) {
                java = BedrockConverter.item(bedrock);
                ChatUtils.info("Converted Bedrock item/kit -> Java. Giving...");
            } else {
                ChatUtils.warning("Not a recognizable Bedrock structure, item, or kit.");
                return;
            }
        } catch (Exception e) {
            ChatUtils.error("Conversion failed: " + e.getMessage());
            return;
        }

        NbtActions.handle(java);
    }
}
