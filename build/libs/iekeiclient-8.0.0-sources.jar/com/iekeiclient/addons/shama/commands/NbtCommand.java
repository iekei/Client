package com.iekeiclient.addons.shama.commands;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import net.minecraft.class_2487;
import net.minecraft.class_310;
import com.iekeiclient.engine.commands.Command;
import com.iekeiclient.engine.utils.player.ChatUtils;
import com.iekeiclient.addons.shama.nbt.NbtActions;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

/**
 * .nbt [data] — paste Java NBT (or leave blank to use your clipboard, e.g. what you
 * middle-clicked with NBT Adder). Item NBT (has "id") is given to your hand
 * (creative); structure NBT ("size"+"blocks") is placed at your feet (singleplayer).
 */
public class NbtCommand extends Command {
    public NbtCommand() {
        super("nbt", "Give an item or place a structure from pasted Java NBT (or your clipboard).");
    }

    @Override
    public void build(LiteralArgumentBuilder<class_2172> builder) {
        builder.executes(ctx -> {
            run(null);
            return SINGLE_SUCCESS;
        });
        builder.then(argument("data", StringArgumentType.greedyString()).executes(ctx -> {
            run(StringArgumentType.getString(ctx, "data"));
            return SINGLE_SUCCESS;
        }));
    }

    private void run(String snbt) {
        class_310 mc = class_310.method_1551();
        if (snbt == null || snbt.isBlank()) snbt = mc.field_1774.method_1460();
        if (snbt == null || snbt.isBlank()) {
            ChatUtils.error("No NBT given and the clipboard is empty.");
            return;
        }
        class_2487 nbt;
        try {
            nbt = com.iekeiclient.addons.shama.nbt.Snbt.parse(snbt.trim());
        } catch (Exception e) {
            ChatUtils.error("Couldn't parse that NBT: " + e.getMessage());
            return;
        }
        NbtActions.handle(nbt);
    }
}
