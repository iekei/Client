package com.iekeiclient.mixin.mixins.viafabricplus;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_746;
import com.iekeiclient.management.mod.impl.player.OldAnimationsMod;

@Mixin(value = class_310.class, priority = 2000)
public class MixinMinecraftClient {

	@Shadow
	public class_746 player;
	
	@Shadow
	public class_636 interactionManager;
	
    @ModifyExpressionValue(method = "doItemUse", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;isBreakingBlock()Z"))
    private boolean injectOldAnimation(boolean original) {
    	
    	if(OldAnimationsMod.getInstance().isEnabled()) {
    		return false;
    	}
    	
        return original;
    }
}
