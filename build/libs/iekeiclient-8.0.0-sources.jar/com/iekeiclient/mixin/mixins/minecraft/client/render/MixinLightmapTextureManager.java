package com.iekeiclient.mixin.mixins.minecraft.client.render;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_765;
import com.iekeiclient.management.mod.impl.render.FullbrightMod;

@Mixin(class_765.class)
public class MixinLightmapTextureManager {

    @ModifyExpressionValue(method = "update(F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/SimpleOption;getValue()Ljava/lang/Object;", ordinal = 1))
    private Object injectFullBright(Object original) {
        if (FullbrightMod.getInstance().isEnabled()) {
            return Double.valueOf(FullbrightMod.getInstance().getGamma());
        }
        return original;
    }
}
