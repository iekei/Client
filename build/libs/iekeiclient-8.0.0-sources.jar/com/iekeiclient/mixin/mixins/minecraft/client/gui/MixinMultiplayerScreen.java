package com.iekeiclient.mixin.mixins.minecraft.client.gui;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.ServerJoinEvent;
import net.minecraft.class_500;
import net.minecraft.class_642;

@Mixin(class_500.class)
public class MixinMultiplayerScreen {

    @Inject(method = "connect(Lnet/minecraft/client/network/ServerInfo;)V", at = @At("HEAD"), cancellable = true)
    private void onConnect(class_642 server, CallbackInfo ci) {
        EventBus.getInstance().post(new ServerJoinEvent(server.field_3761));
    }
}
