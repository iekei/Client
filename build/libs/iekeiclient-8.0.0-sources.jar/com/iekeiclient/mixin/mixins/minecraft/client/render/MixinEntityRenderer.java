package com.iekeiclient.mixin.mixins.minecraft.client.render;

import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.Iekei;
import com.iekeiclient.management.mod.impl.misc.HypixelMod;
import com.iekeiclient.utils.server.Server;
import com.iekeiclient.utils.server.ServerUtils;
import net.minecraft.class_10017;
import net.minecraft.class_10055;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_8012;
import net.minecraft.class_897;

@Mixin(class_897.class)
public abstract class MixinEntityRenderer<T extends class_1297, S extends class_10017> {

	@Shadow
	@Final
	private class_327 textRenderer;

	@Inject(method = "renderLabelIfPresent", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/font/TextRenderer;draw(Lnet/minecraft/text/Text;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;II)I", ordinal = 1))
	private void onRenderLevelHead(S inState, class_2561 text, class_4587 matrices, class_4597 vertexConsumers,
			int light, CallbackInfo ci) {

		class_310 client = class_310.method_1551();

		if (inState instanceof class_10055 state) {
			if (ServerUtils.isJoin(Server.HYPIXEL)) {

				class_742 player = (class_742) client.field_1687.method_8469(state.field_53528);

				if (player != null && text.getString().contains(player.method_5477().getString())) {

					if (HypixelMod.getInstance().isEnabled()
							&& HypixelMod.getInstance().getLevelHeadSetting().isEnabled()) {
						String levelText = class_124.field_1075.toString() + "Level: " + class_124.field_1054.toString()
								+ Iekei.getInstance().getHypixelManager()
										.getByUuid(player.method_5667().toString().replace("-", "")).getNetworkLevel();

						float x = -textRenderer.method_1727(levelText) / 2F;
						float y = text.getString().contains("deadmau5") ? -20 : -10;
						int color = (int) (client.field_1690.method_19343(0.25F) * 255.0F) << 24;

						Matrix4f matrix4f = matrices.method_23760().method_23761();

						textRenderer.method_27521(levelText, x, y, class_8012.field_42973, false, matrix4f, vertexConsumers,
								class_327.class_6415.field_33993, color, light);
					}
				}
			}
		}
	}
}
