package com.iekeiclient.mixin.mixins.minecraft.entity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.management.mod.impl.hud.JumpResetIndicatorMod;
import com.iekeiclient.management.mod.impl.player.NoJumpDelayMod;
import com.iekeiclient.mixin.interfaces.IMixinLivingEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_310;

@Mixin(class_1309.class)
public abstract class MixinLivingEntity implements IMixinLivingEntity {

	@Shadow
	private int jumpingCooldown;

	@Shadow
	public int handSwingTicks;

	@Shadow
	public boolean handSwinging;

	@Shadow
	public class_1268 preferredHand;

	@Shadow
	public abstract int getHandSwingDuration();

	@Inject(method = "tickMovement", at = @At("HEAD"))
	public void onNoJumpDelay(CallbackInfo ci) {
		if (NoJumpDelayMod.getInstance().isEnabled()) {
			jumpingCooldown = 0;
		}
	}

	@Inject(method = "jump", at = @At("HEAD"))
	private void onJump(CallbackInfo info) {

		JumpResetIndicatorMod mod = JumpResetIndicatorMod.getInstance();
		class_310 client = class_310.method_1551();

		if ((class_1309) (Object) this == client.field_1724) {
			mod.setJumpAge(client.field_1724.field_6012);
			mod.setLastTime(System.currentTimeMillis());
		}
	}

	@Inject(method = "onDamaged", at = @At("HEAD"))
	private void onDamage(CallbackInfo info) {

		JumpResetIndicatorMod mod = JumpResetIndicatorMod.getInstance();
		class_310 client = class_310.method_1551();

		if ((class_1309) (Object) this == client.field_1724) {
			mod.setHurtAge(client.field_1724.field_6012);
		}
	}

	@Override
	public void fakeSwingHand(class_1268 hand) {
		if (!this.handSwinging || this.handSwingTicks >= this.getHandSwingDuration() / 2 || this.handSwingTicks < 0) {
			this.handSwingTicks = -1;
			this.handSwinging = true;
			this.preferredHand = hand;
		}
	}
}
