package com.iekeiclient.mixin.mixins.minecraft.client.sound;

import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.iekeiclient.management.mod.impl.player.OldAnimationsMod;

@Mixin(class_1140.class)
public class MixinSoundSystem {

	@Unique
	private final List<class_2960> newPvPSounds = Arrays.asList(class_3417.field_14999.comp_3319(),
			class_3417.field_14706.comp_3319(), class_3417.field_15016.comp_3319(),
			class_3417.field_14840.comp_3319(), class_3417.field_14625.comp_3319(),
			class_3417.field_14914.comp_3319());

	@Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)Lnet/minecraft/client/sound/SoundSystem$PlayResult;", at = @At("HEAD"), cancellable = true)
	public void oldAnimations$disableNewPvPSounds(class_1113 sound,
			CallbackInfoReturnable<class_1140.class_11518> cir) {

		if (OldAnimationsMod.getInstance().isEnabled() && OldAnimationsMod.getInstance().isOldPvPSounds()
				&& newPvPSounds.contains(sound.method_4775())) {
			cir.setReturnValue(class_1140.class_11518.field_60956);
			return;
		}
	}
}
