package com.iekeiclient.mixin.mixins.minecraft.network.packet;

import net.minecraft.class_2824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2824.class)
public interface PlayerInteractEntityC2SPacketAccessor {

	@Accessor("type")
	class_2824.class_5906 getInteractTypeHandler();

	@Accessor("entityId")
	int entityId();
}
