package com.iekeiclient.mixin.mixins.minecraft.client.render;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.RenderGameOverlayEvent;
import com.iekeiclient.management.mod.impl.player.OldAnimationsMod;
import net.minecraft.class_10799;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;

@Mixin(class_329.class)
public class MixinInGameHud {

	@Overwrite
	private void drawHeart(class_332 context, class_329.class_6411 type, int x, int y, boolean hardcore, boolean blinking, boolean half) {
		
    	OldAnimationsMod mod = OldAnimationsMod.getInstance();
    	
		context.method_52706(class_10799.field_56883, type.method_52705(hardcore, half, mod.isEnabled() && mod.isDisableHeartFlash() ? false : blinking), x, y, 9, 9);
	}
    
	@Inject(method = "renderMainHud", at = @At("TAIL"))
	private void renderMainHud(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
		EventBus.getInstance().post(new RenderGameOverlayEvent(context));
	}
}
