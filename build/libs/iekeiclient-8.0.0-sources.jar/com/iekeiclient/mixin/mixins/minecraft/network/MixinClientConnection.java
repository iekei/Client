package com.iekeiclient.mixin.mixins.minecraft.network;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.ReceivePacketEvent;
import com.iekeiclient.event.client.SendPacketEvent;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_2987;
import net.minecraft.class_8042;

@Mixin(class_2535.class)
public abstract class MixinClientConnection {

	@Shadow
	protected static <T extends class_2547> void handlePacket(class_2596<T> packet, class_2547 listener) {
	}

	@Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
	private void onSendPacket(class_2596<?> packet, CallbackInfo ci) {

		SendPacketEvent event = new SendPacketEvent(packet);

		EventBus.getInstance().post(event);

		if (event.isCancelled()) {
			ci.cancel();
		}
	}

	@Inject(method = "handlePacket", at = @At("HEAD"), cancellable = true, require = 1)
	private static void onRecievePacket(class_2596<?> packet, class_2547 listener, CallbackInfo ci) {

		if (packet instanceof class_8042 bundleS2CPacket) {
			ci.cancel();

			for (class_2596<?> packetInBundle : bundleS2CPacket.method_48324()) {
				try {
					handlePacket(packetInBundle, listener);
				} catch (class_2987 ignored) {
				}
			}
			return;
		}

		ReceivePacketEvent event = new ReceivePacketEvent(packet);
		EventBus.getInstance().post(event);

		if (event.isCancelled()) {
			ci.cancel();
		}
	}
}
