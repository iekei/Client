package com.iekeiclient.mixin.mixins.minecraft.client;

import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.Iekei;
import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.MouseScrollEvent;
import com.iekeiclient.management.mod.settings.impl.KeybindSetting;
import net.minecraft.class_312;
import net.minecraft.class_3675.class_307;

@Mixin(class_312.class)
public class MixinMouse {

	@Inject(method = "onMouseButton", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/KeyBinding;onKeyPressed(Lnet/minecraft/client/util/InputUtil$Key;)V", shift = At.Shift.AFTER))
	public void onPressed(long window, int button, int action, int mods, CallbackInfo ci) {

		for (KeybindSetting s : Iekei.getInstance().getModManager().getKeybindSettings()) {

			if (s.getKey().equals(class_307.field_1672.method_1447(button))) {

				if (action == GLFW.GLFW_PRESS) {
					s.setPressed();
				}

				s.setKeyDown(true);
			}
		}
	}

	@Inject(method = "onMouseButton", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/KeyBinding;setKeyPressed(Lnet/minecraft/client/util/InputUtil$Key;Z)V", shift = At.Shift.AFTER, ordinal = 0))
	public void onReleased(long window, int button, int action, int mods, CallbackInfo ci) {
		for (KeybindSetting s : Iekei.getInstance().getModManager().getKeybindSettings()) {
			if (s.getKey().equals(class_307.field_1672.method_1447(button))) {
				s.setKeyDown(false);
			}
		}
	}

	@Inject(method = "onMouseScroll", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerInventory;setSelectedSlot(I)V", shift = At.Shift.BEFORE), cancellable = true)
	private void onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {

		MouseScrollEvent event = new MouseScrollEvent(vertical);

		EventBus.getInstance().post(event);

		if (event.isCancelled()) {
			ci.cancel();
		}
	}
}
