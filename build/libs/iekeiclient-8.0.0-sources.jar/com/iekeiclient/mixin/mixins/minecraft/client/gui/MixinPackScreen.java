package com.iekeiclient.mixin.mixins.minecraft.client.gui;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.gui.GuiResourcePackConvert;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5375;

@Mixin(class_5375.class)
public class MixinPackScreen extends class_437 {

	protected MixinPackScreen(class_2561 title) {
		super(title);
	}

	@Inject(method = "init", at = @At("HEAD"))
	private void onInit(CallbackInfo ci) {

		class_4185.class_7840 builder = class_4185
				.method_46430(class_2561.method_30163("Convert"), button -> field_22787.method_1507(new GuiResourcePackConvert(this))).method_46437(98, 20);

		builder.method_46433(field_22789 - 98 - 5, 5);
		this.method_37063(builder.method_46431());
	}
}
