package com.iekeiclient.mixin.mixins.minecraft.client;

import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.Iekei;
import com.iekeiclient.management.mod.settings.impl.KeybindSetting;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_3675;

@Mixin(class_309.class)
public class MixinKeyboard {

	@Inject(method = "onKey", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/KeyBinding;onKeyPressed(Lnet/minecraft/client/util/InputUtil$Key;)V", shift = At.Shift.AFTER))
	public void onPressed(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {

		for (KeybindSetting s : Iekei.getInstance().getModManager().getKeybindSettings()) {

			if (s.getKey().equals(class_3675.method_15985(new class_11908(key, scancode, modifiers)))) {

				if (action == GLFW.GLFW_PRESS) {
					s.setPressed();
				}

				s.setKeyDown(true);
			}
		}
	}

	@Inject(method = "onKey", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/KeyBinding;setKeyPressed(Lnet/minecraft/client/util/InputUtil$Key;Z)V", shift = At.Shift.AFTER, ordinal = 0))
	public void onReleased(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
		for (KeybindSetting s : Iekei.getInstance().getModManager().getKeybindSettings()) {
			if (s.getKey().equals(class_3675.method_15985(new class_11908(key, scancode, modifiers)))) {
				s.setKeyDown(false);
			}
		}
	}
}
