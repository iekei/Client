package com.iekeiclient.mixin.mixins.minecraft.entity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.PlayerDirectionChangeEvent;
import com.iekeiclient.management.mod.impl.player.FreelookMod;
import com.iekeiclient.mixin.interfaces.IMixinCameraEntity;
import net.minecraft.class_1297;
import net.minecraft.class_3532;
import net.minecraft.class_746;

@Mixin(class_1297.class)
public abstract class MixinEntity implements IMixinCameraEntity {

	@Unique
	private float cameraPitch;

	@Unique
	private float cameraYaw;

	@Shadow
	public abstract float getPitch();

	@Shadow
	public abstract float getYaw();

	@Inject(method = "changeLookDirection", at = @At("HEAD"))
	private void onPlayerDirectionChange(double cursorDeltaX, double cursorDeltaY, CallbackInfo ci) {

		float prevPitch = getPitch();
		float prevYaw = getYaw();
		float pitch = prevPitch + (float) (cursorDeltaY * .15);
		float yaw = prevYaw + (float) (cursorDeltaX * .15);
		pitch = class_3532.method_15363(pitch, -90.0F, 90.0F);

		EventBus.getInstance().post(new PlayerDirectionChangeEvent(prevPitch, prevYaw, pitch, yaw));
	}

	@Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
	public void changeCameraLookDirection(double xDelta, double yDelta, CallbackInfo ci) {
		if (FreelookMod.getInstance().isEnabled() && FreelookMod.getInstance().isActive()
				&& (class_1297) (Object) this instanceof class_746) {
			double pitchDelta = (yDelta * 0.15);
			double yawDelta = (xDelta * 0.15);

			this.cameraPitch = class_3532.method_15363(this.cameraPitch + (float) pitchDelta, -90.0f, 90.0f);
			this.cameraYaw += (float) yawDelta;

			ci.cancel();

		}
	}

	@Override
	@Unique
	public float getCameraPitch() {
		return this.cameraPitch;
	}

	@Override
	@Unique
	public float getCameraYaw() {
		return this.cameraYaw;
	}

	@Override
	@Unique
	public void setCameraPitch(float pitch) {
		this.cameraPitch = pitch;
	}

	@Override
	@Unique
	public void setCameraYaw(float yaw) {
		this.cameraYaw = yaw;
	}
}
