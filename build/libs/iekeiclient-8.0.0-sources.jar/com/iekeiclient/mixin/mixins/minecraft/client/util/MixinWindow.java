package com.iekeiclient.mixin.mixins.minecraft.client.util;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.skia.context.SkiaContext;
import net.minecraft.class_1041;

@Mixin(class_1041.class)
public class MixinWindow {

	@Inject(method = "onFramebufferSizeChanged", at = @At("RETURN"))
	private void onFramebufferSizeChanged(long window, int width, int height, CallbackInfo ci) {
		SkiaContext.createSurface(width, height);
	}
}
