package com.iekeiclient.mixin.mixins.minecraft.client.option;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.iekeiclient.management.mod.impl.player.SnapTapMod;
import com.iekeiclient.mixin.interfaces.IMixinKeyBinding;
import net.minecraft.class_304;
import net.minecraft.class_3675;

@Mixin(class_304.class)
public class MixinKeyBinding implements IMixinKeyBinding {

	@Shadow
	@Final
	private class_3675.class_306 defaultKey;

	@Shadow
	private boolean pressed;

	@Inject(method = "isPressed", at = @At("HEAD"), cancellable = true)
	public void onGetPressed(CallbackInfoReturnable<Boolean> cir) {

		SnapTapMod mod = SnapTapMod.getInstance();

		if (mod == null || !mod.isEnabled()) {
			return;
		}

		if (this.defaultKey.method_1444() == class_3675.field_32015) {
			if (this.pressed) {
				if (mod.getRightPressTime() == 0) {
					cir.setReturnValue(true);
					cir.cancel();
					return;
				}

				cir.setReturnValue(mod.getRightPressTime() <= mod.getLeftPressTime());
				cir.cancel();
			}
		} else if (this.defaultKey.method_1444() == class_3675.field_32018) {
			if (this.pressed) {
				if (mod.getLeftPressTime() == 0) {
					cir.setReturnValue(true);
					cir.cancel();
					return;
				}

				cir.setReturnValue(mod.getLeftPressTime() <= mod.getRightPressTime());
				cir.cancel();
			}
		} else if (this.defaultKey.method_1444() == class_3675.field_31912) {
			if (this.pressed) {
				if (mod.getForwardPressTime() == 0) {
					cir.setReturnValue(true);
					cir.cancel();
					return;
				}

				cir.setReturnValue(mod.getBackPressTime() <= mod.getForwardPressTime());
				cir.cancel();
			}
		} else if (this.defaultKey.method_1444() == class_3675.field_31908) {
			if (this.pressed) {
				if (mod.getBackPressTime() == 0) {
					cir.setReturnValue(true);
					cir.cancel();
					return;
				}

				cir.setReturnValue(mod.getForwardPressTime() <= mod.getBackPressTime());
				cir.cancel();
			}
		}
	}

	@Inject(method = "setPressed", at = @At("HEAD"))
	public void setPressed(boolean pressed, CallbackInfo ci) {

		SnapTapMod mod = SnapTapMod.getInstance();

		if (mod == null || !mod.isEnabled()) {
			return;
		}

		if (this.defaultKey.method_1444() == class_3675.field_32015) {
			if (pressed) {
				mod.setLeftPressTime(System.currentTimeMillis());
			} else {
				mod.setLeftPressTime(0);
			}
		} else if (this.defaultKey.method_1444() == class_3675.field_32018) {
			if (pressed) {
				mod.setRightPressTime(System.currentTimeMillis());
			} else {
				mod.setRightPressTime(0);
			}
		} else if (this.defaultKey.method_1444() == class_3675.field_31912) {
			if (pressed) {
				mod.setForwardPressTime(System.currentTimeMillis());
			} else {
				mod.setForwardPressTime(0);
			}
		} else if (this.defaultKey.method_1444() == class_3675.field_31908) {
			if (pressed) {
				mod.setBackPressTime(System.currentTimeMillis());
			} else {
				mod.setBackPressTime(0);
			}
		}
	}

	@Override
	public boolean getRealIsPressed() {
		return this.pressed;
	}
}
