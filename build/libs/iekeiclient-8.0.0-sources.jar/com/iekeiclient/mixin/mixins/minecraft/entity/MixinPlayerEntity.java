package com.iekeiclient.mixin.mixins.minecraft.entity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.iekeiclient.management.mod.impl.player.ForceMainHandMod;
import com.iekeiclient.management.mod.impl.player.OldAnimationsMod;
import net.minecraft.class_1306;
import net.minecraft.class_1657;
import net.minecraft.class_310;

@Mixin(class_1657.class)
public class MixinPlayerEntity {

	@Inject(method = "getAttackCooldownProgress", at = @At("HEAD"), cancellable = true)
	public void disableCooldown(CallbackInfoReturnable<Float> cir) {
		if (OldAnimationsMod.getInstance().isEnabled() && OldAnimationsMod.getInstance().isDisableAttackCooldown()) {
			cir.setReturnValue(1F);
		}
	}

	@Inject(method = "getMainArm", at = @At("HEAD"), cancellable = true)
	private void injectGetMainArm(CallbackInfoReturnable<class_1306> cir) {

		class_310 client = class_310.method_1551();
		class_1657 player = client.field_1724;
		class_1657 e = ((class_1657) (Object) this);

		if (ForceMainHandMod.getInstance().isEnabled() && e.method_5628() != player.method_5628()) {
			cir.setReturnValue(ForceMainHandMod.getInstance().isRightHand() ? class_1306.field_6183 : class_1306.field_6182);
		}
	}
}
