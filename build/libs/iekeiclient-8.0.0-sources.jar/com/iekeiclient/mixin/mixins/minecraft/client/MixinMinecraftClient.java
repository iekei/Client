package com.iekeiclient.mixin.mixins.minecraft.client;

import java.io.File;
import net.minecraft.class_1041;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_239.class_240;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3965;
import net.minecraft.class_542;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_702;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.iekeiclient.Iekei;
import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.ClientTickEvent;
import com.iekeiclient.event.client.GameLoopEvent;
import com.iekeiclient.libraries.browser.JCefBrowser;
import com.iekeiclient.management.config.ConfigType;
import com.iekeiclient.management.mod.impl.player.HitDelayFixMod;
import com.iekeiclient.management.mod.impl.player.OldAnimationsMod;
import com.iekeiclient.mixin.interfaces.IMixinLivingEntity;
import com.iekeiclient.mixin.interfaces.IMixinMinecraftClient;
import com.iekeiclient.shader.impl.KawaseBlur;
import com.iekeiclient.skia.context.SkiaContext;

@Mixin(value = class_310.class, priority = 300)
public abstract class MixinMinecraftClient implements IMixinMinecraftClient {

	@Shadow
	@Final
	private class_1041 window;

	@Shadow
	public int attackCooldown;

	@Shadow
	public class_636 interactionManager;

	@Final
	@Shadow
	public class_702 particleManager;

	@Shadow
	public class_315 options;

	@Shadow
	public class_239 crosshairTarget;

	@Shadow
	public class_638 world;

	@Shadow
	public class_746 player;

	@Shadow
	public abstract String getWindowTitle();

	@Unique
	private File assetDir;

	@Inject(method = "<init>(Lnet/minecraft/client/RunArgs;)V", at = @At("TAIL"))
	public void onInit(class_542 args, CallbackInfo ci) {
		assetDir = args.field_3277.field_3289;
	}

	@Inject(method = "stop", at = @At("HEAD"))
	public void onStop(CallbackInfo ci) {
		Iekei.getInstance().getConfigManager().save(ConfigType.MOD);
		JCefBrowser.close();
	}

	@Inject(method = "handleBlockBreaking", at = @At("HEAD"), cancellable = true)
	private void handleBlockBreaking(boolean breaking, CallbackInfo ci) {

		if (OldAnimationsMod.getInstance().isEnabled() && OldAnimationsMod.getInstance().isOldBreaking()) {
			if (this.options.field_1886.method_1434() && this.options.field_1904.method_1434()) {

				if (breaking && this.crosshairTarget != null && this.crosshairTarget.method_17783() == class_240.field_1332) {

					class_3965 blockHitResult = (class_3965) this.crosshairTarget;
					class_2338 blockPos = blockHitResult.method_17777();

					if (!this.world.method_8320(blockPos).method_26215()) {
						class_2350 direction = blockHitResult.method_17780();
						this.world.method_74254(blockPos, direction);
						((IMixinLivingEntity) player).fakeSwingHand(class_1268.field_5808);
					}
				}
			}
		}
	}

	@Inject(method = "doAttack", at = @At("HEAD"))
	private void onHitDelayFix(CallbackInfoReturnable<Boolean> cir) {
		if (HitDelayFixMod.getInstance().isEnabled()) {
			attackCooldown = 0;
		}
	}

	@Overwrite
	public void updateWindowTitle() {
		this.window.method_24286(Iekei.getInstance().getName() + " Client v" + Iekei.getInstance().getVersion() + " for "
				+ getWindowTitle());
	}

	@Inject(method = "<init>", at = @At("TAIL"))
	public void init(CallbackInfo ci) {
		SkiaContext.createSurface(window.method_4480(), window.method_4507());
		Iekei.getInstance().start();
	}

	@Inject(method = "tick", at = @At("HEAD"))
	public void onClientTick(CallbackInfo ci) {
		EventBus.getInstance().post(new ClientTickEvent());
	}

	@Inject(method = "run", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;printCrashReport()V"))
	public void onGameLoop(CallbackInfo ci) {
		EventBus.getInstance().post(new GameLoopEvent());
	}

	@Inject(method = "onResolutionChanged", at = @At("TAIL"))
	public void onResolutionChanged(CallbackInfo info) {
		SkiaContext.createSurface(window.method_4489(), window.method_4506());
		KawaseBlur.GUI_BLUR.resize();
		KawaseBlur.INGAME_BLUR.resize();
	}

	@Override
	public File getAssetDir() {
		return this.assetDir;
	}
}
