package com.iekeiclient.mixin.mixins.minecraft.client.gui;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.iekeiclient.libraries.browser.JCefBrowser;
import com.iekeiclient.management.mod.impl.hud.WebBrowserMod;
import com.iekeiclient.utils.mouse.MouseUtils;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_408;
import net.minecraft.class_437;

@Mixin(class_408.class)
public class MixinChatScreen extends class_437 {

	@Unique
	private boolean isInWebBrowser;

	protected MixinChatScreen(class_2561 title) {
		super(title);
	}

	@Inject(method = "mouseClicked", at = @At("HEAD"))
	private void onMouseClicked(class_11909 click, boolean doubleClick, CallbackInfoReturnable<Boolean> cir) {

		if (JCefBrowser.getBrowser() != null) {
			JCefBrowser.getBrowser().sendMousePress(WebBrowserMod.getInstance().getMouseX(click.comp_4798()),
					WebBrowserMod.getInstance().getMouseY(click.comp_4799()), click.method_74245());
			JCefBrowser.getBrowser().setFocus(true);
		}
	}

	@Override
	public boolean method_25406(class_11909 click) {
		if (JCefBrowser.getBrowser() != null) {
			JCefBrowser.getBrowser().sendMouseRelease(WebBrowserMod.getInstance().getMouseX(click.comp_4798()),
					WebBrowserMod.getInstance().getMouseY(click.comp_4799()), click.method_74245());
			JCefBrowser.getBrowser().setFocus(true);
		}
		return super.method_25406(click);
	}

	@Override
	public void method_16014(double mouseX, double mouseY) {
		if (JCefBrowser.getBrowser() != null) {
			JCefBrowser.getBrowser().sendMouseMove(WebBrowserMod.getInstance().getMouseX(mouseX),
					WebBrowserMod.getInstance().getMouseY(mouseY));
			isInWebBrowser = MouseUtils.isInside(mouseX, mouseY, WebBrowserMod.getInstance().getX(),
					WebBrowserMod.getInstance().getY(), WebBrowserMod.getInstance().getPosition().getWidth(),
					WebBrowserMod.getInstance().getPosition().getHeight());
		} else {
			isInWebBrowser = false;
		}
		super.method_16014(mouseX, mouseY);
	}

	@Inject(method = "mouseScrolled", at = @At("HEAD"))
	private void onMouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount,
			CallbackInfoReturnable<Boolean> cir) {
		if (JCefBrowser.getBrowser() != null) {
			JCefBrowser.getBrowser().sendMouseWheel(WebBrowserMod.getInstance().getMouseX(mouseX),
					WebBrowserMod.getInstance().getMouseY(mouseY), verticalAmount);
		}
	}

	@Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
	private void onKeyPressed(class_11908 input, CallbackInfoReturnable<Boolean> cir) {
		if (JCefBrowser.getBrowser() != null) {
			JCefBrowser.getBrowser().sendKeyPress(input.comp_4795(), input.comp_4796(), input.comp_4797());
			JCefBrowser.getBrowser().setFocus(true);
			if(isInWebBrowser) {
				cir.setReturnValue(true);
			}
		}
	}

	@Override
	public boolean method_16803(class_11908 input) {
		if (JCefBrowser.getBrowser() != null) {
			JCefBrowser.getBrowser().sendKeyRelease(input.comp_4795(), input.comp_4796(), input.comp_4797());
			JCefBrowser.getBrowser().setFocus(true);
			if(isInWebBrowser) {
				return true;
			}
		}
		return super.method_16803(input);
	}

	@Override
	public boolean method_25400(class_11905 input) {

		if (!input.method_74227()) {
			return false;
		}

		if (JCefBrowser.getBrowser() != null) {
			JCefBrowser.getBrowser().sendKeyTyped((char) input.comp_4793(), input.comp_4794());
			JCefBrowser.getBrowser().setFocus(true);
			if(isInWebBrowser) {
				return true;
			}
		}

		return super.method_25400(input);
	}
}
