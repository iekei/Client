package com.iekeiclient.mixin.mixins.minecraft.world;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.iekeiclient.management.mod.impl.misc.WeatherChangerMod;
import net.minecraft.class_1959;
import net.minecraft.class_2338;

@Mixin(class_1959.class)
public class MixinBiome {

	@Inject(method = "getPrecipitation", at = @At("HEAD"), cancellable = true)
	public void getPrecipitation(class_2338 pos, int seaLevel, CallbackInfoReturnable<class_1959.class_1963> cir) {
		
		if(WeatherChangerMod.getInstance().isEnabled() && WeatherChangerMod.getInstance().isSnowing()) {
			cir.setReturnValue(class_1959.class_1963.field_9383);
		}
	}
}
