package com.iekeiclient.mixin.mixins.minecraft.client.render;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.iekeiclient.management.mod.impl.player.OldAnimationsMod;
import com.iekeiclient.management.mod.impl.render.CustomHandMod;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1753;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;

@Mixin(class_759.class)
public abstract class MixinHeldItemRenderer {

	@Shadow
	protected abstract void applySwingOffset(class_4587 matrices, class_1306 arm, float swingProgress);

	@Inject(method = "renderFirstPersonItem", at = @At(value = "INVOKE", target = ("Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"), ordinal = 1))
	private void renderFirstPersonItem(class_742 player, float tickDelta, float pitch, class_1268 hand,
			float swingProgress, class_1799 item, float equipProgress, class_4587 matrices,
			class_4597 vertexConsumers, int light, CallbackInfo ci) {

		OldAnimationsMod mod = OldAnimationsMod.getInstance();

		if (item.method_7909() instanceof class_1753 && mod.isEnabled() && mod.isOldBow()) {
			matrices.method_46416(0f, 0.05f, 0.04f);
			matrices.method_22905(0.93f, 1f, 1f);
		} else if (item.method_7909() instanceof class_1787 && mod.isEnabled() && mod.isOldRod()) {
			matrices.method_46416(0.08f, -0.027f, -0.33f);
			matrices.method_22905(0.93f, 1f, 1f);
		}
	}
	
	@Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
	private void applyCustomHand(class_742 player, float tickDelta, float pitch, class_1268 hand,
			float swingProgress, class_1799 item, float equipProgress, class_4587 matrices,
			class_4597 vertexConsumers, int light, CallbackInfo ci) {
		
		CustomHandMod mod = CustomHandMod.getInstance();
		
		if(mod.isEnabled()) {
			matrices.method_46416(mod.getX(), mod.getY(), mod.getZ());
			matrices.method_22905(mod.getScale(), mod.getScale(), mod.getScale());
		}
	}
	
	@Inject(method = "renderFirstPersonItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;applyEquipOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V", ordinal = 2, shift = At.Shift.AFTER))
	private void applyFoodSwingOffset(class_742 player, float tickDelta, float pitch, class_1268 hand,
			float swingProgress, class_1799 item, float equipProgress, class_4587 matrices,
			class_4597 vertexConsumers, int light, CallbackInfo ci) {
		applyOldSwingOffset(player, hand, swingProgress, matrices);
	}

	@Inject(method = "renderFirstPersonItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;applyEquipOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V", ordinal = 3, shift = At.Shift.AFTER))
	private void applyBlockingSwingOffset(class_742 player, float tickDelta, float pitch, class_1268 hand,
			float swingProgress, class_1799 item, float equipProgress, class_4587 matrices,
			class_4597 vertexConsumers, int light, CallbackInfo ci) {
		applyOldSwingOffset(player, hand, swingProgress, matrices);
	}

	@Inject(method = "renderFirstPersonItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;applyEquipOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V", ordinal = 4, shift = At.Shift.AFTER))
	private void applyBowSwingOffset(class_742 player, float tickDelta, float pitch, class_1268 hand,
			float swingProgress, class_1799 item, float equipProgress, class_4587 matrices,
			class_4597 vertexConsumers, int light, CallbackInfo ci) {
		applyOldSwingOffset(player, hand, swingProgress, matrices);
	}

	@Unique
	private void applyOldSwingOffset(class_742 player, class_1268 hand, float swingProgress,
			class_4587 matrices) {
		if (OldAnimationsMod.getInstance().isEnabled() && OldAnimationsMod.getInstance().isOldBreaking()) {
			final class_1306 arm = hand == class_1268.field_5808 ? player.method_6068() : player.method_6068().method_5928();
			applySwingOffset(matrices, arm, swingProgress);
		}
	}
}
