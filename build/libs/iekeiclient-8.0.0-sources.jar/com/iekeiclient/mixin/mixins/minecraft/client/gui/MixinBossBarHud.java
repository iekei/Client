package com.iekeiclient.mixin.mixins.minecraft.client.gui;

import java.util.Map;
import java.util.UUID;
import net.minecraft.class_10209;
import net.minecraft.class_1259;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_337;
import net.minecraft.class_345;
import net.minecraft.class_3695;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.google.common.collect.Maps;
import com.iekeiclient.management.mod.api.Position;
import com.iekeiclient.management.mod.impl.hud.BossBarMod;

@Mixin(class_337.class)
public abstract class MixinBossBarHud {

	@Shadow
	@Final
	private class_310 client;

	@Shadow
	@Final
	final Map<UUID, class_345> bossBars = Maps.<UUID, class_345>newLinkedHashMap();

	@Shadow
	public abstract void renderBossBar(class_332 context, int x, int y, class_1259 bossBar);

	@Inject(method = "render", at = @At("HEAD"), cancellable = true)
	private void render(class_332 context, CallbackInfo ci) {

		BossBarMod mod = BossBarMod.getInstance();

		if (mod.isEnabled() && !mod.isVanillaPosition()) {
			Position position = mod.getPosition();
			onCustomRender(context, (int) position.getX(), (int) position.getY());
			position.setScale(1.0F);
			position.setSize(182, 14);
			ci.cancel();
		} else if (!mod.isEnabled()) {
			ci.cancel();
		}
	}

	public void onCustomRender(class_332 context, int x, int y) {

		if (!this.bossBars.isEmpty()) {

			class_3695 profiler = class_10209.method_64146();
			profiler.method_15396("bossHealth");
			int j = y;

			for (class_345 clientBossBar : this.bossBars.values()) {

				class_2561 text = clientBossBar.method_5414();
				int m = this.client.field_1772.method_27525(text);
				int n = x - m / 2;
				context.method_27535(this.client.field_1772, text, n, j, 16777215);

				int k = x - 91;
				this.renderBossBar(context, k, j + 9, clientBossBar);

				j += 10 + 9;
				if (j >= context.method_51443() / 3) {
					break;
				}
			}

			profiler.method_15407();
		}
	}
}
