package com.iekeiclient.mixin.interfaces;

import net.minecraft.class_1268;

public interface IMixinLivingEntity {
	void fakeSwingHand(class_1268 hand);
}
