package com.iekeiclient.gui.api;

import com.iekeiclient.skia.Skia;
import com.iekeiclient.skia.context.SkiaContext;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class SimpleIekeiGui {

	protected class_310 client = class_310.method_1551();
	private boolean mcScale;

	public SimpleIekeiGui(boolean mcScale) {
		this.mcScale = mcScale;
	}

	public void init() {
	}

	public void draw(double mouseX, double mouseY) {
	}

	public void mousePressed(double mouseX, double mouseY, int button) {
	}

	public void mouseReleased(double mouseX, double mouseY, int button) {
	}

	public void mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
	}

	public void charTyped(char chr, int modifiers) {
	}

	public void keyPressed(int keyCode, int scanCode, int modifiers) {
	}

	public class_437 build() {
		return new class_437(class_2561.method_43473()) {

			@Override
			public void method_25426() {
				SimpleIekeiGui.this.init();
			}

			@Override
			public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {

				SkiaContext.draw((skiaContext) -> {

					Skia.save();

					if (mcScale) {
						Skia.scale((float) field_22787.method_22683().method_4495());
					}

					SimpleIekeiGui.this.draw(mcScale ? mouseX : field_22787.field_1729.method_1603(),
							mcScale ? mouseY : field_22787.field_1729.method_1604());
					Skia.restore();
				});
			}

			@Override
			public boolean method_25402(class_11909 click, boolean doubleClick) {
				SimpleIekeiGui.this.mousePressed(mcScale ? click.comp_4798() : field_22787.field_1729.method_1603(),
						mcScale ? click.comp_4799() : field_22787.field_1729.method_1604(), click.method_74245());
				return true;
			}

			@Override
			public boolean method_25406(class_11909 click) {
				SimpleIekeiGui.this.mouseReleased(mcScale ? click.comp_4798() : field_22787.field_1729.method_1603(),
						mcScale ? click.comp_4799() : (int) field_22787.field_1729.method_1604(), click.method_74245());
				return true;
			}

			@Override
			public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
				SimpleIekeiGui.this.mouseScrolled(mcScale ? mouseX : field_22787.field_1729.method_1603(),
						mcScale ? mouseY : (int) field_22787.field_1729.method_1604(), horizontalAmount, verticalAmount);
				return true;
			}

			@Override
			public boolean method_25404(class_11908 input) {
				SimpleIekeiGui.this.keyPressed(input.comp_4795(), input.comp_4796(), input.comp_4797());
				return true;
			}

			@Override
			public boolean method_25400(class_11905 input) {
				SimpleIekeiGui.this.charTyped((char) input.comp_4793(), input.comp_4794());
				return true;
			}

			@Override
			public boolean method_25421() {
				return false;
			}
		};
	}
}
