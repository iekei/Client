package com.iekeiclient.utils.server;

import net.minecraft.class_310;

public class ServerUtils {

	private static class_310 client = class_310.method_1551();

	public static boolean isJoin(Server server) {
		return isMultiplayer() && getAddress().contains(server.getAddress());
	}

	public static boolean isSingleplayer() {
		return client.method_47392();
	}

	public static boolean isMultiplayer() {
		return client.method_1558() != null;
	}

	public static String getAddress() {
		return isMultiplayer() ? client.method_1558().field_3761 : "null";
	}
}
