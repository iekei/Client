package com.iekeiclient.utils;

import java.io.File;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import com.iekeiclient.mixin.interfaces.IMixinMinecraftClient;

public class SkinUtils {

	public static File getSkin(class_2960 identifier) {
		String fileName = identifier.method_12832().replace("skins/", "");
		String folder = fileName.substring(0, 2);
		File file = new File(((IMixinMinecraftClient) class_310.method_1551()).getAssetDir(),
				"skins/" + folder + "/" + fileName);
		return file;
	}
}
