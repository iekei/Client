package com.iekeiclient.event.server;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.ReceivePacketEvent;
import com.iekeiclient.event.client.SendPacketEvent;
import com.iekeiclient.event.server.impl.AttackEntityEvent;
import com.iekeiclient.event.server.impl.DamageEntityEvent;
import com.iekeiclient.event.server.impl.GameJoinEvent;
import com.iekeiclient.event.server.impl.ReceiveChatEvent;
import com.iekeiclient.event.server.impl.SendChatEvent;
import com.iekeiclient.mixin.mixins.minecraft.network.packet.PlayerInteractEntityC2SPacketAccessor;
import net.minecraft.class_2596;
import net.minecraft.class_2678;
import net.minecraft.class_2797;
import net.minecraft.class_2824;
import net.minecraft.class_7438;
import net.minecraft.class_7439;
import net.minecraft.class_8143;

public class PacketHandler {

	public final EventBus.EventListener<SendPacketEvent> onSendPacket = packetEvent -> {

		class_2596<?> basePacket = packetEvent.getPacket();

		if (basePacket instanceof class_2824) {

			class_2824 packet = (class_2824) basePacket;
			class_2824.class_5907 type = ((PlayerInteractEntityC2SPacketAccessor) packet)
					.getInteractTypeHandler().method_34211();

			if (type.equals(class_2824.class_5907.field_29172)) {
				EventBus.getInstance()
						.post(new AttackEntityEvent(((PlayerInteractEntityC2SPacketAccessor) packet).entityId()));
			}
		}

		if (basePacket instanceof class_2797) {

			class_2797 packet = (class_2797) basePacket;
			SendChatEvent event = new SendChatEvent(packet.comp_945());

			EventBus.getInstance().post(event);

			if (event.isCancelled()) {
				packetEvent.setCancelled(true);
			}
		}
	};

	public final EventBus.EventListener<ReceivePacketEvent> onReceivePacket = packetEvent -> {

		class_2596<?> basePacket = packetEvent.getPacket();

		if (basePacket instanceof class_8143) {

			class_8143 packet = (class_8143) basePacket;

			EventBus.getInstance().post(new DamageEntityEvent(packet.comp_1267()));
		}

		if (basePacket instanceof class_7438) {

			class_7438 packet = (class_7438) basePacket;
			ReceiveChatEvent event = new ReceiveChatEvent(packet.comp_1102().comp_1090());

			EventBus.getInstance().post(event);

			if (event.isCancelled()) {
				packetEvent.setCancelled(true);
			}
		}

		if (basePacket instanceof class_7439) {

			class_7439 packet = (class_7439) basePacket;
			ReceiveChatEvent event = new ReceiveChatEvent(packet.comp_763().getString());

			EventBus.getInstance().post(event);

			if (event.isCancelled()) {
				packetEvent.setCancelled(true);
			}
		}

		if (basePacket instanceof class_2678) {
			EventBus.getInstance().post(new GameJoinEvent());
		}
	};
}
