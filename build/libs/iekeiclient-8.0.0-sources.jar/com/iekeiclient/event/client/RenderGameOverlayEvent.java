package com.iekeiclient.event.client;

import com.iekeiclient.event.Event;
import net.minecraft.class_332;

public class RenderGameOverlayEvent extends Event {
	
	private final class_332 context;
	
	public RenderGameOverlayEvent(class_332 context) {
		this.context = context;
	}

	public class_332 getContext() {
		return context;
	}
}
