package com.iekeiclient.event.client;

import com.iekeiclient.event.Event;
import net.minecraft.class_2596;

public class ReceivePacketEvent extends Event {

	private final class_2596<?> packet;

	public ReceivePacketEvent(class_2596<?> packet) {
		this.packet = packet;
	}

	public class_2596<?> getPacket() {
		return packet;
	}
}
