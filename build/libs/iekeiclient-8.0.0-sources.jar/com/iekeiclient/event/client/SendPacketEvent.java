package com.iekeiclient.event.client;

import com.iekeiclient.event.Event;
import net.minecraft.class_2596;

public class SendPacketEvent extends Event {

	private final class_2596<?> packet;

	public SendPacketEvent(class_2596<?> packet) {
		this.packet = packet;
	}

	public class_2596<?> getPacket() {
		return packet;
	}
}
