package com.iekeiclient.management.mod.settings.impl;

import com.iekeiclient.Iekei;
import com.iekeiclient.management.mod.Mod;
import com.iekeiclient.management.mod.settings.Setting;
import net.minecraft.class_3675;

public class KeybindSetting extends Setting {

	private class_3675.class_306 defaultKey, key;
	private boolean keyDown;
	private int pressTime;

	public KeybindSetting(String name, String description, String icon, Mod parent, class_3675.class_306 key) {
		super(name, description, icon, parent);

		this.defaultKey = key;
		this.key = key;

		Iekei.getInstance().getModManager().addSetting(this);
	}

	@Override
	public void reset() {
		this.key = this.defaultKey;
	}

	public class_3675.class_306 getKey() {
		return key;
	}

	public void setKey(class_3675.class_306 key) {
		this.key = key;
	}

	public class_3675.class_306 getDefaultKey() {
		return defaultKey;
	}

	public boolean isKeyDown() {
		return keyDown;
	}

	public void setKeyDown(boolean keyDown) {
		this.keyDown = keyDown;
	}

	public boolean isPressed() {
		this.pressTime--;
		return pressTime >= 0;
	}

	public void setPressed() {
		this.pressTime = 1;
	}
}