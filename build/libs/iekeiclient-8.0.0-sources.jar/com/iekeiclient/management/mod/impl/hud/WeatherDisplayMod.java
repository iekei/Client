package com.iekeiclient.management.mod.impl.hud;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.RenderSkiaEvent;
import com.iekeiclient.management.mod.api.hud.SimpleHUDMod;
import com.iekeiclient.skia.font.Icon;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_746;

public class WeatherDisplayMod extends SimpleHUDMod {

	public WeatherDisplayMod() {
		super("mod.weatherdisplay.name", "mod.weatherdisplay.description", Icon.SUNNY);
	}

	public final EventBus.EventListener<RenderSkiaEvent> onRenderSkia = event -> {
		this.draw();
	};

	@Override
	public String getText() {

		String prefix = "Weather: ";
		class_638 world = client.field_1687;
		class_746 player = client.field_1724;
		class_2338 playerPos = player.method_24515();
		class_6880<class_1959> biomeEntry = world.method_23753(playerPos);

		if (world.method_8546()) {
			return prefix + "Thundering";
		}
		
		if (world.method_8419()) {
			if (biomeEntry.comp_349().method_48162(playerPos, world.method_8615()).equals(class_1959.class_1963.field_9383)) {
				return prefix + "Snowing";
			} else {
				return prefix + "Raining";
			}
		}

		return prefix + "Cleaning";
	}

	@Override
	public String getIcon() {

		class_638 world = client.field_1687;
		class_746 player = client.field_1724;
		class_2338 playerPos = player.method_24515();
		class_6880<class_1959> biomeEntry = world.method_23753(playerPos);

		String iconFont = Icon.SUNNY;

		if (world.method_8546()) {
			iconFont = Icon.THUNDERSTORM;
		}
		
		if (world.method_8419()) {
			if (biomeEntry.comp_349().method_48162(playerPos, world.method_8615()).equals(class_1959.class_1963.field_9383)) {
				iconFont = Icon.WEATHER_SNOWY;
			} else {
				iconFont = Icon.RAINY;
			}
		}

		return iconFont;
	}
}