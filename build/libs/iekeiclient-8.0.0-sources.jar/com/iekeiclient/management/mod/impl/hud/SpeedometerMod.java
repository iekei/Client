package com.iekeiclient.management.mod.impl.hud;

import java.text.DecimalFormat;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.RenderSkiaEvent;
import com.iekeiclient.management.mod.api.hud.SimpleHUDMod;
import com.iekeiclient.skia.font.Icon;

public class SpeedometerMod extends SimpleHUDMod {

	private DecimalFormat speedFormat = new DecimalFormat("0.00");

	public SpeedometerMod() {
		super("mod.speedometer.name", "mod.speedometer.description", Icon.SPEED);
	}

	public final EventBus.EventListener<RenderSkiaEvent> onRenderSkia = event -> {
		this.draw();
	};
	
	@Override
	public String getText() {

		String suffix = " m/s";
		
		if (client.field_1724 != null) {
			
			class_1297 entity = client.field_1724.method_5854() == null ? client.field_1724 : client.field_1724.method_5854();
			class_243 vec = entity.method_60478();
			
			if (entity.method_24828() && vec.field_1351 < 0) {
				vec = new class_243(vec.field_1352, 0, vec.field_1350);
			}
			
			return speedFormat.format(vec.method_1033() * 20) + suffix;
		}

		return speedFormat.format(0) + suffix;
	}

	@Override
	public String getIcon() {
		return Icon.SPEED;
	}
}
