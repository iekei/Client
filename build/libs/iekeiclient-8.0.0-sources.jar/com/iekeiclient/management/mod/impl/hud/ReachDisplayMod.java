package com.iekeiclient.management.mod.impl.hud;

import java.text.DecimalFormat;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.RenderSkiaEvent;
import com.iekeiclient.event.server.impl.AttackEntityEvent;
import com.iekeiclient.event.server.impl.DamageEntityEvent;
import com.iekeiclient.management.mod.api.hud.SimpleHUDMod;
import com.iekeiclient.skia.font.Icon;

public class ReachDisplayMod extends SimpleHUDMod {

	private DecimalFormat df = new DecimalFormat("0.##");

	private double distance = 0;
	private long hitTime = -1;
	private int possibleTarget;

	public ReachDisplayMod() {
		super("mod.reachdisplay.name", "mod.reachdisplay.description", Icon.SOCIAL_DISTANCE);
	}

	public final EventBus.EventListener<RenderSkiaEvent> onRenderSkia = event -> {
		this.draw();
	};

	public final EventBus.EventListener<DamageEntityEvent> onDamageEntity = event -> {

		if (event.getEntityId() == possibleTarget) {

			class_1297 entity = client.field_1687.method_8469(event.getEntityId());

			possibleTarget = -1;
			distance = client.field_1724.method_33571()
					.method_1022(closestPointToBox(client.field_1724.method_33571(), entity.method_5829()));
			hitTime = System.currentTimeMillis();
		}
	};

	public final EventBus.EventListener<AttackEntityEvent> onAttackEntity = event -> {
		possibleTarget = event.getEntityId();
	};

	private class_243 closestPointToBox(class_243 start, class_238 box) {
		return new class_243(coerceIn(start.field_1352, box.field_1323, box.field_1320), coerceIn(start.field_1351, box.field_1322, box.field_1325),
				coerceIn(start.field_1350, box.field_1321, box.field_1324));
	}

	private double coerceIn(double target, double min, double max) {
		if (target > max) {
			return max;
		}
		return Math.max(target, min);
	}

	@Override
	public String getText() {

		if ((System.currentTimeMillis() - hitTime) > 5000) {
			distance = 0;
		}

		if (distance == 0) {
			return "Hasn't attacked";
		} else {
			return df.format(distance) + " blocks";
		}
	}

	@Override
	public String getIcon() {
		return Icon.SOCIAL_DISTANCE;
	}
}