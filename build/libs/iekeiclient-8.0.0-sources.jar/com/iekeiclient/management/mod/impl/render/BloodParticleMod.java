package com.iekeiclient.management.mod.impl.render;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.server.impl.AttackEntityEvent;
import com.iekeiclient.management.mod.Mod;
import com.iekeiclient.management.mod.ModCategory;
import com.iekeiclient.management.mod.settings.impl.BooleanSetting;
import com.iekeiclient.management.mod.settings.impl.NumberSetting;
import com.iekeiclient.skia.font.Icon;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class BloodParticleMod extends Mod {

	private BooleanSetting soundSetting = new BooleanSetting("setting.sound", "setting.sound.description",
			Icon.EQUALIZER, this, true);
	private NumberSetting multiplierSetting = new NumberSetting("setting.multiplier",
			"setting.bloodparticle.multiplier.description", Icon.CALCULATE, this, 2, 1, 10, 1);

	public BloodParticleMod() {
		super("mod.bloodparticles.name", "mod.bloodparticles.description", Icon.MENSTRUAL_HEALTH, ModCategory.RENDER);
	}

	public final EventBus.EventListener<AttackEntityEvent> onAttackEntity = event -> {

		class_1297 target = client.field_1687.method_8469(event.getEntityId());

		if (target != null && target instanceof class_1309) {
			for (int i = 0; i < multiplierSetting.getValue(); i++) {
				client.field_1713.method_3061(target,
						new class_2388(class_2398.field_11217, class_2246.field_10002.method_9564()));
			}
		}

		if (soundSetting.isEnabled() && target != null) {
			client.method_1483()
					.method_4873(new class_1109(class_3417.field_15026.comp_3319(), class_3419.field_15245, 4.0F,
							1.2F, class_1113.method_43221(), false, 0, class_1113.class_1114.field_5476,
							target.method_23317(), target.method_23318(), target.method_23321(), false));
		}
	};
}