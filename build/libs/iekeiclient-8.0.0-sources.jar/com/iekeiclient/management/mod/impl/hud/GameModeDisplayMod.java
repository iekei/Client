package com.iekeiclient.management.mod.impl.hud;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.RenderSkiaEvent;
import com.iekeiclient.management.mod.api.hud.SimpleHUDMod;
import com.iekeiclient.skia.font.Icon;

public class GameModeDisplayMod extends SimpleHUDMod {

	public GameModeDisplayMod() {
		super("mod.gamemodedisplay.name", "mod.gamemodedisplay.description", Icon.SPORTS_ESPORTS);
	}

	public final EventBus.EventListener<RenderSkiaEvent> onRenderSkia = event -> {
		this.draw();
	};

	@Override
	public String getText() {

		String prefix = "Mode: ";

		if (client.field_1724.method_68878()) {
			return prefix + "Creative";
		} else if (client.field_1724.method_7325()) {
			return prefix + "Spectator";
		} else {
			return prefix + "Survival";
		}
	}

	@Override
	public String getIcon() {
		return Icon.SPORTS_ESPORTS;
	}
}