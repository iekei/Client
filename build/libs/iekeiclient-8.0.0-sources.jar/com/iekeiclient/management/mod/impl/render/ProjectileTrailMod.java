package com.iekeiclient.management.mod.impl.render;

import java.util.Arrays;
import net.minecraft.class_1676;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.ClientTickEvent;
import com.iekeiclient.management.mod.Mod;
import com.iekeiclient.management.mod.ModCategory;
import com.iekeiclient.management.mod.settings.impl.ComboSetting;
import com.iekeiclient.skia.font.Icon;

public class ProjectileTrailMod extends Mod {

	private ComboSetting effectSetting = new ComboSetting("setting.effect", "setting.effect.description",
			Icon.EXPLOSION, this,
			Arrays.asList("setting.blacksmoke", "setting.fire", "setting.greenstar", "setting.hearts", "setting.magic",
					"setting.musicnote", "setting.slime", "setting.spark", "setting.swirl", "setting.whitesmoke"),
			"setting.hearts");

	public ProjectileTrailMod() {
		super("mod.projectiletrail.name", "mod.projectiletrail.description", Icon.TRAIL_LENGTH, ModCategory.RENDER);
	}

	public final EventBus.EventListener<ClientTickEvent> onClientTick = event -> {

		if (client.field_1724 != null && client.field_1687 != null) {

			class_238 box = new class_238(client.field_1724.method_30950(1).method_1031(-150.0, -150.0, -150.0),
					client.field_1724.method_30950(1).method_1031(150.0, 150.0, 150.0));

			for (class_1676 projectile : client.field_1687.method_8390(class_1676.class, box,
					entity -> true)) {

				if (!(projectile.method_18798().method_1027() > 0.01) || projectile.method_24828()
						|| client.field_1687.method_8320(projectile.method_24515()).method_26212(client.field_1687,
								projectile.method_24515()) && projectile.method_24921().method_5628() != client.field_1724.method_5628()) {
					continue;
				}

				class_2394 type = getCurrentType();

				if (type != null) {
					client.field_1713.method_3056(type, projectile.method_23317(), projectile.method_23318(),
							projectile.method_23321(), 0.0, 0.0, 0.0);
				}
			}
		}
	};

	private class_2394 getCurrentType() {

		String option = effectSetting.getOption();

		if (option.contains("blacksmoke")) {
			return class_2398.field_11251;
		} else if (option.contains("fire")) {
			return class_2398.field_11240;
		} else if (option.contains("greenstar")) {
			return class_2398.field_11211;
		} else if (option.contains("hearts")) {
			return class_2398.field_11201;
		} else if (option.contains("magic")) {
			return class_2398.field_11249;
		} else if (option.contains("musicnote")) {
			return class_2398.field_11224;
		} else if (option.contains("slime")) {
			return class_2398.field_11246;
		} else if (option.contains("spark")) {
			return class_2398.field_11248;
		} else if (option.contains("whitesmoke")) {
			return class_2398.field_46911;
		}

		return null;
	}
}