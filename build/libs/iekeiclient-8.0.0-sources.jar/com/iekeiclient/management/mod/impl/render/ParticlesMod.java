package com.iekeiclient.management.mod.impl.render;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.server.impl.AttackEntityEvent;
import com.iekeiclient.management.mod.Mod;
import com.iekeiclient.management.mod.ModCategory;
import com.iekeiclient.management.mod.settings.impl.BooleanSetting;
import com.iekeiclient.management.mod.settings.impl.NumberSetting;
import com.iekeiclient.skia.font.Icon;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2398;
import net.minecraft.class_746;
import net.minecraft.class_7924;

public class ParticlesMod extends Mod {

	private BooleanSetting alwaysSharpnessSetting = new BooleanSetting("setting.alwayssharpness",
			"setting.alwayssharpness.description", Icon.CONTRAST, this, false);
	private BooleanSetting alwaysCriticalsSetting = new BooleanSetting("setting.alwayscriticals",
			"setting.alwayscriticals.description", Icon.CONTRAST, this, false);
	private BooleanSetting sharpnessSetting = new BooleanSetting("setting.sharpness", "setting.sharpness.description",
			Icon.FLARE, this, true);
	private BooleanSetting criticalsSetting = new BooleanSetting("setting.criticals", "setting.criticals.description",
			Icon.FLARE, this, true);
	private NumberSetting sharpnessAmountSetting = new NumberSetting("setting.sharpnessamount",
			"setting.sharpnessamount.description", Icon.FILTER_5, this, 2, 1, 10, 1);
	private NumberSetting criticalsAmountSetting = new NumberSetting("setting.criticalsamount",
			"setting.criticalsamount.description", Icon.FILTER_5, this, 2, 1, 10, 1);

	public ParticlesMod() {
		super("mod.particles.name", "mod.particles.description", Icon.FLARE, ModCategory.RENDER);
	}

	public final EventBus.EventListener<AttackEntityEvent> onAttackEntity = event -> {

		int sharpnessAmount = (int) sharpnessAmountSetting.getValue();
		int criticalsAmount = (int) criticalsAmountSetting.getValue();
		class_1297 target = client.field_1687.method_8469(event.getEntityId());
		class_746 player = client.field_1724;

		boolean critical = criticalsSetting.isEnabled() && player.method_7261(0.5F) > 0.9F
				&& !player.method_24828() && !player.method_6101() && !player.method_5799()
				&& !player.method_6059(class_1294.field_5919) && !player.method_5765()
				&& target instanceof class_1309 && !player.method_5624();
		boolean alwaysSharpness = alwaysSharpnessSetting.isEnabled();
		boolean sharpness = sharpnessSetting.isEnabled() && class_1890.method_8225(client.field_1687.method_30349()
				.method_30530(class_7924.field_41265).method_46747(class_1893.field_9118), player.method_59958()) > 0;
		boolean alwaysCriticals = alwaysCriticalsSetting.isEnabled();

		if (critical || alwaysCriticals) {
			for (int i = 0; i < criticalsAmount - 1; i++) {
				client.field_1713.method_3061(target, class_2398.field_11205);
			}
		}

		if (alwaysSharpness || sharpness) {
			for (int i = 0; i < sharpnessAmount - 1; i++) {
				client.field_1713.method_3061(target, class_2398.field_11208);
			}
		}
	};
}
