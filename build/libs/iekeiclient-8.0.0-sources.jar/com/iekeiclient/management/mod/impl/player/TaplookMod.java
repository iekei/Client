package com.iekeiclient.management.mod.impl.player;

import java.util.Arrays;
import net.minecraft.class_11908;
import net.minecraft.class_3675;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.ClientTickEvent;
import com.iekeiclient.management.mod.Mod;
import com.iekeiclient.management.mod.ModCategory;
import com.iekeiclient.management.mod.settings.impl.BooleanSetting;
import com.iekeiclient.management.mod.settings.impl.ComboSetting;
import com.iekeiclient.management.mod.settings.impl.KeybindSetting;
import com.iekeiclient.skia.font.Icon;

public class TaplookMod extends Mod {

	private boolean active;
	private class_5498 prevPerspective;
	private boolean toggled;

	private ComboSetting perspectiveSetting = new ComboSetting("setting.perspective", "setting.perspective.description",
			Icon.CAMERASWITCH, this, Arrays.asList("setting.front", "setting.behind"), "setting.front");
	private BooleanSetting toggleSetting = new BooleanSetting("setting.toggle", "setting.toggle.description",
			Icon.SWITCH, this, false);
	private KeybindSetting keybindSetting = new KeybindSetting("setting.keybind", "setting.keybind.description",
			Icon.KEYBOARD, this, class_3675.method_15985(new class_11908(GLFW.GLFW_KEY_V, 0, 0)));

	public TaplookMod() {
		super("mod.taplook.name", "mod.taplook.description", Icon.TOUCH_APP, ModCategory.PLAYER);
	}

	public final EventBus.EventListener<ClientTickEvent> onClientTick = event -> {

		if (toggleSetting.isEnabled()) {

			if (keybindSetting.isPressed()) {
				toggled = !toggled;

				if (toggled) {
					if (!active) {
						this.start();
					}
				} else {
					if (active) {
						this.stop();
					}
				}
			}
		} else {
			if (keybindSetting.isKeyDown()) {
				if (!active) {
					this.start();
				}
			} else if (active) {
				this.stop();
			}
		}
	};

	private void start() {

		String option = perspectiveSetting.getOption();
		class_5498 perspective = option.equals("setting.front") ? class_5498.field_26666
				: class_5498.field_26665;

		active = true;
		prevPerspective = client.field_1690.method_31044();
		client.field_1690.method_31043(perspective);
	}

	private void stop() {
		active = false;
		client.field_1690.method_31043(prevPerspective);
	}
}
