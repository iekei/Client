package com.iekeiclient.management.mod.impl.player;

import java.util.Arrays;
import net.minecraft.class_11908;
import net.minecraft.class_3675;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.ClientTickEvent;
import com.iekeiclient.management.mod.Mod;
import com.iekeiclient.management.mod.ModCategory;
import com.iekeiclient.management.mod.settings.impl.BooleanSetting;
import com.iekeiclient.management.mod.settings.impl.ComboSetting;
import com.iekeiclient.management.mod.settings.impl.KeybindSetting;
import com.iekeiclient.skia.font.Icon;

public class FreelookMod extends Mod {

	private static FreelookMod instance;
	private boolean active;
	private boolean toggled;
	private class_5498 prevPerspective;

	private ComboSetting perspectiveSetting = new ComboSetting("setting.perspective", "setting.perspective.description",
			Icon.CAMERASWITCH, this, Arrays.asList("setting.front", "setting.behind"), "setting.behind");
	private BooleanSetting toggleSetting = new BooleanSetting("setting.toggle", "setting.toggle.description",
			Icon.SWITCH, this, false);
	private KeybindSetting keybindSetting = new KeybindSetting("setting.keybind", "setting.keybind.description",
			Icon.KEYBOARD, this, class_3675.method_15985(new class_11908(GLFW.GLFW_KEY_B, 0, 0)));

	public FreelookMod() {
		super("mod.freelook.name", "mod.freelook.description", Icon._360, ModCategory.PLAYER);

		instance = this;
		active = false;
	}

	public final EventBus.EventListener<ClientTickEvent> onClientTick = event -> {

		if (toggleSetting.isEnabled()) {

			if (keybindSetting.isPressed()) {
				toggled = !toggled;

				if (toggled) {
					if (!active) {
						this.start();
					}
				} else {
					if (active) {
						this.stop();
					}
				}
			}
		} else {
			if (keybindSetting.isKeyDown()) {
				if (!active) {
					this.start();
				}
			} else if (active) {
				this.stop();
			}
		}
	};

	private void start() {

		String option = perspectiveSetting.getOption();
		class_5498 perspective = option.equals("setting.front") ? class_5498.field_26666
				: class_5498.field_26665;

		active = true;
		prevPerspective = client.field_1690.method_31044();
		client.field_1690.method_31043(perspective);
	}

	private void stop() {
		active = false;
		client.field_1690.method_31043(prevPerspective);
	}

	public static FreelookMod getInstance() {
		return instance;
	}

	public boolean isActive() {
		return active;
	}
}
