package com.iekeiclient.management.websocket;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_310;
import net.minecraft.class_320;
import com.google.gson.JsonObject;
import com.mojang.authlib.GameProfile;
import com.iekeiclient.management.websocket.client.IekeiWebSocketClient;
import com.iekeiclient.management.websocket.packet.IekeiPacket;
import com.iekeiclient.utils.HttpUtils;

public class WebSocketManager {

    private static final int MAX_RETRY = 3;
    
    private class_310 client = class_310.method_1551();
    private GameProfile gameProfile;
    private IekeiWebSocketClient webSocket;
    private int retryCount = 0;
    
    public WebSocketManager() {
        new Thread("Websocket Thread") {
            @Override
            public void run() {
                while (true) {
                	
                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                    }
                    
                    GameProfile currentProfile = client.method_53462();
                    
                    if (gameProfile != null && currentProfile != null && !gameProfile.equals(currentProfile)) {
                        retryCount = 0;
                    }
                    
                    if ((webSocket == null || !gameProfile.equals(currentProfile) || webSocket.isClosed()) 
                            && retryCount < MAX_RETRY) {
                        
                        gameProfile = currentProfile;
                        
                        if (webSocket != null) {
                            webSocket.close();
                        }
                        
                        JsonObject postObject = new JsonObject();
                        class_320 session = client.method_1548();

                        postObject.addProperty("accessToken", session.method_1674());
                        postObject.addProperty("selectedProfile", session.method_44717().toString().replace("-", ""));
                        postObject.addProperty("serverId", "cbd2c3f65d7ba5cceba0cc9647ff9a85c371f4");
                        HttpUtils.postJson("https://sessionserver.mojang.com/session/minecraft/join", postObject);
                        
                        Map<String, String> headers = new HashMap<>();
                        headers.put("name", gameProfile.name());
                        headers.put("uuid", gameProfile.id().toString().replace("-", ""));
                        
                        try {
                            webSocket = new IekeiWebSocketClient(headers, () -> {
                            	retryCount++;
                            });
                            webSocket.connect();
                        } catch (URISyntaxException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }.start();
    }
    
    public void send(IekeiPacket packet) {
        if (webSocket != null && webSocket.isOpen()) {
            webSocket.send(packet.toJson().toString());
        }
    }
}
