package com.iekeiclient.ui.component.handler.impl;

import com.iekeiclient.ui.component.handler.ComponentHandler;

public abstract class SliderHandler extends ComponentHandler {
	public abstract void onValueChanged(float value);
}
