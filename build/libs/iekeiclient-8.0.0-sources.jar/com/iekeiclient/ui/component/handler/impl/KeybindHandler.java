package com.iekeiclient.ui.component.handler.impl;

import com.iekeiclient.ui.component.handler.ComponentHandler;
import net.minecraft.class_3675.class_306;

public abstract class KeybindHandler extends ComponentHandler {
	public abstract void onBinded(class_306 key);
}