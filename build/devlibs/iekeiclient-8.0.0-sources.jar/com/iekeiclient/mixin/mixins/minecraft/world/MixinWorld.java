package com.iekeiclient.mixin.mixins.minecraft.world;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.iekeiclient.management.mod.impl.misc.WeatherChangerMod;

import net.minecraft.world.World;

@Mixin(World.class)
public class MixinWorld {

	@Inject(method = "getRainGradient", at = @At("HEAD"), cancellable = true)
	public void getRainGradient(float delta, CallbackInfoReturnable<Float> cir) {
		
		WeatherChangerMod mod = WeatherChangerMod.getInstance();
		
		if(mod.isEnabled()) {
			if(mod.isRaining()) {
				cir.setReturnValue(1F);
			} else {
				cir.setReturnValue(0F);
			}
		}
	}
	
	@Inject(method = "isRaining", at = @At("HEAD"), cancellable = true)
	public void isRaining(CallbackInfoReturnable<Boolean> cir) {
		if(WeatherChangerMod.getInstance().isEnabled()) {
			cir.setReturnValue(WeatherChangerMod.getInstance().isRaining());
		}
	}
	
	@Inject(method = "getThunderGradient", at = @At("HEAD"), cancellable = true)
	public void getThunderGradient(float delta, CallbackInfoReturnable<Float> cir) {
		
		WeatherChangerMod mod = WeatherChangerMod.getInstance();
		
		if(mod.isEnabled()) {
			if(mod.isThundering()) {
				cir.setReturnValue(1F);
			} else {
				cir.setReturnValue(0F);
			}
		}
	}
	
	@Inject(method = "isThundering", at = @At("HEAD"), cancellable = true)
	public void isThundering(CallbackInfoReturnable<Boolean> cir) {
		if(WeatherChangerMod.getInstance().isEnabled()) {
			cir.setReturnValue(WeatherChangerMod.getInstance().isThundering());
		}
	}
}
