package com.iekeiclient.addons.rejects.gui.hud;

import com.iekeiclient.addons.rejects.IekeiRejectsAddon;
import com.iekeiclient.engine.renderer.Renderer2D;
import com.iekeiclient.engine.settings.*;
import com.iekeiclient.engine.systems.hud.HudElement;
import com.iekeiclient.engine.systems.hud.HudElementInfo;
import com.iekeiclient.engine.systems.hud.HudRenderer;
import com.iekeiclient.engine.systems.modules.Modules;
import com.iekeiclient.engine.systems.modules.render.ESP;
import com.iekeiclient.engine.systems.waypoints.Waypoint;
import com.iekeiclient.engine.systems.waypoints.Waypoints;
import com.iekeiclient.engine.utils.render.color.Color;
import com.iekeiclient.engine.utils.render.color.SettingColor;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.Set;

import static com.iekeiclient.engine.IekeiClient.mc;

public class RadarHud extends HudElement {
    public static final HudElementInfo<RadarHud> INFO = new HudElementInfo<>(IekeiRejectsAddon.HUD_GROUP, "radar", "Draws a Radar on your HUD telling you where entities are.", RadarHud::new);

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<SettingColor> backgroundColor = sgGeneral.add(new ColorSetting.Builder()
            .name("background-color")
            .description("Color of background.")
            .defaultValue(new SettingColor(0, 0, 0, 64))
            .build()
    );


    private final Setting<Set<EntityType<?>>> entities = sgGeneral.add(new EntityTypeListSetting.Builder()
            .name("entities")
            .description("Select specific entities.")
            .defaultValue(EntityType.PLAYER)
            .build()
    );

    private final Setting<Boolean> letters = sgGeneral.add(new BoolSetting.Builder()
            .name("letters")
            .description("Use entity's type first letter.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> showWaypoints = sgGeneral.add(new BoolSetting.Builder()
            .name("waypoints")
            .description("Show waypoints.")
            .defaultValue(false)
            .build()
    );

    private final Setting<Double> scale = sgGeneral.add(new DoubleSetting.Builder()
            .name("scale")
            .description("The scale.")
            .defaultValue(1)
            .min(1)
            .sliderRange(0.01, 5)
            .onChanged(aDouble -> calculateSize())
        .build()
    );

    private final Setting<Double> zoom = sgGeneral.add(new DoubleSetting.Builder()
        .name("zoom")
        .description("Radar zoom.")
        .defaultValue(1)
        .min(0.01)
        .sliderRange(0.01, 3)
        .build()
    );

    public RadarHud() {
        super(INFO);
        calculateSize();
    }

    public void calculateSize() {
        setSize(200 * scale.get(), 200 * scale.get());
    }

    @Override
    public void render(HudRenderer renderer) {
        ESP esp = Modules.get().get(ESP.class);
        if (esp == null) return;
        renderer.post(() -> {
            if (mc.player == null) return;
            double width  = getWidth();
            double height = getHeight();
            Renderer2D.COLOR.begin();
            Renderer2D.COLOR.quad(x, y, width, height, backgroundColor.get());
            Renderer2D.COLOR.render();
            if (mc.world != null) {
                for (Entity entity : mc.world.getEntities()) {
                    if (!entities.get().contains(entity.getType())) return;
                    double xPos = ((entity.getX() - mc.player.getX()) * scale.get() * zoom.get() + width/2);
                    double yPos = ((entity.getZ() - mc.player.getZ()) * scale.get() * zoom.get()  + height/2);
                    if (xPos < 0 || yPos < 0 || xPos > width - scale.get() || yPos > height - scale.get()) continue;
                    String icon = "*";
                    if (letters.get()) 
                        icon = entity.getType().getUntranslatedName().substring(0,1).toUpperCase();
                    Color c = esp.getColor(entity);
                    if (c == null) c = Color.WHITE;
                    renderer.text(icon, xPos + x, yPos + y, c, false);
                }
            }
            if (showWaypoints.get()) {
                for (Waypoint waypoint : Waypoints.get()) {
                    BlockPos blockPos = waypoint.getPos();
                    Vec3d coords = new Vec3d(blockPos.getX() + 0.5, blockPos.getY(), blockPos.getZ() + 0.5);
                    double xPos = ((coords.getX() - mc.player.getX()) * scale.get() * zoom.get() + width / 2);
                    double yPos = ((coords.getZ() - mc.player.getZ()) * scale.get() * zoom.get() + height / 2);
                    if (xPos < 0 || yPos < 0 || xPos > width - scale.get() || yPos > height - scale.get()) continue;
                    String icon = "*";
                    if (letters.get() && !waypoint.name.get().isEmpty())
                        icon = waypoint.name.get().substring(0, 1);
                    renderer.text(icon, xPos + x, yPos + y, waypoint.color.get(), false);
                }
            }
            Renderer2D.COLOR.render();
        });
        
    }
    
}
