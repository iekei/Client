package com.iekeiclient.addons.rejects.gui.screens;

import com.iekeiclient.addons.rejects.utils.GiveUtils;
import com.google.common.reflect.TypeToken;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.iekeiclient.engine.gui.GuiTheme;
import com.iekeiclient.engine.gui.WindowScreen;
import com.iekeiclient.engine.gui.widgets.containers.WTable;
import com.iekeiclient.engine.gui.widgets.pressable.WButton;
import com.iekeiclient.engine.settings.EnumSetting;
import com.iekeiclient.engine.settings.Setting;
import com.iekeiclient.engine.settings.SettingGroup;
import com.iekeiclient.engine.settings.Settings;
import com.iekeiclient.engine.utils.network.Http;
import com.iekeiclient.engine.utils.network.IekeiExecutor;
import com.iekeiclient.engine.utils.player.ChatUtils;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.Text;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.iekeiclient.engine.IekeiClient.mc;

public class HeadScreen extends WindowScreen {

    public enum Categories {
        Alphabet,
        Animals,
        Blocks,
        Decoration,
        Food_Drinks,
        Humanoid,
        Miscellaneous,
        Monsters,
        Plants
    }

    private static final Type gsonType = new TypeToken<List<Map<String, String>>>() {}.getType();

    private final Settings settings = new Settings();
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private static Categories category = Categories.Decoration;
    private final Setting<Categories> categorySetting = sgGeneral.add(new EnumSetting.Builder<Categories>()
        .name("Category")
        .defaultValue(category)
        .description("Category")
        .onChanged((v) -> this.loadHeads())
        .build()
    );

    public HeadScreen(GuiTheme theme) {
        super(theme, "Heads");
        loadHeads();
    }

    private void set() {
        clear();
        add(theme.settings(settings)).expandX();
        add(theme.horizontalSeparator()).expandX();
    }

    private String getCat() {
        category = categorySetting.get();
        return category.toString().replace("_", "-");
    }

    private void loadHeads() {
        IekeiExecutor.execute(() -> {
            List<Map<String, String>> res = Http.get("https://minecraft-heads.com/scripts/api.php?cat="+getCat()).sendJson(gsonType);
            List<ItemStack> heads = new ArrayList<>();
            res.forEach(a -> {
                try {
                    heads.add(createHeadStack(a.get("uuid"), a.get("value"), a.get("name")));
                } catch (Exception e) { }
            });

            WTable t = theme.table();
            for (ItemStack head : heads) {
                t.add(theme.item(head));
                t.add(theme.label(head.getName().getString()));
                WButton give = t.add(theme.button("Give")).widget();
                give.action = () -> {
                    try {
                        GiveUtils.giveItem(head);
                    } catch (CommandSyntaxException e) {
                        ChatUtils.errorPrefix("Heads", e.getMessage());
                    }
                };
                WButton equip = t.add(theme.button("Equip")).widget();
                equip.tooltip = "Equip client-side.";
                equip.action = () -> mc.player.equipStack(EquipmentSlot.HEAD, head.copy());
                t.row();
            }
            set();
            add(t).expandX().minWidth(400).widget();
        });
    }

    private ItemStack createHeadStack(String uuid, String value, String name) {
        ItemStack head = Items.PLAYER_HEAD.getDefaultStack();
        NbtCompound tag = new NbtCompound();
        tag.put("SkullOwner", createSkullOwnerNbt(uuid, name, value));
        head.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));
        head.set(DataComponentTypes.CUSTOM_NAME, Text.literal(name));
        return head;
    }

    @Override
    public void initWidgets() {}

    private static NbtCompound createSkullOwnerNbt(String uuidString, String name, String textureValue) {
        NbtCompound skullOwner = new NbtCompound();

        try {
            if (uuidString != null && !uuidString.isEmpty()) skullOwner.putString("Id", UUID.fromString(uuidString).toString());
        } catch (IllegalArgumentException ignored) {
        }

        if (name != null && !name.isEmpty()) skullOwner.putString("Name", name);

        if (textureValue != null && !textureValue.isEmpty()) {
            NbtCompound properties = new NbtCompound();
            NbtList textures = new NbtList();
            NbtCompound value = new NbtCompound();
            value.putString("Value", textureValue);
            textures.add(value);
            properties.put("textures", textures);
            skullOwner.put("Properties", properties);
        }

        return skullOwner;
    }
}
