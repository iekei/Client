package com.iekeiclient.addons.rejects.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.iekeiclient.engine.commands.Command;
import com.iekeiclient.engine.systems.modules.Module;
import com.iekeiclient.engine.systems.modules.Modules;
import net.minecraft.command.CommandSource;

import java.util.ArrayList;

public class PanicCommand extends Command {
    public PanicCommand() {
        super("panic", "Disables all modules.", "disable-all");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            new ArrayList<>(Modules.get().getActive()).forEach(Module::toggle);

            return SINGLE_SUCCESS;
        });
    }
}
