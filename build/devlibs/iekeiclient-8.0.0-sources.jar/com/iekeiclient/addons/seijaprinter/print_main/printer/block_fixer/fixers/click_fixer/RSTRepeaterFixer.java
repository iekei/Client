/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers.click_fixer;

import net.minecraft.block.*;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;

public class RSTRepeaterFixer extends AbstractClickFixer {


    public RSTRepeaterFixer() {
        super("RepeaterFix");
    }

    @Override
    public boolean needFix(BlockPos pos, BlockState needState) {
        if (!super.needFix(pos,needState)) {
            return false;
        }
        BlockState blockState = mc.world.getBlockState(pos);
        if (
            blockState.getBlock() instanceof RepeaterBlock
                &&needState.getBlock()==blockState.getBlock()) {
            return !blockState.get(Properties.DELAY).equals(needState.get(Properties.DELAY));
        }
        return false;
    }
}
