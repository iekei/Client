/*
 * Copyright 2025 Nippaku_Zanmu
 * SPDX-License-Identifier: gplv3
 */

package com.iekeiclient.addons.seijaprinter.print_main.printer.block_fixer.fixers.click_fixer;

import net.minecraft.block.*;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;

public class DoorFixer extends AbstractClickFixer {
    public DoorFixer() {
        super("DoorFix");
    }

    @Override
    public boolean needFix(BlockPos pos, BlockState needState) {
        if (!super.needFix(pos,needState)) {
            return false;
        }
        BlockState blockState = mc.world.getBlockState(pos);
        if (blockState.getBlock()!= Blocks.IRON_DOOR
            &&blockState.getBlock()!= Blocks.IRON_TRAPDOOR
            &&(blockState.getBlock() instanceof DoorBlock
            || blockState.getBlock() instanceof FenceGateBlock
            || blockState.getBlock() instanceof TrapdoorBlock)) {
            return needState.getBlock().getClass().equals(blockState.getBlock().getClass())
                &&blockState.get(Properties.OPEN) != needState.get(Properties.OPEN);
        }
        return false;
    }
}
