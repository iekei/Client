package com.iekeiclient.management.mod.impl.player;

import java.util.Arrays;

import org.lwjgl.glfw.GLFW;

import com.iekeiclient.event.EventBus;
import com.iekeiclient.event.client.ClientTickEvent;
import com.iekeiclient.management.mod.Mod;
import com.iekeiclient.management.mod.ModCategory;
import com.iekeiclient.management.mod.settings.impl.BooleanSetting;
import com.iekeiclient.management.mod.settings.impl.ComboSetting;
import com.iekeiclient.management.mod.settings.impl.KeybindSetting;
import com.iekeiclient.skia.font.Icon;

import net.minecraft.client.option.Perspective;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;

public class FreelookMod extends Mod {

	private static FreelookMod instance;
	private boolean active;
	private boolean toggled;
	private Perspective prevPerspective;

	private ComboSetting perspectiveSetting = new ComboSetting("setting.perspective", "setting.perspective.description",
			Icon.CAMERASWITCH, this, Arrays.asList("setting.front", "setting.behind"), "setting.behind");
	private BooleanSetting toggleSetting = new BooleanSetting("setting.toggle", "setting.toggle.description",
			Icon.SWITCH, this, false);
	private KeybindSetting keybindSetting = new KeybindSetting("setting.keybind", "setting.keybind.description",
			Icon.KEYBOARD, this, InputUtil.fromKeyCode(new KeyInput(GLFW.GLFW_KEY_B, 0, 0)));

	public FreelookMod() {
		super("mod.freelook.name", "mod.freelook.description", Icon._360, ModCategory.PLAYER);

		instance = this;
		active = false;
	}

	public final EventBus.EventListener<ClientTickEvent> onClientTick = event -> {

		if (toggleSetting.isEnabled()) {

			if (keybindSetting.isPressed()) {
				toggled = !toggled;

				if (toggled) {
					if (!active) {
						this.start();
					}
				} else {
					if (active) {
						this.stop();
					}
				}
			}
		} else {
			if (keybindSetting.isKeyDown()) {
				if (!active) {
					this.start();
				}
			} else if (active) {
				this.stop();
			}
		}
	};

	private void start() {

		String option = perspectiveSetting.getOption();
		Perspective perspective = option.equals("setting.front") ? Perspective.THIRD_PERSON_FRONT
				: Perspective.THIRD_PERSON_BACK;

		active = true;
		prevPerspective = client.options.getPerspective();
		client.options.setPerspective(perspective);
	}

	private void stop() {
		active = false;
		client.options.setPerspective(prevPerspective);
	}

	public static FreelookMod getInstance() {
		return instance;
	}

	public boolean isActive() {
		return active;
	}
}
