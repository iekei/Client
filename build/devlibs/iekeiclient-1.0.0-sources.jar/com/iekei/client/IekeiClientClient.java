package com.iekei.client;

import com.iekei.IekeiClient;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.client.KeyMapping.Category;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class IekeiClientClient implements ClientModInitializer {
	private static final KeyMapping OPEN_GUI = new KeyMapping(
			"key.iekeiclient.open_gui",
			GLFW.GLFW_KEY_RIGHT_SHIFT,
			Category.register(Identifier.fromNamespaceAndPath(IekeiClient.MOD_ID, "main"))
	);

	@Override
	public void onInitializeClient() {
		KeyBindingHelper.registerKeyBinding(OPEN_GUI);
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (OPEN_GUI.consumeClick()) {
				if (client.screen instanceof IekeiClientScreen) {
					client.setScreen(null);
				} else {
					client.setScreen(new IekeiClientScreen());
				}
			}
		});
	}
}
