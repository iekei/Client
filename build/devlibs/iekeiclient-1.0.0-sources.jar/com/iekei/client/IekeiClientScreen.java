package com.iekei.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class IekeiClientScreen extends Screen {
	private static final int PANEL_WIDTH = 650;
	private static final int PANEL_HEIGHT = 450;
	private static final int SIDEBAR_WIDTH = 70;
	private static final String[] PAGES = {"Home", "Modules", "Mirror", "Music", "Edit", "Settings"};
	private static final String[] ICONS = {"H", "M", "◇", "♫", "E", "⚙"};
	private static final int BACKGROUND = 0xFFF3F4F6;
	private static final int WHITE = 0xFFFFFFFF;
	private static final int TEXT = 0xFF333333;
	private static final int MUTED = 0xFF777777;
	private static final int BLUE = 0xFF3BB6FF;
	private int activePage;
	private int panelLeft;
	private int panelTop;
	private int panelWidth;
	private int panelHeight;

	public IekeiClientScreen() {
		super(Component.literal("IekeiClient"));
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		graphics.fill(0, 0, this.width, this.height, 0x88000000);
		panelWidth = Math.min(PANEL_WIDTH, this.width - 24);
		panelHeight = Math.min(PANEL_HEIGHT, this.height - 24);
		panelLeft = (this.width - panelWidth) / 2;
		panelTop = (this.height - panelHeight) / 2;

		graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + panelHeight, BACKGROUND);
		graphics.fill(panelLeft, panelTop, panelLeft + SIDEBAR_WIDTH, panelTop + panelHeight, WHITE);
		renderSidebar(graphics, mouseX, mouseY);

		if (activePage == 0) {
			renderHome(graphics);
		} else {
			renderPlaceholder(graphics);
		}
		super.render(graphics, mouseX, mouseY, delta);
	}

	private void renderSidebar(GuiGraphics graphics, int mouseX, int mouseY) {
		drawCentered(graphics, "≡", panelLeft + SIDEBAR_WIDTH / 2, panelTop + 29, MUTED);
		for (int i = 0; i < PAGES.length; i++) {
			int top = panelTop + 70 + i * 58;
			boolean selected = i == activePage;
			boolean hovered = contains(mouseX, mouseY, panelLeft + 13, top, 44, 44);
			if (selected || hovered) {
				graphics.fill(panelLeft + 13, top, panelLeft + 57, top + 44, selected ? BLUE : 0xFFF0F0F0);
			}
			drawCentered(graphics, ICONS[i], panelLeft + SIDEBAR_WIDTH / 2, top + 14, selected ? WHITE : MUTED);
			if (hovered) {
				drawText(graphics, PAGES[i], panelLeft + SIDEBAR_WIDTH + 8, top + 17, TEXT);
			}
		}
	}

	private void renderHome(GuiGraphics graphics) {
		int contentLeft = panelLeft + SIDEBAR_WIDTH + 30;
		int contentRight = panelLeft + panelWidth - 30;
		int contentWidth = contentRight - contentLeft;
		drawText(graphics, "Home", contentLeft, panelTop + 26, TEXT);

		int y = panelTop + 66;
		drawCard(graphics, contentLeft, y, contentWidth, 100);
		drawText(graphics, "Welcome to Iekei Client", contentLeft + 20, y + 20, TEXT);
		graphics.fill(contentLeft + 20, y + 50, contentLeft + 68, y + 98, 0xFFD8EFFF);
		drawCentered(graphics, "I", contentLeft + 44, y + 66, BLUE);
		drawText(graphics, playerName(), contentLeft + 82, y + 67, 0xFF555555);

		y += 115;
		drawCard(graphics, contentLeft, y, contentWidth, 114);
		renderUnavailableModule(graphics, contentLeft, y + 12, contentWidth, "KillAura");
		renderUnavailableModule(graphics, contentLeft, y + 48, contentWidth, "AutoArmor");
		renderUnavailableModule(graphics, contentLeft, y + 84, contentWidth, "Sprint");

		y += 129;
		drawCard(graphics, contentLeft, y, contentWidth, 76);
		graphics.fill(contentLeft, y, contentRight, y + 76, 0xFF72D7EA);
		drawText(graphics, "Join Our Discord", contentLeft + 20, y + 20, WHITE);
		drawText(graphics, "Community link is not configured.", contentLeft + 20, y + 43, WHITE);
	}

	private void renderUnavailableModule(GuiGraphics graphics, int left, int top, int width, String name) {
		drawText(graphics, name, left + 20, top + 9, 0xFF444444);
		int badgeWidth = 112;
		graphics.fill(left + width - badgeWidth - 16, top + 3, left + width - 16, top + 28, 0xFFF0F0F0);
		drawCentered(graphics, "Unavailable", left + width - badgeWidth / 2 - 16, top + 10, MUTED);
		if (!name.equals("Sprint")) {
			graphics.fill(left + 18, top + 35, left + width - 18, top + 36, 0xFFF0F0F0);
		}
	}

	private void renderPlaceholder(GuiGraphics graphics) {
		int contentLeft = panelLeft + SIDEBAR_WIDTH + 30;
		drawText(graphics, PAGES[activePage], contentLeft, panelTop + 26, TEXT);
		drawCard(graphics, contentLeft, panelTop + 66, panelLeft + panelWidth - 30 - contentLeft, 84);
		drawText(graphics, "This page is not available yet.", contentLeft + 20, panelTop + 96, MUTED);
	}

	private void drawCard(GuiGraphics graphics, int left, int top, int width, int height) {
		graphics.fill(left, top, left + width, top + height, WHITE);
	}

	private void drawText(GuiGraphics graphics, String text, int x, int y, int color) {
		graphics.drawString(this.font, text, x, y, color, false);
	}

	private void drawCentered(GuiGraphics graphics, String text, int centerX, int y, int color) {
		drawText(graphics, text, centerX - this.font.width(text) / 2, y, color);
	}

	private String playerName() {
		Minecraft minecraft = Minecraft.getInstance();
		return minecraft.getUser() == null ? "PlayerName" : minecraft.getUser().getName();
	}

	private boolean contains(double mouseX, double mouseY, int left, int top, int width, int height) {
		return mouseX >= left && mouseX < left + width && mouseY >= top && mouseY < top + height;
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() == 0) {
			for (int i = 0; i < PAGES.length; i++) {
				int top = panelTop + 70 + i * 58;
				if (contains(event.x(), event.y(), panelLeft + 13, top, 44, 44)) {
					activePage = i;
					return true;
				}
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
