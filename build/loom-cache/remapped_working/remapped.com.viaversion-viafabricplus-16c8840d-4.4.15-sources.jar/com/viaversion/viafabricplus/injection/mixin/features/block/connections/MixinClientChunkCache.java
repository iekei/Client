/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.injection.mixin.features.block.connections;

import com.viaversion.viafabricplus.features.block.connections.BlockConnectionsEmulation1_12_2;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.packet.s2c.play.BlockBreakingProgressS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockEventS2CPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class MixinClientChunkCache {

    @Shadow
    private ClientWorld level;

    @Inject(method = "updateLevelChunk", at = @At("TAIL"))
    private void updateBlockConnections(int chunkX, int chunkZ, ChunkData clientboundLevelChunkPacketData, CallbackInfo ci) {
        BlockConnectionsEmulation1_12_2.updateChunkNeighborConnections(this.level, chunkX, chunkZ);
    }

    @Inject(method = "handleBlockUpdate", at = @At("TAIL"))
    private void updateBlockConnections(BlockUpdateS2CPacket clientboundBlockUpdatePacket, CallbackInfo ci) {
        BlockConnectionsEmulation1_12_2.updateChunkNeighborConnections(this.level, clientboundBlockUpdatePacket.getPos());
    }

    @Inject(method = "handleBlockEvent", at = @At("TAIL"))
    private void updateBlockConnections(BlockEventS2CPacket clientboundBlockEventPacket, CallbackInfo ci) {
        BlockConnectionsEmulation1_12_2.updateChunkNeighborConnections(this.level, clientboundBlockEventPacket.getPos());
    }

    @Inject(method = "handleBlockDestruction", at = @At("TAIL"))
    private void updateBlockConnections(BlockBreakingProgressS2CPacket clientboundBlockDestructionPacket, CallbackInfo ci) {
        BlockConnectionsEmulation1_12_2.updateChunkNeighborConnections(this.level, clientboundBlockDestructionPacket.getPos());
    }

}
