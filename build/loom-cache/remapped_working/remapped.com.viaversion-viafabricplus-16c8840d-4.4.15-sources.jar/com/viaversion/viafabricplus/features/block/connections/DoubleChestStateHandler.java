/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.block.connections;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.enums.ChestType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;

public final class DoubleChestStateHandler implements IBlockStateHandler {

    @Override
    public BlockState connect(final BlockState blockState, final WorldView levelReader, final BlockPos blockPos) {
        if (!blockState.isOf(Blocks.ENDER_CHEST)) { // Ignore Ender-chests
            return blockState.with(ChestBlock.CHEST_TYPE, getChestType(blockState, levelReader, blockPos));
        } else {
            return blockState;
        }
    }

    private ChestType getChestType(final BlockState blockState, final BlockView blockGetter, final BlockPos blockPos) {
        final Direction facing = blockState.get(ChestBlock.FACING);
        for (final Direction direction : Direction.Type.HORIZONTAL) {
            final BlockState neighborState = blockGetter.getBlockState(blockPos.offset(direction));
            if (neighborState.isOf(blockState.getBlock()) && neighborState.get(ChestBlock.FACING).equals(facing)) {
                if (direction == facing.rotateYClockwise()) {
                    return ChestType.LEFT;
                } else if (direction == facing.rotateYCounterclockwise()) {
                    return ChestType.RIGHT;
                }
            }
        }

        return ChestType.SINGLE;
    }

}
