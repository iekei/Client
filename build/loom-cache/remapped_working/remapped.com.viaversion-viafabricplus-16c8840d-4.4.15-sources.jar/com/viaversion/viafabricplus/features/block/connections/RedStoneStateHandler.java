/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.block.connections;

import net.minecraft.block.BlockState;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.WorldView;

public final class RedStoneStateHandler implements IBlockStateHandler {

    @Override
    public BlockState connect(final BlockState blockState, final WorldView levelReader, final BlockPos blockPos) {
        final RedstoneWireBlock redStoneWireBlock = (RedstoneWireBlock) blockState.getBlock();
        return blockState.with(RedstoneWireBlock.WIRE_CONNECTION_WEST, redStoneWireBlock.getRenderConnectionType(levelReader, blockPos, Direction.WEST))
            .with(RedstoneWireBlock.WIRE_CONNECTION_EAST, redStoneWireBlock.getRenderConnectionType(levelReader, blockPos, Direction.EAST))
            .with(RedstoneWireBlock.WIRE_CONNECTION_NORTH, redStoneWireBlock.getRenderConnectionType(levelReader, blockPos, Direction.NORTH))
            .with(RedstoneWireBlock.WIRE_CONNECTION_SOUTH, redStoneWireBlock.getRenderConnectionType(levelReader, blockPos, Direction.SOUTH));
    }

}
