/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.block.connections;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ConnectingBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldView;

// Code sourced and adapted from 1.12.2 (Feather)
public final class PipeStateHandler implements IBlockStateHandler {

    @Override
    public BlockState connect(final BlockState blockState, final WorldView levelReader, final BlockPos blockPos) {
        final Block block = blockState.getBlock();
        final BlockState belowState = levelReader.getBlockState(blockPos.down());
        final BlockState aboveState = levelReader.getBlockState(blockPos.up());
        final BlockState northState = levelReader.getBlockState(blockPos.north());
        final BlockState eastState = levelReader.getBlockState(blockPos.east());
        final BlockState southState = levelReader.getBlockState(blockPos.south());
        final BlockState westState = levelReader.getBlockState(blockPos.west());
        return blockState.with(ConnectingBlock.DOWN, belowState.isOf(block) || belowState.isOf(Blocks.CHORUS_FLOWER) || belowState.isOf(Blocks.END_STONE))
            .with(ConnectingBlock.UP, aboveState.isOf(block) || aboveState.isOf(Blocks.CHORUS_FLOWER))
            .with(ConnectingBlock.NORTH, northState.isOf(block) || northState.isOf(Blocks.CHORUS_FLOWER))
            .with(ConnectingBlock.EAST, eastState.isOf(block) || eastState.isOf(Blocks.CHORUS_FLOWER))
            .with(ConnectingBlock.SOUTH, southState.isOf(block) || southState.isOf(Blocks.CHORUS_FLOWER))
            .with(ConnectingBlock.WEST, westState.isOf(block) || westState.isOf(Blocks.CHORUS_FLOWER));
    }

}
