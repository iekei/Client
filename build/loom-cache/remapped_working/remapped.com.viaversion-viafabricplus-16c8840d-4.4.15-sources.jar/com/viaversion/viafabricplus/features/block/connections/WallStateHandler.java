/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.block.connections;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.SlimeBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.WallBlock;
import net.minecraft.block.enums.WallShape;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;

public final class WallStateHandler implements IBlockStateHandler {

    @Override
    public BlockState connect(final BlockState blockState, final WorldView levelReader, final BlockPos blockPos) {
        final boolean north = connectsTo(levelReader, blockPos.north(), Direction.NORTH);
        final boolean south = connectsTo(levelReader, blockPos.south(), Direction.SOUTH);
        final boolean west = connectsTo(levelReader, blockPos.west(), Direction.WEST);
        final boolean east = connectsTo(levelReader, blockPos.east(), Direction.EAST);
        final boolean up = !(south && !west && north && !east || !south && west && !north && east) || !levelReader.getBlockState(blockPos.up()).isAir();
        return blockState
            .with(WallBlock.UP, up)
            .with(WallBlock.NORTH_WALL_SHAPE, getWallSide(north))
            .with(WallBlock.SOUTH_WALL_SHAPE, getWallSide(south))
            .with(WallBlock.WEST_WALL_SHAPE, getWallSide(west))
            .with(WallBlock.EAST_WALL_SHAPE, getWallSide(east));
    }

    // TODO: Fine-tune and make perfect/1:1
    private boolean connectsTo(final BlockView blockGetter, final BlockPos blockPos, final Direction direction) {
        final BlockState neighborState = blockGetter.getBlockState(blockPos);

        final Block block = neighborState.getBlock();
        if (block instanceof StairsBlock) {
            // TODO: Sometimes isn't right
            return neighborState.get(StairsBlock.FACING) == direction.getOpposite(); // Only connect to the backside of stairs
        }

        return !isExceptionForConnection(neighborState) && (block instanceof WallBlock || block instanceof FenceGateBlock || block instanceof SlimeBlock || neighborState.isOpaqueFullCube());
    }

    private WallShape getWallSide(final boolean value) {
        return value ? WallShape.LOW : WallShape.NONE;
    }

}
