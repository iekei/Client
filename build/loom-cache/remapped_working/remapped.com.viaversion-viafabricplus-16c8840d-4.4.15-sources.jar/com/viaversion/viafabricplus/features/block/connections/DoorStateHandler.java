/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.block.connections;

import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldView;

// TODO: Fix on place/powered (works fine/normal when joining or updating the block)
// Code sourced and adapted from 1.12.2 (Feather)
public final class DoorStateHandler implements IBlockStateHandler {

    @Override
    public BlockState connect(final BlockState blockState, final WorldView levelReader, final BlockPos blockPos) {
        final boolean lowerHalf = blockState.get(DoorBlock.HALF) == DoubleBlockHalf.LOWER;
        final BlockState halfState = levelReader.getBlockState(lowerHalf ? blockPos.up() : blockPos.down());
        if (!halfState.isOf(blockState.getBlock())) return blockState; // Not the same type of door, ignore

        if (lowerHalf) {
            return blockState
                .with(DoorBlock.HINGE, halfState.get(DoorBlock.HINGE))
                .with(DoorBlock.POWERED, halfState.get(DoorBlock.POWERED));
        } else {
            return blockState
                .with(DoorBlock.FACING, halfState.get(DoorBlock.FACING))
                .with(DoorBlock.OPEN, halfState.get(DoorBlock.OPEN));
        }
    }

}
