/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.block.connections;

import java.util.function.Predicate;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalConnectingBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;

// Handles [Fences, Iron Bars, Glass Panes]
public record CrossCollisionStateHandler(Predicate<BlockState> customAllowed) implements IBlockStateHandler {

    @Override
    public BlockState connect(final BlockState blockState, final WorldView levelReader, final BlockPos blockPos) {
        return blockState
            .with(HorizontalConnectingBlock.NORTH, connectsTo(levelReader, blockPos.north(), Direction.NORTH))
            .with(HorizontalConnectingBlock.SOUTH, connectsTo(levelReader, blockPos.south(), Direction.SOUTH))
            .with(HorizontalConnectingBlock.WEST, connectsTo(levelReader, blockPos.west(), Direction.WEST))
            .with(HorizontalConnectingBlock.EAST, connectsTo(levelReader, blockPos.east(), Direction.EAST));
    }

    private boolean connectsTo(final BlockView blockGetter, final BlockPos blockPos, final Direction direction) {
        final BlockState neighborState = blockGetter.getBlockState(blockPos);

        boolean bl = false;
        if (neighborState.isIn(BlockTags.STAIRS)) {
            // TODO: Sometimes isn't right
            bl = neighborState.get(StairsBlock.FACING) == direction.getOpposite(); // Only connect to the backside of stairs
        }

        return !isExceptionForConnection(neighborState) && (this.customAllowed.test(neighborState) || bl || neighborState.isOpaqueFullCube());
    }

}
