/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.block.connections;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.WorldView;

// Code sourced and adapted from 1.12.2 (Feather)
public final class FenceGateStateHandler implements IBlockStateHandler {

    @Override
    public BlockState connect(final BlockState blockState, final WorldView levelReader, final BlockPos blockPos) {
        final Direction.Axis axis = blockState.get(FenceGateBlock.FACING).getAxis();
        final BlockState westState = levelReader.getBlockState(blockPos.west());
        final BlockState eastState = levelReader.getBlockState(blockPos.east());
        final BlockState northState = levelReader.getBlockState(blockPos.north());
        final BlockState southState = levelReader.getBlockState(blockPos.south());
        if (axis == Direction.Axis.Z && (westState.isOf(Blocks.COBBLESTONE_WALL) || eastState.isOf(Blocks.COBBLESTONE_WALL))
            || axis == Direction.Axis.X && (northState.isOf(Blocks.COBBLESTONE_WALL) || southState.isOf(Blocks.COBBLESTONE_WALL))) {
            return blockState.with(FenceGateBlock.IN_WALL, true);
        } else {
            return blockState;
        }
    }

}
