/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.block.connections;

import com.viaversion.viafabricplus.protocoltranslator.ProtocolTranslator;
import com.viaversion.viafabricplus.settings.impl.GeneralSettings;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.ConnectingBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.FireBlock;
import net.minecraft.block.PaneBlock;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.block.SlimeBlock;
import net.minecraft.block.SnowyBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.WallBlock;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.world.WorldView;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.raphimc.viabedrock.api.BedrockProtocolVersion;
import org.jspecify.annotations.Nullable;

/**
 * TODO/FIX:
 * - visual artifacts (collision/hitbox is correct, but visually the connection is wrong)
 * - door block place/redstone issue (doors are fine when joining/after updating) -^ RELATED
 * - when stairs are facing a certain way, sometimes fences wont connect to them for some reason (CORNER STAIRS?)
 * - possible inaccuracies missed
 * Nitpicks:
 * - wish it was as instant visually like in older or equal 1.12.2, there is a noticeable delay before blocks connect when placed (not on join)
 *   - Probably due to the update logic being handled in packet-related stuff instead of something native
 */
public final class BlockConnectionsEmulation1_12_2 {

    private static final int UPDATE_FLAGS = 18;
    private static final Object2ObjectOpenHashMap<Class<? extends Block>, IBlockStateHandler> connectionHandlers = new Object2ObjectOpenHashMap<>();
    private static final Object2ObjectOpenHashMap<Class<? extends Block>, IBlockStateHandler> lookupCache = new Object2ObjectOpenHashMap<>();

    public static void init() {
        connectionHandlers.put(DoorBlock.class, new DoorStateHandler());
        connectionHandlers.put(ChestBlock.class, new DoubleChestStateHandler());
        connectionHandlers.put(FenceGateBlock.class, new FenceGateStateHandler());
        connectionHandlers.put(FenceBlock.class, new CrossCollisionStateHandler(state -> state.isIn(BlockTags.FENCES) || state.isIn(BlockTags.FENCE_GATES) || state.getBlock() instanceof SlimeBlock));
        connectionHandlers.put(FireBlock.class, new FireStateHandler());
        connectionHandlers.put(PaneBlock.class, new CrossCollisionStateHandler(state -> state.getBlock() instanceof PaneBlock));
        connectionHandlers.put(ConnectingBlock.class, new PipeStateHandler());
        connectionHandlers.put(RepeaterBlock.class, new RedStoneRepeaterStateHandler());
        connectionHandlers.put(RedstoneWireBlock.class, new RedStoneStateHandler());
        connectionHandlers.put(SnowyBlock.class, new SnowyGrassStateHandler());
        connectionHandlers.put(StairsBlock.class, new StairsStateHandler());
        connectionHandlers.put(WallBlock.class, new WallStateHandler());
    }

    public static void updateChunkConnections(final WorldView levelReader, final int chunkX, final int chunkZ) {
        if (!isApplicable() || !levelReader.isChunkLoaded(chunkX, chunkZ)) {
            return;
        }

        final Chunk chunkAccess = levelReader.getChunk(chunkX, chunkZ);
        final BlockPos.Mutable blockPos = new BlockPos.Mutable();
        for (int sectionY = chunkAccess.getBottomSectionCoord(); sectionY < chunkAccess.getTopSectionCoord(); sectionY++) {
            final ChunkSection section = chunkAccess.getSection(chunkAccess.sectionCoordToIndex(sectionY));
            if (section.isEmpty()) {
                continue;
            }

            final int baseY = ChunkSectionPos.getBlockCoord(sectionY);
            for (int x = -1; x <= 16; ++x) {
                final boolean insideX = x >= 0 && x < 16;
                for (int y = baseY; y < baseY + 16; y++) {
                    for (int z = -1; z <= 16; ++z) {
                        blockPos.set(ChunkSectionPos.getBlockCoord(chunkX) + x, y, ChunkSectionPos.getBlockCoord(chunkZ) + z);
                        if (!levelReader.isChunkLoaded(ChunkSectionPos.getSectionCoord(blockPos.getX()), ChunkSectionPos.getSectionCoord(blockPos.getZ()))) {
                            continue;
                        }

                        final BlockState blockState = levelReader.getBlockState(blockPos);
                        if (blockState.isAir()) {
                            continue;
                        }

                        final IBlockStateHandler connectionHandler = getConnectionHandler(blockState.getBlock().getClass());
                        if (connectionHandler == null) {
                            continue;
                        }

                        final BlockState newState = connectionHandler.connect(blockState, levelReader, blockPos);
                        if (newState != blockState && insideX && z >= 0 && z < 16) {
                            chunkAccess.setBlockState(blockPos, newState, UPDATE_FLAGS);
                        }
                    }
                }
            }
        }
    }

    public static void updateChunkNeighborConnections(final WorldView levelReader, final int chunkX, final int chunkZ) {
        updateChunkConnections(levelReader, chunkX, chunkZ);
        updateChunkConnections(levelReader, chunkX + 1, chunkZ);
        updateChunkConnections(levelReader, chunkX - 1, chunkZ);
        updateChunkConnections(levelReader, chunkX, chunkZ + 1);
        updateChunkConnections(levelReader, chunkX, chunkZ - 1);
    }

    public static void updateChunkNeighborConnections(final WorldView levelReader, final BlockPos blockPos) {
        updateChunkNeighborConnections(levelReader, ChunkSectionPos.getSectionCoord(blockPos.getX()), ChunkSectionPos.getSectionCoord(blockPos.getZ()));
    }

    private static @Nullable IBlockStateHandler getConnectionHandler(final Class<? extends Block> blockClass) {
        return lookupCache.computeIfAbsent(blockClass, clazz -> {
            Class<?> current = (Class<?>) clazz;
            while (current != Block.class && current != null) {
                final IBlockStateHandler handler = connectionHandlers.get(current);
                if (handler != null) {
                    return handler;
                }

                current = current.getSuperclass();
            }

            return null;
        });
    }

    private static boolean isApplicable() {
        if (GeneralSettings.INSTANCE.experimentalBlockConnections.getValue()) {
            return ProtocolTranslator.getTargetVersion().olderThanOrEqualTo(ProtocolVersion.v1_12_2) || ProtocolTranslator.getTargetVersion().equals(BedrockProtocolVersion.bedrockLatest);
        } else {
            return false;
        }
    }

}
