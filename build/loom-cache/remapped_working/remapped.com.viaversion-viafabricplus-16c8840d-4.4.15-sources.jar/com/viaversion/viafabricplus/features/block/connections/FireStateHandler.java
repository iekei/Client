/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.block.connections;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FireBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldView;

// Code sourced and adapted from 1.12.2 (Feather)
public final class FireStateHandler implements IBlockStateHandler {

    @Override
    public BlockState connect(final BlockState blockState, final WorldView levelReader, final BlockPos blockPos) {
        // TODO: Double check is `isSolidRender` is the same as `isFullBlock`
        final boolean canBurn = !levelReader.getBlockState(blockPos.down()).isOpaqueFullCube() && !((FireBlock) Blocks.FIRE).isFlammable(levelReader.getBlockState(blockPos.down()));
        if (canBurn) {
            final FireBlock fireBlock = (FireBlock) blockState.getBlock();
            return blockState.with(FireBlock.NORTH, fireBlock.isFlammable(levelReader.getBlockState(blockPos.north())))
                .with(FireBlock.EAST, fireBlock.isFlammable(levelReader.getBlockState(blockPos.east())))
                .with(FireBlock.SOUTH, fireBlock.isFlammable(levelReader.getBlockState(blockPos.south())))
                .with(FireBlock.WEST, fireBlock.isFlammable(levelReader.getBlockState(blockPos.west())))
                .with(FireBlock.UP, fireBlock.isFlammable(levelReader.getBlockState(blockPos.up())));
        }

        return blockState;
    }

}
